/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nttdata.framework.exceptions;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LowLevelException extends RuntimeException {
	private final static Logger LOGGER = Logger.getLogger(LowLevelException.class.getName());

	public LowLevelException(String exceptionMsg) {
		// Here we will be writing the result to the Database using API Call when the
		// failure has been occured along with sMessage which passed from the low level
		// class.
		super(exceptionMsg);
		LOGGER.log(Level.SEVERE, exceptionMsg);

	}

	public LowLevelException(Exception ex) {
		super(ex.getMessage());
		LOGGER.log(Level.SEVERE, "Low Level Exception has been occured" + ex.getMessage());
	}

}
