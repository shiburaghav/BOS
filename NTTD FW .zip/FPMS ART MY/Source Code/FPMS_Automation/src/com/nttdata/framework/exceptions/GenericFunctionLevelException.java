package com.nttdata.framework.exceptions;


public class GenericFunctionLevelException extends Exception
{
	public GenericFunctionLevelException(Exception ex) throws Exception
	{
		super(ex.getMessage());
	}
}
