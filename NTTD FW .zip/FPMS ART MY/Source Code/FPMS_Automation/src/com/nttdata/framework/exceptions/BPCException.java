package com.nttdata.framework.exceptions;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.nttdata.common.util.RunStatus;
import com.nttdata.core.backend.DashboardProperties;

public class BPCException extends RuntimeException {
	private final static Logger LOGGER = Logger.getLogger(BPCException.class.getName());

	public BPCException(String exceptionMsg) throws Exception
	{
		super(exceptionMsg);
		LOGGER.log(Level.SEVERE, "BPC Level Exception has been occured" + exceptionMsg);
		DashboardProperties.gBPCStatus = RunStatus.FAIL.value;
		
	}
	public BPCException(Exception ex)
	{
		super(ex);
		LOGGER.log(Level.SEVERE, "BPC Level Exception has been occured" + ex.getMessage());
		DashboardProperties.gBPCStatus = RunStatus.FAIL.value;
	}
}
