package com.nttdata.app;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Properties;

import com.nttdata.framework.exceptions.BPCException;


public abstract class ARTProperties {

	// private static ARTProperties obj;


	private static Properties prop;

	private final String GUIMAP = "GuiMap.xls";
	private final String TEST_DATA = "TestData.xlsm";
	private final String TEST_PLAN = "TestPlan.xlsx";
	private final String COMMON_GUIMAP = "CommonGuiMap.xls";
	private final String API_MAPPING = "API_Mapping.xlsx";
	private final String COMMON_TEST_DATA = "CommonTestData.xlsx";
	protected String FOLDER_DELIMITER = "";
	private final String FILENAME_DELIMITER = "_";
	private final String CONFIGURATION_FOLDER ="configs";
	private final String GUIMAP_FOLDER ="Guimap";
	private final String TESTDATA_FOLDER ="Testdata";
	private final String TESTPLAN_FOLDER ="Testplan";

	private static String ART_INSTALL_PATH;
	private static String ART_PROJECT_PATH;
	private static final String RESOURCE_FOLDER = "resources";
	private static final String TEMPLATE_FOLDER = "templates";
	

	// TODO: to be removed when new design implemented
	public static Hashtable<String, Hashtable<String, String>> guiMap = new Hashtable<String, Hashtable<String, String>>();

	public ARTProperties() {
		prop = new Properties();
		initialize();
		FOLDER_DELIMITER = File.separator;
		setArtFPMSInstallPath();
		setProjectLocation();
		
	}

	private void initialize() {

		FileInputStream input;
		try {
			input = new FileInputStream("build.properties");
			prop.load(input);
		} catch (FileNotFoundException e) {
			throw new BPCException(e);
		} catch (IOException e) {
			throw new BPCException(e);
		}
	}

	public String getProperty(String key) {
		return prop.getProperty(key);
	}
	/**
	 * getFPMSLocation - method to get FPMS installed location based on the projectName
	 * @return
	 */
	public String getProjectLocation() {
		return ART_PROJECT_PATH;
	}
	
	public String setProjectLocation() {
		String projectFolderPath[] = new String[]{ART_INSTALL_PATH,FOLDER_DELIMITER,
				getProperty("projectName")};
		ART_PROJECT_PATH = pathToJoin(projectFolderPath).toString();
		return ART_PROJECT_PATH;
	}

	public String getGUIMapLocation(String moduleName) {
		String guiMapFileLoc[] = new String[]{getConfigurationLocation(),FOLDER_DELIMITER,
				GUIMAP_FOLDER, FOLDER_DELIMITER ,moduleName, FILENAME_DELIMITER , GUIMAP};
		return pathToJoin(guiMapFileLoc).toString();
		
	}
	
	public String getTestDataFilePath(String moduleName) {
		String testDataFileLoc[] = new String[]{ getTestDataFolderPath(moduleName),FOLDER_DELIMITER,
				moduleName,FILENAME_DELIMITER,TEST_DATA};
		return pathToJoin(testDataFileLoc).toString();
		
	}
	public String getTestDataFolderPath(String moduleName) {
		String testDataFolderLoc[] = new String[]{getResourceLocation(),FOLDER_DELIMITER,
				TESTDATA_FOLDER,FOLDER_DELIMITER,moduleName};
		return pathToJoin(testDataFolderLoc).toString();
	}

	public String getTestPlanLocation() {
		String testPlanLoc[]= new String[]{getResourceLocation(),FOLDER_DELIMITER,TESTPLAN_FOLDER,
				FOLDER_DELIMITER,TEST_PLAN} ;
		return pathToJoin(testPlanLoc).toString() ;
	}

	public String getAPIMapLocation() {
		String apiMapLoc[]= new String[]{getConfigurationLocation(), FOLDER_DELIMITER,API_MAPPING};
		return pathToJoin(apiMapLoc).toString();
	}

	public String getCommonGUIMapLocation() {
		String commonGuiMapLoc[] = new String[] {getConfigurationLocation(),FOLDER_DELIMITER,
				GUIMAP_FOLDER,FOLDER_DELIMITER,COMMON_GUIMAP};
		return pathToJoin(commonGuiMapLoc).toString();
	}
	public String getCommonTestDataLocation() {
		
		String commonTestDataLoc[] = new String[] {getResourceLocation(),FOLDER_DELIMITER,
				TESTDATA_FOLDER,FOLDER_DELIMITER,COMMON_TEST_DATA} ;
		return pathToJoin(commonTestDataLoc).toString();
	}
	
	
    public String getConfigurationLocation() {
		String configLoc[] = new String[]{ART_PROJECT_PATH, FOLDER_DELIMITER, CONFIGURATION_FOLDER} ;
		return pathToJoin(configLoc).toString() ;
		
	}
    public String getResourceLocation() {
		String resLoc [] = new String[]{ART_PROJECT_PATH, FOLDER_DELIMITER, RESOURCE_FOLDER};
		return  pathToJoin(resLoc).toString();
		
	}
    public String getTemplatesLocation() {
    	String templatesLoc[] = new String[]{ART_PROJECT_PATH, FOLDER_DELIMITER, TEMPLATE_FOLDER};
		return pathToJoin(templatesLoc).toString();
	}
    private void setArtFPMSInstallPath(){
    	String homeDir = System.getProperty("user.home");
		String artFpmsDir = homeDir + "\\AppData\\Local\\ART_FPMS";
		File artFpmsProperties = new File(artFpmsDir + "\\art.properties");
		
		Properties prop = new Properties();
		InputStream in = null;
		String path="";
		try {
			in = new FileInputStream(artFpmsProperties);

			prop.load(in);
			path = prop.getProperty("art.fpms.install.path");
			ART_INSTALL_PATH = path;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	/**
	 * pathToJoin - joins the array of strings 
	 * @param elements - to joins
	 * @return - a string of combined text
	 */
	public String pathToJoin(String[] elements) {

		StringBuilder builder = new StringBuilder();

		for (String element : elements) {
			builder.append(element);
		}

		return builder.toString();

	}
	
	public abstract String getDriverPath();
}
