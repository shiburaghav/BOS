package com.nttdata.app;

import io.github.lukehutch.fastclasspathscanner.FastClasspathScanner;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;
import com.nttdata.common.util.ColumnHeader;
import com.nttdata.common.util.ExcelUtility;
import com.nttdata.common.util.RunStatus;
import com.nttdata.common.util.Utils;
import com.nttdata.common.util.WindowsUtility;
import com.nttdata.core.LL_Actions;
import com.nttdata.core.TestCase;
import com.nttdata.core.backend.APIHandler;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.core.handler.TestCaseHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.FPMSARTDao;
import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.bpc.common.FPMSFileProcessor;

public abstract class ARTDriver {
	private String executionStatus;
	private DataHandler dataHandler;
	private ARTProperties properties;
	private LL_Actions llAction;
	private DashboardHandler dashboard;
	private TestCaseHandler testHandler;
	private final static Logger LOGGER = Logger.getLogger(ARTDriver.class.getName());

	public ARTDriver() {
		dataHandler = new DataHandler();
		dashboard = DashboardHandler.getInstance();
		llAction = new LL_Actions();
		testHandler = TestCaseHandler.getInstance();
	}

	public abstract void preExecution();

	public void execute(ARTProperties prop) {
		try {

			this.properties = prop;

			// Loading the Configuration settings from Excel
			dataHandler.qaLoadToHashTable(properties.getTestPlanLocation(), "Settings", "Setting", "Value", true);
//Temporary fix to handle cross module execution--Need to be reviewed

			dataHandler.qaLoadGUIMap(properties.getCommonGUIMapLocation(), "ObjectRepository");
			String[] guis = new String[] {"NBU","CSD","Claims","BCPOnline","BCPBatch","Finance"}; 
			for(String gui : guis) {
				dataHandler.qaLoadGUIMap(properties.getGUIMapLocation( gui), "ObjectRepository");
			}

			DashboardProperties.gRunID = APIHandler.checkIfRunExists();
			
			runAllTestCases();
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE, "Error has been thrown by ARTDriver :" + ex.getMessage());

		}
	}

	public abstract void postExecution();

	public void runAllTestCases() {
		long startTime;
		try {
			String loginQuery = "select TCID,TestScenarioName,TestCaseName from Login where  ExecuteTC='Yes'";
			String querySheetRange = String.valueOf(ColumnHeader.Login.getColumnHeader());

			Recordset testCaseRecordSet = ExcelUtility.queryExcel(properties.getTestDataFilePath( System.getProperty("Settings.Module")), loginQuery,
					querySheetRange);
			
			while (testCaseRecordSet.next()) {
				String testScenarioName = testCaseRecordSet.getField("TestScenarioName").trim();
				String testCaseId = testCaseRecordSet.getField("TCID").trim();
				String testCasename = Utils.formatString(testCaseRecordSet.getField("TestCaseName"));

				// Get the TCInstance from testPlan
				try {

					String testPlanQuery = "select * from " +  System.getProperty("Settings.Module");
					Recordset testPlanRecordSet = ExcelUtility.queryExcel(properties.getTestPlanLocation(),
							testPlanQuery);

					List<String> a = testPlanRecordSet.getFieldNames();

					if (a.contains("SubScenario")) {
						testPlanRecordSet = testPlanRecordSet.where("Run='Yes'")
								.where("SubScenario='" + testScenarioName + "'");
					} else {

						testPlanRecordSet = testPlanRecordSet.where("Run='Yes'")
								.where("TestScenario='" + testScenarioName + "'");
					}

					testPlanRecordSet.next();
					String currentTCInstance = testPlanRecordSet.getField("TCInstance");
					String testScenario = testPlanRecordSet.getField("TestScenario");
					// get all business components
					String[][] allBCforTC = getAllBusinesComponents(properties.getTestPlanLocation(),
							currentTCInstance, System.getProperty("Settings.Module"));

					DashboardProperties.gBPCStatus = 4;
					APIHandler.insertIntoTestSuite(DashboardProperties.gRunID, testScenario,
							RunStatus.INPROGRESS.value);

					System.out.println(testCaseId);
					testHandler.setTestCase(new TestCase(testCaseId, testScenario, testCasename));
					dashboard.initSteps(testHandler.getTestCase());					
					executeEachTestcase(testHandler.getTestCase(), allBCforTC);
					endTestCase(testHandler.getTestCase());
				} catch (FilloException ex) {
					LOGGER.log(Level.SEVERE,
							"Exception occured while parsing resource files (Testdata or TestPlan). Query failed to execute."
									+ ex.getMessage());
					ex.printStackTrace();
				} catch (Throwable ex) {

					try {
						APIHandler.updateTestComponent(DashboardProperties.gComponentID,
								DashboardProperties.gComponentName, RunStatus.FAIL.value);
						APIHandler.updateTestCase(DashboardProperties.gTestCasesInstanceID, testCasename,
								RunStatus.FAIL.value,"");
					} catch (Exception e) {
					} finally {
						Utils.sleep(3);
						LOGGER.log(Level.SEVERE, "BPC Level Exception has been occured" + ex.getMessage());
						dashboard.writeErrorMessage(ex.getMessage());
						ex.printStackTrace();
						dashboard.reset();
						llAction.quitApplication();
					}
				} 

			}
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE,
					String.format("Failed to load the TestData from location  %s", properties.getTestDataFilePath( System.getProperty("Settings.Module"))));
			LOGGER.log(Level.SEVERE, "Please Refer the Exception is " + ex.getMessage());
		}

	}

	private String[][] getAllBusinesComponents(String testPlanPath, String currentTCInstance, String moduleName) {

		String[][] bcArray = null;
		try {

			String bcQuery = "select BusinessComponents,TestDataSheetName,TestData_Reference from " + moduleName + " where TCInstance = "
					+ currentTCInstance + " and Run = 'yes'";
			Recordset bpcRecordset = ExcelUtility.queryExcel(testPlanPath, bcQuery, String.valueOf("1"));

			bcArray = new String[bpcRecordset.getCount()][2];
			int count = 0;
			while (bpcRecordset.next()) {
				bcArray[count][0] = bpcRecordset.getField("BusinessComponents");
				bcArray[count][1] = bpcRecordset.getField("TestDataSheetName");
				count++;
			}

		}

		catch (Exception ex) {
			LOGGER.log(Level.SEVERE, String.format("Failed to load the BPC from from location %s", testPlanPath));
			LOGGER.log(Level.SEVERE, "Please Refer the Excpetion is " + ex.getMessage());
		}
		return bcArray;
	}

	private void executeEachTestcase(TestCase testCase, String[][] allBCforTC)
			throws Throwable {
		// Handle Multiscenario cases	
		long startTime = System.currentTimeMillis(); 
		
		String testCaseID = testCase.getId().replaceAll("[^A-Za-z0-9]", "").toUpperCase();
		APIHandler.insertIntoTestCase(testCaseID,DashboardProperties.gTestSuiteID,
				testCase.getName(), RunStatus.INPROGRESS.value); 
		System.out.println("Test Case ID " + testCase.getId());

		for (int i = 0; i < allBCforTC.length; i++) {

			String testDataSheetRef = allBCforTC[i][1];
			String bpcName = allBCforTC[i][0]; // the business component name
			DashboardProperties.gComponentName = bpcName;
			int excelTDRange = ColumnHeader.getColumnHeader(testDataSheetRef);

			APIHandler.insertIntoTestComponents(
					DashboardProperties.gTestCasesInstanceID,
					DashboardProperties.gComponentName,
					RunStatus.INPROGRESS.value); // Insert module/Product Name
													// into the test Suite

			
			Hashtable<String, String> paramForBC = new Hashtable<>();
			
			/********************************************************************/
			
			paramForBC = dataHandler.getTestData(testDataSheetRef,
					properties.getTestDataFilePath(System.getProperty("Settings.Module")), excelTDRange,
					testCase.getId()); // Code Review need to surround a catch
			
			/********************************************************************/
			
			executeIndividualBusinessComponent(bpcName.replace(" ", "_"),
					paramForBC);
			APIHandler.updateTestComponent(DashboardProperties.gComponentID,
					DashboardProperties.gComponentName, RunStatus.PASS.value);
		}
		long endTime = System.currentTimeMillis();
		String duration = getExecutionTime(startTime, endTime);
		APIHandler.updateTestCase(DashboardProperties.gTestCasesInstanceID,
				testCase.getName(), RunStatus.PASS.value , duration);

	}

	private void executeIndividualBusinessComponent(String bpcName, Hashtable<String, String> hsTable)
			throws Throwable {

		// String SYNERGE_BPC_PACKAGE_NAME = "ge.fpms.my.bpc"; //Shibu Review
		// comment - this cant be hard coded

		boolean methodFound = false;

		try {
			List<String> classNames = new FastClasspathScanner(properties.getProperty("fpms.bc.path")).scan()
					.getNamesOfAllClasses();

			for (String className : classNames) {
				if (methodFound)
					break;

				Class<?> classDetails = Class.forName(className);

				Method[] methods = classDetails.getMethods();

				for (Method method : methods) {

					if (bpcName.toLowerCase().equalsIgnoreCase(method.getName().toLowerCase())) {

						WindowsUtility.keepSystemActive();
						Class<?> bpcClass = Class.forName(className); // convert
																		// string
																		// classname
																		// to
																		// class
						Object dog = bpcClass.newInstance(); // invoke empty
																// constructor
						Method setNameMethod = dog.getClass().getMethod(method.getName(), Hashtable.class);
						setNameMethod.invoke(dog, hsTable); // Invoking BPC

						/*
						 * Fail the test case if the method passed from the test plan is not available
						 * Fail the tC if the GlobalVariables.giBPCStatus is 1 update the bsuiness
						 * component status as per the satus of teh business component executed Note
						 * when the BC fails this loop should exit and fo back to test case Once all the
						 * BC is completed (all passed ) then also go back to TC
						 */
						WindowsUtility.keepSystemActive();
						methodFound = true;
						break;

					}
				}

			}

			if (!methodFound) {
				LOGGER.log(Level.SEVERE, "Business Process " + bpcName
						+ " Mentioned in test plan doesnt found in .java file \n Please correct the test Plan");
				throw new BPCException(new Exception("Unable to find BPC implementation " + bpcName));
			}
		} catch (BPCException ex) {
			System.out.println("Error has been occured while invoking the method in the Execute BPC class");
			/*
			 * throw new BPCException("Script Error occurred for component " + bpcName +
			 * ".Please check with the automation team.");
			 */
			throw ex;
		} catch (InvocationTargetException  ex) {
			System.out.println("Error has been occured while invoking the method in the Execute BPC class");
			/*
			 * throw new BPCException("Script Error occurred for component " + bpcName +
			 * ".Please check with the automation team.");
			 */
			throw ex.getTargetException();
		}
	}

	public void endTestCase(TestCase testCase) throws Exception {

		PolicyHandler policyHandler = FPMSManager.getInstance().getPolicyHandler();
		try {
			FPMSARTDao artDao = new FPMSARTDao(testCase, policyHandler.getPolicy());
			policyHandler.addPolicytoList(artDao);
			FPMSFileProcessor fpmsFileProcessor = new FPMSFileProcessor();
			fpmsFileProcessor.persistCSDInfo();

		} catch (Exception e) {

			throw new Exception(e);
		}

	}

	private String getExecutionTime(long startTime, long endTime) {
		long time_ms = endTime - startTime;
		long time_sec = TimeUnit.MILLISECONDS.toSeconds(time_ms);
		long time_min = TimeUnit.MILLISECONDS.toMinutes(time_ms);

		String duration = String.valueOf(time_min) + " min" + String.valueOf(time_sec % 60) + " sec";
		return duration;

	}
	public String getExecutionStatus() {
		return executionStatus;
	}

	public void setExecutionStatus(String executionStatus) {
		this.executionStatus = executionStatus;
	}

}
