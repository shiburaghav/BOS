package com.nttdata.core;

/*code reveiw comment s\
 * 1. implement the coding standards
 * 2. Update global variable for the low level action to pass /fail or warning
 */

import java.io.File;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.AuthenticationException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.components.table.TableColumn;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.LowLevelException;

public class LL_Actions {

	enum Drivers {
		IE, firefox, chrome, safari
	}

	enum Actions {
		set, getText, click, submit, getAttribute, getCssValue, moveToElement
	}

	private final static Logger LOGGER = Logger.getLogger(LL_Actions.class.getName());
	Actions action = null;
	protected static WebDriver driver = null;
	private static String parent;
	private DashboardHandler dashboard;

	public LL_Actions() {
		dashboard = DashboardHandler.getInstance();
	}

	public static WebDriver getDriver(String sDriver, String driverPath) throws Exception {
		try {
			Drivers sdriver = null;
			sdriver = Drivers.valueOf(sDriver);
			String currentProjectPath = System.getProperty("user.dir");
			File file;
			switch (sdriver) {
			case IE:
				file = new File(driverPath);
				// file = new File("D:\\resource\\IEDriverServer.exe");
				if (!file.exists())
					LOGGER.log(Level.SEVERE, "IEDriverServer file ");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());

				InternetExplorerOptions options = new InternetExplorerOptions();
				options.takeFullPageScreenshot();
				options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.IGNORE);
				driver = new InternetExplorerDriver(options);
				break;
			case firefox:
				Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
				Utils.sleep(1);
				file = new File(currentProjectPath + "\\resources\\geckodriver.exe");
				if (!file.exists())
					LOGGER.log(Level.SEVERE, "geckodriver file ");
				// This section should be added for WebDriver version 3 or
				// upper.
				// System.setProperty("webdriver.gecko.driver",
				// file.getAbsolutePath());

				// ProfilesIni profile = new ProfilesIni(); // This has to be
				// removed while
				// building jar.
				// FirefoxProfile myprofile = profile.getProfile("default");
				try {
					driver = new FirefoxDriver();
				} catch (UnhandledAlertException ex) {
					Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
					driver = new FirefoxDriver();
				}
				// tempdriver=new FirefoxDriver();
				break;
			case chrome:
				file = new File(currentProjectPath + "\\resources\\chromedriver.exe");
				if (!file.exists())
					LOGGER.log(Level.SEVERE, "chromedriver file ");
				System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
				driver = new ChromeDriver();
				break;
			case safari:
				LOGGER.log(Level.SEVERE, "Its discontinued ");
				driver = new SafariDriver();
				break;
			}
			if (((RemoteWebDriver) driver).getSessionId() == null) {
				throw new LowLevelException("Unable to open the browser ");
			}
			return driver;
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE, "Error in GetDriver " + ex.getMessage());

			throw new LowLevelException("Failed to Launch the brower " + ex.getMessage());
		}

	}

	public void setImplicitTime(int time) throws Exception {
		if (((RemoteWebDriver) driver).getSessionId() != null) {
			//WebDriver driver = LL_Actions.driver;
			driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
		}
	}

	public void openApplication(String browerName, String strURL, String driverPath) throws Exception {
		try {

			dashboard.setStepDetails("Launch Browser", "User should be navigated to FPMS login page", strURL);
			if (driver == null || ((RemoteWebDriver) driver).getSessionId() == null) {

				driver = getDriver(browerName, driverPath);
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(Long.parseLong(System.getProperty("Settings.ImplicitWait")),
						TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(
						Long.parseLong(System.getProperty("Settings.Window Wait Time")), TimeUnit.SECONDS);
				driver.navigate().to(strURL);
				driver.get("javascript:document.getElementById('overridelink').click();");
				driver.get("javascript:document.getElementById('overridelink').click();");
				// check if the the FPMS aplicatiion is availbe
				// check if the FPMS is on the anding page / esle bring this to landing page ,
				// if not success kill the driver and launch again
			} else {
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(Long.parseLong(System.getProperty("Settings.ImplicitWait")),
						TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(
						Long.parseLong(System.getProperty("Settings.Window Wait Time")), TimeUnit.SECONDS);
				driver.navigate().to(strURL);
			}
		} catch (Exception ex) {
			throw new LowLevelException("Failed to Navigate to the page " + strURL);
		}

	}

	public void closeApplication() throws Exception {
		dashboard.setStepDetails("Close FPMS Sub Window", "FPMS sub window should be closed", "N/A");
		try {
			if (driver.equals(null))
				throw new LowLevelException("Failed to close the brower");
			driver.close();
		} catch (Exception ex) {
			throw new LowLevelException("Failed to close the application ");
		}
	}

	public void quitApplication() throws Exception {
		dashboard.setStepDetails("Quit FPMS Application", "FPMS Application should be closed", "N/A");
		try {
			if (driver.equals(null)) {
				throw new LowLevelException("Failed to quit the browser");
			} else {
			}
		} catch (Exception ex) {
			throw new LowLevelException("Failed to quit the application ");
		} finally {
			driver.quit();
		}
	}

	public void sendkeyStroke(String webElementKey, Keys key) throws Exception {
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);

		dashboard.setStepDetails("Entering The KeyStrokes:'" + key + "'",
				"Key Stroke '" + key + "' should be entered in field: " + webElementKey + "", "N/A");
		try {
			WebElement element = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));

			element.sendKeys(key);

		} catch (ElementNotVisibleException ex) {

			throw new LowLevelException(
					String.format("Element= %s is not visible to Enter value =%s ", webElementKey, key.toString()));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(String.format(
					"Element was not clickable as the page reloaded before the actual the Enter value =%s has been occured ",
					webElementKey, key.toString()));
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual Enter value =%s happend on Element %s",
					webElementKey, key.toString()));
		} catch (WebDriverException ex) {
			throw new LowLevelException(String.format(
					"Current browser is closed or Terminated before the actual value enter =%s occured for Element =%s",
					webElementKey, key.toString()));
		}

		catch (Exception ex) {
			driver.quit();
			throw new LowLevelException(String.format(
					"General Exception has been occured while entering the value %s on Element %s \n Please refer the Exception details %s",
					key.toString(), webElementKey, ex.getMessage()));
		}
	}

	public void enterValue(String webElementKey, String value) throws Exception {
		if (value != null && !value.isEmpty()) {
			try {

				/*
				 * dashboard.setStepDetails("Enter Value", "Value: " + value +
				 * " should be Entered to the text field: " + webElementKey, webElementKey);
				 */
				// dashboard.setStepDetails("Enter");
				Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);

				WebElement element = new ObjectIdentifier(driver).FindObject(
						hTableGUIMap.keySet().toArray()[0].toString(),
						hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));

				if (element.isDisplayed() && element.isEnabled()) {
					element.clear();
					element.sendKeys(value);
				}

			} catch (ElementNotVisibleException ex) {

				throw new LowLevelException(
						String.format("Element= %s is not visible to Enter value =%s ", webElementKey, value));
			} catch (StaleElementReferenceException ex) {
				throw new LowLevelException(String.format(
						"Element was not clickable as the page reloaded before the actual the Enter value =%s has been occured ",
						webElementKey, value));
			}

			catch (UnexpectedTagNameException ex) {
				throw new LowLevelException(String.format(
						"Unexpected tag name error has been found before the actual Enter value =%s happend on Element %s",
						webElementKey, value));
			} catch (WebDriverException ex) {
				throw new LowLevelException(String.format(
						"Current browser is closed or Terminated before the actual value enter =%s occured for Element =%s",
						webElementKey, value));
			}

			catch (Exception ex) {

				throw new LowLevelException(String.format(
						"  General Exception  has been occured while entering the value %s on Element %s \n Please refer the Exception details %s",
						value, webElementKey, ex.getMessage()));
			}
		}
	}

	public void enterValueWithoutClear(String webElementKey, String value) throws Exception {
		dashboard.setStepDetails("Enter Value",
				"Value: " + value + " should be Entered to the text field: " + webElementKey, webElementKey);
		// dashboard.setStepDetails("Enter");
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			WebElement element = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			// element.clear();
			element.sendKeys(value);

		} catch (ElementNotVisibleException ex) {

			throw new LowLevelException(
					String.format("Element= %s is not visible to Enter value =%s ", webElementKey, value));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(String.format(
					"Element was not clickable as the page reloaded before the actual the Enter value =%s has been occured ",
					webElementKey, value));
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual Enter value =%s happend on Element %s",
					webElementKey, value));
		} catch (WebDriverException ex) {
			throw new LowLevelException(String.format(
					"Current browser is closed or Terminated before the actual value enter =%s occured for Element =%s",
					webElementKey, value));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while entering the value %s on Element %s \n Please refer the Exception details %s",
					value, webElementKey, ex.getMessage()));
		}
	}

	public void clickLinkByText(String textVal) throws Exception {
		// Hashtable<String, String> hTableGUIMap=
		// GlobalVariables.guiMap.get(webElementKey);

		dashboard.setStepDetails("Click Link", textVal + " link should be clicked successfully", "N/A");
		try {
			driver.findElement(By.linkText(textVal)).click();
		} catch (ElementNotVisibleException ex) {
			throw new LowLevelException(String.format("Element with text %s is not visible to click ", textVal));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(
					"Element was not clickable as the page reloaded before the actual click has been occured "
							+ textVal);
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual click happend on Element %s", textVal));
		} catch (WebDriverException ex) {
			throw new LowLevelException(String.format(
					"Current browser is closed or Terminated before the actual click occured for Element =%s",
					textVal));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while clicking on Element having text %s \n Please refer the Exception details %s",
					textVal, ex.getMessage()));
		}

	}

	public void clickElement(String webElementKey) throws Exception {

		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);

		/*
		 * dashboard.setStepDetails("Click Element", webElementKey +
		 * " button should be clicked successfully", "N/A");
		 */
		try {

			WebElement element = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			new WebDriverWait(driver, Long.parseLong(System.getProperty("Settings.ImplicitWait")))
					.until(ExpectedConditions.elementToBeClickable(element));
			element.click();

		} catch (ElementNotVisibleException ex) {
			throw new LowLevelException(String.format("Element=%s is not visible to click ", webElementKey));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(
					"Element was not clickable as the page reloaded before the actual click has been occured "
							+ webElementKey);
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual click happend on Element %s",
					webElementKey));
		} catch (WebDriverException ex) {
			throw new LowLevelException(String.format(
					"Current browser is closed or Terminated before the actual click occured for Element =%s",
					webElementKey));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while clicking on Element %s \n Please refer the Exception details %s",
					webElementKey, ex.getMessage()));
		}
	}

	public String getText(String webElementKey) throws Exception {
		String text = "";
		dashboard.setStepDetails("Retrieve Text",
				"Should be able to get the text from component : " + webElementKey + "", "N/A");
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			WebElement element = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			movetoElement(element);
			text = element.getText();
			/*
			 * if (text.equals(null) || text.equals("")) { throw new
			 * LowLevelException(String.format(
			 * "Element %s has been returned null or Empty text ", webElementKey)); }
			 */

		} catch (ElementNotVisibleException ex) {
			try {
				throw new LowLevelException(
						String.format("Element= %s is not visiable to get the Text ", webElementKey));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (StaleElementReferenceException ex) {
			try {
				throw new LowLevelException(
						"Page was reloaded or Refreshed before the actual GetText has been occured for element "
								+ webElementKey);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		catch (UnexpectedTagNameException ex) {
			try {
				throw new LowLevelException(String.format(
						"Unexpected tag name error has been found before the actual getText happend on Element %s",
						webElementKey));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (WebDriverException ex) {
			throw new LowLevelException(String.format(
					"Current browser is closed or Terminated before the actual getText occured for Element =%s",
					webElementKey));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while getting the text \n Please refer the Exception details %s",
					ex.getMessage()));
		}
		return text;

	}

	public void selectByValue(String webElementKey, String value) throws Exception {
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			WebElement dropDownListBox = new ObjectIdentifier(driver).FindObject(
					hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			Select clickThis = new Select(dropDownListBox);
			clickThis.selectByValue(value);
			new WebDriverWait(driver, Long.parseLong(System.getProperty("Settings.ImplicitWait")))
					.until(ExpectedConditions.textToBePresentInElement(clickThis.getFirstSelectedOption(), value));

		} catch (NoSuchElementException ex) {
			throw new LowLevelException(
					String.format("No such Option %s found in the dropdown %s ", value, webElementKey));
		}

		catch (ElementNotVisibleException ex) {
			throw new LowLevelException(String.format("Element= %s is not visible to select in the drop down box %s",
					value, webElementKey));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(String.format(
					"Page was reloaded or Refreshed before the actual Selection of dropdown element %s in the dropdown box %s",
					value, webElementKey));
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual Element =%s selected in the dropdown for Element %s",
					value, webElementKey));
		} catch (WebDriverException ex) {
			throw new LowLevelException(
					String.format("Current browser is closed or Terminated before the selection of drop down element ",
							webElementKey));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while selecting the drop down element %s\n Please refer the Exception details %s",
					value, ex.getMessage()));
		}
	}

	public void selectByIndex(String webElementKey, int index) throws Exception {
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			WebElement dropDownListBox = new ObjectIdentifier(driver).FindObject(
					hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			Select clickThis = new Select(dropDownListBox);
			clickThis.selectByIndex(index);

		} catch (NoSuchElementException ex) {
			throw new LowLevelException(
					String.format("No such Option %s found in the dropdown %s ", index, webElementKey));
		}

		catch (ElementNotVisibleException ex) {
			throw new LowLevelException(String.format("Element= %s is not visible to select in the drop down box %s",
					index, webElementKey));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(String.format(
					"Page was reloaded or Refreshed before the actual Selection of dropdown element %s in the dropdown box %s",
					index, webElementKey));
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual Element =%s selected in the dropdown for Element %s",
					index, webElementKey));
		} catch (WebDriverException ex) {
			throw new LowLevelException(
					String.format("Current browser is closed or Terminated before the selection of drop down element ",
							webElementKey));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while selecting the drop down element %s\n Please refer the Exception details %s",
					index, ex.getMessage()));
		}
	}

	public void checkBox_Check(String webElementKey) throws Exception {

		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			WebElement checkBox = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));

			if (!checkBox.isSelected()) {
				checkBox.click();

			}

		} catch (NoSuchElementException ex) {
			throw new LowLevelException(
					String.format("No such Element exception is occured for the checkBox Element %s", webElementKey));
		}

		catch (ElementNotVisibleException ex) {
			throw new LowLevelException(
					String.format("Element= %s is not visible exception is occured", webElementKey));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(
					String.format("Page was reloaded or Refreshed before checking the checkbox =%s", webElementKey));
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String
					.format("Unexpected tag name error has been found before checking the checkbox ", webElementKey));
		} catch (WebDriverException ex) {
			throw new LowLevelException(String
					.format("Current browser is closed or Terminated before checking the checkBox ", webElementKey));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while checking the checkBox %s\n Please refer the Exception details %s",
					ex.getMessage()));
		}

	}

	public void checkBox_CheckByID(String chkboxXPath) throws Exception // Added
																		// by
																		// Abhay
																		// to
																		// make
																		// it
																		// dynamic
																		// for
																		// multi
																		// sales
	{
		Hashtable<String, String> hTableGUIMap = new Hashtable<String, String>();
		hTableGUIMap.put("id", chkboxXPath);

		dashboard.setStepDetails("Check CheckBox",
				"CheckBox field with XPath: '" + chkboxXPath + "'should be checked successfully", "N/A");
		try {
			WebElement checkBox = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));

			if (!checkBox.isSelected()) {
				checkBox.click();

			}

		} catch (NoSuchElementException ex) {
			throw new LowLevelException(String.format(
					"No such Element exception is occured for the checkBox Element having XPath: %s", chkboxXPath));
		}

		catch (ElementNotVisibleException ex) {
			throw new LowLevelException(
					String.format("Element having XPath = %s is not visible exception is occured ", chkboxXPath));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(String.format(
					"Page was reloaded or Refreshed before checking the checkbox having XPath=%s", chkboxXPath));
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before checking the checkbox having XPath: ",
					chkboxXPath));
		} catch (WebDriverException ex) {
			throw new LowLevelException(
					"Current browser is closed or Terminated before checking the checkBox having XPath: "
							+ chkboxXPath);
		}

		catch (Exception ex) {

			throw new LowLevelException(
					"General Exception has been occured while checking the checkBox %s\n Please refer the Exception details"
							+ ex.getMessage());
		}

	}

	public void checkBox_Uncheck(String webElementKey) throws Exception {

		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		dashboard.setStepDetails("UnCheck CheckBox",
				"CheckBox field '" + webElementKey + "'should be unchecked successfully", "N/A");
		try {
			WebElement checkBox = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			if (checkBox.isSelected()) {
				checkBox.click();

			}

		} catch (NoSuchElementException ex) {

			throw new LowLevelException(String.format(
					"No such Element exception is occured for the unchecking the checkBox Element %s", webElementKey));
		}

		catch (ElementNotVisibleException ex) {

			throw new LowLevelException(
					String.format("Element= %s is not unchecking the checkBox is occured", webElementKey));
		} catch (StaleElementReferenceException ex) {

			throw new LowLevelException(
					String.format("Page was reloaded or Refreshed before unchecking the checkBox =%s", webElementKey));
		}

		catch (UnexpectedTagNameException ex) {

			throw new LowLevelException(String
					.format("Unexpected tag name error has been found before unchecking the checkBox ", webElementKey));
		} catch (WebDriverException ex) {

			throw new LowLevelException(String
					.format("Current browser is closed or Terminated before unchecking the checkBox", webElementKey));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while unchecking the checkBox %s\n Please refer the Exception details %s",
					ex.getMessage()));
		}

	}

	public void clickElementJs(String webElementKey) throws Exception {

		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		dashboard.setStepDetails("Click " + webElementKey, webElementKey + " button should be clicked successfully",
				"N/A");

		WebElement element = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
				hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
		clickElementJs(element);

	}

	public void acceptAlert() throws Exception {

		try {
			if (isAlertPresent(Long.parseLong(System.getProperty("Settings.ImplicitWait")))) {
				dashboard.setStepDetails("Accept JavaScript Alert", "Alert box should be accepted succesfully", "N/A");
				driver.switchTo().alert().accept();
			}
		} catch (NumberFormatException e) {
			throw new LowLevelException(
					"Exception occured while calling Number Format method \\n Exception is \" + ex.getMessage()");
		} catch (Exception e) {
			throw new LowLevelException(
					"Exception occured while calling acceptAlert method \\n Exception is \" + ex.getMessage()");
		} finally {
			setImplicitTime(Integer.parseInt(System.getProperty("Settings.ImplicitWait")));

		}
	}

	public void acceptAlert(Long timeOut) throws Exception {
		try {
			if (isAlertPresent(timeOut)) {
				dashboard.setStepDetails("Alert message is found", "Alert message is captured", "N/A");
				dashboard.writeResults();
				driver.switchTo().alert().accept();
			}
		} catch (Exception e) {
			throw new LowLevelException(
					"Exception occured while calling acceptAlert method \\n Exception is \" + ex.getMessage()");
		} finally {
			setImplicitTime(Integer.parseInt(System.getProperty("Settings.ImplicitWait")));
		}
	}

	public void acceptAlertOk() {

		dashboard.setStepDetails("Accept JavaScript Alert", "Alert box should be accepted succesfully", "N/A");
		try {
			if (isAlertPresent(Long.parseLong(System.getProperty("Settings.ImplicitWait")))) {
				driver.switchTo().alert().dismiss();
			}
		} catch (NumberFormatException e) {
			throw new LowLevelException(
					"Exception in Number Format occured while calling isAlertDisplayed method \\n Exception is \" + ex.getMessage()");
		} catch (Exception e) {
			throw new LowLevelException(
					"Exception occured while calling acceptAlertOk method \\n Exception is \" + ex.getMessage()");
		}
	}

	public void dismissAlert() throws Exception {
		dashboard.setStepDetails("Accept JavaScript Alert", "Alert box should be accepted succesfully", "N/A");
		try {
			if (isAlertPresent(Long.parseLong(System.getProperty("Settings.ImplicitWait")))) {
				dashboard.setStepDetails("Alert message is found", "Alert message is captured", "N/A");
				dashboard.writeResults();
				driver.switchTo().alert().dismiss();
			}
		} catch (NumberFormatException e) {
			throw new LowLevelException(
					"Exception in Number Format occured while calling isAlertDisplayed method \\n Exception is \" + ex.getMessage()");
		} catch (Exception e) {
			throw new LowLevelException(
					"Exception occured while calling acceptAlertOk method \\n Exception is \" + ex.getMessage()");
		} finally {
			setImplicitTime(Integer.parseInt(System.getProperty("Settings.ImplicitWait")));
		}
	}

	private boolean isAlertPresent(Long timeOut) throws Exception {

		boolean foundAlert = false;
		WebDriverWait wait = new WebDriverWait(driver, timeOut);
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			foundAlert = true;
		} catch (Exception eTO) {
			foundAlert = false;
		}
		return foundAlert;
	}

	private boolean isAlertPresent(WebDriverWait wait) {

		boolean foundAlert = false;
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			foundAlert = true;
		} catch (Exception eTO) {
			foundAlert = false;
		}
		return foundAlert;
	}

	public void handleMultipleAlerts(Long timeOut) {
		WebDriverWait wait = new WebDriverWait(driver, timeOut);
		while (isAlertPresent(wait)) {
			driver.switchTo().alert().accept();
		}

	}

	public void drag_and_drop(String dragElementKey, String droppingtoKey) throws Exception {
		waitUntilLoadingCompletes();
		// waitUntilLoadingCompletes();
		Hashtable<String, String> source = ARTProperties.guiMap.get(dragElementKey);

		dashboard.setStepDetails("Drag and Drop",
				"Drag object: '" + dragElementKey + "' to and drop to the object: '" + droppingtoKey + "'", "N/A");
		WebElement sourceElement = new ObjectIdentifier(driver).FindObject(source.keySet().toArray()[0].toString(),
				source.get(source.keySet().toArray()[0]));

		Hashtable<String, String> destination = ARTProperties.guiMap.get(droppingtoKey);
		WebElement targetElement = new ObjectIdentifier(driver).FindObject(destination.keySet().toArray()[0].toString(),
				destination.get(destination.keySet().toArray()[0]));

		org.openqa.selenium.interactions.Actions actionObj = new org.openqa.selenium.interactions.Actions(driver);

		actionObj.dragAndDrop(sourceElement, targetElement).build().perform();
	}

	public void move_to_element(String elementKey) throws Exception {
		dashboard.setStepDetails("Mouse Hover", "Mouse hover to the object:'" + elementKey + "' should be successful",
				"N/A");
		try {
			Hashtable<String, String> elementValue = ARTProperties.guiMap.get(elementKey);
			WebElement webelement = new ObjectIdentifier(driver).FindObject(
					elementValue.keySet().toArray()[0].toString(),
					elementValue.get(elementValue.keySet().toArray()[0]));

			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.visibilityOf(webelement));

			org.openqa.selenium.interactions.Actions actionObj = new org.openqa.selenium.interactions.Actions(driver);
			actionObj.moveToElement(webelement).build().perform();
		} catch (ElementNotVisibleException ex) {
			throw new LowLevelException(String.format("Element = %s is not visible to move to ", elementKey));
		} catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual move to element happened on Element %s",
					elementKey));
		} catch (WebDriverException ex) {
			throw new LowLevelException(String.format(
					"Current browser is closed or Terminated before the actual  move to element occurred for Element =%s",
					elementKey));
		} catch (Exception ex) {
			throw new LowLevelException(String.format(
					"General Exception has been occurred while moving to element on Element %s \n Please refer the Exception details %s",
					elementKey, ex.getMessage()));
		}
	}

	public void move_to_elementByXPath(String elementXPath) throws Exception {
		dashboard.setStepDetails("Mouse Hover",
				"Mouse hover to the object with XPath:'" + elementXPath + "' should be successful", "N/A");
		try {
			// Hashtable<String, String> elementValue =
			// GlobalVariables.guiMap.get(elementKey);

			Hashtable<String, String> elementValue = new Hashtable<String, String>();
			elementValue.put("xpath", elementXPath);

			WebElement webelement = new ObjectIdentifier(driver).FindObject(
					elementValue.keySet().toArray()[0].toString(),
					elementValue.get(elementValue.keySet().toArray()[0]));

			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.visibilityOf(webelement));

			org.openqa.selenium.interactions.Actions actionObj = new org.openqa.selenium.interactions.Actions(driver);
			actionObj.moveToElement(webelement).build().perform();
		} catch (ElementNotVisibleException ex) {
			throw new LowLevelException(
					String.format("Element with XPath = %s is not visible to move to  ", elementXPath));
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual move to element happened on Element with XPath = %s",
					elementXPath));
		} catch (WebDriverException ex) {
			throw new LowLevelException(String.format(
					"Current browser is closed or Terminated before the actual  move to element occurred for Element with XPath = %s",
					elementXPath));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occurred while moving to element on Element %s \n Please refer the Exception details %s",
					elementXPath, ex.getMessage()));
		}

	}

	public void acceptDialogue(String webElementKey) throws Exception {
		//

		try {
			Hashtable<String, String> dialogue = ARTProperties.guiMap.get(webElementKey);
			dashboard.setStepDetails("Accept Application Dialog",
					"FPMS dialog box: '" + webElementKey + "' should be accepted successfuly", "N/A");
			WebElement dialogueElement = new ObjectIdentifier(driver).FindObject(
					dialogue.keySet().toArray()[0].toString(), dialogue.get(dialogue.keySet().toArray()[0]));

			if (dialogueElement.isDisplayed()) {
				dialogueElement.click();
			}
		} catch (Exception ex) {
			throw new LowLevelException(
					"Exception occured in Accept dialogue while accepting dialogue:" + webElementKey);
		}

	}

	/**
	 * This method will return all the web element which matches to the locator
	 * 
	 * @param String
	 *            objectID the object id in the GUiMap.xls sheet
	 * @return the list of web elements
	 * @throws Exception
	 * @throws AuthenticationException
	 *             Throws when authentication fails
	 */
	public ArrayList<ArrayList<String>> transposeHTMLtoArrayList(String htmlTableObjectID, String xpathFilter)
			throws Exception {
		List<WebElement> rows = null; // to store the row elements
		ArrayList<String> rowToAdd = null; // to store the html row into array
											// of array list
		ArrayList<ArrayList<String>> tableList = new ArrayList<ArrayList<String>>();
		List<WebElement> webElements = null;
		String finalXpath = null; // finally formed xpath
		int ctrRow = 0; // ctr to increment the row

		try {
			// returnWebelemnts not working Rasheed to look
			// List<WebElement> webElements =
			// returnWebElements(htmlTableObjectID); //get the weblements for
			// the xpath , this will be the <tr> tags or rows

			webElements = new ObjectIdentifier(driver).FindWeblements(htmlTableObjectID);
			String rowCellData = "NA"; // get the cell data
			for (WebElement we : webElements) {
				rowToAdd = new ArrayList<String>();
				ctrRow++;
				finalXpath = htmlTableObjectID + "[" + ctrRow + "]" + xpathFilter;
				Thread.sleep(1000);
				rows = we.findElements(By.xpath(finalXpath));// get the elements
																// in a row,
																// this can be
																// the columns
																// <td> tags
				for (WebElement row : rows)// iterate with the filter applied to
											// narrow down to the expected
											// result
				{
					rowCellData = (row.getText() == null || row.getText().length() == 0) ? "NA" : row.getText(); // Ternary
																													// operator
																													// for
																													// adding
																													// NA
																													// for
																													// blank
																													// Data
					rowToAdd.add(rowCellData);
				}
				tableList.add(rowToAdd);
			}
		} catch (Exception ex) {
			throw new LowLevelException // custom exception raised
			(String.format("Excpetion occured for the webtable reading ", htmlTableObjectID, ex.getMessage()));
		}

		return tableList;
	}

	public String getAttribute(String webElementKey, String attributeName) throws Exception {
		String text = "";
		dashboard.setStepDetails("Retrieve Text",
				"Should be able to get the text from component : " + webElementKey + "", "N/A");
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			WebElement element = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			text = element.getAttribute(attributeName);

			if (text.equals(null) || text.equals("")) {
				throw new LowLevelException(
						String.format("Element %s has been returned null or Empty text ", webElementKey));
			}

		} catch (ElementNotVisibleException ex) {
			try {
				throw new LowLevelException(
						String.format("Element= %s is not visiable to get the Attribute specified ", webElementKey));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (StaleElementReferenceException ex) {
			try {
				throw new LowLevelException(
						"Page was reloaded or Refreshed before the actual GetText has been occured for element "
								+ webElementKey);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		catch (UnexpectedTagNameException ex) {
			try {
				throw new LowLevelException(String.format(
						"Unexpected tag name error has been found before the actual getAttribute happend on Element %s",
						webElementKey));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (WebDriverException ex) {
			throw new LowLevelException(String.format(
					"Current browser is closed or Terminated before the actual getAttribute occured for Element =%s",
					webElementKey));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while getting the text \n Please refer the Exception details %s",
					ex.getMessage()));
		}
		return text;

	}

	public boolean isEnabled(String webElementKey) {
		boolean isEnabled = false;
		try {
			dashboard.setStepDetails("Verify Element Is Enabled",

					"State of object: '" + webElementKey + "' should be returned", "N/A");
			Hashtable<String, String> dialogue = ARTProperties.guiMap.get(webElementKey);
			WebElement dialogueElement = new ObjectIdentifier(driver).FindObject(
					dialogue.keySet().toArray()[0].toString(), dialogue.get(dialogue.keySet().toArray()[0]));

			isEnabled = dialogueElement != null && dialogueElement.isEnabled() ? true : false;

		} catch (Exception ex) {

		}

		return isEnabled;
	}

	public void switchtoChildWindow(int windowId) throws Exception {
		try {
			new WebDriverWait(driver, Long.parseLong(System.getProperty("Settings.ImplicitWait")));
			Set<String> allWindows = driver.getWindowHandles();

			int i = 0;
			for (String currentWindow : allWindows) {
				if (i == windowId) {
					driver.switchTo().window(currentWindow);
					System.out.println(driver.getTitle());
				}
				i++;
			}
		} catch (Exception e) {
			System.out.println("   ");
		}

	}

	public void switchtoChildWindow(String title) throws Exception {
		try {
			Set<String> allWindows = driver.getWindowHandles();
			for (String currentWindow : allWindows) {
				if (driver.switchTo().window(currentWindow).getTitle().equalsIgnoreCase(title))
					break;
			}
		} catch (Exception e) {
			throw new LowLevelException(e);
		}
	}

	public void selectByVisibleText(String webElementKey, String value) throws Exception {
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			if (value != null && !value.isEmpty()) {
				WebElement dropDownListBox = new ObjectIdentifier(driver).FindObject(
						hTableGUIMap.keySet().toArray()[0].toString(),
						hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
				Select clickThis = new Select(dropDownListBox);
				clickThis.selectByVisibleText(value);

			}

		} catch (NoSuchElementException ex) {
			throw new LowLevelException(
					String.format("No such O ption %s found in the drop down %s ", value, webElementKey));
		}

		catch (ElementNotVisibleException ex) {
			throw new LowLevelException(String.format("Element= %s is not visible to select in the drop down box %s",
					value, webElementKey));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(String.format(
					"Page was reloaded or Refreshed before the actual Selection of drop down element %s in the drop down box %s",
					value, webElementKey));
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual Element =%s selected in the drop down for Element %s",
					value, webElementKey));
		} catch (WebDriverException ex) {
			throw new LowLevelException(
					String.format("Current browser is closed or Terminated before the selection of drop down element ",
							webElementKey));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occurred while selecting the drop down element %s\n Please refer the Exception details %s",
					value, ex.getMessage()));
		}
	}

	public List<String> getDropDownList(String webElementKey) throws Exception {
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			WebElement dropDownListBox = new ObjectIdentifier(driver).FindObject(
					hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			Select clickThis = new Select(dropDownListBox);
			List<WebElement> webElements = clickThis.getOptions();
			List<String> values = new ArrayList<>();
			for (WebElement we : webElements) {
				values.add(we.getText());
			}
			return values;

		} catch (NoSuchElementException ex) {
			throw new NoSuchElementException(String.format("No such Option found in the drop down %s ", webElementKey));
		}

		catch (ElementNotVisibleException ex) {
			throw new LowLevelException(
					String.format("Element is not visible to select in the drop down box %s", webElementKey));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(String.format(
					"Page was reloaded or Refreshed before the actual Selection of drop down element in the drop down box %s",
					webElementKey));
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual Element selected in the drop down for Element %s",
					webElementKey));
		} catch (WebDriverException ex) {
			throw new LowLevelException(
					String.format("Current browser is closed or Terminated before the selection of drop down element ",
							webElementKey));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occurred while selecting the drop down element \n Please refer the Exception details %s",
					ex.getMessage()));
		}

	}

	public List<WebElement> returnWebElements(String webElementKey) throws Exception {
		List<WebElement> listWebElement = null;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			listWebElement = new ObjectIdentifier(driver).FindObjects(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));

		}

		catch (Exception ex) {
			throw new LowLevelException(String.format(
					"General Exception has been occured while Finding list of WebElemnt for Key %s\n Please refer the Exception details %s",
					webElementKey, ex.getMessage()));
		}

		return listWebElement;
	}

	public void clickElementSuppressException(String webElementKey) {

		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);

		dashboard.setStepDetails("Click Element", webElementKey + " button should be clicked successfully", "N/A");
		try {

			WebElement element = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			element.click();

		} catch (ElementNotVisibleException ex) {
			LOGGER.log(Level.INFO, "clickElementSuppressException",
					"Exception has been occured but its ignored as expected");
		}
	}

	public void waitUntilElementPresent(String webElementKey) throws Exception {

		try {
			Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
			WebDriverWait wait = new WebDriverWait(driver, Long.parseLong(System.getProperty("Settings.ImplicitWait")));
			wait.ignoring(NoSuchElementException.class).ignoring(NoSuchElementException.class)
					.pollingEvery(2, TimeUnit.SECONDS)
					.until(ExpectedConditions.visibilityOf(
							new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
									hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]))));

		} catch (ElementNotVisibleException ex) {

			throw new LowLevelException(String.format("Element= %s is not visible ", webElementKey));
		}
	}

	public WebElement returnWebElement(String webElementKey) throws Exception {

		WebElement webElement = null;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {

			webElement = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));

		}

		catch (Exception ex) {
			throw new LowLevelException(String.format(
					"General Exception has been occured while Finding list of WebElemnt for Key %s\n Please refer the Exception details %s",
					webElementKey, ex.getMessage()));
		}

		return webElement;
	}

	public boolean isDisplayed(String webElementKey) // negative cases this has
														// to modified
	{
		try {
			dashboard.setStepDetails("Verify Element Exists",
					"Existance of object: '" + webElementKey + "' should be returned", "N/A");
			Hashtable<String, String> dialogue = ARTProperties.guiMap.get(webElementKey);
			WebElement dialogueElement = new ObjectIdentifier(driver).FindObject(
					dialogue.keySet().toArray()[0].toString(), dialogue.get(dialogue.keySet().toArray()[0]), "yes");

			if (dialogueElement.equals(null)) {
				return false;
			} else {
				return dialogueElement.isDisplayed();
			}
		}

		catch (Exception ex) {
			return false;
		}
	}

	public boolean isDisplayed(String webElementKey, int TimeOut) throws Exception {
		boolean status = false;
		List<WebElement> dialogueElement = new ArrayList<WebElement>();
		try {
			setImplicitTime(TimeOut);
			dashboard.setStepDetails("Verify Element Exists",
					"Existance of object: '" + webElementKey + "' should be returned", "N/A");
			Hashtable<String, String> dialogue = ARTProperties.guiMap.get(webElementKey);
			dialogueElement = new ObjectIdentifier(driver).FindObjects(dialogue.keySet().toArray()[0].toString(),
					dialogue.get(dialogue.keySet().toArray()[0]));
			if (dialogueElement.size() == 0) {
				status = false;
			} else {
				status = dialogueElement.get(0).isDisplayed();
				if (dialogueElement.get(0).getText().equalsIgnoreCase("Continue")) {
					dashboard.setStepDetails("Warning message is displayed", "Warning message is captured successfully",
							"N/A");
					dashboard.writeResults();
				}
			}
		} catch (Exception ex) {

		} finally {
			setImplicitTime(Integer.parseInt(System.getProperty("Settings.ImplicitWait")));
		}
		return status;
	}

	public boolean isDisplayedByXPath(String attachmentXPath) // Created by
																// Abhay for
																// verifying
																// dynamically
																// multiple pdfs
																// attached in
																// FBL for multi
																// sales
	{
		try {
			dashboard.setStepDetails("Verify Element Exists",
					"Element with XPath: '" + attachmentXPath + "' should be returned", "N/A");
			Hashtable<String, String> dialogue = new Hashtable<String, String>();
			dialogue.put("xpath", attachmentXPath);
			WebElement dialogueElement = new ObjectIdentifier(driver).FindObject(
					dialogue.keySet().toArray()[0].toString(), dialogue.get(dialogue.keySet().toArray()[0]), "yes");

			if (dialogueElement.equals(null)) {
				return false;
			} else {
				return dialogueElement.isDisplayed();
			}
		}

		catch (Exception ex) {
			System.out.println("Exception occured in isDisplayedByXPath");
			return false;
		}
	}

	public void movetoElement(WebElement element) {
		org.openqa.selenium.interactions.Actions act = new org.openqa.selenium.interactions.Actions(driver);
		act.moveToElement(element).perform();
	}

	public void doubleClick(WebElement element) {
		org.openqa.selenium.interactions.Actions act = new org.openqa.selenium.interactions.Actions(driver);
		act.doubleClick().perform();
	}

	public void navigatetoUrl(String url) {
		try {
			driver.navigate().to(url);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void switchtoFrame(int frameIndex) {
		driver.switchTo().frame(frameIndex);

	}

	public void switchtoFrame(String frameName) {
		try {
			/*WebDriverWait wait = new WebDriverWait(driver, Long.parseLong(System.getProperty("Settings.ImplicitWait")));
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.name(frameName)));*/
			driver.switchTo().frame(frameName);
		} catch (Exception ex) {
			throw new LowLevelException(ex);
		}
	}

	public void switchtoFrame(String locatorName, String frame1) {

		switch (locatorName.toUpperCase()) {
		case "INDEX":
			driver.switchTo().frame(Integer.parseInt(frame1));
			break;
		case "XPATH":
			Hashtable<String, String> hMap = ARTProperties.guiMap.get(frame1);
			WebElement frameElement = new ObjectIdentifier(driver).FindObject(hMap.keySet().toArray()[0].toString(),
					hMap.get(hMap.keySet().toArray()[0]), "yes");

			driver.switchTo().frame(frameElement);
			break;
		default:
			driver.switchTo().frame(frame1);
			break;
		}
	}

	public void switchtoDefaultContent() throws Exception {
		try {
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			throw new LowLevelException("Exception in switchtoDefaultContent");
		}
	}

	public void clickOnTab() throws Exception {

		List<WebElement> elements = returnWebElements("web_tab_Contact");

		for (WebElement el : elements) {
			if (el.getText().equalsIgnoreCase("contact")) {
				new org.openqa.selenium.interactions.Actions(DashboardProperties._driverWeb).moveToElement(el)
						.perform();
				el.click();
			}
		}
	}

	public void executeMethod() throws Exception {

		JavascriptExecutor jsexecutor = (JavascriptExecutor) driver;
		jsexecutor.executeScript("javascript:AmendProposer(1)");
		waitUntilLoadingCompletes();

	}

	public List<WebElement> getAllChildren(String parentPath) {
		List<WebElement> listWebElement = null;
		listWebElement = new ObjectIdentifier(driver).FindWeblements(parentPath);

		return listWebElement;
	}

	public void enterValues(WebElement webElement, String value) throws Exception {

		dashboard.setStepDetails("Enter Value",
				"Value: " + value + " should be Entered to the text field: " + webElement.getText(), value);
		try {
			webElement.clear();
			webElement.sendKeys(value);

		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"  General Exception   has been occured while entering the value %s on Element %s \n Please refer the Exception details %s",
					value, webElement.getTagName(), ex.getMessage()));
		}
	}

	public String getSelectedOption(String webElementKey) throws Exception {
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		try {
			WebElement dropDownListBox = new ObjectIdentifier(driver).FindObject(
					hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			Select clickThis = new Select(dropDownListBox);

			WebElement option = clickThis.getFirstSelectedOption();
			String defaultItem = option.getText();
			return defaultItem;

		} catch (Exception ex) {
			throw new LowLevelException(String.format("Exception in getSelectedOption"));
		}
	}

	public void maximizeWindow() {
		driver.manage().window().maximize();

	}

	public void scrolldown() {
		JavascriptExecutor jse = ((JavascriptExecutor) driver);
		jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public WebElement getElement(String elementName) {
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(elementName);
		WebElement element = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
				hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
		return element;
	}

	public void scrollToElement(WebElement element) {
		JavascriptExecutor jse = ((JavascriptExecutor) driver);

		jse.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void printAllWindowHandles() {
		Set<String> allWindowHandles = driver.getWindowHandles();
		for (String handle : allWindowHandles) {
			System.out.println("Window handle - > " + handle);
		}
	}

	public String getCurrentWindowName() {
		return driver.getTitle();
	}

	/*
	 * close() is a webdriver command which closes the browser window which is
	 * currently in focus.
	 */
	public void closeWindow(String winName) {
		Set<String> allWindows = driver.getWindowHandles();
		for (String currentWindow : allWindows) {

			if (driver.switchTo().window(currentWindow).getTitle().equalsIgnoreCase(winName)) {
				driver.close();
			}

		}

	}

	/*
	 * Name: switchtoSecondWindow Purpose: Switch to Second Window Handle
	 * Parameters: NA Return Value: NA Exception: LowLevelException
	 */
	public void switchtoSecondWindow() throws Exception {
		try {
			List<String> allWindows = new ArrayList<String>(driver.getWindowHandles());
			if (allWindows.isEmpty() == false) {
				driver.switchTo().window(allWindows.get(1));
			}
		} catch (Exception ex) {
			throw new LowLevelException(String.format("switchtoSecondWindow failed"));
		}

	}

	
	public void switchtoWindowsPopUp() throws Exception {
		try {
			Object firstHandle;
			Object lastHandle;
			
			List<String> allWindows = new ArrayList<String>(driver.getWindowHandles());
			
			Iterator <String> itr = allWindows.iterator();
			firstHandle=itr.next();
			lastHandle=firstHandle;
			while(itr.hasNext()) {
				lastHandle = itr.next();
			}
			driver.switchTo().window(lastHandle.toString());
		} catch (Exception ex) {
			throw new LowLevelException(String.format("switchtoSecondWindow failed"));
		}

	}
	
	
	
	/*
	 * Name: closeCurrentWindow Purpose: Closes Current Window Handle and Context
	 * Switches back to the First Window Handle Parameters: NA Return Value: NA
	 * Exception: LowLevelException
	 */
	public void closeCurrentWindow() throws Exception {
		try {
			driver.getWindowHandle();
			driver.close();
			switchtoDefaultWindow();
		} catch (Exception ex) {
			throw new LowLevelException(String.format("closeCurrentWindow"));
		}

	}

	/*
	 * Name: ClickOnOverideLink Purpose: Click on Override Link on Window
	 * Certification Error Page Parameters: NA Return Value: NA Exception:
	 * ElementNotVisibleException, LowLevelException
	 */
	public void ClickOnOverideLink() throws Exception {
		try {
			driver.get("javascript:document.getElementById('overridelink').click();");
		} catch (Exception ex) {
			throw new LowLevelException("ClickOnOverideLink failed.. ");
		}

	}

	/*
	 * Name: waitUntilBrowserWindowLoads Purpose: wait Until Browser Window Loads
	 * before performing Accept or Decline Parameters: NA Return Value: NA
	 * Exception: ElementNotVisibleException, LowLevelException
	 */
	public void waitUntilLoadingCompletes() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver,
					Long.parseLong(System.getProperty("Settings.Window Wait Time")));
			ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver driver) {
					return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
							.equals("complete");
				}
			};
			wait.until(pageLoadCondition);
		} catch (Exception ex) {
			System.out.println("Supressed exception in method : waitUntilLoadingCompletes");
		}
	}

	/*
	 * Name: waitUntilAlertisShown Purpose: Wait till the ALert Window is shown
	 * before performing Accept or Decline Parameters: NA Return Value: NA
	 * Exception: ElementNotVisibleException, LowLevelException
	 */
	public void waitUntilAlertisShown() throws Exception {
		try {
			new WebDriverWait(driver, Long.parseLong(System.getProperty("Settings.ImplicitWait")))
					.ignoring(NoAlertPresentException.class).until(ExpectedConditions.alertIsPresent());

		} catch (ElementNotVisibleException ex) {

			throw new LowLevelException("In waitUntilAlertisShown " + ex.getMessage());
		} catch (UnhandledAlertException ex) {
			if (ex.getAlertText().trim().equalsIgnoreCase("Your login attempt was not successful, Please try again")) {
				throw new LowLevelException(
						"Failed to Login with credentials supplied, Please verify your user name and password in testdata file");
			}
			throw new LowLevelException("Alert has been thrown: " + ex.getAlertText());
		} catch (Exception ex) {
			System.out.println("Supressed exception in method : waitUntilLoadingCompletes");
		}

	}

	@Deprecated
	/*
	 * Name: waitforPageLoad Purpose: Wait till the ALert Window is shown before
	 * performing Accept or Decline Parameters: NA Return Value: NA Exception:
	 * ElementNotVisibleException, LowLevelException
	 */
	public void waitforPageLoad() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Long.parseLong(System.getProperty("Settings.ImplicitWait")));
			ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver driver) {
					return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
							.equals("complete");
				}
			};
			wait.until(pageLoadCondition);
		} catch (Exception ex) {
			System.out.println("Supressed exception in method : waitUntilLoadingCompletes");
		}
	}

	/*
	 * Name: sleep Purpose: Perform thread sleep for specified seconds Parameters:
	 * integer - seconds Return Value: NA Exception: ElementNotVisibleException,
	 * LowLevelException
	 */
	public void sleep(int seconds) {
		try {
			Thread.sleep(1000 * seconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * Name: switchtoDefaultWindow Purpose: Switch to the First Window Handle
	 * Always. To Switch to Main - Home Page from Any Window. Parameters: NA Return
	 * Value: NA Exception: ElementNotVisibleException, LowLevelException
	 */
	public void switchtoDefaultWindow() throws Exception {
		try {
			Set<String> allWindows = driver.getWindowHandles();
			if (allWindows.isEmpty() == false) {
				driver.switchTo().window(allWindows.iterator().next());
			}
		} catch (Exception ex) {
			throw new LowLevelException(String
					.format("Exception occured in the Method switchtoDefaultWindow. Exception is " + ex.getMessage()));
		}
	}

	public WebElement findElementByXpath(String XPath) throws Exception {

		try {
			WebElement Element = driver.findElement(By.xpath(XPath));
			return Element;
		}

		catch (Exception ex) {
			return null;

		}
	}

	public List<WebElement> findElementsByXpath(String XPath) throws Exception {

		try {
			List<WebElement> Elements = driver.findElements(By.xpath(XPath));
			return Elements;
		}

		catch (Exception ex) {
			return null;

		}
	}

	public void pageRefresh() throws Exception {
		driver.navigate().refresh();
	}

	public String getItemAt(String tablePathWebElementKey, int rowPosition, int colPosition, String optionalXPath)
			throws Exception {
		WebElement tblCells;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);
		String temp;
		try {

			if (StringUtils.isEmpty(optionalXPath)) {
				temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]" + "/td["
						+ colPosition + "]";
			} else {
				temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]" + "/td["
						+ colPosition + "]/" + optionalXPath + "";
			}
			Utils.sleep(1);

			tblCells = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(), temp);

			return tblCells.getText();

		} catch (Exception ex) {
			throw new LowLevelException(String.format("No such Element exception is occured for the checkBox Element"));
		}
	}

	public int getSize(String xpathExpression) throws Exception {
		List<WebElement> elements = driver.findElements(By.xpath(xpathExpression + "/tbody/tr"));
		return elements.size();

	}

	/* Table Operations */

	/*
	 * Name: GetRowPositionInTable Purpose: Get Row Number of a Particular Element
	 * under a Specified Column Parameters: String - Table Path, String - Cell Value
	 * to be Searched, Integer - Column Position - Use Method
	 * GetColumnPositionInTable Return Value: NA Exception: NoSuchElementException,
	 * LowLevelException
	 */
	public int GetRowPositionInTable(String tablePathWebElementKey, String searchString, int colPosition)
			throws Exception {
		try {

			int rowPos = GetRowPositionInTable(tablePathWebElementKey, searchString, colPosition, 1);
			return rowPos;
		} catch (Exception ex) {
			throw new LowLevelException(String
					.format("Low Level Exception Occured in Method: GetRowPositionInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	/*
	 * Name: GetRowPositionInTable Purpose: Get Row Number of a Particular Element
	 * under a Specified Column Parameters: String - Table Path, String - Cell Value
	 * to be Searched, Integer - Column Position - Use Method
	 * GetColumnPositionInTable Return Value: NA Exception: NoSuchElementException,
	 * LowLevelException
	 */
	public int GetRowPositionInTable(String tablePathWebElementKey, String searchString, int colPosition, int headerRow)
			throws Exception {
		WebElement tblFullRow;
		String cellValue;
		int rowPos = 0;
		headerRow = headerRow + 1;
		List<WebElement> tblRows;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);
		Hashtable<String, String> dummy_hTableGUIMap = ARTProperties.guiMap.get("web_InitailReg_TableElement_Dummy");
		try {

			String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr";
			tblRows = new ObjectIdentifier(driver).FindObjects(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			Utils.sleep(1);
			if (colPosition == 0) {
				// TODO If Column Position is Unknown. Search Whole Table
			} else {
				for (int i = headerRow; i <= tblRows.size(); i++) {

					temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + i + "]" + "/td["
							+ colPosition + "]";

					dummy_hTableGUIMap.put("xpath", temp);
					ARTProperties.guiMap.put("web_InitailReg_TableElement_Dummy", dummy_hTableGUIMap);

					if (isDisplayed("web_InitailReg_TableElement_Dummy", 1)) {
						tblFullRow = new ObjectIdentifier(driver)
								.FindObject(hTableGUIMap.keySet().toArray()[0].toString(), temp);
						cellValue = tblFullRow.getText().trim().toUpperCase().replaceAll("-", "");
						searchString = searchString.trim().toUpperCase().replaceAll("-", "");
						if (cellValue.equalsIgnoreCase(searchString)) {
							rowPos = i;
							break;
						}
					}
				}
			}
			return rowPos;
		} catch (Exception ex) {
			throw new LowLevelException(String
					.format("Low Level Exception Occured in Method: GetRowPositionInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	/*
	 * Name: GetColumnPositionInTable Purpose: Get Column Number of a Particular
	 * Element Parameters: String - Table Path, String - Column Name to be Searched
	 * Return Value: NA Exception: NoSuchElementException, LowLevelException
	 */
	public int GetColumnPositionInTable(String tablePathWebElementKey, String columnName) throws Exception {
		try {
			int colPos = GetColumnPositionInTable(tablePathWebElementKey, columnName, 1);
			return colPos;
		} catch (Exception ex) {
			throw new LowLevelException(String
					.format("Low Level Exception Occured in Method: GetColumnPositionInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	/*
	 * Name: GetColumnPositionInTable Purpose: Get Column Number of a Particular
	 * Element Parameters: String - Table Path, String - Column Name to be Searched
	 * Return Value: NA Exception: NoSuchElementException, LowLevelException
	 */
	public int GetColumnPositionInTable(String tablePathWebElementKey, String columnName, int headerRow)
			throws Exception {
		WebElement tblFullRow;
		String cellValue;
		int colPos = 0;
		// int headerRow = 1;
		List<WebElement> tblCols;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);
		try {

			String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + headerRow + "]/td";
			tblCols = new ObjectIdentifier(driver).FindObjects(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			Utils.sleep(1);
			for (int i = 1; i <= tblCols.size(); i++) {
				temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + headerRow + "]" + "/td["
						+ i + "]";

				tblFullRow = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
						temp);

				cellValue = tblFullRow.getText().trim().toUpperCase();
				if (cellValue.equalsIgnoreCase(columnName.trim().toUpperCase())) {
					colPos = i;
					break;
				}
			}

			return colPos;
		} catch (Exception ex) {
			throw new LowLevelException(String
					.format("Low Level Exception Occured in Method: GetColumnPositionInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	/*
	 * Name: SelectRowInTable Purpose: Select a Cell in a Table with Specified Row
	 * and Column Parameters: String - Table Path, Integer - Row Number, Integer -
	 * Column Number Return Value: NA Exception: NoSuchElementException,
	 * LowLevelException
	 */
	public void SelectRowInTable(String tablePathWebElementKey, int rowPosition, int colPosition, String tagName)
			throws Exception {
		WebElement tblCells;
		List<WebElement> tblCellElement;
		Boolean chckBoxStatus;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);
		try {
			String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]"
					+ "/td[" + colPosition + "]";
			Utils.sleep(1);
			tblCells = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			tblCellElement = tblCells.findElements(By.tagName(tagName));

			for (WebElement cellElement : tblCellElement) {
				if (cellElement.isDisplayed()) {
					switch (tagName) {
					case "input":
						chckBoxStatus = cellElement.isSelected();

						if (chckBoxStatus != true) {
							cellElement.click();
						}
						break;
					default:
						cellElement.click();
						break;
					}
				}
			}
		} catch (Exception ex) {
			throw new LowLevelException(
					String.format("Low Level Exception Occured in Method: SelectRowInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	public void DeSelectRowInTable(String tablePathWebElementKey, int rowPosition, int colPosition, String tagName)
			throws Exception {
		WebElement tblCells;
		List<WebElement> tblCellElement;
		Boolean chckBoxStatus;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);
		try {
			String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]"
					+ "/td[" + colPosition + "]";
			Utils.sleep(1);
			tblCells = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			tblCellElement = tblCells.findElements(By.tagName(tagName));

			for (WebElement cellElement : tblCellElement) {
				if (cellElement.isDisplayed()) {
					switch (tagName) {
					case "input":
						chckBoxStatus = cellElement.isSelected();

						if (chckBoxStatus != false) {
							cellElement.click();
						}
						break;
					default:
						cellElement.click();
						break;
					}
				}
			}
		} catch (Exception ex) {
			throw new LowLevelException(
					String.format("Low Level Exception Occured in Method: SelectRowInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	/*
	 * Name: GetColumnPositionInTable Purpose: Get Row Count of a Particular table
	 * Element Parameters: String - Table Path
	 */
	public int getRowCountInTable(String tablePathWebElementKey) throws Exception {
		int rowCount = 0;
		List<WebElement> tblRows;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);

		try {
			String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr";
			tblRows = new ObjectIdentifier(driver).FindObjects(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			Utils.sleep(1);
			rowCount = tblRows.size();
			return rowCount;
		}

		catch (Exception ex) {
			throw new LowLevelException(
					String.format("Low Level Exception Occured in Method: getRowCountInTable. The Exception Message : "
							+ ex.getMessage()));

		}
	}

	/*
	 * Name: EnterTextInTable Purpose: Enter Text in a Table in specific cell Column
	 * Parameters: String - Table Path, Integer - Row Number, Integer - Column
	 * Number, String - Text to Enter Return Value: NA Exception:
	 * NoSuchElementException, LowLevelException
	 */
	public void enterTextInTable(String tablePathWebElementKey, int rowPosition, int colPosition, String textToEnter)
			throws Exception {
		try {
			enterTextInTable(tablePathWebElementKey, rowPosition, colPosition, textToEnter, "");

		} catch (Exception ex) {
			throw new LowLevelException(
					String.format("Low Level Exception Occured in Method: enterTextInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	/*
	 * Name: enterTextInTable Purpose: Enter Text in a Table in specific cell Column
	 * Parameters: String - Table Path, Integer - Row Number, Integer - Column
	 * Number, String - Text to Enter Return Value: NA Exception:
	 * NoSuchElementException, LowLevelException
	 */
	public void enterTextInTable(String tablePathWebElementKey, int rowPosition, int colPosition, String textToEnter,
			String optionalXPath) throws Exception {
		WebElement tblCellElement;
		String temp = StringUtils.EMPTY;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);
		try {
			if(!StringUtils.isEmpty(textToEnter)) {
				if (!StringUtils.isEmpty(optionalXPath)) {
					temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]" + "/td["
							+ colPosition + "]" + optionalXPath + "";
				} else {
					temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]" + "/td["
							+ colPosition + "]";
				}
				Utils.sleep(2);
				tblCellElement = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
						temp);
				if (tblCellElement.getTagName().equalsIgnoreCase("select")) {
					Select clickThis = new Select(tblCellElement);
					clickThis.selectByVisibleText(textToEnter);
				} else {
					String readonly = tblCellElement.getAttribute("readonly");
					if (!"true".equals(readonly)) {
						tblCellElement.clear();
						tblCellElement.sendKeys(textToEnter);
					}
				}
			}
		} catch (Exception ex) {
			throw new LowLevelException(
					String.format("Low Level Exception Occured in Method: enterTextInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	/*
	 * Name: GetAllTextUnderColumnInTable Purpose: Get All Text under a Specified
	 * Column in a Table Parameters: String - Table Path, Integer - Column Position
	 * - Use Method GetColumnPositionInTable Return Value: NA Exception:
	 * NoSuchElementException, LowLevelException
	 */
	public List<String> GetAllTextUnderColumnInTable(String tablePathWebElementKey, int colPosition) throws Exception {
		try {
			return GetAllTextUnderColumnInTable(tablePathWebElementKey, colPosition, "");
		} catch (Exception ex) {
			throw new LowLevelException(String.format(
					"Low Level Exception Occured in Method: GetAllTextUnderColumnInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	/*
	 * Name: GetAllTextUnderColumnInTable Purpose: Get All Text under a Specified
	 * Column in a Table Parameters: String - Table Path, Integer - Column Position
	 * - Use Method GetColumnPositionInTable Return Value: NA Exception:
	 * NoSuchElementException, LowLevelException
	 */
	public List<String> GetAllTextUnderColumnInTable(String tablePathWebElementKey, int colPosition,
			String optionalXpath) throws Exception {
		WebElement tblFullRow;
		List<String> cellsData = new ArrayList<>();
		String cellValue;
		int rowOffSet = 1; // Always checks for the Item from Row 1
		List<WebElement> tblRows;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);

		try {
			String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr";
			tblRows = new ObjectIdentifier(driver).FindObjects(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			Utils.sleep(2);
			if (colPosition == 0) {
				// TODO If Column Position is Unknown. Search Whole Table
			} else {
				for (int i = 1 + rowOffSet; i <= (tblRows.size()); i++)// Removed -1 from tblRows.size()-1
				{

					if (StringUtils.isEmpty(optionalXpath)) {
						temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + i + "]" + "/td["
								+ colPosition + "]";
					} else {
						temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + i + "]" + "/td["
								+ colPosition + "]" + optionalXpath;

					}

					tblFullRow = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
							temp);

					String tagName = tblFullRow.getTagName();
					if (tagName.equalsIgnoreCase("input")) {
						cellValue = tblFullRow.getAttribute("value");
					} else {
						cellValue = tblFullRow.getText();
					}
					cellsData.add(cellValue.trim().toUpperCase());

				}

			}
			return cellsData;
		} catch (Exception ex) {
			throw new LowLevelException(String.format(
					"Low Level Exception Occured in Method: GetAllTextUnderColumnInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	/*
	 * Name: GetTextFromTable Purpose: Get text from Cell in a Table with Specified
	 * Row and Column Parameters: String - Table Path, Integer - Row Number, Integer
	 * - Column Number Return Value: String - Text Exception:
	 * NoSuchElementException, LowLevelException
	 */
	public String GetTextFromTable(String tablePathWebElementKey, int rowPosition, int colPosition) throws Exception {
		try {
			return GetTextFromTable(tablePathWebElementKey, rowPosition, colPosition, "");
		} catch (Exception ex) {
			throw new LowLevelException(String.format("No such Element exception is occured for the checkBox Element"));
		}
	}

	/*
	 * Name: GetTextFromTable Purpose: Get text from Cell in a Table with Specified
	 * Row and Column Parameters: String - Table Path, Integer - Row Number, Integer
	 * - Column Number Return Value: String - Text Exception:
	 * NoSuchElementException, LowLevelException
	 */
	public String GetTextFromTable(String tablePathWebElementKey, int rowPosition, int colPosition, String OptionalPath)
			throws Exception {
		WebElement tblCells;
		String temp = StringUtils.EMPTY;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);
		try {

			if (!StringUtils.isEmpty(OptionalPath)) {
				temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]" + "/td["
						+ colPosition + "]" + OptionalPath + "";
			} else {
				temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]" + "/td["
						+ colPosition + "]";
			}
			Utils.sleep(1);
			tblCells = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			return tblCells.getText();

		} catch (Exception ex) {
			throw new LowLevelException(String.format("No such Element exception is occured for the checkBox Element"));
		}
	}

	public List<WebElement> findElements(String WebElementKey) throws Exception {
		List<WebElement> Elements = null;
		try {
			Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(WebElementKey);
			Elements = new ObjectIdentifier(driver).FindObjects(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			return Elements;
		}

		catch (Exception ex) {
			return null;

		}
	}

	/*
	 * Name: getElementAt Purpose: Get a webElement from Cell in a Table with
	 * Specified Row and Column Parameters: String - Table Path, Integer - Row
	 * Number, Integer - Column Number Return Value: WebElement - Text Exception:
	 * NoSuchElementException, LowLevelException
	 */
	public WebElement getElementAt(String tablePathWebElementKey, int rowPosition, int colPosition, String OptionalPath)
			throws Exception {
		WebElement tblCells;
		String temp = StringUtils.EMPTY;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);
		try {

			if (!StringUtils.isEmpty(OptionalPath)) {
				temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]" + "/td["
						+ colPosition + "]" + OptionalPath + "";
			} else {
				temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + rowPosition + "]" + "/td["
						+ colPosition + "]";
			}
			Utils.sleep(1);
			tblCells = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			return tblCells;

		} catch (Exception ex) {
			throw new LowLevelException(String.format("No such Element exception is occured for the checkBox Element"));
		}

	}

	public boolean isAlertDisplayed() throws Exception {
		boolean foundAlert = false;
		try {
			if (isAlertPresent(Long.parseLong(System.getProperty("Settings.ImplicitWait"))))
				foundAlert = true;

		} catch (Exception ex) {
			throw new LowLevelException(ex);
		}
		return foundAlert;
	}

	public boolean isAlertDisplayed(Long timeout) throws Exception {
		boolean foundAlert = false;
		try {
			if (isAlertPresent(timeout))
				foundAlert = true;

		} catch (Exception ex) {
			throw new LowLevelException(ex);
		} finally {
			setImplicitTime(Integer.parseInt(System.getProperty("Settings.ImplicitWait")));
		}
		return foundAlert;
	}

	public void waitTillAllPopUpWindowsClosed() throws Exception {
		try {
			Set<String> allWindows = driver.getWindowHandles();
			if (allWindows.isEmpty() == false) {
				while (allWindows.size() > 1) {
					allWindows = driver.getWindowHandles();
					Utils.sleep(3);
				}
			}

		} catch (Exception ex) {
			throw new LowLevelException(ex);
		}
	}

	public String getAlertText() throws Exception {
		try {
			String alertText = "";
			if (isAlertPresent(Long.parseLong(System.getProperty("Settings.ImplicitWait")))) {
				alertText = driver.switchTo().alert().getText();

			}
			return alertText;
		} catch (Exception ex) {
			throw new LowLevelException(String.format(
					"Low Level Exception Occured in Method: getAlertText. The Exception Message : " + ex.getMessage()));
		}

	}

	public String getCurrentURL() throws Exception {
		return driver.getCurrentUrl();
	}

	public void clearText(String webElementKey) throws Exception {
		try {
			Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);

			WebElement element = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
					hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
			String readonly = element.getAttribute("readonly");
			if (element.isDisplayed() && element.isEnabled() && !"true".equals(readonly)) {
				element.clear();
			}

		} catch (Exception ex) {
			throw new LowLevelException("No such Element exception is occured for the checkBox Element");
		}
	}

	/*
	 * Name: GetValueOfSpecificQueryLabel Purpose: Get the value of Any label
	 * displayed in Common Query Page Parameters: TableElementKey: Exception:
	 * BPCException
	 */
	public String table_GetValueOfSpecificLabel(String TableElement, String LabelName) throws Exception {
		try {
			Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(TableElement);
			String xPath = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr/td[contains(text(), '"
					+ LabelName + "')]/following-sibling::td";

			WebElement tdWithValue = findElementByXpath(xPath);
			return tdWithValue.getText();

		} catch (Exception e) {
			throw new LowLevelException(e);
		}
	}

	public void clickElementJs(WebElement element) throws Exception {
		String buttonName = element.getText();
		dashboard.setStepDetails("Click " + buttonName, buttonName + " button should be clicked successfully", "N/A");
		try {

			JavascriptExecutor jsexecutor = (JavascriptExecutor) driver;
			jsexecutor.executeScript("arguments[0].click();", element);

		} catch (ElementNotVisibleException ex) {
			throw new LowLevelException(String.format("Element= %s is not visiable to click ", element));
		} catch (StaleElementReferenceException ex) {
			throw new LowLevelException(
					"Element was not clickable as the page reloaded before the actual click has been occured "
							+ element);
		}

		catch (UnexpectedTagNameException ex) {
			throw new LowLevelException(String.format(
					"Unexpected tag name error has been found before the actual click happend on Element %s", element));
		} catch (WebDriverException ex) {
			throw new LowLevelException(String.format(
					"Current browser is closed or Terminated before the actual click occured for Element =%s",
					element));
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while clicking on Element %s \n Please refer the Exception details %s",
					element, ex.getMessage()));
		}
	}

	public ArrayList<TableColumn> getColumnHeaders(String tablePathWebElementKey, int headerRowPosistion)
			throws Exception {
		ArrayList<TableColumn> tblColumns = new ArrayList<TableColumn>();
		List<WebElement> columns;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);

		try {
			String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + headerRowPosistion
					+ "]//*";
			columns = new ObjectIdentifier(driver).FindObjects(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			int i = 0;
			for (WebElement we : columns) {
				tblColumns.add(new TableColumn(++i, we.getText().trim()));
			}
			return tblColumns;
		} catch (Exception ex) {
			throw new LowLevelException(String.format(
					"Low Level Exception Occured in Method: GetAllTextUnderColumnInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}

	public void waitUntilIframeLoadingCompletes(final String frameName) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver,
					Long.parseLong(System.getProperty("Settings.Window Wait Time")));
			ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver driver) {
					return ((JavascriptExecutor) driver)
							.executeScript("function myfunction(){ var a = document.frames['" + frameName
									+ "']; if(a != 'undefined'){ return a.document.readyState; } }")
							.toString().equals("complete");
				}
			};
			wait.until(pageLoadCondition);
			// WebDriverWait wait = new WebDriverWait(driver,Long.parseLong("10"));
			// wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameName));

		} catch (Exception ex) {
			System.out.println("Supressed exception in method : waitUntilLoadingCompletes");
		} finally {
			setImplicitTime(Integer.parseInt(System.getProperty("Settings.ImplicitWait")));
		}
	}

	/**
	 * @param WebElementKey:
	 *            Table Element Key
	 * @param charToBeReplacedWith:
	 *            Strings to be replaced with ?? in the Xpath saved in GUI Map
	 * @return
	 * @throws Exception
	 *             LowLevelException
	 */
	public List<WebElement> findElementsByXpath(String WebElementKey, String[] charToBeReplacedWith) throws Exception {
		List<WebElement> elements = new ArrayList<WebElement>();
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(WebElementKey);
		String tempXPath = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]);
		String xPathParts[] = tempXPath.split("##");
		StringBuilder builder = new StringBuilder();
		builder.append(xPathParts[0]);
		for (int i = 0; i < charToBeReplacedWith.length; i++) {
			builder.append(charToBeReplacedWith[i]);
			builder.append(xPathParts[i + 1]);
		}
		elements = findElementsByXpath(builder.toString());
		return elements;

	}

	public void addToCookies(String key, String value) {
		Cookie cookie = new Cookie(key, value);
		driver.manage().addCookie(cookie);
	}

	public void deleteFromCookies(Cookie cookie) {
		Cookie currentCookie = driver.manage().getCookieNamed(cookie.getName());
		if (currentCookie.getName().equalsIgnoreCase(cookie.getName())
				&& currentCookie.getValue().equalsIgnoreCase(cookie.getValue())) {
			driver.manage().deleteCookieNamed(cookie.getName());
		}
	}

	public Set<Cookie> getAllCookies() {
		Set<Cookie> oldCookies = driver.manage().getCookies();
		return oldCookies;
	}

	public int GetRowPositionInTableByPartialTextMatch(String tablePathWebElementKey, String searchString,
			int colPosition) throws Exception {
		WebElement tblFullRow;
		String cellValue;
		int rowPos = 0;
		int headerRow = 1;
		List<WebElement> tblRows;
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(tablePathWebElementKey);
		Hashtable<String, String> dummy_hTableGUIMap = ARTProperties.guiMap.get("web_InitailReg_TableElement_Dummy");
		try {

			String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr";
			tblRows = new ObjectIdentifier(driver).FindObjects(hTableGUIMap.keySet().toArray()[0].toString(), temp);
			Utils.sleep(1);
			if (colPosition == 0) {
				// TODO If Column Position is Unknown. Search Whole Table
			} else {
				for (int i = headerRow; i <= tblRows.size(); i++) {

					temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr[" + i + "]" + "/td["
							+ colPosition + "]";

					dummy_hTableGUIMap.put("xpath", temp);
					ARTProperties.guiMap.put("web_InitailReg_TableElement_Dummy", dummy_hTableGUIMap);

					if (isDisplayed("web_InitailReg_TableElement_Dummy", 1)) {
						tblFullRow = new ObjectIdentifier(driver)
								.FindObject(hTableGUIMap.keySet().toArray()[0].toString(), temp);
						cellValue = tblFullRow.getText().trim().toUpperCase().replaceAll("-", "");
						searchString = searchString.trim().toUpperCase().replaceAll("-", "");
						if (cellValue.contains(searchString)) {
							rowPos = i;
							break;
						}
					}
				}
			}
			return rowPos;
		} catch (Exception ex) {
			throw new LowLevelException(String
					.format("Low Level Exception Occured in Method: GetRowPositionInTable. The Exception Message : "
							+ ex.getMessage()));
		}
	}
	 public int getNoOfActiveWindows() {
		 int handles = 0;
		 try {
			  handles = driver.getWindowHandles().size();
		 }catch(Exception ex) {
			 throw new LowLevelException(ex);
		 }
		 return handles;
	 }

}
