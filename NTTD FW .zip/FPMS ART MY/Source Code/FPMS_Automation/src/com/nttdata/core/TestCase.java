package com.nttdata.core;


public class TestCase {

	private String id;
	private String suiteName;
	private String name; //Test Case Name
	
	private int status;
	
	public TestCase(String id, String suiteName, String name) {
		super();
		this.id = id.trim();
		this.suiteName = suiteName.trim();
		this.name = name.trim();
	}


	public String getId() {
		return id;
	}

	public String getSuiteName() {
		return suiteName;
	}

	public String getName() {
		return name;
	}

	public int getStatus() {
		return status;
	}

	
	public void setStatus(int status) {
		this.status = status;
	}

}
