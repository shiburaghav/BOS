package com.nttdata.core.handler;

import com.nttdata.core.TestCase;

public class TestCaseHandler
{

	private TestCase  testCase;

	private static TestCaseHandler instance;
	
	private TestCaseHandler() {
		
	}
	public TestCase getTestCase() {
		return testCase;
	}

	public void setTestCase(TestCase testCase) {
		this.testCase = testCase;
	}
	
	public static TestCaseHandler getInstance() {
		if (instance == null) {
			instance = new TestCaseHandler();
		}
		return instance;
	}
}
