package com.nttdata.core.handler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.common.util.Utils;
import com.nttdata.framework.exceptions.GenericFunctionLevelException;

public class DBHandler {
	private final static Logger LOGGER = Logger.getLogger(DataHandler.class.getName());
	private static java.sql.Connection dbConnection;
	private static ResultSet resultSet;

	public DBHandler() {

	}

	public Connection createConnection() throws Exception {
		try {
			if (dbConnection == null) {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				dbConnection = DriverManager.getConnection(System.getProperty("Settings.DBConnectionString"),
						System.getProperty("Settings.DBUsername"), System.getProperty("Settings.DBPassword"));
			}
		}catch(Exception ex) {
			throw new GenericFunctionLevelException(ex);
		}
		return dbConnection;
	}

	public ResultSet getResultSet(String query, String[] queryParams, Connection dbConnection) throws SQLException {
		ResultSet rs = null;
		String Query = query;
		try {
			if (queryParams.length > 0) {
				Query = Utils.editString(query, queryParams);
			}

			Statement stmt = dbConnection.createStatement();
			setResultSet(stmt.executeQuery(Query));
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE, String.format(" Exception occured while establishing connection with database"));
		} finally {
			// if(rs != null)rs.close();
			if (dbConnection != null)
				dbConnection.close();
		}
		return rs;
	}

	public static ResultSet getResultSet() {
		return resultSet;
	}

	public static void setResultSet(ResultSet resultSet) {
		DBHandler.resultSet = resultSet;
	}
}
