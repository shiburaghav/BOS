package com.nttdata.common.util;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class FTPClientUtils {

	private DashboardHandler dashboard;

	public FTPClientUtils() {
		dashboard = DashboardHandler.getInstance();
	}

	/**
	 * check if the file exist on the Secured FTP Site
	 * 
	 * @param serverIp
	 *            - ip address of the server
	 * @param userName
	 *            - username
	 * @param password
	 *            - password
	 * @param folderPath
	 *            - Search location
	 * @param fileName
	 *            - file to search
	 * @param filesAfterDt
	 *            - fileName generated after this datetime
	 * @return - boolean status true or false based on file found or not found
	 */
	public boolean fileExist(String serverIp, String userName, String password,
			String folderPath, final String fileName, final Date filesAfterDt) {
		JSch jsch = new JSch();
		Session session = null;
		boolean isFileFound = false;
		try {
			session = jsch.getSession(userName, serverIp, 22);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(password);
			session.connect();

			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			Vector vList = sftpChannel.ls(folderPath);
			if (!vList.isEmpty() && vList.size() > 0) {
				sftpChannel.cd(folderPath);
				File folder = new File(folderPath);
				File[] fileList = folder.listFiles(new FileFilter() {

					@Override
					public boolean accept(File file) {
						/*System.out
								.println("BatchJobFileProcessor.getFileFromFESFolder(...).new SmbFileFilter() {...}.accept() file : : "
										+ new Date(file.lastModified()));*/
						boolean accepted = false;

						Date remoteFileDate = new Date(file.lastModified());
						if (file.getName().startsWith(fileName)) {
							if (remoteFileDate.compareTo(filesAfterDt) >= 0) {
								accepted = true;
							}
						}
						return accepted;
					}
				});
				isFileFound = fileList != null && fileList.length > 0 ? true
						: false;
			}
			sftpChannel.exit();
			session.disconnect();

		} catch (JSchException e) {
			throw new BPCException(e);
		} catch (SftpException e) {
			throw new BPCException(e);
		}
		return isFileFound;
	}

	/**
	 * check if the downloadFile exist on the Secured FTP Site
	 * 
	 * @param serverIp
	 *            - ip address of the server
	 * @param userName
	 *            - username
	 * @param password
	 *            - password
	 * @param folderPath
	 *            - Search location
	 * @param fileName
	 *            - file to search
	 * @param filesAfterDt
	 *            - fileName generated after this datetime
	 * @return - boolean status true or false based if file is successfully
	 *         downloaded
	 */
	public ArrayList<String> downloadFile(String serverIp, String userName,	String password, String folderPath, final String fileName,	final Date filesAfterDt) {
		JSch jsch = new JSch();
		ArrayList<String> dwlFileList = new ArrayList<String>();
		Session session = null;
		boolean fileFound = false;
		try {
			session = jsch.getSession(userName, serverIp, 22);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(password);
			session.connect();

			Channel channel = session.openChannel("sftp");
			channel.connect();
			boolean b = channel.isConnected();
			String downloadedFileName = null;
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			Vector<LsEntry> vList = sftpChannel.ls(folderPath);
			if (!vList.isEmpty() && vList.size() > 0) {
				sftpChannel.cd(folderPath);
				for (LsEntry file : vList) {
					Date remoteFileDate = new Date(file.getAttrs().getMTime() * 1000L);
					downloadedFileName = file.getFilename();
					if (downloadedFileName.startsWith(fileName)) {
						if (remoteFileDate.compareTo(filesAfterDt) >= 0) {
							fileFound = true;
							break;

						}
					}
					/*System.out.println(String.format("File - %s",
							downloadedFileName + " Date : " + remoteFileDate
									+ " long name : " + file.getLongname()));*/
				}

				if (fileFound) {
					String downloadPath = System.getProperty("Settings.ART Downloads") + File.separator + downloadedFileName;
					File destinationFile = new File(downloadPath);
					sftpChannel.get(downloadedFileName,destinationFile.getAbsolutePath());
					dwlFileList.add(downloadPath);
				}

				else {

					dashboard.setFailStatus(new BPCException("Batch Job File Processing "
											+ "Failed : No new file generated upon running batch job "));

				}

			}
			sftpChannel.exit();
			session.disconnect();

		} catch (JSchException e) {
			throw new BPCException(e);
		} catch (SftpException e) {
			throw new BPCException(e);
		} catch (Exception e) {
			throw new BPCException(e);
		}
		return dwlFileList;
	}

	public void uploadFile(String serverIp, String userName, String password,
			String folderPath, String sourceFile) {
		JSch jsch = new JSch();
		Session session = null;
		try {
			session = jsch.getSession(userName, serverIp, 22);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(password);
			session.connect();

			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			sftpChannel.cd(folderPath);
			File f = new File(sourceFile);

			try {
				sftpChannel.put(new FileInputStream(f), f.getName(),
						ChannelSftp.OVERWRITE);
			} catch (FileNotFoundException e) {

				throw new BPCException(e);
			}
			sftpChannel.exit();
			session.disconnect();
		} catch (JSchException e) {
			throw new BPCException(e);
		} catch (SftpException e) {
			throw new BPCException(e);
		}

	}
}
