package com.nttdata.common.util;
import java.io.File;
import java.util.ArrayList;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class PdfParser 
{
	String filePath = null ; 
	void PDFPasrser(String pdfFilePath)
	{
		this.filePath = pdfFilePath; 
	}
	/*public ArrayList<String> getTextBetweenStrings(String startText,String endText)
	{
	
		PDDocument pdfDoc = null; 
	    String pdfAllTexts = null; 
	    ArrayList<String> allOccurance = null;
		
		File file = new File(filePath);      
	    PDFTextStripper pdfStripper = new PDFTextStripper();	   
	    pdfStripper.setSortByPosition(true);
	    pdfDoc = PDDocument.load(file);
	    pdfAllTexts = pdfStripper.getText(pdfDoc); 
	    String lines[] = pdfAllTexts.split("\\r?\\n");
		allOccurance = pipsObj.getAllValuesBetweenStrings(lines, startText, endText);
		return allOccurance;
	}*/

}
