package com.nttdata.common.util;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//import com.ge.tabula;
//import ge.synergeart.bpc.testdata;

public class PIPSGenerics 
{	

	 public static ArrayList<String> getAllValuesBetweenStrings(String[] pdfLines,String firstString,String secondString)
	   {
		   
	         ArrayList<String>  allOccurance = new ArrayList<String> (); //store the values based on the search , one or more 
	         String returnValue = null;              
	         try 
	         {                   
	          for (String line : pdfLines) 
	          {
	          returnValue = getValueBetweenStrings(firstString,secondString,line);  
	           if (returnValue.trim().length() >0 ) 
	           {
	        	   	//String temp = returnValue.trim().replace(",", "");
	        	   	String temp = returnValue.trim();
	        		if(temp.charAt(temp.length()-1)=='.')
	        		{
	        	   	temp = (String) temp.subSequence(0, temp.length()-1);
	        		}
	        	   	
	                allOccurance.add(temp);                       
	           }
	          }
	  } 
	         catch (Exception  e) 
	         {
	        	 System.out.println("Exception occurred in getAllValuesBetweenStrings(): Exception Message: "+e.getMessage() );
	                //throw BPC custom exception 
	         }
	         return allOccurance; 
	   }
	 
	  public static String getValueBetweenStrings(String startString, String endString, String line)
	   {
		   
	         Pattern p = null; 
	         String regexString = null; 
	         String  returnVal = null; 
	         
	         try {
	         if (endString.trim().length() > 0) regexString = Pattern.quote(startString) + "(.*?)" + Pattern.quote(endString);//create string literal and grouping for the matcher
	         else regexString = Pattern.quote(startString) + "(.*?)" + "$"; //$ stand for the end of the string            
	         p = Pattern.compile(regexString); //compile to a custom regular expression.                             
	         Matcher m = p.matcher(line);            
	           while (m.find()) 
	           {                   
	                   returnVal = m.group(1); //match as per the group expression (.*?)
	           }
	           if (returnVal == null)  return "";
	         }
	         catch(Exception e)
	         {
	        	 System.out.println("Exception occurred in method getAllValuesBetweenStrings() - Exception Message: "+e.getMessage() ); 
	         }
	           return returnVal; 
	   }
	
	
}