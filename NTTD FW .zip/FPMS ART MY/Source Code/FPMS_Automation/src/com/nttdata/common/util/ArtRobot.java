package com.nttdata.common.util;

import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

public class ArtRobot {
	public static void mouseClick(Point point){
		 //For testing
	   Utils.sleep(2);

	    PointerInfo originalMousePointerInfo = MouseInfo.getPointerInfo();
	    Point originalLocation = originalMousePointerInfo.getLocation();
	    int xOrig = (int) originalLocation.getX();
	    int yOrig = (int) originalLocation.getY();

	    try {
	        Robot r = new Robot();

	        r.mouseMove(point.x, point.y);
	        r.delay(1500);        
	        // press the left mouse button
	        r.mousePress(InputEvent.BUTTON1_MASK);
	        // release the left mouse button
	        r.mouseRelease(InputEvent.BUTTON1_MASK);
	      
	    } catch (Exception e) {
	        System.out.println(e.toString());
	    }

	}
	
	public static void saveFile(){
		 Utils.sleep(2);
		try{
	        Robot robot=new Robot();
	        robot.keyPress(KeyEvent.VK_ALT);
	        robot.keyPress(KeyEvent.VK_S);
	        robot.keyRelease(KeyEvent.VK_ALT);
	        robot.keyRelease(KeyEvent.VK_S);    
	    }
	    catch(Exception ex){
	        System.out.println(ex.getMessage());
	    }

	}

}
