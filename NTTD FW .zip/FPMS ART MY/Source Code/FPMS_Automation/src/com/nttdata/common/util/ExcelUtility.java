package com.nttdata.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.nttdata.app.ARTProperties;
import com.nttdata.core.TestCase;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.GenericFunctionLevelException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.FPMSProperties;
import ge.fpms.data.BenefitData;
import ge.fpms.data.FPMSARTDao;
import ge.fpms.data.Policy;
import ge.fpms.data.PolicyHandler;

public class ExcelUtility
{
	private final static Logger LOGGER = Logger.getLogger(ExcelUtility.class.getName());
	//This method will query the excel file.

	public static Recordset queryExcel(String filePath, String excelQuery)
	{
		Recordset recordset = null;
		Connection connection = null;
		try
		{
			Fillo fillo = new Fillo();
			connection = fillo.getConnection(filePath);
			recordset = connection.executeQuery(excelQuery);

			if(recordset.equals(null))
			{
				LOGGER.log(Level.SEVERE, String.format("Query %s is returned null data for excel file location %s",excelQuery, filePath));
			}

			return recordset;

		} catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE,String.format("Exception occured while querying the excel using " + "Query %s is from  file location %s",excelQuery, filePath));

		}
		return recordset;
	}


	public static Recordset queryExcel(String filePath, String excelQuery,String columnRange) throws  Exception
	{		System.setProperty("ROW",columnRange);
	Recordset recordset = null;
	Connection connection = null;
	try
	{
		Fillo fillo = new Fillo();
		connection = fillo.getConnection(filePath);
		recordset = connection.executeQuery(excelQuery);

		if(recordset.equals(null))
		{
			LOGGER.log(Level.SEVERE, String.format("Query %s is returned null data for excel file location %s",excelQuery, filePath));
			throw new GenericFunctionLevelException(new Exception(String.format("Null returned while querying the excel using " + "Query %s is from  file location %s",excelQuery, filePath)));
		}
		System.setProperty("ROW","1");
		return recordset;

	}

	catch (Exception ex)
	{

		System.setProperty("ROW","1");
		LOGGER.log(Level.SEVERE,String.format("Exception occured while querying the excel using " + "Query %s is from  file location %s",excelQuery, filePath));
		throw new GenericFunctionLevelException(new Exception(String.format("Exception occured while querying the excel using " + "Query %s is from  file location %s",excelQuery, filePath)));
	}

	}
	
}








