package com.nttdata.common.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Hashtable;
import java.util.Random;

import com.nttdata.app.ARTProperties;
import com.nttdata.framework.exceptions.BPCException;

public class Utils {

	public static void killProcess(String pName) throws Exception {

		if (isProcessRunning(pName)) {
			Runtime.getRuntime().exec("taskkill /F /IM " + pName);
		}

	}

	public static Boolean isProcessRunning(String pName) {
		String line;
		String pidInfo = "";
		Boolean isRunning = false;
		Process p;BufferedReader input = null;
		try {
			p = Runtime.getRuntime().exec("tasklist.exe");
			//p = Runtime.getRuntime().exec(
				//	System.getenv("windir") + "\\system32\\" + "tasklist.exe");
			input = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			while ((line = input.readLine()) != null) {
				pidInfo += line;
			}

			input.close();
			if (pidInfo.contains(pName)) {
				isRunning = true;
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return isRunning;

	}

	public static void sleep(int seconds)
	{
		try {
			Thread.sleep(1000*seconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * formatDateTime - formats the provided date in the provided formated
	 * @param dt - date to be formatted
	 * @param ft - type of format
	 * @return - the formated date
	 */
	public static String formatDateTime(String dt, String ft){
		SimpleDateFormat format = new SimpleDateFormat(ft);
		Date date;
		String dateTime = "";
		try {
			date = format.parse(dt);
			 dateTime = format.format(date);
		
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateTime;
	}
	
	/**
	 * getCurrentTimeStamp - To get current time stamp as per MS SQL Server format
	 * @return -  timestamp (current Time stamp)
	 */
	public static Timestamp getCurrentTimeStamp()
	{
		Date date = new Date();
		Timestamp timestamp = new Timestamp(date.getTime());
		return timestamp;
	}
	
	public static String formatString(String text){
		
		String formatString =  text.replaceAll("[^a-zA-Z0-9_\\s-]", "");
		if(formatString.length() > 150){
			formatString = formatString.substring(formatString.indexOf(0),140);
			formatString = formatString + "_" + "TRUNCATED";
		}
		return formatString;
	}
	
	public static String generateNRIC(String dateOfBirth, boolean isSingaporean) throws Exception {
		String NRIC = "";
		char []NonSGArray = new char[]{'X', 'W', 'U', 'T', 'R', 'Q', 'P', 'N', 'M', 'L', 'K' };
		char []SGArray = new char[]{ 'J', 'Z', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A'};

		try {
			DateTimeFormatter formatter = DateTimeFormatter
					.ofPattern("dd/MM/yyyy");
			LocalDate dob = LocalDate.parse(dateOfBirth, formatter);
			int dobYear = dob.getYear();

			String dobYearS = Integer.toString(dobYear);
			String dobYearLast2 = dobYearS.substring(2);
			if (isSingaporean) {
				if (dobYear < 2000) {
					NRIC = "S" + dobYearLast2;
				}
				{
					NRIC = "T" + dobYearLast2;
				}
			} else {
				NRIC = "G" + dobYearLast2;
			}
			int loop = 6;
			int temp = 0;
			int rndNumTemp = 0;
			int calSum = 0;
			int calSum1 = 0;
			String rndNumTemp1 = "";
			Random rnd = new Random();
			for (int i = 1; i < 6; i++) {
				rndNumTemp = (int) (rnd.nextInt(9));
				temp = rndNumTemp * loop;
				calSum = calSum + temp;
				loop--;
				rndNumTemp1 = rndNumTemp1 + Integer.toString(rndNumTemp);

			}
			int fchar = Character.getNumericValue(dobYearLast2.charAt(0));
			int lchar = Character.getNumericValue(dobYearLast2.charAt(1));
			NRIC = NRIC + rndNumTemp1;
			calSum1 = (fchar * 2) + (lchar * 7) + calSum;

			if(NRIC.contains("T") || NRIC.contains("G")){
				calSum1 =+4;
			}
			int mod = calSum1 % 11;
			NRIC = isSingaporean ? NRIC + SGArray[mod] : NRIC + NonSGArray[mod];
			
			/*if (calSum1 % 11 == 0) {
				NRIC = NRIC + "J";
			} else if (calSum1 % 11 == 1) {
				NRIC = NRIC + "Z";
			} else {
				NRIC = NRIC + Character.toString((char) (75 - (calSum1 % 11)));
			}*/

		} catch (Exception e) {
			throw new BPCException("Error while generating NRIC code!!");

		}
		return NRIC;
	}
	
	public static void deleteFiles(File path) {
		if (path.exists()) {
			File[] c = path.listFiles();
			System.out.println("Cleaning out folder:" + path.toString());
			for (File file : c) {
				if (file.isDirectory()) {
					System.out.println("Deleting file:" + file.toString());
					deleteFiles(file);
					file.delete();
				} else {
					file.delete();
				}
			}
			path.delete();
		}
	}

	public static void editXpath(String webElementKey, String newWebElementKey, String[] charToBeReplacedWith) {
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);
		
		Hashtable<String, String> hTableGUIMapNew  = new Hashtable<String, String>();
		String tempXPath = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]);
		String xPathParts[] = tempXPath.split("##");
		StringBuilder builder = new StringBuilder();
		builder.append(xPathParts[0]);
		for (int i = 0; i < charToBeReplacedWith.length; i++) {
			builder.append(charToBeReplacedWith[i]);
			builder.append(xPathParts[i + 1]);
		}
		hTableGUIMapNew.put("xpath", builder.toString());
		if(ARTProperties.guiMap.containsKey(newWebElementKey)) {
			ARTProperties.guiMap.replace(newWebElementKey, hTableGUIMapNew);
		}else {
			ARTProperties.guiMap.put(newWebElementKey, hTableGUIMapNew);
		}
	}
	
	public static String editString(String oldString, String[] charToBeReplacedWith) {
		
		String parts[] = oldString.split("##");
		StringBuilder builder = new StringBuilder();
		builder.append(parts[0]);
		for (int i = 0; i < charToBeReplacedWith.length; i++) {
			builder.append(charToBeReplacedWith[i]);
			builder.append(parts[i + 1]);
		}
		return builder.toString();
	}
	
	public static void executeScript(String string) {
		// TODO Auto-generated method stub
		
	}
	public static boolean isAlpha(String name) {
	    return name.matches("[a-zA-Z]*");
	}
	public static boolean isNumeric(String name) {
	    return name.matches("[0-9]*");
	}

	public static String leftPad(String str, Integer length, char car) {
		  return (str + String.format("%" + length + "s", "").replace(" ", String.valueOf(car))).substring(0, length);
		}

	public static String rightPad(String str, Integer length, char car) {
	  return (String.format("%" + length + "s", "").replace(" ", String.valueOf(car)) + str).substring(str.length(), length + str.length());
	}
	
	/**
	 * formatDateTime - formats the provided date in the provided formated
	 * @param dt - date to be formatted
	 * @param ft - type of format
	 * @return - the formated date
	 */
	public static String formatDateTime(String dt, String currentft, String newFormat){
		SimpleDateFormat format = new SimpleDateFormat(currentft);
		SimpleDateFormat newFmat = new SimpleDateFormat(newFormat);
		Date date;
		String dateTime = "";
		try {
			date = format.parse(dt);
			dateTime = newFmat.format(date);
		
		} catch (ParseException e) {
			throw new BPCException (e);
		}
		return dateTime;
	}
	public static Date getDateTime(String dateTime, String sdf) {
		
		
		SimpleDateFormat format = new SimpleDateFormat(sdf);
		Date dt;
		try {
			dt = format.parse(dateTime.trim());

		} catch (ParseException e) {
			throw new BPCException(e);
		}

		return dt;
	}
}
