package com.nttdata.common.util;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;

import org.openqa.selenium.JavascriptExecutor;

import ge.fpms.main.actions.FPMS_Actions;

public class AWTScreenshot {
	/**
	 * @author Mahammad Rasheed M
	 * @param :
	 *            Takes the File Name jpeg format and saves the file in specified
	 *            file name location
	 * @return void
	 * @exception :
	 *                File not found
	 * 
	 */
	
	private final static Logger LOGGER = Logger.getLogger(AWTScreenshot.class.getName());

	public static void captureScreenshot1(String filename) {
		try {
			Robot robot = new Robot();
			Toolkit toolkit = Toolkit.getDefaultToolkit();
			Dimension dim = toolkit.getScreenSize();
			BufferedImage bi = robot.createScreenCapture(new Rectangle(dim.width, dim.height));
			try {
				File f = new File(filename);
				Iterator<?> iter = ImageIO.getImageWritersByFormatName("jpeg");
				ImageWriter writer = (ImageWriter) iter.next();
				ImageWriteParam iwp = writer.getDefaultWriteParam();
				iwp.setCompressionMode(ImageWriteParam.MODE_EXPLICIT); // This will compress the image quality
				iwp.setCompressionQuality(0.3f);
				ImageIO.write(bi, "jpeg", f);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Error while taking the screenshot " + e.getMessage());
		}
	}

	public static void captureScreenshot(String filename) {
		FPMS_Actions llAction = new FPMS_Actions();
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Dimension dim = toolkit.getScreenSize();
		int waitTime = 0;
		try {
			
			waitTime = Integer.parseInt(System.getProperty("Settings.ImplicitWait"));
			System.setProperty("Settings.ImplicitWait","0");
			if (llAction.isAlertDisplayed()) {
				captureScreenshot1(filename);
			} else {
				HashMap<String, Integer> hMap = llAction.getFPMSScreenDimensions();
				int temp = 0;
				llAction.scrollTo(0, 0);
				List<BufferedImage> images = new ArrayList<BufferedImage>();
				BufferedImage mergedImage = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
				if (hMap.get("windowHeight").equals(hMap.get("totalHeight"))) {
					captureScreenshot1(filename);// Custom function created to capture when there in no scroll for a
													// single page.

				} else {
					do {
						Robot robot = new Robot();
						images.add(robot
								.createScreenCapture(new Rectangle(dim.width, dim.height)));

						temp = temp-5 + hMap.get("windowHeight");
						llAction.scrollTo(0, temp);
					} while (hMap.get("totalHeight") > temp);

					for (int i = 0; i < images.size(); i++) {
						mergedImage = joinBufferedImage(mergedImage, images.get(i));
					}
					ImageIO.write(mergedImage, "PNG", new File(filename));
				}
			}
			
		} catch (

		Exception e) {			
			LOGGER.log(Level.SEVERE, "Error while taking the screenshot " + e.getMessage());			
		}
		finally
		{
			if(waitTime != 0)
			System.setProperty("Settings.ImplicitWait",Integer.toString(waitTime));
		}
	}

	public static BufferedImage joinBufferedImage(BufferedImage img1, BufferedImage img2) throws Exception {
		int offset = 2;
		int width = img1.getWidth() + img2.getWidth() + offset;
		int height = Math.max(img1.getHeight(), img2.getHeight()) + offset;
		BufferedImage newImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = newImage.createGraphics();
		Color oldColor = g2.getColor();
		g2.setPaint(Color.BLACK);
		g2.fillRect(0, 0, width, height);
		g2.setColor(oldColor);
		g2.drawImage(img1, null, 0, 0);
		g2.drawImage(img2, null, img1.getWidth() + offset, 0);
		g2.dispose();
		return newImage;
	}

}
