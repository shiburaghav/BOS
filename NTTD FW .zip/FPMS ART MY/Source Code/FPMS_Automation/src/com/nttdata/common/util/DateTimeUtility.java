package com.nttdata.common.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

public class DateTimeUtility 
{
	private final static  Logger LOGGER = Logger.getLogger(DateTimeUtility.class.getName());
	public static String GetFormattedDate()
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
		Date date = new Date();
		System.out.println(dateFormat.format(date)); //2016/11/16 12:08:43
		return null;
		
	}
	
	
	
	public static String GetCurrentDateTime()
	{
		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd HH:MM:ss.SSS");
		Date date = new Date();
		System.out.println(dateFormat.format(date)); //2016/11/16 12:08:43
		return null;
		
	}
	
	
}
