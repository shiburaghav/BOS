package com.nttdata.common.util;

public enum ColumnHeader {

Login(1), PartyCreation(5), Registration(5), Underwriting_Document_Mgmt(5), ReceiveCounterCollection(
			2), NR_ApplicationEntry(5), ChangeBeneficiary(5), BATCHJOBENTRY(2), ChangeBenefits(
					5), FinancialManualAdjustment(5), Collection(5), SmokerStatusOrForeignerInd(5), SBOrCBOption(
							5), RPApportionment(5), FullSurrender(5), ChangeAssignment(5), AddRider(5),IncreaseSA(5), DeleteRider(
									5), InvestmentRP(5), Cancellation(5),PartialWithdraw(5),SetOrChangeRecurringTopUp(5),SwitchFundAdHoc(5), DisbursementMethod(
											5), IncludeUnitDeductionRider(5), PaymentFrequency(5),ChangeTrustee(5), ChangeCommencementDate(5),Reinstatement(5), 
											DOBorGender(5),Freelook(5), PaymentMethod(5),PolicyBasicInfo(5), AdhocSPTopup(5),PolicyManagement(5),DecreaseSA(5),
	Surrender(5),ApplyPolicyloan(5),ChangePolicyHolder(5),Party(5),ChangeTerm(5), Admin(4),MedicalBilling(2),CaseRegistration(5),UnlockFrozenPolicy(5),HealthWarrantyConsent(2),BCP(4), CaseAcceptanceDetails(5),
	Liability(2),Claims(5),GeneralContractualEndorsement(5),PolicyMgmt(2),Finance(5),PartialSurrender(5),PaymentRequisition(4),BCP_Collection(2),CSD_Collection(2), SQLQuery(2),CancelPayment(4),Payment(4),BatchJobEntry_1(2),BatchJobEntry_2(2),BatchJobEntry_3(2),
	BatchJobEntry_4(2),ClaimsMalaysiaSpecific(5),ChangePayment(4),Cheque_Printing(4),ChangeDisbursmentPlan(5),ChangeBenefitAllocation(5),AdjustmentAmount(2),ClaimInvestigation(5),
	GIRO(2),BatchJobEntry1(2),BatchJobEntry2(2),BatchJobEntry3(2),BatchJobEntry4(2), LOCKBOX(2);

	private int column;

	private ColumnHeader(int val) {
		column = val;
	}

	public int getColumnHeader() {
		return column;
	}

	public String toString() {
		return name();
	}

	public static int getColumnHeader(String sheetName) {
		for (ColumnHeader e : ColumnHeader.values()) {
            if(sheetName.equalsIgnoreCase(e.name().toString())) return e.getColumnHeader();
		}
		return 1;
	}
}
