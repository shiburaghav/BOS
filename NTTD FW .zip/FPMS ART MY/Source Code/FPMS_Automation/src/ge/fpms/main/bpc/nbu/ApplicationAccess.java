package ge.fpms.main.bpc.nbu;


import ge.fpms.data.Login;
import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.FPMSProperties;

import java.util.Hashtable;

import com.nttdata.common.util.Utils;
import com.nttdata.common.util.WindowsUtility;
import com.nttdata.core.LL_Actions;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class ApplicationAccess
{
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	
	public ApplicationAccess() {
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}
	public void login(Hashtable<String, String> hParams) throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		try {
			WindowsUtility.keepSystemActive();
			LL_Actions llAction = new LL_Actions();

			llAction.openApplication(System.getProperty("Settings.Browser"),
					System.getProperty("Settings.Application URL"),FPMSProperties.getInstance().getDriverPath());
			dashboard.writeResults();

			llAction.selectByVisibleText("web_lst_frameworkList", hParams.get("FrameworkList"));

			dashboard.setStepDetails("Select Framework List",
					"Framework List: " + hParams.get("FrameworkList") + " should be selected successfully", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_signIn_enter");

			llAction.waitUntilLoadingCompletes();

			llAction.enterValue("web_txt_userName", hParams.get("UserName"));

			llAction.enterValue("web_txt_Password", hParams.get("Password"));

			llAction.selectByVisibleText("web_lst_CountryCode", hParams.get("Country"));

			dashboard.setStepDetails("Enter Login credentials",
					"Login credentials for user: " + hParams.get("UserName") + " should be entered successfully",
					"N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_submit");
			if (hParams.get("FrameworkList").equals("External (Internet application)")) {
				llAction.enterValue("web_txt_otp", hParams.get("OTP"));
				llAction.clickElement("web_btn_submit");
			}

			dashboard.setStepDetails("Verify the user is naigated to the FPMS Home page",
					"The FPMS Home page should be displayed", "N/A");
			dashboard.writeResults();
			policyHandler.initializePolicy();
			save(hParams);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void logout(Hashtable<String, String> hParams) throws Exception {
		try {

			LL_Actions llAction = new LL_Actions();
			llAction.waitUntilLoadingCompletes();
			llAction.waitUntilElementPresent("web_lnk_logoutLink");
			llAction.clickElementJs("web_lnk_logoutLink");
			
			llAction.waitUntilLoadingCompletes();
			llAction.waitUntilElementPresent("web_txt_userName");
			dashboard.setStepDetails("Click on  Logout", "The application is logged out", "N/A");
			dashboard.writeResults();

			// llAction.quitApplication();
		} catch (Exception e) {
			throw new BPCException(e);
		}
		WindowsUtility.keepSystemActive();
	}

	/*
	 * Name: save Purpose: Method is called to set the user name and password of a
	 * approver Parameters: NA Return Value: NA Exception: BPC Exception on
	 * component execution fail Author : Shree Ganesh
	 */

	private void save(Hashtable<String, String> hParams) {

		Login login = FPMSManager.getInstance().getLoginHandler();
		login.setUserName(hParams.get("ApproverUserName"));
		login.setPassword(hParams.get("ApproverPassword"));
		login.setCountry(hParams.get("Country"));
		login.setFrameworkList(hParams.get("FrameworkList"));
	}

	/*
	 * Name: getAccessParameters Purpose: Method is called to get the user name and
	 * password of a approver Parameters: NA Return Value: NA Exception: BPC
	 * Exception on component execution fail Author : Shree Ganesh
	 */
	public Hashtable<String, String> getAccessParameters() throws Exception {

		Hashtable<String, String> hParams = new Hashtable<String, String>();
		Login login = FPMSManager.getInstance().getLoginHandler();
		hParams.put("UserName", login.getUserName());
		hParams.put("Password", login.getPassword());
		hParams.put("Country", login.getCountry());
		hParams.put("FrameworkList", login.getFrameworkList());

		return hParams;
	}
}
