package ge.fpms.main.bpc.csd;
import java.util.Hashtable;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class Transaction {
	
	FPMS_Actions llAction = new FPMS_Actions();

	public Transaction() {
		
	}	
	
	public void changePaymentMethod(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			if  (llAction.isDisplayed("web_btn_continue",8)) 
			{ 
				llAction.clickElement("web_btn_continue");
			}
			CSDHelper.getInstance().captureChange("changepaymentmethod", "BeforeChange");
			llAction.enterValue("web_txt_ILPTopUp_ValidityDate",hParams.get("Validitydate"));
			llAction.selectByVisibleText("web_list_Tsn_PaymentMethod", hParams.get("Paymentmethod"));
			CSDHelper.getInstance().captureChange("changepaymentmethod", "AfterChange");			
			llAction.clickElement("web_Btn_Submit");
			llAction.waitUntilLoadingCompletes();
			if  (llAction.isDisplayed("web_btn_continue",8)) 
			{ 
				{
					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg",hParams.get("WarningErrorMessage"));
				}
				llAction.clickElement("web_btn_continue");
			}
			CSDHelper.getInstance().endOfTransaction();
		}
		catch (Exception ex) 
		{
			throw new BPCException("changePaymentMethod");
		}

	}
}


