package ge.fpms.main.bpc.claims;

import java.sql.Driver;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.ColumnHeader;
import com.nttdata.common.util.Utils;
import com.nttdata.core.components.table.TableColumn;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.data.Claims;
import ge.fpms.data.Login;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.ProductConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class Case extends BusinessComponent {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private Claims caseHandler;
	private Claims claims;
	private final String ADJUSTMENT_SHEET = "AdjustmentAmount";

	public Case() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		caseHandler = FPMSManager.getInstance().getCaseHandler();
		claims = Claims.getInstance();
	}

	public void searchAndProcessCaseTillEvaluation(Hashtable<String, String> hParams) throws Exception {

		try {
			searchClaimsProcessingPoolbyCaseNumber(hParams);
			enterCaseAcceptanceEntryDetails(hParams);
			updateAcceptanceSummary(hParams);

			if (StringUtils.isEmpty(hParams.get("ClaimDecision"))) {
				llAction.clickElement("web_evaluation_btn_exitToPool");
				llAction.waitUntilLoadingCompletes();
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	/*
	 * Name: searchCase Purpose: Search by case number And Validate the search
	 * results Case Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void searchClaimsProcessingPoolbyCaseNumber(Hashtable<String, String> hParams) throws Exception {
		try {

			if (caseHandler.isCaseNumberEmpty()) {
				caseHandler.setCaseNumber(hParams.get("CaseNumber"));
			}
			String caseNumber = caseHandler.getCaseNumber();

			// navigate to claims processing pool
			llAction.selectMenuItem("Claim", "Claims Processing Pool");
			llAction.waitUntilElementPresent("web_txt_ClaimsProcessingPool_CaseNumber");
			llAction.clickElement("web_btn_ClaimsProcessingPool_Reset");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_ClaimsProcessingPool_CaseNumber", caseNumber);
			// few more search criteria.

			// llAction.enterValue("web_claimsprocessingpool_policyNumber",
			// hParams.get("PolicyNumber"));
			// llAction.selectByVisibleText("web_claimsprocessingpool_claimType",
			// hParams.get("TypeOfClaim"));
			// llAction.selectByVisibleText("web_claimsprocessingpool_caseStatus",
			// hParams.get("SearchCaseStatus"));

			llAction.clickElement("web_txt_ClaimsProcessingPool_Search");
			llAction.waitUntilLoadingCompletes();
			validateSearchResults(hParams, true);
		}

		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: Validate the search results based on the flag set Case Parameters:
	 * hParams Return Value,boolean flag: NA Exception: BPCException
	 */
	public void validateSearchResults(Hashtable<String, String> hParams, boolean countToBeDisplayed) throws Exception {
		try {

			int recordsCountColPos = llAction.GetColumnPositionInTable("web_tbl_ClaimsProcessingPool_searchResults",
					"0 Records");
			if (countToBeDisplayed) {
				if (recordsCountColPos != 0) {
					dashboard.setFailStatus(new BPCException("0 records displayed."));
					dashboard.writeResults();
				} else {
					dashboard.setStepDetails("Verify search results in the Claims Processing Pool Screen",
							"Record(s) displayed.", "N/A");
					dashboard.writeResults();

				}
			} else {
				dashboard.setStepDetails("Verify search results in the Claims Processing Pool Screen",
						"Record(s) displayed.", "N/A");
				dashboard.writeResults();
			}
		}

		catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	/*
	 * Name:enterCaseAcceptanceEntryDetails Purpose:To enter all case acceptance
	 * details in the case acceptance entry screen Case Parameters: hParams Return
	 * Value,boolean flag: NA Exception: BPCException
	 */
	public void enterCaseAcceptanceEntryDetails(Hashtable<String, String> hParams) throws Exception {
		try {

			if (caseHandler.getCaseNumber().isEmpty()) {
				caseHandler.setCaseNumber(hParams.get("CaseNumber"));
			}
			String caseNumber = caseHandler.getCaseNumber();

			int colPos = llAction.GetColumnPositionInTable("web_tbl_ClaimsProcessingPool_searchResults", "Case Number");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_ClaimsProcessingPool_searchResults", caseNumber,
					colPos);
			llAction.SelectRowInTable("web_tbl_ClaimsProcessingPool_searchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();
			llAction.selectByVisibleText("web_lst_CaseAcceptanceEntry_ClaimNature", hParams.get("ClaimNature"));
			// Adding Malaysia specific fields.
			// add last documentation date

			String eventDate = hParams.get("EventDate");
			// String notificationDate = hParams.get("LastDocSubmissionDate");
			if (StringUtils.isEmpty(eventDate) && !claims.isSysDateEmpty()) {
				eventDate = claims.getSysDate();
			}

			String lastDocSubmissionDate = hParams.get("LastDocSubmissionDate");
			if (StringUtils.isEmpty(lastDocSubmissionDate) && !claims.isSysDateEmpty()) {
				lastDocSubmissionDate = claims.getSysDate();
			}
			String notificationDate = hParams.get("NotificationDate");
			if (StringUtils.isEmpty(notificationDate) && !claims.isSysDateEmpty()) {
				notificationDate = claims.getSysDate();
			}
			llAction.enterValue("web_claimsprocessingpool_lastDocSubmitDate", lastDocSubmissionDate);
			llAction.enterValue("web_claimsprocessingpool_notificationDate", notificationDate);

			updateDiagnosisCode(hParams);
			updateHospitalCode(hParams);
			// update LG data
			String lgCaseChecBox = hParams.get("LGCase");
			if (lgCaseChecBox.equalsIgnoreCase("On")) {
				llAction.checkBox_Check("web_claimsprocessingpool_chk_LGCase");
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_claimsprocessingpool_lst_LGStatus", hParams.get("LGStatus"));
				llAction.enterValue("web_claimsprocessingpool_lst_LGNumber", hParams.get("LGNumber"));

			}

			llAction.selectByVisibleText("web_lst_CaseAcceptanceEntry_CaseClassification",
					hParams.get("CaseClassification"));
			dashboard.setStepDetails("Enter Claim Acceptance details", "Claim Acceptance details should be entered",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_txt_ClaimsProcessingPool_Next");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Next button ", "Acceptance Summary Screen Should be displayed", "N/A");
			dashboard.writeResults();
		}

		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void updateAcceptanceSummary(Hashtable<String, String> hParams) throws Exception {

		try {
			String caseAcceptancePolicyDecision = hParams.get("AcceptanceDecision").trim();
			String byPassCheckListForCompleteness = hParams.get("BypassCheckListCompleteness").trim();
			String priceEffectiveDate = hParams.get("PriceEffectiveDateILPProduct").trim();
			String reason = hParams.get("Reason").trim();
			llAction.switchtoFrame(2);
			llAction.selectByVisibleText("web_lst_ClaimsAcceptancePolicy_acceptDecision", caseAcceptancePolicyDecision);
			if (caseAcceptancePolicyDecision.equalsIgnoreCase("CANCEL")
					|| caseAcceptancePolicyDecision.equalsIgnoreCase("WITHDRAWN")) {
				if (reason.isEmpty() == true) {
					dashboard.setFailStatus(new BPCException("Reason is required for " + caseAcceptancePolicyDecision));
					dashboard.writeResults();
				} else {
					llAction.selectByVisibleText("web_lst_ClaimsAcceptancePolicy_reason", reason);
				}
			}

			if (byPassCheckListForCompleteness.isEmpty() == false) {
				llAction.selectByVisibleText("web_lst_ClaimsAcceptancePolicy_bypassCheckListCompleteness",
						byPassCheckListForCompleteness);
			}
			if (llAction.isEnabled("web_evaluation_txt_ILPEffectiveDate")) {
				WebElement webElement = llAction.returnWebElement("web_evaluation_txt_ILPEffectiveDate");
				String readonly = webElement.getAttribute("readonly");
				if (!"true".equals(readonly)) {
					llAction.enterValue("web_evaluation_txt_ILPEffectiveDate", priceEffectiveDate);
				}
			}
			dashboard.setStepDetails("Fill in Acceptance summary", "System should accept input details", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_ClaimsAcceptancePolicy_save");
			Utils.sleep(2);
			Long timeout = (long) 0;
			if (llAction.isAlertDisplayed(timeout)) {
				dashboard.setStepDetails("Click on Save button", "Save button is clicked.", "N/A");
				dashboard.writeResults();
				String alertText = llAction.getAlertText();
				llAction.acceptAlert();
				dashboard.setFailStatus(new BPCException("An error or warning  " + alertText
						+ " is displayed. Please check acceptance status before this case can be accepted."));

			}
			llAction.waitUntilLoadingCompletes();

			llAction.switchtoChildWindow("Case Acceptance Confirmation");
			validateCaseAcceptanceConfirmation(hParams);
		}

		catch (Exception ex) {
			ex.printStackTrace();
			throw new BPCException(ex);
		}
	}

	public void validateCaseAcceptanceConfirmation(Hashtable<String, String> hParams) throws Exception {
		try {
			String caseAcceptanceStatus = hParams.get("CaseStatus");
			String caseAcceptanceConfirmation = llAction
					.getText("web_txt_ClaimsAcceptanceConfirm_AcceptanceConfirmMsg");
			if (caseAcceptanceConfirmation.toLowerCase().contains(caseAcceptanceStatus.toLowerCase())) {
				dashboard.setStepDetails(caseAcceptanceStatus + " Should be populated", "Message is validated", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setFailStatus(new BPCException("Case could not be '" + caseAcceptanceStatus + "'"));
				dashboard.writeResults();
				dashboard.setFailStatus(
						new BPCException(caseAcceptanceStatus + " message is invalid/Submit was not successful"));
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void updateDiagnosisCode(Hashtable<String, String> hParams) throws Exception {
		try {

			// Launch hospital code UI
			llAction.clickElement("web_claimsprocessingpool_diagnosisCategory");
			llAction.waitUntilLoadingCompletes();
			llAction.handleCertificateErrors();
			llAction.waitUntilLoadingCompletes();

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_SearchLDiagnosisCode);
			llAction.enterValue("web_claimsprocessingpool_diagnosisCode", hParams.get("DiagnosisCode"));
			llAction.sendkeyStroke("web_claimsprocessingpool_diagnosisCode", Keys.ENTER);
			llAction.clickElement("web_claimsprocessingpool_btn_Search");
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_txt_select_diagnosis_code", "Select_diagnosis_code",
					new String[] { hParams.get("DiagnosisCode") });
			dashboard.setStepDetails("Click on diagnosis code after selecting diagnostic code",
					"diagnostic code should be selected", "N/A");
			dashboard.writeResults();
			llAction.clickElement("Select_diagnosis_code");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoChildWindow("Case Acceptance Entry");

		}

		catch (Exception ex) {
			ex.printStackTrace();
			throw new BPCException(ex);
		}
	}

	public void updateHospitalCode(Hashtable<String, String> hParams) throws Exception {
		try {

			// Launch hospital code UI
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_searchHospital_lnk_hospitalCode");
			llAction.waitUntilLoadingCompletes();
			llAction.handleCertificateErrors();
			llAction.waitUntilLoadingCompletes();

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_SearchHospitalCode);
			llAction.enterValue("web_claimsprocessingpool_providerCode", hParams.get("ProviderCode"));
			llAction.sendkeyStroke("web_claimsprocessingpool_providerCode", Keys.ENTER);

			if (hParams.get("web_claimsprocessingpool_providerDesc") == null
					&& hParams.get("web_claimsprocessingpool_providerDesc") == "") {
				llAction.enterValue("web_claimsprocessingpool_providerDesc", hParams.get("ProviderDesc"));
				llAction.sendkeyStroke("web_claimsprocessingpool_providerDesc", Keys.ENTER);
			}

			llAction.clickElement("web_claimsprocessingpool_btn_Search");
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_txt_select_hospital_code", "Select_Hospital_code",
					new String[] { hParams.get("ProviderCode") });
			dashboard.setStepDetails("Click on submit after selecting Provider Code ",
					"Provider Code should be selected", "N/A");
			dashboard.writeResults();
			llAction.clickElement("Select_Hospital_code");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoChildWindow("Case Acceptance Entry");

		}

		catch (Exception ex) {
			ex.printStackTrace();
			throw new BPCException(ex);
		}
	}

	public void updateCaseInvestigationDetail(Hashtable<String, String> hParams) throws Exception {
		try {

			// navigate to the claim investigation detail menu
			llAction.selectMenuItem("Claim", "Claims Investigation Detail");
			llAction.waitUntilLoadingCompletes();
			// Enter case no and policy no:
			llAction.enterValue("web_ci_text_caseNo", hParams.get("CaseNumber"));
			llAction.enterValue("web_ci_text_policyNo", hParams.get("PolicyNumber"));
			// click on search button
			dashboard.setStepDetails("Enter Case Number and Policy Number and click on search",
					"Case Number and Policy Number is entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_ci_btn_search");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Search result should be displayed",
					"Search result is displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_ci_btn_add");
			dashboard.setStepDetails("Click Add button and claim investigation details should be displayed",
					"Navigate to Claim Investigation Detail page", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			addClaimInvestigationDetail(hParams);

		}

		catch (Exception ex) {
			ex.printStackTrace();
			throw new BPCException(ex);
		}
	}

	private void addClaimInvestigationDetail(Hashtable<String, String> hParams) throws BPCException {
		try {
			// Enter claim investigation detail.
			llAction.enterValue("web_ci_text_receiepntInfo", hParams.get("ReceiepentName"));
			llAction.enterValue("web_ci_text_receiepntDesc", hParams.get("ReceiepentDesc"));
			llAction.enterValue("web_ci_text_sendDate", hParams.get("SendDate"));
			llAction.enterValue("web_ci_text_receievedDate", hParams.get("ReceievedDate"));
			llAction.enterValue("web_ci_text_assignedDate", hParams.get("AssignedDate"));
			llAction.selectByVisibleText("web_ci_list_decision", hParams.get("ClaimInvDecision"));
			llAction.selectByVisibleText("web_ci_gst_applicable", hParams.get("GSTApplicable"));
			llAction.enterValue("web_ci_gst_feeAmount", hParams.get("FeeAmount"));
			llAction.sendkeyStroke("web_ci_gst_feeAmount", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_ci_gst_gstAmount", hParams.get("CIGSTAmount"));
			llAction.sendkeyStroke("web_ci_gst_gstAmount", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			//llAction.enterValue("web_ci_gst_TotalfeeAmount", hParams.get("CITotalFeeAmount"));
			dashboard.setStepDetails("Enter the details for claim investigation",
					"Details for claim investigation is accepted by the system", "N/A");
			dashboard.writeResults();
			// Click on Edit
			llAction.clickElement("web_ci_btn_edit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on edit button payee information should be displayed",
					"Payee information is displayed", "N/A");
			dashboard.writeResults();
			// input the disbursement method.
			llAction.selectByVisibleText("web_ci_inv_disbursemntMthd", hParams.get("DisbursementMethod"));

			// click on payee name hyper link
			llAction.clickElement("web_ci_lnk_payeename");
			llAction.switchtoSecondWindow();
			llAction.handleCertificateErrors();
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_partyName", hParams.get("Name"));
			llAction.enterValue("web_txt_partyrecordno", hParams.get("PartyRecordNo"));
			llAction.enterValue("web_txt_partyidnumber", hParams.get("PartyIDNumber"));
			llAction.selectByVisibleText("web_txt_partyidtype", hParams.get("PartyIDType"));
			dashboard.setStepDetails("Enter Party Details for the search",
					"Enter Party Details for search is accepted", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_txt_ClaimsProcessingPool_Next");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on next button",
					"Search result is displayed", "N/A");
			dashboard.writeResults();
			int partyNameCol = llAction.GetColumnPositionInTable("web_tbl_partyList", "Name");
			int partyRow = llAction.GetRowPositionInTable("web_tbl_partyList", hParams.get("Name"), partyNameCol);
			int partyRecordNoCol = llAction.GetColumnPositionInTable("web_tbl_partyList", "Party Record No");
			llAction.SelectRowInTable("web_tbl_partyList", partyRow, partyRecordNoCol, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on PartyRecordNo link",
					"Create and Maintain Party-Step 2 page is displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_registration_btn_submit");			
			if(llAction.isDisplayed("web_btn_continuebutton",5))
			{				
				llAction.clickElement("web_btn_continuebutton");				
			}
			llAction.switchtoDefaultWindow();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Party details for selected party should be displayed",
					"Party details for selected party is displayed", "N/A");
			dashboard.writeResults();
			// click on save
			llAction.clickElement("web_evaluation_btn_save");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on save button",
					"Investigation details is saved", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_registration_btn_exit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on exit button",
					"Claim Investigation screen is displayed", "N/A");
			dashboard.writeResults();
			llAction.selectByVisibleText("web_tbl_investigationstatus", hParams.get("InvestigationStatus"));
			dashboard.setStepDetails("Select Investigation status",
					"Claim Investigation status is selected", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_registration_btn_submit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click submit on claim investigation page",
					"Claim investigation should be submitted", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_registration_btn_exit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception e) {
			throw new BPCException(e);
		}

	}

	public void updateBenefitAllocation(Hashtable<String, String> hParams) throws Exception {
		try {
			
			//Launch Change the benefit Allocation UI
			llAction.waitUntilLoadingCompletes();
			llAction.selectMenuItem("Claim", "Change Benefit Allocation");
			llAction.waitUntilLoadingCompletes();
			
			llAction.switchtoDefaultContent();
			llAction.switchtoFrame("main");
			//Enter Case Number 
			llAction.enterValue("web_ci_text_caseNo", hParams.get("CaseNumber"));	
			llAction.sendkeyStroke("web_ci_text_caseNo", Keys.ENTER);
			//UI opens up with policies and benefits .
			llAction.waitUntilLoadingCompletes();
			Utils.sleep(10);
			llAction.switchtoDefaultContent();
			llAction.switchtoFrame("left");
			dashboard.setStepDetails("Amend Policy screen should be displayed",
					"Amend Policy screen is displayed", "N/A");
			dashboard.writeResults();
			
			List<WebElement> allParents = llAction.findElements("web_evaluation_expand_tree_lnk");
			for (int j = 0; j < allParents.size(); j++) {

				WebElement parent = allParents.get(j);

				Hashtable<String, String> childElementPath = ARTProperties.guiMap.get("web_div_childnode_name");
				String childPath = childElementPath.get(childElementPath.keySet().toArray()[0]);
				childPath = childPath.replace("0", String.valueOf(j));
		
				List<WebElement> allChildren = llAction.findElementsByXpath(childPath);

				for (int i = 0; i < allChildren.size(); i++) {
					WebElement element = allChildren.get(i);
					browseCase(parent);
					String benefitName = element.getText();
					//if String benefitName.equalsIgnoreCase(arg0)
					llAction.clickElementJs(element);// selecting the product
					// switching to main frame for evaluating product details					
					llAction.switchtoDefaultContent();
					llAction.switchtoFrame("main");
					llAction.waitUntilLoadingCompletes();
					updateBenfitAllocationDetails(benefitName);
					llAction.switchtoDefaultContent();
					llAction.switchtoFrame("left");

					// reinitializing the list as after swtiching between frames, it is throwing
					// staleElementexception
					allChildren = llAction.findElementsByXpath(childPath);
					allParents = llAction.findElements("web_evaluation_expand_tree_lnk");
					parent = allParents.get(j);
				}
			}
			
			List<WebElement> allParentPolicies = llAction.findElements("web_evaluation_click_policy");
			allParents = llAction.findElements("web_evaluation_expand_tree_lnk");
			for (int j = 0; j < allParents.size(); j++) {
				WebElement parent = allParents.get(j);
				WebElement parentPolicy = allParentPolicies.get(j);
				browseCase(parent);
				llAction.clickElementJs(parentPolicy);
				llAction.waitUntilLoadingCompletes();
				llAction.switchtoDefaultContent();
				llAction.switchtoFrame("main");
				llAction.waitUntilLoadingCompletes();
				updateAdjustment(hParams);
				dashboard.setStepDetails("Policy details should be displayed", "Policy details should be displayed", "N/A");
				dashboard.writeResults();
				llAction.switchtoDefaultContent();
				llAction.switchtoFrame("left");
				allParentPolicies = llAction.findElements("web_evaluation_click_policy");
				allParents = llAction.findElements("web_evaluation_expand_tree_lnk");
				
			}
			
		}

		catch (Exception ex) {
			ex.printStackTrace();
			throw new BPCException(ex);
		}
	}

	private void browseCase(WebElement parent) {
		// String childWebElementNode = "web_div_childnode_name";
		WebElement img = parent.findElement(By.tagName("img"));
		img.getAttribute("src").contains("Tplus");
		try {
			if (img.getAttribute("src").contains("Tplus")) {
				llAction.sendkeyStroke("web_evaluation_expand_tree_lnk", Keys.ENTER);
				llAction.clickElementJs(parent);
				llAction.waitUntilLoadingCompletes();
				Utils.sleep(2);
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}

	private void updateBenfitAllocationDetails(String BenefitName) throws BPCException {
		try {
			Long timeOut = (long) 10;
			boolean isBenefitAllocated = false;
			int i = 0, rowPos,rIndx=2;	
			
			
			
			Hashtable<String, String> benefitdetails = getBenefitAllocation(BenefitName);			
			
			String ReversionaryAdjAmount = benefitdetails.get("ReversionaryBonus");
			llAction.enterTextInTable("web_ba_tbl_benefit_allocation", rIndx, 3, ReversionaryAdjAmount,
					"/input[@name='adjAmount']");
			llAction.enterTextInTable("web_ba_tbl_benefit_allocation", rIndx, 5, benefitdetails.get("Remarks"),  "/input[@name='remarks']");
			
			String interimBonusAdjAmount = benefitdetails.get("InterimBonus");
			llAction.enterTextInTable("web_ba_tbl_benefit_allocation", rIndx+1, 3, interimBonusAdjAmount,
					"/input[@name='adjAmount']");
			llAction.enterTextInTable("web_ba_tbl_benefit_allocation", rIndx+1, 5, benefitdetails.get("Remarks"), "/input[@name='remarks']");
			
			String terminalBonusAdjAmount = benefitdetails.get("TerminalBonus");
			llAction.enterTextInTable("web_ba_tbl_benefit_allocation", rIndx+2, 3, terminalBonusAdjAmount,
					"/input[@name='adjAmount']");
			llAction.enterTextInTable("web_ba_tbl_benefit_allocation", rIndx+2, 5, benefitdetails.get("Remarks"),  "/input[@name='remarks']");
			
			String additionalBonussAdjAmount = benefitdetails.get("AdditionalBenefit");
			llAction.enterTextInTable("web_ba_tbl_benefit_allocation", rIndx+3, 3, additionalBonussAdjAmount,
					"/input[@name='adjAmount']");
			llAction.enterTextInTable("web_ba_tbl_benefit_allocation", rIndx+3, 5, benefitdetails.get("Remarks"),  "/input[@name='remarks']");
			
			llAction.clickElement("web_ba_btn_save");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Validate if benefit allocation is updated", "benefit allocation is updated successfully", "");
			dashboard.writeResults();	
		
			
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}


	public void updateAdjustment (Hashtable<String, String> hParams) throws BPCException {
		try {
			Long timeOut = (long) 10;
			boolean isComputationTableUpdated = false;
			int i = 0, rowPos;
		
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_ba_btn_add");
			//llAction.waitUntilLoadingCompletes();
			llAction.printAllWindowHandles();
			llAction.switchtoWindowsPopUp();
			//llAction.getElement("web_list_ba_adjustmentItem");
			//llAction.switchtoChildWindow("Amend Benefit Allocation");
			//llAction.switchtoSecondWindow();
			//llAction.switchtoDefaultContent();
			llAction.switchtoDefaultContent();
			llAction.switchtoFrame("main");
			llAction.waitUntilLoadingCompletes();
			llAction.selectByVisibleText("web_list_ba_adjustmentItem", hParams.get("AdjustmentItem"));
			llAction.selectByVisibleText("web_list_ba_adjustmentType", hParams.get("AdjustmentType"));
			llAction.enterValue("web_text_ba_adjustmentAmount", hParams.get("AdjustmentAmount"));
			llAction.enterValue("web_text_ba_Remarks", hParams.get("adjustmentRemarks"));
			llAction.clickElement("web_ba_btn_adjustmentSubmit");
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Validate if adjustment  is updated", "Adjustment item is updated successfully", "");
			dashboard.writeResults();
			llAction.clickElement("web_ba_btn_adjustmentClose");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click Button", "Close button is clicked successfully", "");
			dashboard.writeResults();
			//llAction.switchtoChildWindow("Amend Benefit Allocation");
			//llAction.switchtoDefaultContent();
			//llAction.switchtoFrame("main");
			//llAction.waitUntilLoadingCompletes();
			//llAction.clickElement("web_ba_btn_exitToMainMenu");
		//	llAction.waitUntilLoadingCompletes();
			//dashboard.setStepDetails("Click Button", "Exit To Main Menu is clicked successfully", "");
			//dashboard.writeResults();
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}

	public void specialClaimFunction(Hashtable<String, String> hParams) {
		try {
			llAction.selectMenuItem("Claim", "Special Claim Function");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_ClaimsProcessingPool_CaseNumber", hParams.get("CaseNumber"));
			llAction.sendkeyStroke("web_txt_ClaimsProcessingPool_CaseNumber", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Enter Case number and details should be displayed",
					"Case number should be entered and details are displayed", "");
			dashboard.writeResults();
			llAction.clickElement("web_btn_" + hParams.get("CaseFunction").replace(" ", "").toLowerCase());
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on claim " + hParams.get("CaseFunction") + " button",
					"Case Status should be updated", "");
			dashboard.writeResults();
			llAction.clickElement("web_evaluation_btn_exitToMainMenu");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	private Hashtable<String, String> getBenefitAllocation(String BenefitName) {
		DataHandler dataHandler = new DataHandler();
		System.out.println(FPMSProperties.getInstance().getLiabilitiesFileLocation());
		Hashtable<String, String> benefits = dataHandler.getTestData(ADJUSTMENT_SHEET,
				FPMSProperties.getInstance().getLiabilitiesFileLocation(),
				ColumnHeader.getColumnHeader(ADJUSTMENT_SHEET), BenefitName, "BenefitName");

		return benefits;
	}
}
