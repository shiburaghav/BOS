package ge.fpms.main;

import com.nttdata.common.util.Utils;

import ge.fpms.main.actions.FPMS_Actions;

public class AdhocBatchJob extends BatchJob {

	private String[] parameters;
	private FPMS_Actions llAction;
	
	public AdhocBatchJob( String jobName,  String scheduleId, String batchDueDate, String batchProcessingDate, String param) {
		super(jobName,scheduleId, batchDueDate, batchProcessingDate);
		
		setParameters(param);
		this.llAction = new FPMS_Actions();
	}
	public AdhocBatchJob( String jobName,  String scheduleId, String batchDueDate, String batchProcessingDate, String param,String[] multiStreamJobs) {
		super(jobName,batchDueDate, batchProcessingDate,multiStreamJobs);
		setParameters(param);
		this.llAction = new FPMS_Actions();
	}

	public String[] getParametesr() {
		return parameters;
	}

	public void setParameters(String parameters) {
		if(parameters!=null){
			this.parameters = parameters.split(",");
		}
		
	}

	@Override
	public void updateUI() throws Exception {
		super.updateUI();
	//	llAction.goMenuItem("Adhoc Batch Task", "web_batchjobs_menuitem_l7");
	//	llAction.selectMenuItem("RUN_ADHOC_JOB_TASK");
		for(int i=1;i<=parameters.length;i++){
			Utils.editXpath("web_txt_adhoc_parameter1", "GetParameterInput",new String[] { "Parameter"+i});
			llAction.enterValue("GetParameterInput", parameters[i-1]);
		}
		
	}
	/*@Override
	public Hashtable<String, String> processMultiStream() throws Exception {
		int hasMultiStreamJobs = getMultiStreamJobCount();
		String[] multiStreamJobs = getMultiStreamJobs();
		int streamCount = multiStreamJobs.length;
		Hashtable<String, String> hParams = new Hashtable<String, String>();

		if (hasMultiStreamJobs > 0) {

			hParams.put(BatchConstants.BATCH_DUE_DATE, getBatchDueDate());
			hParams.put(BatchConstants.BATCH_PROCESSING_DATE,
					getBatchProcessingDate());
			hParams.put(BatchConstants.BATCH_NO_OF_JOBS,
					String.valueOf(streamCount));
			for (int i = 0; i < streamCount; i++) {
				hParams.put(BatchConstants.BATCH_JOBID + (i + 1),
						multiStreamJobs[i]);
				hParams.put(BatchConstants.BATCH_JOBNAME + (i + 1), "");
			}

		}
		Utils.sleep(2);
		llAction.clickElement("web_btn_ExitBatchJobMonitor");
		llAction.waitUntilLoadingCompletes();

		return hParams;
	}*/
	
	public void menuSelection() throws Exception{
		llAction.goMenuItem("TEST&DEBUG", "web_batchjobs_menuitem_l1");
		llAction.goMenuItem("eBao Use Module", "web_batchjobs_menuitem_l2");
		llAction.goMenuItem("Tools", "web_batchjobs_menuitem_l3");
		llAction.goMenuItem("Batch Job Testing", "web_batchjobs_menuitem_l4");
		llAction.goMenuItem("Adhoc Batch Task", "web_batchjobs_menuitem_l7");
		llAction.selectMenuItem("RUN_ADHOC_JOB_TASK");
		
	}
}