package ge.fpms.main.bpc.csd;

import java.util.Enumeration;
import java.util.Hashtable;
import org.openqa.selenium.Keys;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class Rider {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;

	public Rider() {
		dashboard = DashboardHandler.getInstance();
	}

	/*
	 * Name: AddRiderByDate Purpose: Add Rider to the policy based on the date and
	 * plan code Parameters: Add Rider Test Data sheet Return Value: N/A Exception:
	 * BPC Exception on component execution fail Author : Shree Ganesh
	 */
	public void AddRiderByDate(Hashtable<String, String> hParams) throws Exception {

		try {

			String benfitCode = hParams.get("BenefitCode");
			String benfitType = hParams.get("BenefitType");
			String clickButtonName = hParams.get("AddRiderfrom");
			String validityDate = hParams.get("Validitydate");
			String saUnits = hParams.get("SAUnits");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Navigate to Add Rider screen", "Add Rider screen should be displayed", "N/A");
			dashboard.writeResults();

			// Enter validity date. step 11
			llAction.enterValue("web_txt_addrider_validitydate", validityDate);

			// Select Benefit by
			int colPos = llAction.GetColumnPositionInTable("web_tbl_addrider_benefit_info_before_change", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_addrider_benefit_info_before_change", benfitCode,
					colPos);
			AddRiderCaptureBeforeOrAfterChange("BeforeChange");
			llAction.SelectRowInTable("web_tbl_addrider_benefit_info_before_change", rowPos, colPos - 2, "input");
			llAction.waitUntilLoadingCompletes();

			String temp = "web_btn_addrider_" + clickButtonName.replace(" ", "_").toLowerCase();

			llAction.clickElement(temp);
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				llAction.clickElement("web_btn_ContinueRP");
				llAction.waitUntilLoadingCompletes();
			}

			dashboard.setStepDetails("Application should navigate to Benefit Information screen",
					"Benefit Information screen should be displayed", "N/A");
			dashboard.writeResults();

			llAction.waitUntilElementPresent("web_txt_addrider_benefit_type");

			llAction.enterValue("web_txt_addrider_benefit_type", benfitType);
			llAction.sendkeyStroke("web_txt_addrider_benefit_type", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();

			// Deepa 14032019
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				llAction.clickElement("web_btn_ContinueRP");
				llAction.waitUntilLoadingCompletes();
			}

			if (hParams.get("FirstLifeAssured") != "") {
				llAction.selectByVisibleText("web_txt_addrider_firstlifeassured", hParams.get("FirstLifeAssured"));
			}
			if (hParams.get("MarketingDiscountCode") != "") {
				llAction.enterValue("web_txt_addrider_discountcode", hParams.get("MarketingDiscountCode"));
			}
			if (hParams.get("TypeofCoverageperiod") != "") {
				llAction.enterValue("web_txt_addrider_coverageperiod", hParams.get("TypeofCoverageperiod"));
			}
			llAction.enterValue("web_txt_addrider_coverageyear", hParams.get("Yearageofcoverageterm"));
			if (hParams.get("Typeofpremiumpaymentperiod") != "") {
				llAction.enterValue("web_txt_addrider_chargeperiod", hParams.get("Typeofpremiumpaymentperiod"));
			}
			llAction.enterValue("web_txt_addrider_chargeyear", hParams.get("Yearageofpremiumterm"));
			llAction.enterValue("web_txt_addrider_premium_frequency", hParams.get("InitialPremiumFrequency"));
			llAction.enterValue("web_txt_addrider_Initial_sum_assured", hParams.get("PremiumAmount"));
			if (hParams.get("PremiumCalculatingmethod") != "") {
				llAction.enterValue("web_txt_addrider_calculatingMethod", hParams.get("PremiumCalculatingmethod"));
			}
			if (hParams.get("GIBIndicator") != "") {
				llAction.enterValue("web_txt_addrider_gib", hParams.get("GIBIndicator"));
			}
			llAction.enterValue("web_txt_AnnualAmtWaived", hParams.get("WaiverAnnualAmtWaived"));
			llAction.enterValue("web_txt_InitialWaivedBenefit", hParams.get("WaiverInitialSAWaivedBenefit"));
			llAction.enterValue("web_txt_WaivedofWaivedBenefit", hParams.get("WaiverWaivedofBenefit"));
			llAction.enterValue("web_txt_AnnualBenefit", hParams.get("WaiverAnnualBenefit"));
			llAction.enterValue("web_txt_WaiverCalMethod", hParams.get("WaiverCalculationMethod"));
			llAction.enterValue("web_txt_WaiverPayFrequency", hParams.get("WaiverPaymentFrequency"));
			llAction.enterValue("web_txt_FactFindIndicator", hParams.get("FactFindInd"));

			dashboard.setStepDetails("Enter the benefit details ", "Benefit Details should be accepted", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_addrider_common_submit_button");
			AddRiderCaptureBeforeOrAfterChange("AfterChange");
			llAction.clickElement("web_btn_addrider_common_submit_button");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: ValidateApplicationStatus Purpose: Validate the application status and
	 * capture the result Parameters: Add Rider Test Data sheet Return Value: N/A
	 * Exception: BPC Exception on component execution fail Author : Shree Ganesh
	 */
	public void ValidateApplicationStatus(String webElementKey, String applicationStatus) throws Exception {
		try {
			if (llAction.getText(webElementKey).toLowerCase().contains(applicationStatus.toLowerCase())) {
				dashboard.setStepDetails(applicationStatus + " Should be populated", "Message is validated", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(applicationStatus + "message is invalid/Submit was not successful");
				dashboard.writeResults();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: submit Purpose: Submit application and return the next screen name for
	 * navigation and validation Parameters: Add Rider Test Data sheet Return Value:
	 * N/A Exception: BPC Exception on component execution fail Author : Shree
	 * Ganesh
	 */
	public String submit(String actualScreen) throws Exception {
		try {

			llAction.clickElement("web_btn_addrider_common_submit_button");
			llAction.waitUntilLoadingCompletes();
			String screenName = llAction.getText("web_txt_deleterider_screen_validation").replaceAll("[^a-zA-Z0-9\\s+]",
					" ");
			dashboard.setStepDetails("System should display " + screenName + " screen on submit button click",
					screenName + " is Displayed on submit button click", "N/A");
			dashboard.writeResults();
			return screenName;

		} catch (Exception ex) {

			throw new BPCException(ex);
		}
	}

	/*
	 * Name: AddRiderCaptureBeforeOrAfterChange Purpose: Capture Before and after
	 * add rider changes Parameters: Add Rider Test Data sheet Return Value: N/A
	 * Exception: BPC Exception on component execution fail Author : Shree Ganesh
	 */
	public void AddRiderCaptureBeforeOrAfterChange(String ActionType) throws Exception {
		try {
			switch (ActionType.toUpperCase()) {
			case "BEFORECHANGE":
				dashboard.setStepDetails("Add Rider Before Changes", "Captured changes successfully", "N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":

				dashboard.setStepDetails("Add Rider After Changes", "Captured changes successfully", "N/A");
				dashboard.writeResults();
				break;
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: DeleteRiderByDate Purpose: Capture Before and after add rider changes
	 * Parameters: Add Rider Test Data sheet Return Value: N/A Exception: BPC
	 * Exception on component execution fail Author : Shree Ganesh
	 */
	public void DeleteRiderByDate(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.waitUntilElementPresent("web_txt_deleterider_validity_date");
			String benfitcode = hParams.get("BenefitCode");
			String clickButtonName = hParams.get("DeleteRiderfrom");
			String cancelationReason = hParams.get("Cancellationreason");
			String validityDate = hParams.get("Validitydate");

			llAction.enterValue("web_txt_deleterider_validity_date", validityDate);
			llAction.move_to_element("web_txt_deleterider_refundamt");
			DeleteRiderCaptureBeforeOrAfterChange("BeforeChange");

			int colPos = llAction.GetColumnPositionInTable("web_tbl_deleterider_benefitinfo", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_deleterider_benefitinfo", benfitcode, colPos);
			llAction.SelectRowInTable("web_tbl_deleterider_benefitinfo", rowPos, colPos - 2, "input");
			dashboard.setStepDetails("Benefit code should be selected", "Benefit code is selected", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_deleterider_" + clickButtonName.replace(" ", "_").toLowerCase());
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Click on " + clickButtonName + " Cancelation Reason screen should be displayed",
					"Cancelation Reason screen is displayed", "N/A");
			dashboard.writeResults();

			llAction.selectByVisibleText("web_dd_deleterider_cancellation_reason", cancelationReason);
			submit("Cancelation Reason Screen");
			llAction.waitUntilLoadingCompletes();
			DeleteRiderCaptureBeforeOrAfterChange("AfterChange");
			submit("ILP Delete Rider Screen");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: DeleteRiderCaptureBeforeOrAfterChange Purpose: Capture Before and after
	 * Delete rider changes Parameters: Add Rider Test Data sheet Return Value: N/A
	 * Exception: BPC Exception on component execution fail Author : Shree Ganesh
	 */
	public void DeleteRiderCaptureBeforeOrAfterChange(String ActionType) throws Exception {
		try {
			switch (ActionType.toUpperCase()) {
			case "BEFORECHANGE":
				dashboard.setStepDetails("Capture ILP Delete Rider Before Changes",
						"Captured ILP Rider Before changes successfully", "N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":
				dashboard.setStepDetails("Capture ILP Delete Rider After Changes",
						"Captured ILP Rider After changes successfully", "N/A");
				dashboard.writeResults();
				break;
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

}
