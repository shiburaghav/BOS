package ge.fpms.main.bpc.bcp.templates.lockbox;

public class BillType {

	private int count;
	private String type;
	private int amount;
	
	
	public int getCount() {
		return count;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int totalAmount) {
		this.amount += totalAmount;
		count++;
	}
	
}
