package ge.fpms.main.bpc.bcp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.ObjectIdentifier;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;

public class FPMSBill {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;

	public FPMSBill() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	public void extractionAmountToBill(Hashtable<String, String> hParams) throws Exception {
		try {
			String policyNumber = StringUtils.EMPTY;
			String extractionDate = hParams.get("Extractiondate");
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNumber");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			llAction.selectMenuItem("Billing", "extraction amount to bill");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_EB_txt_PolicyNumber");
			llAction.enterValue("web_EB_txt_PolicyNumber", policyNumber);

			llAction.clickElement("web_EB_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();

			int colPos = llAction.GetColumnPositionInTable("web_EB_tbl_SearchResults", "Policy number");
			int rowPos = llAction.GetRowPositionInTable("web_EB_tbl_SearchResults", policyNumber, colPos);
			llAction.SelectRowInTable("web_EB_tbl_SearchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();

			if (StringUtils.isEmpty(extractionDate)) {
				String dueDate = llAction.getAttribute("web_EB_txt_DueDate", "value");
				String[] Date = dueDate.substring(3).split("/");
				extractionDate = Date[0] + Date[1];
			}

			llAction.clickElement("web_EB_txt_ExtractionDueDate");
			llAction.enterValue("web_EB_txt_ExtractionDueDate", extractionDate);
			llAction.clickElement("web_EB_btn_SubmitExtraction");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Validate if the extraction method is a success",
					"Extracted method status should be a success", "");

			if (llAction.getText("web_EB_lbl_ExtractionStatusMessage").equalsIgnoreCase("Extraction succeeded!")) {
				dashboard.writeResults();
				llAction.clickElement("web_EB_btn_ExtractionBack");
				llAction.clickElement("web_EB_btn_ExtractionExit");
			} else {
				dashboard.writeResults();
				dashboard.setFailStatus(new BPCException("extraction method is not a success"));
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void performManualExtraction(Hashtable<String, String> hParams) throws Exception {
		try {
			List<WebElement> record = new ArrayList<WebElement>();
			String policyNumber = StringUtils.EMPTY;
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNumber");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			llAction.selectMenuItem("Billing", "perform manual extraction");
			llAction.waitUntilLoadingCompletes();

			llAction.selectByVisibleText("web_PME_lst_PaymentMethod", hParams.get("PaymentMethod"));
			llAction.clickElement("web_PME_txt_PolicyNumber");
			llAction.enterValue("web_PME_txt_PolicyNumber", policyNumber);
			llAction.clickElement("web_PME_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();

			int colPos = llAction.GetColumnPositionInTable("web_PME_tbl_SearchResults", "Proposal/Policy Number");
			int rowPos = llAction.GetRowPositionInTable("web_PME_tbl_SearchResults", policyNumber, colPos);
			llAction.SelectRowInTable("web_PME_tbl_SearchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();

			llAction.clickElement("web_PME_txt_amountForceBilling");
			llAction.enterValue("web_PME_txt_amountForceBilling", hParams.get("ForceBillingAmount"));
			llAction.clickElement("web_PME_txt_addAmountForceBilling");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_PME_btn_SubmitManualExtraction");
			llAction.waitUntilAlertisShown();
			String alertText = llAction.getAlertText();
			if (alertText.equalsIgnoreCase("Successfully!")) {
				llAction.acceptAlert();
			} else {
				dashboard.setFailStatus(new BPCException("Extraction amount not added successfully"));
			}

			colPos = llAction.GetColumnPositionInTable("web_PME_tbl_DeductionRecords", "Amount");
			List<String> alldeductableAmounts = llAction.GetAllTextUnderColumnInTable("web_PME_tbl_DeductionRecords",
					colPos);
			int colPos2 = llAction.GetColumnPositionInTable("web_PME_tbl_DeductionRecords", "Extraction date");
			List<String> allExtractionDate = llAction.GetAllTextUnderColumnInTable("web_PME_tbl_DeductionRecords",
					colPos2, "/input");
			dashboard.setStepDetails("Validate if newly added amount is found in deductable tables",
					"Newly added amount should be displayed", "");
			if (alldeductableAmounts.contains(hParams.get("ForceBillingAmount"))
					&& allExtractionDate.contains(hParams.get("Extractiondate"))) {
				dashboard.writeResults();
				Utils.editXpath("web_PME_tbl_selectRecord", "web_PME_tbl_selectRecord" + policyNumber + "",
						new String[] { hParams.get("ForceBillingAmount"), hParams.get("Extractiondate") });
				Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap
						.get("web_PME_tbl_selectRecord" + policyNumber + "");
				String xpath = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]);
				record = llAction.findElementsByXpath(xpath);
				for (int i = 0; i < 5; i++) {
					record.get(i).click();
				}
			} else {
				dashboard.writeResults();
				dashboard.setFailStatus(new BPCException("Extraction amount not added successfully"));
			}
			dashboard.setStepDetails("Record is selected in deductable tables", "Record should be selected", "");
			dashboard.writeResults();
			llAction.clickElement("web_PME_btn_SubmitManualExtraction");
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void manuallySuspendOrUnsuspendExtraction(Hashtable<String, String> hParams) throws Exception {
		try {
			String policyNumber = StringUtils.EMPTY;
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNumber");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			llAction.selectMenuItem("Billing", "manually suspend and unsuspend extraction");
			llAction.waitUntilLoadingCompletes();

			llAction.selectByVisibleText("web_MS_lst_PaymentMethod", hParams.get("Suspend_PaymentMethod"));
			llAction.clickElement("web_MS_txt_PolicyNumber");
			llAction.enterValue("web_MS_txt_PolicyNumber", policyNumber);
			llAction.clickElement("web_MS_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();

			int colPos = llAction.GetColumnPositionInTable("web_MS_tbl_SearchResults", "Policy Number");
			int rowPos = llAction.GetRowPositionInTable("web_MS_tbl_SearchResults", policyNumber, colPos);
			llAction.SelectRowInTable("web_MS_tbl_SearchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();

			int colEffectiveFromDate = llAction.GetColumnPositionInTable("web_MS_tbl_SuspendDetails",
					"Effective from date");
			int colEffectiveToDate = llAction.GetColumnPositionInTable("web_MS_tbl_SuspendDetails",
					"Effective to date");
			int colCollectionType = llAction.GetColumnPositionInTable("web_MS_tbl_SuspendDetails", "Collection type");
			int colRemarks = llAction.GetColumnPositionInTable("web_MS_tbl_SuspendDetails", "Remarks");

			List<String> collectionTypes = Arrays.asList(hParams.get("CollectionType").split("\\s*,\\s*"));
			for (String collectionType : collectionTypes) {
				rowPos = llAction.GetRowPositionInTable("web_MS_tbl_SuspendDetails", collectionType, colCollectionType);
				llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colEffectiveFromDate,
						hParams.get("EffectiveFromDate"), "/input");
				llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colEffectiveToDate,
						hParams.get("EffectiveToDate"), "/input");
				llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colRemarks, hParams.get("Remarks"),
						"/textarea");
				// break;
			}
			/*
			 * switch(hParams.get("CollectionType").toUpperCase()) { case "ALL": int
			 * noOfRows = llAction.getRowCountInTable("web_MS_tbl_SuspendDetails"); for(int
			 * i = 2; i <= noOfRows; i++) {
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", i,
			 * colEffectiveFromDate, hParams.get("EffectiveFromDate"), "/input");
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", i, colEffectiveToDate,
			 * hParams.get("EffectiveToDate"), "/input");
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", i, colRemarks,
			 * hParams.get("Remarks"), "/textarea"); } break; case "PREMIUM": rowPos =
			 * llAction.GetRowPositionInTable("web_MS_tbl_SuspendDetails", "Premium",
			 * colCollectionType); llAction.enterTextInTable("web_MS_tbl_SuspendDetails",
			 * rowPos, colEffectiveFromDate, hParams.get("EffectiveFromDate"), "/input");
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos,
			 * colEffectiveToDate, hParams.get("EffectiveToDate"), "/input");
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colRemarks,
			 * hParams.get("Remarks"), "/textarea"); break; case "RECURRING TOPUP": rowPos =
			 * llAction.GetRowPositionInTable("web_MS_tbl_SuspendDetails",
			 * "Recurring Topup", colCollectionType);
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos,
			 * colEffectiveFromDate, hParams.get("EffectiveFromDate"), "/input");
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos,
			 * colEffectiveToDate, hParams.get("EffectiveToDate"), "/input");
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colRemarks,
			 * hParams.get("Remarks"), "/textarea"); break; case "POLICY COLLECTION": rowPos
			 * = llAction.GetRowPositionInTable("web_MS_tbl_SuspendDetails",
			 * "Policy Collection", colCollectionType);
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos,
			 * colEffectiveFromDate, hParams.get("EffectiveFromDate"), "/input");
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos,
			 * colEffectiveToDate, hParams.get("EffectiveToDate"), "/input");
			 * llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colRemarks,
			 * hParams.get("Remarks"), "/textarea"); break; }
			 */

			llAction.clickElement("web_MS_btn_SubmitManuallySuspendExtraction");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Validate if the payment method is suspended or unsuspended successfully",
					"payment method should be suspended or unsuspended successfully", "");
			dashboard.writeResults();
			llAction.clickElement("web_EB_btn_ExtractionExit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
