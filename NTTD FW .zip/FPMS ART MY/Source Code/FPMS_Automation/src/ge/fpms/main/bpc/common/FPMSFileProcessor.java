package ge.fpms.main.bpc.common;

import java.io.File;
import java.io.FileFilter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.html5.ApplicationCache;

import com.codoid.products.fillo.Recordset;
import com.nttdata.common.util.ApachePOIUtility;
import com.nttdata.common.util.ExcelUtility;
import com.nttdata.core.TestCase;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.core.handler.TestCaseHandler;
import com.nttdata.framework.exceptions.BPCException;
import com.nttdata.framework.exceptions.GenericFunctionLevelException;

import ge.fpms.data.BenefitData;
import ge.fpms.data.FPMSARTDao;
import ge.fpms.data.Policy;
import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.FPMSProperties;

public class FPMSFileProcessor {

	private static String NBUExtractionPath;
	private static String CSDExtractionPath;
	private static FPMSFileProcessor fileProcessor;
	private static FPMSProperties fileProperties;
	private static DashboardHandler dashboard;

	public static FPMSFileProcessor getInstance() {
		fileProperties = FPMSProperties.getInstance();
		if (fileProcessor == null) {
			fileProcessor = new FPMSFileProcessor();
		}
		return fileProcessor;
	}

	public void persistInfo() throws Exception {
		if (System.getProperty("Settings.Is NBU Extract Required?").equalsIgnoreCase("Yes")) {
			try {

				ApachePOIUtility apacheUtils = new ApachePOIUtility();
				PolicyHandler policyHandler = FPMSManager.getInstance().getPolicyHandler();
				// copy template to desired location
				File src = new File(FPMSProperties.getInstance().getNBUExtractTemplate());
				NBUExtractionPath = FPMSProperties.getInstance().getNBUExtractionPath();
				File dest = new File(NBUExtractionPath);
				FileUtils.copyFile(src, dest);
				apacheUtils.Xlsx_Reader(NBUExtractionPath);
				ArrayList<FPMSARTDao> policyList = policyHandler.getPolicyList();

				int rowcount = apacheUtils.getRowCount(FPMSConstants.NBUEXTRACT_SHEETNAME);

				for (int i = 0; i < policyList.size(); i++) {

					Policy policyobj = policyList.get(i).getPolicy();
					TestCase testCase = policyList.get(i).getTestCase();
					ArrayList<BenefitData> benefitsList = policyobj.getBenefitList();

					for (int j = 0; j < benefitsList.size(); j++, rowcount++) {
						BenefitData benefits = benefitsList.get(j);
						String runName = System.getProperty("Settings.Run Name");
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Run Name", rowcount, runName);
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Test case ID", rowcount,
								testCase.getId());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Test case name", rowcount,
								testCase.getName());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Policy Number", rowcount,
								policyobj.getPolicyNo());

						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Benefit Code", rowcount,
								benefits.getBenefitCode());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Life Assured Name", rowcount,
								benefits.getLifeAssured());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Benefit Term", rowcount,
								benefits.getBenefitTerm());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "SA", rowcount,
								benefits.getSumAssured());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Next Standard Installment Premium",
								rowcount, benefits.getStandardPremium());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Next Extra Installment Premium",
								rowcount, benefits.getExtraPremium());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Benefit Status", rowcount,
								benefits.getBenefitStatus());

						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Policy Status", rowcount,
								policyobj.getPolicyStatus());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Commencement Date", rowcount,
								policyobj.getCommencementDate());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Payment method", rowcount,
								policyobj.getPaymentMethod());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Payment Frequency", rowcount,
								policyobj.getPaymentFrequency());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Policy Holder Name", rowcount,
								policyobj.getPolicyHolder());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Agent Code", rowcount,
								policyobj.getAgentCode());

					}

				}

			} catch (Exception ex) {

				throw new GenericFunctionLevelException(new Exception(
						String.format("Exception occured while persisting the data into NBU Extract template")));
			}
		}

	}

	public void persistCSDInfo() throws Exception {
		String mode = System.getProperty("Settings.CSD Extract file mode");

		try {
			ApachePOIUtility apacheUtils = new ApachePOIUtility();
			PolicyHandler policyHandler = FPMSManager.getInstance().getPolicyHandler();
			// copy template to desired location
			File src = new File(FPMSProperties.getInstance().getCSDExtractTemplate());
			String ouputFileFolderPath = System.getProperty("Settings.ART Downloads") + File.separator
					+ System.getProperty("Settings.Run Name") + File.separator + FPMSConstants.OUTPUTFILES_FOLDER;
			// DashboardHandler.getInstance().createDirStruct(ouputFileFolderPath);
			CSDExtractionPath = FPMSProperties.getInstance().getCSDExtractionPath();
			File csdFile = new File(CSDExtractionPath);

			if (csdFile.exists()) {
				if (mode.equalsIgnoreCase("Append")) {
					System.out.println(
							"Append mode is chosen for CSD Extract and existing file will be appended with new data");
				} else if (mode.equalsIgnoreCase("New")) {
					System.out.println(
							"New mode is chosen for CSD Extract and existing file name will be renamed with timestamp appended");
					String timestamp = new SimpleDateFormat("ddMMYYHHmm").format(new Date());
					String renamedFilePath = ouputFileFolderPath + File.separator
							+ FPMSConstants.CSDEXTRACTION_FILE_BASENAME + FPMSConstants.NAME_SEPERATOR + timestamp
							+ FPMSConstants.EXCELFILE_FORMAT;
					File renamedFile = new File(renamedFilePath);
					FileUtils.copyFile(csdFile, renamedFile);
					FileUtils.copyFile(src, csdFile);
				}

			} else {
				System.out.println("New file will be created as no file is found in the path");
				FileUtils.copyFile(src, csdFile);
			}
			apacheUtils.Xlsx_Reader(CSDExtractionPath);
			ArrayList<FPMSARTDao> policyList = policyHandler.getPolicyList();
			int rowcount = apacheUtils.getRowCount(FPMSConstants.CSDEXTRACT_SHEETNAME);
			for (int i = 0; i < policyList.size(); i++) {
				Policy policyobj = policyList.get(i).getPolicy();
				TestCase testCase = policyList.get(i).getTestCase();
				String runName = System.getProperty("Settings.Run Name");
				if (policyobj.getPolicyNo() != null) {
					apacheUtils.setCellData(FPMSConstants.CSDEXTRACT_SHEETNAME, "RunName", rowcount, runName);
					apacheUtils.setCellData(FPMSConstants.CSDEXTRACT_SHEETNAME, "TestCaseID", rowcount,
							testCase.getId());
					apacheUtils.setCellData(FPMSConstants.CSDEXTRACT_SHEETNAME, "TestCaseName", rowcount,
							testCase.getName());
					apacheUtils.setCellData(FPMSConstants.CSDEXTRACT_SHEETNAME, "PolicyNumber", rowcount,
							policyobj.getPolicyNo());
					rowcount++;
				}
			}
		}

		catch (Exception ex) {

			throw new GenericFunctionLevelException(new Exception(
					String.format("Exception occured while persisting the data into CSD Extract template")));
		}
	}

	public void readCSDInfo(Hashtable<String, String> hParams) {
		try {
			dashboard = DashboardHandler.getInstance();
			String testCaseID = TestCaseHandler.getInstance().getTestCase().getId();// get the test case id
			PolicyHandler policyHandler = FPMSManager.getInstance().getPolicyHandler();
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) // precedence is for the policy from																				// test data
			{
				String csdExtractionPath = FPMSProperties.getInstance().getCSDExtractionPath();
				String testDataQuery = "Select PolicyNumber from CSD_Run_Data where TestCaseID='"
						+ testCaseID.substring(0, testCaseID.length() - 1) + "'";
				Recordset recordSet = ExcelUtility.queryExcel(csdExtractionPath, testDataQuery, String.valueOf(1));
				if (recordSet.next()) { 
					policyHandler.getPolicy().setPolicyNo(recordSet.getField("PolicyNumber")); // set policy from CSD extract.xls
					dashboard.setStepDetails("Read policy number from CSD Extractor for test case ID " + testCaseID,
							"Path " + csdExtractionPath, "");
					dashboard.writeResults();
				}
				else
				{
					throw new BPCException("Test Case Not found in CSD Extraction");
				}
					

			}
		} catch (Exception ex) {
			throw new BPCException(ex);

		}
	}

	public void readFromNBUExtractor() {
		try {
			String[] elements = new String[] { System.getProperty("Settings.ART Downloads"), File.separator,
					System.getProperty("Settings.Run Name"), File.separator, FPMSConstants.OUTPUTFILES_FOLDER};
			
			StringBuilder builder = new StringBuilder();
			for (String element : elements) {
				builder.append(element);
			}
			getTheNewestFile(builder.toString(), "xlsx", "NBU_Extraction");
			
			
		}catch(Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public File getTheNewestFile(String dirPath, String ext, String partialFileName) {
	    File theNewestFile = null;
	    
	    File dir = new File(dirPath);
	    FileFilter fileFilter = new WildcardFileFilter("*." + ext);
	    File[] files = dir.listFiles(fileFilter);
	    Object[] nbuFiles = dir.listFiles(fileFilter);
	    List<File> nbuFiles1 = new ArrayList<File>();
	    
	    for(File file: files) {
	    	if(file.getName().startsWith(partialFileName)) {
	    		nbuFiles1.add(file);
	    	}
	    }

	    if (nbuFiles1.size() > 0) {
	    	nbuFiles = nbuFiles1.toArray();
	        Arrays.sort((File[])nbuFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
	        theNewestFile = files[0];
	    }
	    return theNewestFile;
	}


}
