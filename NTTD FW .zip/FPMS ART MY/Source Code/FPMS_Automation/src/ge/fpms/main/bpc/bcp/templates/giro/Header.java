package ge.fpms.main.bpc.bcp.templates.giro;

import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Header implements IPaymentSection {
	private Type hdrRecType;
	private Type hdrBatchNo;
	private Type hdrOrgCode;
	private Type hdrOrgName;
	private Type hdrBillDate;
	private Type hdrSecurityCode;
	private Type hdrFiller;

	private final String DEFAULT_SCECURITY_CODE = "2002166280";
	public Header() {
	}


	public Type getHdrRecType() {
		return hdrRecType;
	}


	public void setHdrRecType(Type hdrRecType) {
		this.hdrRecType = hdrRecType;
	}


	public Type getHdrBatchNo() {
		return hdrBatchNo;
	}


	public void setHdrBatchNo(Type hdrBatchNo) {
		this.hdrBatchNo = hdrBatchNo;
	}


	public Type getHdrOrgCode() {
		return hdrOrgCode;
	}


	public void setHdrOrgCode(Type hdrOrgCode) {
		this.hdrOrgCode = hdrOrgCode;
	}


	public Type getHdrOrgName() {
		return hdrOrgName;
	}


	public void setHdrOrgName(Type hdrOrgName) {
		this.hdrOrgName = hdrOrgName;
	}


	public Type getHdrBillDate() {
		return hdrBillDate;
	}


	public void setHdrBillDate(Type hdrBillDate) {
		this.hdrBillDate = hdrBillDate;
	}


	public Type getHdrSecurityCode() {
		return hdrSecurityCode;
	}


	public void setHdrSecurityCode(Type hdrSecurityCode) {
		this.hdrSecurityCode = hdrSecurityCode;
	}


	public Type getHdrFiller() {
		return hdrFiller;
	}


	public void setHdrFiller(Type filler) {
		this.hdrFiller = filler;
	}


	public int[] getAttributesSize() {
		
		return new int[] { hdrRecType.getSize(), hdrBatchNo.getSize(), hdrOrgCode.getSize(), hdrOrgName.getSize(),
				hdrBillDate.getSize(), hdrSecurityCode.getSize(), hdrFiller.getSize()};
	}

	public void setParamaters(ArrayList<String> buffer) {
		
		hdrRecType.setValue(buffer.get(0));
		hdrBatchNo.setValue(buffer.get(1));
		hdrOrgCode.setValue(buffer.get(2));
		hdrOrgName.setValue(buffer.get(3));
		hdrBillDate.setValue(buffer.get(4));
		String securityCode = hdrSecurityCode.getValue().trim();
		if(StringUtils.isEmpty(securityCode)){
			securityCode = DEFAULT_SCECURITY_CODE;
		}
		int code = Integer.parseInt(securityCode) + Integer.parseInt(hdrBatchNo.getValue().trim());
		hdrSecurityCode.setValue(String.valueOf(code));
		hdrFiller.setValue(buffer.get(6));
	}

	public String getName() {
		return "01";
	}

	public String toString() {
		String headerText =  new StringBuffer().append(getHdrRecType().toString()).append(getHdrBatchNo().toString())
				.append(getHdrOrgCode().toString()).append(getHdrOrgName().toString())
				.append(getHdrBillDate().toString()).append(getHdrSecurityCode().toString())
				.append(getHdrFiller().toString()).toString();
		return headerText;
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}
}
