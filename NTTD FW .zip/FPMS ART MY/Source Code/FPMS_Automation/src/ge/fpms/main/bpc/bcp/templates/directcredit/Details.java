package ge.fpms.main.bpc.bcp.templates.directcredit;


import java.util.ArrayList;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Details implements IPaymentSection {
	private Type recordType;
	private Type accountNumber;
	private Type dFiller1;
	private Type amount;
	private Type dInstruction; 
	private Type newICNumber;
	private Type oldICNumber;
	private Type txnDescription;
	private Type businessRegistrationNo;
	private Type referenceNumber;
	private Type receivingFIID;
	private Type beneficiaryName;
	private Type policeArmyId;
	private Type sendVia;
	private Type email;
	private Type faxNo;
	private Type idCheckingRequired;
	private Type dFiller2;
	private Type returnCode;
	private Type rejectCode;
	private Type successIndicator;
	private Type dFiller3;
	public static final int DETAILS_OUTPUT_FIELD_COUNT = 17;

	public Details(){
		
	}
	
	public Details(Type[] type) {
		super();
		this.recordType= new Type(type[0].getSize(), type[0].getDataType(),type[0].getValue(), type[0].getAlignment(),type[0].getPaddingChar());
		
		this.accountNumber= new Type(type[1].getSize(), type[1].getDataType(),type[1].getValue(), type[1].getAlignment(),type[1].getPaddingChar());
		
		this.amount= new Type(type[2].getSize(), type[2].getDataType(),type[2].getValue(), type[2].getAlignment(),type[2].getPaddingChar());
		
		this.dInstruction= new Type(type[3].getSize(), type[3].getDataType(),type[3].getValue(), type[3].getAlignment(),type[3].getPaddingChar()); 
		
		this.referenceNumber= new Type(type[4].getSize(), type[4].getDataType(),type[4].getValue(), type[4].getAlignment(),type[4].getPaddingChar());
		
		this.receivingFIID= new Type(type[5].getSize(), type[5].getDataType(),type[5].getValue(), type[5].getAlignment(),type[5].getPaddingChar());
		
		this.returnCode= new Type(type[6].getSize(), type[6].getDataType(),type[6].getValue(), type[6].getAlignment(),type[6].getPaddingChar());
		
		this.rejectCode= new Type(type[7].getSize(), type[7].getDataType(),type[7].getValue(), type[7].getAlignment(),type[7].getPaddingChar());
		
		this.successIndicator= new Type(type[8].getSize(), type[8].getDataType(),type[8].getValue(), type[8].getAlignment(),type[8].getPaddingChar());
		
		this.dFiller3= new Type(type[9].getSize(), type[9].getDataType(),type[9].getValue(), type[9].getAlignment(),type[9].getPaddingChar());

	}

	
	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Type accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Type getdFiller1() {
		return dFiller1;
	}

	public void setdFiller1(Type dFiller1) {
		this.dFiller1 = dFiller1;
	}

	public Type getAmount() {
		return amount;
	}

	public void setAmount(Type amount) {
		this.amount = amount;
	}

	public Type getdInstruction() {
		return dInstruction;
	}

	public void setdInstruction(Type dInstruction) {
		this.dInstruction = dInstruction;
	}

	public Type getNewICNumber() {
		return newICNumber;
	}

	public void setNewICNumber(Type newICNumber) {
		this.newICNumber = newICNumber;
	}

	public Type getOldICNumber() {
		return oldICNumber;
	}

	public void setOldICNumber(Type oldICNumber) {
		this.oldICNumber = oldICNumber;
	}

	public Type getTxnDescription() {
		return txnDescription;
	}

	public void setTxnDescription(Type txnDescription) {
		this.txnDescription = txnDescription;
	}

	public Type getBusinessRegistrationNo() {
		return businessRegistrationNo;
	}

	public void setBusinessRegistrationNo(Type businessRegistrationNo) {
		this.businessRegistrationNo = businessRegistrationNo;
	}

	public Type getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(Type referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public Type getReceivingFIID() {
		return receivingFIID;
	}

	public void setReceivingFIID(Type receivingFIID) {
		this.receivingFIID = receivingFIID;
	}

	public Type getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(Type beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public Type getPoliceArmyId() {
		return policeArmyId;
	}

	public void setPoliceArmyId(Type policeArmyId) {
		this.policeArmyId = policeArmyId;
	}

	public Type getSendVia() {
		return sendVia;
	}

	public void setSendVia(Type sendVia) {
		this.sendVia = sendVia;
	}

	public Type getEmail() {
		return email;
	}

	public void setEmail(Type email) {
		this.email = email;
	}

	public Type getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(Type faxNo) {
		this.faxNo = faxNo;
	}

	public Type getIdCheckingRequired() {
		return idCheckingRequired;
	}

	public void setIdCheckingRequired(Type idCheckingRequired) {
		this.idCheckingRequired = idCheckingRequired;
	}

	public Type getdFiller2() {
		return dFiller2;
	}

	public void setdFiller2(Type dFiller2) {
		this.dFiller2 = dFiller2;
	}

	public Type getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(Type returnCode) {
		this.returnCode = returnCode;
	}

	public Type getRejectCode() {
		return rejectCode;
	}

	public void setRejectCode(Type rejectCode) {
		this.rejectCode = rejectCode;
	}

	public Type getSuccessIndicator() {
		return successIndicator;
	}

	public void setSuccessIndicator(Type successIndicator) {
		this.successIndicator = successIndicator;
	}

	public Type getdFiller3() {
		return dFiller3;
	}

	public void setdFiller3(Type dFiller3) {
		this.dFiller3 = dFiller3;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(),accountNumber.getSize(),dFiller1.getSize(),amount.getSize(),
				dInstruction.getSize(),newICNumber.getSize(),oldICNumber.getSize(),txnDescription.getSize(),
				businessRegistrationNo.getSize(),referenceNumber.getSize(),receivingFIID.getSize(),beneficiaryName.getSize(),
				policeArmyId.getSize(),sendVia.getSize(),email.getSize(),faxNo.getSize(),idCheckingRequired.getSize(),dFiller2.getSize()};
	}

	
	public String getName() {
		return "02";
	}

	

	public String toString() {
		String details = new StringBuilder().append(getRecordType().toString())
				.append(getReceivingFIID().toString()).append(getAccountNumber().toString())
				.append(getdInstruction().toString()).append(getAmount().toString())
				.append(getReferenceNumber().toString()).append(getReturnCode().toString())
				.append(getRejectCode().toString()).append(getSuccessIndicator().toString())
				.append(getdFiller3().getSize()).toString();
		
		return details;
	}

	public Type[] getAllAttributes() {	
		return new Type[] { recordType,accountNumber,dFiller1,amount,dInstruction,newICNumber,oldICNumber,
				txnDescription,businessRegistrationNo,referenceNumber,receivingFIID,beneficiaryName,policeArmyId,
				sendVia,email,faxNo,idCheckingRequired,dFiller2};
	}
	public String[] getAllAttributeNames() {	
		return new String[] { "recordType","accountNumber","dFiller1","amount","dInstruction","newICNumber",
				"oldICNumber","txnDescription","businessRegistrationNo","referenceNumber","receivingFIID",
				"beneficiaryName","policeArmyId","sendVia","email","faxNo","idCheckingRequired","dFiller2"};
	}
	public ArrayList<String> getOutputFieldName(){
		ArrayList<String> fieldNames =  new ArrayList<String>();
		fieldNames.add("recordType");
		fieldNames.add("receivingFIID");
		fieldNames.add("accountNumber");
		fieldNames.add("dInstruction");
		fieldNames.add("amount");
		fieldNames.add("referenceNumber");
		fieldNames.add("returnCode");
		fieldNames.add("rejectCode");
		fieldNames.add("successIndicator");
		fieldNames.add("dFiller3");
		return fieldNames;
	}
	
}
