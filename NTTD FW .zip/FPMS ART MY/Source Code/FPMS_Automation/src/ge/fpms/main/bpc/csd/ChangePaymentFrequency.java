package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;
public class ChangePaymentFrequency {

	/*
	 * Name: Change Payment Frequency Purpose: Navigate to CS module from the Main
	 * Page and Change Payment Frequency for a policy Parameters:Parameter Hash
	 * table Return Value: NA Exception: BPCException
	 * 
	 * @author: Sahil SIngh 0n 27/12/2018
	 */

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public ChangePaymentFrequency() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void changeFrequency(Hashtable<String, String> hParams) throws Exception {
		try {
			
			if (llAction.isDisplayed("web_btn_ContinueRP",5)) {
				if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {

					String getWarningMsg = llAction.getText("web_txt_ErrorWarning").trim();

					validateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilElementPresent("web_list_NewPayFrequency");
			CSDHelper.getInstance().captureChange("Payment Frequency", "BEFORECHANGE");
			llAction.selectByVisibleText("web_list_NewPayFrequency", hParams.get("NewPaymentFrequency"));
			llAction.clickElement("web_btn_ChangePayFrequency");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("Payment Frequency", "AFTERCHANGE");
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();

		}  catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void validateWarningMessages(String warningMsg, String message) throws Exception {
		try {
			if (warningMsg.contains(message)) { // compare warning messages
				dashboard.setStepDetails(message + "Warning message should be displayed",
						"\"Warning message should is displayed ", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(
						"Warning message " + warningMsg + " from application is not matching with test data");
				dashboard.writeResults();
			}
		}  catch (Exception ex) {
			throw new BPCException(ex);

		}
	}
}
