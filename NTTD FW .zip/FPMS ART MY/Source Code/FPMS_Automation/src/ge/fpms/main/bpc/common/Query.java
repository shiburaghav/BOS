package ge.fpms.main.bpc.common;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.lang.reflect.Method;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.codoid.products.fillo.Recordset;
import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.ExcelUtility;
import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.components.table.TableColumn;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import com.nttdata.framework.exceptions.LowLevelException;

import ge.fpms.data.BenefitData;
import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.actions.FPMS_Actions;

public class Query {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;

	public Query() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	public void verifyPendingFundTransaction(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("Query", "Common Query");
			llAction.clickElement("web_radio_PolicyNumber");

			if (policyHandler.isPolicyEmpty()) {
				policyHandler.getPolicy().setPolicyNo(hParams.get("PolicyId"));

			}
			llAction.enterValue("web_txt_CommonQueryPolicyNumber", policyHandler.getPolicy().getPolicyNo()); // should
																												// come
																												// Run
																												// time
			llAction.clickElement("web_btn_SearchParty");

			dashboard.setStepDetails("Seach Policy ", "Policy number should be entered and clicked successfully",
					"N/A");
			dashboard.writeResults();

			llAction.selectTab("Benefit Info");

			dashboard.setStepDetails("Enter search criteria for fund price approval and click on search.",
					"The fund price entry screen should be displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_lnk_ViewBenefitDetails");

			Utils.sleep(20);
			dashboard.setStepDetails("Verify Pending Transaction Record",
					"Pending Transaction records should be displayed", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void verifyRiskCharges(Hashtable<String, String> hParams) throws Exception {
		llAction.selectMenuItem("Query", "Common Query");
		llAction.enterValue("web_txt_CommonQueryPolicyNumber", ""); // should come Run time
		llAction.clickElement("web_btn_SearchParty");
		llAction.selectTab("Benefit Info");
		llAction.clickElement("web_lnk_ViewBenefitDetails");
		List<WebElement> transactionAmounts = llAction.returnWebElements("web_tbl_TransactionAmount");
		for (int i = 1; i < transactionAmounts.size(); i++) {
			System.out.println(transactionAmounts.get(i).getText()); // validate all these values
		}
	}

	public void verifyFundTransactionCompleted(Hashtable<String, String> hParams) throws Exception {
		llAction.selectMenuItem("Query", "Common Query");
		llAction.enterValue("web_txt_CommonQueryPolicyNumber", ""); // should come Run time
		llAction.clickElement("web_btn_SearchParty");
		llAction.selectTab("Benefit Info");
		llAction.clickElement("web_lnk_ViewBenefitDetails");
		// String recordsFoundText =
		// llAction.getText("web_tbl_PendingFundTransactionRecord");
	}

	public void VerifyFundTransaction(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("Query", "Common Query");
			llAction.clickElement("web_radio_PolicyNumber");
			llAction.enterValue("web_txt_CommonQueryPolicyNumber", policyHandler.getPolicy().getPolicyNo()); // should
																												// come
																												// Run
																												// time
			llAction.clickElement("web_btn_SearchParty");

			dashboard.setStepDetails("Seach Policy ", "Policy number should be entered and clicked successfully",
					"N/A");
			dashboard.writeResults();

			llAction.selectTab("Benefit Info");

			dashboard.setStepDetails("Enter search criteria for fund price approval and click on search.",
					"The fund price entry screen should be displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_lnk_ViewBenefitDetails");

			Utils.sleep(20);
			dashboard.setStepDetails("Verify Fund Transaction Record", "Fund Transaction records should be displayed",
					"N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void VerifyChargeDeductions(Hashtable<String, String> hParams) throws Exception {
		llAction.selectMenuItem("Query", "Common Query");
		llAction.clickElement("web_radio_PolicyNumber");
		llAction.enterValue("web_txt_CommonQueryPolicyNumber", policyHandler.getPolicy().getPolicyNo());
		llAction.clickElement("web_btn_SearchParty");
		dashboard.setStepDetails("Seach Policy ", "Policy number should be entered and clicked successfully", "N/A");
		dashboard.writeResults();
		llAction.selectTab("Quick Links");
		dashboard.setStepDetails("Quick Links ", "Quick Link Tab should be clicked", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_lnk_PolicRecievable");
		String actual_dueDate = llAction.getText("web_table_DueDate");
		String actual_Amount = llAction.getText("web_tableAmount");
		/*
		 * List<WebElement>
		 * rows=llAction.returnWebElements("web_tbl_PolicyRecievablesTable");
		 * 
		 * for(WebElement row:rows) { List<WebElement>
		 * colums=row.findElements(By.xpath("//td[4]"));
		 * 
		 * for(int i=0;i<colums.size();i++) {
		 * if(colums.get(i).getText().equalsIgnoreCase("Risk Charge")) {
		 * 
		 * actual_dueDate=colums.get(i+3).getText();
		 * actual_Amount=colums.get(i+4).getText(); break; } } }
		 */
		if (actual_dueDate.trim().equalsIgnoreCase(hParams.get("DueDate"))) {
			dashboard.setStepDetails("Due Date", "Due date verified successfuly", "N/A");
			dashboard.writeResults();
		}
		if (actual_Amount.trim().equalsIgnoreCase(hParams.get("RiskAmount"))) {
			dashboard.setStepDetails("Risk Amount", "Risk Amount verified successfuly", "N/A");
			dashboard.writeResults();
		}
	}

	public void verifyRiskChargePolicyReceivablePayable(Hashtable<String, String> hParams) throws Exception {
		llAction.selectTab("Quick Links");
		dashboard.setStepDetails("Quick Links ", "Quick Link Tab should be clicked", "N/A");
		dashboard.writeResults();
		Utils.sleep(20);
		llAction.clickElementJs("web_lnk_PolicRecievable");
		dashboard.setStepDetails("click link Policy Receivable", "Policy Receivable should be clicked", "N/A");
		dashboard.writeResults();
		// String actual_dueDate = llAction.getText("web_table_DueDate");
		String actual_Amount = llAction.getText("web_tableAmount");
		/*
		 * List<WebElement>
		 * rows=llAction.returnWebElements("web_tbl_PolicyRecievablesTable");
		 * 
		 * for(WebElement row:rows) { List<WebElement>
		 * colums=row.findElements(By.xpath("//td[4]"));
		 * 
		 * for(int i=0;i<colums.size();i++) {
		 * if(colums.get(i).getText().equalsIgnoreCase("Risk Charge")) {
		 * 
		 * actual_dueDate=colums.get(i+3).getText();
		 * actual_Amount=colums.get(i+4).getText(); break; } } }
		 */

		/*
		 * if(actual_dueDate.trim().equalsIgnoreCase(hParams.get("DueDate"))) {
		 * dashboard.setStepDetails("Due Date", "Due date verified successfuly", "N/A");
		 * dashboard.writeResults(); }
		 * 
		 * 
		 */
		if (actual_Amount.trim().equalsIgnoreCase(DashboardProperties.riskAmount.trim())) {
			dashboard.setStepDetails("Risk Amount", "Risk Amount verified successfuly actual:" + actual_Amount
					+ " and expected:" + DashboardProperties.riskAmount + "", "N/A");
			dashboard.writeResults();
		}
	}

	public void captureRiskChargesfromBenefitInfo(Hashtable<String, String> hParams) throws Exception {
		String policyNumber = "";
		policyNumber = hParams.get("policyNumber");
		FPMS_Actions llAction = new FPMS_Actions();
		llAction.selectMenuItem("Query", "Common Query");
		llAction.clickElement("web_radio_PolicyNumber");
		Utils.sleep(10);
		llAction.enterValue("web_txt_CommonQueryPolicyNumber", policyNumber);
		llAction.clickElement("web_btn_SearchParty");
		Utils.sleep(10);
		dashboard.setStepDetails("Seach Policy ", "Policy number should be entered and clicked successfully", "N/A");
		dashboard.writeResults();
		llAction.selectTab("Benefit Info");
		dashboard.setStepDetails("Click on Policy Name link ", "Policy number link should be clicked", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_lnk_PlanName");
		dashboard.setStepDetails("Benefit Information Page ", "Benefit Information page should be opened", "N/A");
		dashboard.writeResults();
		DashboardProperties.riskAmount = llAction.getText("web_table_RiskAmount");
		dashboard.setStepDetails("Capture Risk Amount ",
				"Risk Amount :" + DashboardProperties.riskAmount + "Captured successfully", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_benefitInfo_ClickBack");
		dashboard.setStepDetails("click on Back Button ", "Back button should be clicked successfully", "N/A");
		dashboard.writeResults();
	}

	/*
	 * public void Verify_PartyId_Number(Hashtable<String, String> hParams) throws
	 * Exception { try { FPMS_Actions llAction = new FPMS_Actions(); Recordset
	 * recordset =
	 * ExcelUtility.queryExcel(FPMSProperties.getInstance().getRiskChargesLocation()
	 * , "Select * from RiskChargeExternal where Reference='" + hParams.get("Ref#")
	 * + "'", "2"); recordset.next(); String PartyIdNumber =
	 * recordset.getField("PartyIdNumber");
	 * 
	 * 
	 * llAction.selectMenuItem("Query", "Common Query");
	 * llAction.waitUntilElementPresent("web_radio_PolicyNumber");
	 * llAction.clickElement("web_radio_PolicyNumber");
	 * llAction.enterValue("web_txt_CommonQueryPolicyNumber",
	 * hParams.get("PolicyNumber")); // should come Run time
	 * llAction.returnWebElement("web_txt_CommonQueryPolicyNumber").sendKeys(Keys.
	 * TAB); llAction.sleep(1);
	 * dashboard.setStepDetails("Enter Policy #","Policy number: "+hParams.
	 * get("PolicyNumber")+" should be entered successfully","N/A");
	 * dashboard.writeResults(); llAction.clickElement("web_btn_SearchParty");
	 * 
	 * dashboard.setStepDetails("Click Search Button "
	 * ,"Search button should be clicked successfully","N/A");
	 * llAction.waitUntilElementPresent("web_btn_ExitBenefitInformation");
	 * dashboard.writeResults();
	 * 
	 * llAction.selectTab("Party Info"); // llAction.waitforPageLoad();
	 * 
	 * dashboard.setStepDetails("Click On Party Info Tab",
	 * "Party info Tab should be  clicked successfully", "N/A");
	 * llAction.waitUntilElementPresent("web_btn_ExitBenefitInformation");
	 * dashboard.writeResults();
	 * 
	 * String actual_PartyId = llAction.getText("web_tbl_PartyIdNumber"); String
	 * expected_PartyId = PartyIdNumber;
	 * 
	 * dashboard.setStepDetails("Verify PartyId", "PartyId In TestData :" +
	 * expected_PartyId + " and In UI: " + actual_PartyId +
	 * " verified successfully", "N/A"); if
	 * (actual_PartyId.trim().equalsIgnoreCase(expected_PartyId.trim())) {
	 * dashboard.writeResults(); } else { throw new
	 * LowLevelException("Mismatch Party Id, In UI found " + actual_PartyId +
	 * " and in TestData expected: " + expected_PartyId); }
	 * 
	 * 
	 * dashboard.setStepDetails("Click on Exit",
	 * "Exit button should be clicked successfully", "N/A");
	 * llAction.clickElement("web_btn_ExitBenefitInformation");
	 * llAction.waitforPageLoad(); dashboard.writeResults();
	 * 
	 * } catch (Exception e) { throw new BPCException(e); } }
	 */

	public void Verify_Plan_Code_Name(Hashtable<String, String> hParams) throws Exception {
		/*
		 * try { FPMS_Actions llAction = new FPMS_Actions(); Recordset recordset =
		 * ExcelUtility.queryExcel(FPMSProperties.getInstance().getRiskChargesLocation()
		 * , "Select * from RiskChargeExternal where Reference='" + hParams.get("Ref#")
		 * + "'", "2"); recordset.next(); String PlanCode =
		 * recordset.getField("PlanCode"); llAction.selectTab("Benefit Info"); //
		 * llAction.waitforPageLoad();
		 * 
		 * dashboard.setStepDetails("Click On Benefit Info Tab",
		 * "Benefit info Tab should be  clicked successfully", "N/A");
		 * llAction.waitUntilElementPresent("web_btn_ExitBenefitInformation");
		 * dashboard.writeResults();
		 * 
		 * String actual_PlanName = llAction.getText("web_lnk_PlanName"); String
		 * expected_PlanName = PlanCode;
		 * 
		 * dashboard.setStepDetails("Verify Plan Name/Code", "Plan Name In TestData :" +
		 * expected_PlanName + " and In UI: " + actual_PlanName +
		 * " verified successfully", "N/A"); if
		 * (actual_PlanName.trim().equalsIgnoreCase(expected_PlanName.trim())) {
		 * dashboard.writeResults(); } else { throw new
		 * LowLevelException("Mismatch Plan Name/Code, In UI found " + actual_PlanName +
		 * " and in TestData expected: " + expected_PlanName); }
		 * 
		 * 
		 * dashboard.setStepDetails("Click on Exit",
		 * "Exit button should be clicked successfully", "N/A");
		 * llAction.clickElement("web_btn_ExitBenefitInformation");
		 * llAction.waitforPageLoad(); dashboard.writeResults();
		 * 
		 * } catch (Exception e) { throw new BPCException(e); }
		 */
	}

	/*
	 * public void logOut(Hashtable<String, String> hParams) { LL_Actions ll=new
	 * LL_Actions(); try { ll.quitApplication(); } catch (Exception e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } }
	 */
	public void Verify_Commencement_Date(Hashtable<String, String> hParams) throws Exception {
		/*
		 * try { FPMS_Actions llAction = new FPMS_Actions();
		 * 
		 * Recordset recordset =
		 * ExcelUtility.queryExcel(FPMSProperties.getInstance().getRiskChargesLocation()
		 * , "Select * from RiskChargeExternal where Reference='" + hParams.get("Ref#")
		 * + "'", "2"); recordset.next();
		 * 
		 * String CommencemenDate = recordset.getField("CommencemenDate");
		 * 
		 * llAction.selectTab("Policy Info"); // llAction.waitforPageLoad();
		 * 
		 * dashboard.setStepDetails("Click On Policy Info Tab",
		 * "Policy Info Tab should be  clicked successfully", "N/A");
		 * llAction.waitUntilElementPresent("web_btn_ExitBenefitInformation");
		 * dashboard.writeResults();
		 * 
		 * String actual_CommencementDate =
		 * llAction.getText("web_tbl_CommencementDate"); String
		 * expected_CommencementDate = CommencemenDate;
		 * 
		 * dashboard.setStepDetails("Verify Commencement Date",
		 * "Commencement Date In TestData :" + expected_CommencementDate +
		 * " and In UI: " + actual_CommencementDate + " verified successfully", "N/A");
		 * if
		 * (actual_CommencementDate.trim().equalsIgnoreCase(expected_CommencementDate.
		 * trim())) { dashboard.writeResults(); } else { throw new
		 * LowLevelException("Mismatch In Commenecement Date, In UI found " +
		 * actual_CommencementDate + " and in TestData expected: " +
		 * expected_CommencementDate); }
		 * 
		 * } catch (Exception e) { throw new BPCException(e); }
		 */
	}

	public void Verify_Risk_Charge_due_Date(Hashtable<String, String> hParams) throws Exception {
		/*
		 * try { FPMS_Actions llAction = new FPMS_Actions();
		 * 
		 * Recordset recordset =
		 * ExcelUtility.queryExcel(FPMSProperties.getInstance().getRiskChargesLocation()
		 * , "Select * from RiskChargeExternal where Reference='" + hParams.get("Ref#")
		 * + "'", "2"); recordset.next(); String RiskChargeDueDate =
		 * recordset.getField("RiskChargeDueDate"); String RiskChargeAmount =
		 * recordset.getField("RiskChargeAmount");
		 * 
		 * dashboard.setStepDetails("Click on Quick Links Tab",
		 * "Quick Link Tab should be clicked", "N/A");
		 * llAction.selectTab("Quick Links");
		 * llAction.waitUntilElementPresent("web_lnk_PolicRecievable");
		 * dashboard.writeResults();
		 * 
		 * llAction.clickElement("web_lnk_PolicRecievable");
		 * 
		 * String actual_dueDate = llAction.getText("web_table_DueDate"); String
		 * actual_Amount = llAction.getText("web_tableAmount");
		 * 
		 * if (actual_dueDate.trim().equalsIgnoreCase(RiskChargeDueDate)) {
		 * dashboard.setStepDetails("Verify Due Date", "Due date In test data:" +
		 * RiskChargeDueDate + " and In UI :" + actual_dueDate +
		 * " verified successfuly", "N/A"); dashboard.writeResults(); }
		 * 
		 * if (actual_Amount.trim().equalsIgnoreCase(RiskChargeAmount)) {
		 * dashboard.setStepDetails("Verify Risk Charge",
		 * "Risk Charge Amount In test data:" + RiskChargeAmount + " and In UI:" +
		 * actual_Amount + " verified successfuly", "N/A"); dashboard.writeResults(); }
		 * 
		 * } catch (Exception e) { throw new BPCException(e); }
		 * 
		 * llAction.clickElement("web_btn_ExitBenefitInformation"); //
		 * llAction.waitforPageLoad(); dashboard.setStepDetails("Click on Exit",
		 * "Exit button should be clicked successfully", "N/A");
		 * dashboard.writeResults();
		 */
	}

	/*
	 * Name: VerifyPolicyStatus Purpose: Get the value and Also take a SCreenshot of
	 * the Policy Status Parameters: HashMap Exception: BPCException
	 */

	public String queryPolicyInfo(Hashtable<String, String> hParams) throws Exception {
		String policyStatus = FPMSConstants.UNKNOWN;
		String policyNumber;
		launchQuerySearch(hParams.get("PolicyNo"));
		String evalPolicyStatus = hParams.get("PolicyStatus");
		try {
			policyNumber = GetValueOfSpecificQueryLabel("web_query_policy_number_tbl", "Policy number");
			policyStatus = GetValueOfSpecificQueryLabel("web_query_tbl_PolicyStatus", "Policy Status");
			llAction.move_to_element("web_query_tbl_PolicyStatus");

			if (!StringUtils.isEmpty(evalPolicyStatus) && !(evalPolicyStatus.equalsIgnoreCase(policyStatus))) {
				String errorMessage = "Verify Policy status failed" + "Policy number : " + policyNumber
						+ "Expected status = " + evalPolicyStatus + "Actual status = " + policyStatus;
				dashboard.setFailStatus(new BPCException(errorMessage));
			} else {
				dashboard.setStepDetails("Get the Policy Status of Policy " + policyNumber + "",
						"The Policy Status is " + policyStatus + "  ", "N/A");
				dashboard.writeResults();
			}
		} catch (Exception e) {
			dashboard.writeResults();
			throw new BPCException("Exception occured in VerifyPolicyStatus");
		}
		return policyStatus;
	}

	public String queryCSInfo_TransactionDate(Hashtable<String, String> hParams) throws Exception {
		String transactionDate = StringUtils.EMPTY;
		launchQuerySearch(hParams.get("PolicyNumber"));
		try {
			llAction.selectTab("CS Info");
			llAction.waitUntilLoadingCompletes();
			int colPos = llAction.GetColumnPositionInTable("web_tbl_csInfo_batchTable", "TRANSACTION");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_csInfo_batchTable", hParams.get("Transaction"),
					colPos);
			transactionDate = llAction.GetTextFromTable("web_tbl_csInfo_batchTable", rowPos, colPos + 4).split(" ")[0];
			llAction.clickElement("web_query_benefitInfo_exit");
		} catch (Exception e) {
			dashboard.writeResults();
			throw new BPCException("Exception occured in VerifyPolicyStatus");
		}
		return transactionDate;
	}

	/*
	 * Name: GetValueOfSpecificQueryLabel Purpose: Get the value of Any label
	 * displayed in Common Query Page Parameters: TableElementKey: Exception:
	 * BPCException
	 */
	public String GetValueOfSpecificQueryLabel(String TableElement, String LabelName) throws Exception {
		try {
			Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(TableElement);
			String xPath = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr/td[contains(text(), '"
					+ LabelName + "')]/following-sibling::td";
			WebElement tdWithValue = llAction.findElementByXpath(xPath);
			return tdWithValue.getText();
		} catch (Exception e) {
			throw new BPCException("e");
		}
	}

	public void launchQuerySearch(String policyNo) throws Exception {
		PolicyHandler policyHandler = FPMSManager.getInstance().getPolicyHandler();

		String policyNumber = StringUtils.EMPTY;

		llAction.selectMenuItem("Query", "Common Query");
		llAction.clickElement("web_query_Radio_SearchPolicyNo");
		if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
			policyNumber = policyNo;
			policyHandler.getPolicy().setPolicyNo(policyNumber);
		} else {

			policyNumber = policyHandler.getPolicy().getPolicyNo();
		}
		llAction.enterValue("web_query_txt_PolicyNumber", policyNumber);
		llAction.sendkeyStroke("web_query_txt_PolicyNumber", Keys.ENTER);
		dashboard.setStepDetails("Search Policy ", "Policy number should be entered ", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_query_btn_Search");
		llAction.waitUntilLoadingCompletes();
	}

	public void getQueryPolicyFields(Hashtable<String, String> hParams) throws Exception {
		PolicyHandler policyHandler = FPMSManager.getInstance().getPolicyHandler();
		try {
			launchQuerySearch(hParams.get("PolicyNo"));

			llAction.selectTab("Benefit Info");
			llAction.waitUntilLoadingCompletes();
			int noOfBenefits = llAction.getRowCountInTable("web_query_benefitInfo_tbl");
			int planCodecol = llAction.GetColumnPositionInTable("web_query_benefitInfo_tbl", "Plan Name");
			int lifeAssuredCol = llAction.GetColumnPositionInTable("web_query_benefitInfo_tbl", "Life Assured");
			int benefitTermCol = llAction.GetColumnPositionInTable("web_query_benefitInfo_tbl", "Benefit Term");
			int sumAssuredCol = llAction.GetColumnPositionInTable("web_query_benefitInfo_tbl", "Sum Assured");
			int standardIPCol = llAction.GetColumnPositionInTable("web_query_benefitInfo_tbl",
					"Next Standard Installment Premium");
			int extraIPCol = llAction.GetColumnPositionInTable("web_query_benefitInfo_tbl",
					"Next Extra Installment Premium");
			int benefitStatusCol = llAction.GetColumnPositionInTable("web_query_benefitInfo_tbl", "Benefit Status");

			for (int i = 2; i <= noOfBenefits; i++) {
				BenefitData benefit = new BenefitData();
				String planCode = llAction.GetTextFromTable("web_query_benefitInfo_tbl", i, planCodecol);
				String planCodeParts[] = planCode.split(FPMSConstants.COLON_SEPERATOR);
				String benefitCode = planCodeParts[1].trim();
				String lifeAssured = llAction.GetTextFromTable("web_query_benefitInfo_tbl", i, lifeAssuredCol);
				String benefitTerm = llAction.GetTextFromTable("web_query_benefitInfo_tbl", i, benefitTermCol);
				String sumAssured = llAction.GetTextFromTable("web_query_benefitInfo_tbl", i, sumAssuredCol);
				String standardIP = llAction.GetTextFromTable("web_query_benefitInfo_tbl", i, standardIPCol);
				String extraIP = llAction.GetTextFromTable("web_query_benefitInfo_tbl", i, extraIPCol);
				String benefitStatus = llAction.GetTextFromTable("web_query_benefitInfo_tbl", i, benefitStatusCol);
				benefit.setBenefitCode(benefitCode);
				benefit.setLifeAssured(lifeAssured);
				benefit.setBenefitTerm(benefitTerm);
				benefit.setSumAssured(sumAssured);
				benefit.setStandardPremium(standardIP);
				benefit.setExtraPremium(extraIP);
				benefit.setBenefitStatus(benefitStatus);

				policyHandler.getPolicy().addBenefittoList(benefit);
			}
			llAction.selectTab("Policy Info");
			llAction.waitUntilLoadingCompletes();
			String policyStatus = llAction.table_GetValueOfSpecificLabel("web_tbl_policyInfo_PolicyStatus",
					"Policy Status");
			String commencementDate = llAction.table_GetValueOfSpecificLabel("web_tbl_policyInfo_DateInfo",
					"Commencement Date");
			policyHandler.updatePolicy("PolicyStatus", policyStatus);
			policyHandler.updatePolicy("CommencementDate", commencementDate);
			llAction.selectTab("Financial Info");
			llAction.waitUntilLoadingCompletes();
			String paymentFrequency = llAction.table_GetValueOfSpecificLabel("web_query_financialInfo_tbl",
					"Renewal Payment Frequency");
			String paymentMethod = llAction.table_GetValueOfSpecificLabel("web_query_financialInfo_tbl",
					"Payment Method");
			policyHandler.updatePolicy("PaymentFrequency", paymentFrequency);
			policyHandler.updatePolicy("PaymentMethod", paymentMethod);
			llAction.selectTab("Party Info");
			llAction.waitUntilLoadingCompletes();
			int proposerNameCol = llAction.GetColumnPositionInTable("web_query_proposerInfo_tbl", "Name");
			String policyHolder = llAction.GetTextFromTable("web_query_proposerInfo_tbl", 2, proposerNameCol);
			policyHandler.updatePolicy("PolicyHolder", policyHolder);
			llAction.selectTab("Quick Links");
			llAction.clickElement("web_lnk_quickLinks_policyBasicInfo");
			String agentCode = llAction.table_GetValueOfSpecificLabel("web_tbl_policybasicInformation",
					"Issue IAC No.");
			policyHandler.updatePolicy("AgentCode", agentCode);
			llAction.clickElement("web_query_benefitInfo_exit");
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}

	public void displayCommonQueryInfo(Hashtable<String, String> hParams) throws Exception {
		try {
			/*
			 * llAction.selectMenuItem("Query", "Common Query");
			 * llAction.waitUntilLoadingCompletes();
			 * llAction.clickElement("web_radio_PolicyNumber");
			 * llAction.waitUntilLoadingCompletes(); String policyNumber =
			 * StringUtils.EMPTY;
			 * 
			 * if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
			 * policyNumber = hParams.get("PolicyNumber"); } else { policyNumber =
			 * policyHandler.getPolicy().getPolicyNo(); }
			 * llAction.enterValue("web_query_txt_PolicyNumber", policyNumber); // should
			 * come // Run time llAction.sendkeyStroke("web_query_txt_PolicyNumber",
			 * Keys.ENTER); llAction.waitUntilLoadingCompletes();
			 * llAction.clickElement("web_query_btn_Search");
			 * llAction.waitUntilLoadingCompletes();
			 */
			launchQuerySearch(hParams.get("PolicyNumber"));
			dashboard.setStepDetails("Capturing screen shot for Policy Info", "Policy Info screenshot is captured",
					"N/A");
			dashboard.writeResults();
			List<WebElement> webElements = llAction.findElements("web_tbl_common_tabs");
			List<String> tabs = new ArrayList<>();
			for (WebElement element : webElements) {
				tabs.add(element.getText());
			}
			if (hParams.get("Capture").equalsIgnoreCase("All")) {

				for (int i = 0; i < tabs.size(); i++) {

					captureTabName(tabs.get(i).toString());
					System.out.print(tabs.get(i).toString());
					// if (tabName.get(i).getText().toString().equalsIgnoreCase("Benefit Info")) {
					// captureMainBenefitInfo(hParams.get("BenefitCode"));
					// // added by Prashantha March 02,2019 to only capture main benefit code
					// llAction.clickElement("web_btn_CommonQuery_Back");
					// llAction.waitUntilLoadingCompletes();
					//
					// }
				}
			} else {
				String tabNames[] = hParams.get("Capture").isEmpty() ? new String[] {}
						: hParams.get("Capture").split(",");
				for (int i = 0; i < tabNames.length; i++) {
					captureTabName(tabNames[i]);
					// if (tabNames[i].equalsIgnoreCase("Benefit Info")) {
					// captureMainBenefitInfo();
					// // added by Prashantha March 02,2019 to only capture main benefit code
					// llAction.clickElement("web_btn_CommonQuery_Back");
					// llAction.waitUntilLoadingCompletes();
					// }
				}
			}

			llAction.clickElement("web_query_benefitInfo_exit");

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void captureTabName(String tabname) throws Exception {
		try {
			llAction.selectTab(tabname);
			llAction.waitUntilLoadingCompletes();
			if (tabname.equalsIgnoreCase("Quick Links")) {
				dashboard.setStepDetails("Quick Links", "Quick Links", "N/A");
				dashboard.writeResults();
				capturePolicyBasicInfo();
				capturePolicyPaymentInformation();
				capturePolicyReceivableandPayableInformation();
				captureSurvivalbenefitInfo();
				captureBonusInfo();
				captureDisburseMethodInfo();
				captureCreditCardGIROTransactionInformation();
			} else if (tabname.equalsIgnoreCase("Financial Info")) {
				dashboard.setStepDetails("Financial Info", "Financial Info", "N/A");
				dashboard.writeResults();
				capturePaymentMethod();
				// This is to check main benefit in tab "Benefit Info".
			} else if (tabname.equalsIgnoreCase("Benefit Info")) {
				dashboard.setStepDetails("Benefit Info", "Benefit Info", "N/A");
				dashboard.writeResults();
				captureMainBenefitInfo();
			} else {
				dashboard.setStepDetails(tabname, tabname, "N/A");
				dashboard.writeResults();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	// Capture All quick Links
	public void captureQuickLinks(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("Query", "Common Query");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_radio_PolicyNumber");
			llAction.enterValue("web_query_txt_PolicyNumber", hParams.get("PolicyNumber"));
			llAction.sendkeyStroke("web_query_txt_PolicyNumber", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_query_btn_Search");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Policy Info", "Policy Info screenshot is captured",
					"N/A");
			dashboard.writeResults();
			llAction.selectTab("Quick Links");
			llAction.waitUntilLoadingCompletes();
			capturePolicyBasicInfo();
			capturePolicyPaymentInformation();
			capturePolicyReceivableandPayableInformation();
			captureSurvivalbenefitInfo();
			captureBonusInfo();
			captureDisburseMethodInfo();
			llAction.clickElement("web_query_benefitInfo_exit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void capturePaymentMethod() {
		try {

			if (llAction.isDisplayed("web_common_query_financialinfo", 3)) {
				llAction.clickElement("web_common_query_financialinfo");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Capturing screen shot for Payment Method",
						"Payment Method screenshot is captured", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_CommonQuery_Back");
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void captureDisburseMethodInfo() {
		try {
			int rowPos = llAction.GetRowPositionInTable("web_table_quickLinks", "Disbursement Method", 2, 0);
			llAction.SelectRowInTable("web_table_quickLinks", rowPos, 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Disbursement Method",
					"Policy Basic Information screenshot is captured", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CommonQuery_Back");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {

		}

	}

	public void captureBonusInfo() {
		try {
			int rowPos = llAction.GetRowPositionInTable("web_table_quickLinks", "Bonus Information", 2, 0);
			llAction.SelectRowInTable("web_table_quickLinks", rowPos, 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Bonus Information",
					"Policy Basic Information screenshot is captured", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CommonQuery_Back");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {

		}

	}

	public void captureSurvivalbenefitInfo() {
		try {
			int rowPos = llAction.GetRowPositionInTable("web_table_quickLinks", "Suvival Benefit Information", 2, 0);
			llAction.SelectRowInTable("web_table_quickLinks", rowPos, 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Suvival Benefit Information",
					"Policy Basic Information screenshot is captured", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CommonQuery_Back");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {

		}

	}

	public void capturePolicyReceivableandPayableInformation() {
		try {
			int rowPos = llAction.GetRowPositionInTable("web_table_quickLinks",
					"Policy Receivable and Payable Information", 2, 0);
			llAction.SelectRowInTable("web_table_quickLinks", rowPos, 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Policy Receivable and Payable Information",
					"Policy Basic Information screenshot is captured", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CommonQuery_Back");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {

		}

	}

	public void capturePolicyPaymentInformation() {
		try {
			int rowPos = llAction.GetRowPositionInTable("web_table_quickLinks", "Policy Payment Information", 2, 0);
			llAction.SelectRowInTable("web_table_quickLinks", rowPos, 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Policy Payment Information",
					"Policy Basic Information screenshot is captured", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CommonQuery_Back");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {

		}

	}
	
	
	public void captureAnnuityInformation() {
		try {
			int rowPos = llAction.GetRowPositionInTable("web_table_quickLinks", "Annuity Information", 2, 0);
			llAction.SelectRowInTable("web_table_quickLinks", rowPos, 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Annuity Information",
					"Annuity Information screenshot is captured", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CommonQuery_Back");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {

		}

	}
	
	
	public void capturePolicyBasicInfo() {
		try {
			int rowPos = llAction.GetRowPositionInTable("web_table_quickLinks", "Policy Basic Information", 2, 0);
			llAction.SelectRowInTable("web_table_quickLinks", rowPos, 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Policy Basic Information",
					"Policy Basic Information screenshot is captured", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CommonQuery_Back");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {

		}
	}

	public void captureCreditCardGIROTransactionInformation() {
		try {
			int rowPos = llAction.GetRowPositionInTable("web_table_quickLinks",
					"Credit Card / GIRO Transaction Information", 2, 0);
			llAction.SelectRowInTable("web_table_quickLinks", rowPos, 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Batch Transaction Information",
					"Batch Transaction Information screenshot is captured", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CommonQuery_Back");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {

		}
	}

	public void captureMainBenefitInfo() {
		try {
			if (llAction.isDisplayed("web_txt_benefit_info_main_plan_name", 2)) {
				int rowCount = llAction.getRowCountInTable("web_txt_benefit_info_main_plan_name");
				if (rowCount > 1) {
					for (int i = 1; i < rowCount; i++) {
						Utils.editXpath("web_txt_benefit_info_plan_name", "BenefitPlanNames",
								new String[] { Integer.toString(i + 1) });
						String benefitName = llAction.getText("BenefitPlanNames");
						llAction.clickElement("BenefitPlanNames");
						llAction.waitUntilLoadingCompletes();
						dashboard.setStepDetails("Benefit info - " + benefitName, "Benefit info - " + benefitName,
								"N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_CommonQuery_Back");
						llAction.waitUntilLoadingCompletes();

					}
				}

			} else {
				dashboard.setFailStatus(new BPCException("Capture main benefit from Benefit Info page:"
						+ "Failed : There is no main benefit plan name found."));
			}

		} catch (Exception ex) {

		}

	}
	public void captureCSinfo(Hashtable<String, String> hParams) throws Exception {
		String Appdate;
		llAction.selectTab("CS Info");
		llAction.waitUntilLoadingCompletes();
		dashboard.setStepDetails("Capturing screen shot for  CS Info", "CS Info screenshot is captured", "N/A");
		dashboard.writeResults();

		if (hParams.get("ApplicationDate") != null && hParams.get("ApplicationDate") != "") {
			Appdate = hParams.get("ApplicationDate");
		} else {
			String Applicationdate = llAction.getText("web_txt_systemdate");
			System.out.println("Applicationdate ----> " + Applicationdate);
			String[] appdate = Applicationdate.split(" ");
			String data = appdate[0];
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date date = formatter.parse(data);
			Calendar calender = Calendar.getInstance();
			calender.setTime(date);
			Appdate = formatter.format(calender.getTime());

		}
		Utils.editXpath("web_link_csinfoDummy", "web_link_csinfo",
				new String[] { hParams.get("PolicyAlterationitem"), Appdate, });

		llAction.clickElementJs("web_link_csinfo");
		llAction.waitUntilLoadingCompletes();
		dashboard.setStepDetails("Capturing screen shot for CSInfo from customer Serviceinformation ",
				"CS info screenshot is captured", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_btn_csinfo_back");

	}

	public void cs_CheckCommonQueryBeforeBatchRun(Hashtable<String, String> hParams) throws Exception {

		launchQuerySearch(hParams.get("PolicyNumber"));
		captureTabName("Policy Info");
		captureTabName("Financial Info");
		captureTabName("Benefit Info");
		captureCSinfo(hParams);
		llAction.selectTab("Quick Links");
		llAction.waitUntilLoadingCompletes();
		capturePolicyBasicInfo();
		capturePolicyReceivableandPayableInformation();
		llAction.clickElement("web_query_benefitInfo_exit");

	}

	public void cs_CheckCommonQueryAfterBatchRun(Hashtable<String, String> hParams) throws Exception {

		launchQuerySearch(hParams.get("PolicyNumber"));
		captureTabName("Benefit Info");
		llAction.selectTab("Quick Links");
		llAction.waitUntilLoadingCompletes();
		capturePolicyReceivableandPayableInformation();
		llAction.clickElement("web_query_benefitInfo_exit");

	}

	public void captureQuickLinksSubSection(Hashtable<String, String> hParams) throws Exception {
		try {

			String policyNumber = hParams.get("PolicyNumber");

			if (!StringUtils.isEmpty(policyNumber)) {

				String[] policies = hParams.get("PolicyNumber").split(",");

				for (String policy : policies) {
					llAction.selectMenuItem("Query", "Common Query");
					llAction.waitUntilLoadingCompletes();
					llAction.clickElement("web_radio_PolicyNumber");
					llAction.enterValue("web_query_txt_PolicyNumber", policy);
					llAction.sendkeyStroke("web_query_txt_PolicyNumber", Keys.ENTER);
					llAction.waitUntilLoadingCompletes();
					llAction.clickElement("web_query_btn_Search");
					llAction.waitUntilLoadingCompletes();
					dashboard.setStepDetails("Capturing screen shot for Policy Info",
							"Policy Info screenshot is captured", "N/A");
					dashboard.writeResults();
					llAction.selectTab("Quick Links");
					llAction.waitUntilLoadingCompletes();

					String links[] = hParams.get("Capture").split(",");
					for (String link : links) {
						String methodName = "capture" + link.replace(" ", "");
						methodName = methodName.replace("/", "");
						Method method = this.getClass().getMethod(methodName);
						method.invoke(this);
					}
				}
				llAction.clickElement("web_query_benefitInfo_exit");
				llAction.waitUntilLoadingCompletes();
			} else {
				dashboard.setStepDetails("Common Query Quick Links", "No policies defined", "N/A");
				dashboard.writeResults();
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void multiPolicyCommonQueryInfo(Hashtable<String, String> hParams) throws Exception {
		try {

			String policyNumber = hParams.get("PolicyNumber");

			if (!StringUtils.isEmpty(policyNumber)) {

				String[] policies = hParams.get("PolicyNumber").split(",");
				PolicyHandler policyHandler = FPMSManager.getInstance().getPolicyHandler();
				for (String policy : policies) {
					policyHandler.getPolicy().setPolicyNo(policy);
					llAction.selectMenuItem("Query", "Common Query");
					llAction.waitUntilLoadingCompletes();
					llAction.clickElement("web_radio_PolicyNumber");
					llAction.enterValue("web_query_txt_PolicyNumber", policy);
					llAction.sendkeyStroke("web_query_txt_PolicyNumber", Keys.ENTER);
					llAction.waitUntilLoadingCompletes();
					llAction.clickElement("web_query_btn_Search");
					llAction.waitUntilLoadingCompletes();
					dashboard.setStepDetails("Capturing screen shot for Policy Info",
							"Policy Info screenshot is captured", "N/A");
					dashboard.writeResults();
					List<WebElement> webElements = llAction.findElements("web_tbl_common_tabs");
					List<String> tabs = new ArrayList<>();
					for (WebElement element : webElements) {
						tabs.add(element.getText());
					}
					String links[] = hParams.get("Capture").isEmpty() ? new String[] {}
							: hParams.get("Capture").split(",");
					ArrayList<String> captureQuickLinks = new ArrayList<String>();
					for (String link : links) {
						if (tabs.contains(link)) {
							captureTabName(link);
						} else {
							captureQuickLinks.add(link);
						}
					}
					llAction.selectTab("Quick Links");
					llAction.waitUntilLoadingCompletes();
					for (String link : captureQuickLinks) {
						String methodName = "capture" + link.replace(" ", "");
						methodName = methodName.replace("/", "");
						Method method = this.getClass().getMethod(methodName);
						method.invoke(this);
					}
				}
				llAction.clickElement("web_query_benefitInfo_exit");
				llAction.waitUntilLoadingCompletes();
			} else {
				dashboard.setStepDetails("Common Query Quick Links", "No policies defined", "N/A");
				dashboard.writeResults();
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void paymentQuery(Hashtable<String, String> hParams) {
		try {
			llAction.selectMenuItem("Query", "Query Payments", "PaymentQuery");
			llAction.waitUntilLoadingCompletes();
			llAction.clearText("web_btn_fee_generation_from");// cleardates
			llAction.clearText("web_btn_fee_generation_to");// cleardates
			llAction.enterValue("web_rcc_txt_Search_PolicyNo", hParams.get("PolicyNumber"));// enter policy sumber
			llAction.clickElement("web_registration_btn_search");// Click search button
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Payment information should be displayed",
					"Payment information for given policy is displayed", "");
			dashboard.writeResults();
			llAction.clickElement("web_registration_btn_exit");// click Exit
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	private void captureDirectCreditPaymentInformation(){
		try {
			int rowPos = llAction.GetRowPositionInTable("web_table_quickLinks", "Direct Credit Payment Information", 2, 0);
			llAction.SelectRowInTable("web_table_quickLinks", rowPos, 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Capturing screen shot for Direct Credit Payment Information",
					"Direct Credit Payment Information is captured", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CommonQuery_Back");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

}
