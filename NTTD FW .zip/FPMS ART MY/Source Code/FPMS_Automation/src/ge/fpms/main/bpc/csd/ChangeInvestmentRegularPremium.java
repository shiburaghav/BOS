package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;
public class ChangeInvestmentRegularPremium {

	/*
	 * Name: Change Investment Regular Premium Purpose: Navigate to CS module from
	 * the Main Page and Change Investment Regular Premium for a policy
	 * Parameters:Parameter Hash table Return Value: NA Exception: BPCException
	 * 
	 * @author: Sahil SIngh 0n 12/12/2018
	 */

	private final static Logger LOGGER = Logger.getLogger(ChangeInvestmentRegularPremium.class.getName());

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public ChangeInvestmentRegularPremium() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void changeInvestmentRegularPrem(Hashtable<String, String> hParams) throws Exception {

		try {

			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage1"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			increaseDecreaseRegularPrem(hParams);
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage3") != null && hParams.get("WarningErrorMessage3") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage3"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			dashboard.setStepDetails("After successfully entering new regular premium",
					"New Regular Premium should be entered", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_submitRP");

			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage4") != null && hParams.get("WarningErrorMessage4") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage4"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}

			captureBeforeAndAfterChange("AFTERCHANGE");
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();

			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage5") != null && hParams.get("WarningErrorMessage5") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage5"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}

			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void increaseDecreaseRegularPrem(Hashtable<String, String> hParams) throws Exception {

		try {
			llAction.waitUntilElementPresent("web_tbl_BenefitAlteration");
			dashboard.writeResults();
			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_BenefitAlteration", "Benefit");

			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_BenefitAlteration",
					hParams.get("BenefitCode"), BenefitalterCol);
			if (llAction.getRowCountInTable("web_tbl_BenefitAlteration") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitAlteration", BenefitalterRow, BenefitalterCol - 2, "input");
			}
			
			dashboard.setStepDetails("Benefit Alteration Item before change is chosen",
					"Benefit Alteration item should be selected", "N/A");
			dashboard.writeResults();

			String click = hParams.get("IncreaseDecreaseEffectivefrom");
			switch (click) {

			case "Increase RP from last Anniversary":
				llAction.clickElement("web_btn_IncreaseRP");

				break;

			case "Increase RP from next due":
				llAction.clickElement("web_btn_IncreaseRPNextDue");

				break;
			case "Decrease RP from next due":
				llAction.clickElement("web_btn_DecreaseRP");

				break;
			}
			llAction.waitUntilLoadingCompletes();

			if (llAction.isDisplayed("web_btn_ContinueRP", 10)) {
				if (hParams.get("WarningErrorMessage2") != null && hParams.get("WarningErrorMessage2") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage2"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}

			llAction.enterValue("web_txt_newRP", hParams.get("NewInvestmentRegularPremium"));

			llAction.clickElement("web_btn_ConfirmRP");

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void captureBeforeAndAfterChange(String ActionType) throws Exception {
		try {
			switch (ActionType.toUpperCase()) {
			case "BEFORECHANGE":
				dashboard.setStepDetails("Before the regular premium is changed", "Screenshot should be taken", "N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":
				dashboard.setStepDetails("After the regular premium is changed", "Screenshot should be taken", "N/A");
				dashboard.writeResults();
				break;
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void changeRPValidatePolicyalteration(Hashtable<String, String> hParams) throws Exception {

		try {

			int alterationCol = llAction.GetColumnPositionInTable("web_tbl_PolicyAlteration", "Policy alteration item");
			int alterationRow = llAction.GetRowPositionInTable("web_tbl_PolicyAlteration",
					hParams.get("PolicyAlterationitem"), alterationCol);
			String s = llAction.GetTextFromTable("web_tbl_PolicyAlteration", alterationRow, alterationCol + 1);

			if (s.equalsIgnoreCase("Completed")) {

				System.out.println("Status appearing is : " + s);
				dashboard.setStepDetails("Validate status is completed", "Status should be checked", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setFailStatus(new BPCException("Status is not completed"));
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void validateWarningMessages(String warningMsg, String message) throws Exception {
		try {
			if (warningMsg.contains(message)) { // compare warning messages
				dashboard.setStepDetails(message + "Warning message should be displayed",
						"\"Warning message should be displayed ", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(
						"Warning message " + warningMsg + " from application is not matching with test data");
				dashboard.writeResults();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateInvestmentRegularPremLapsePolicyWarning(Hashtable<String, String> hParams) throws Exception {

		llAction = new FPMS_Actions();

		try {

			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage1"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilElementPresent("web_tbl_BenefitAlteration");
			dashboard.writeResults();
			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_BenefitAlteration", "Benefit");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_BenefitAlteration",
					hParams.get("BenefitCode"), BenefitalterCol);
			if (llAction.getRowCountInTable("web_tbl_BenefitAlteration") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitAlteration", BenefitalterRow, BenefitalterCol - 2, "input");
			}
			
			dashboard.setStepDetails("Benefit Alteration Item before change is chosen",
					"Benefit Alteration item should be selected", "N/A");
			dashboard.writeResults();

			String click = hParams.get("IncreaseDecreaseEffectivefrom");
			switch (click) {

			case "Increase RP from last Anniversary":
				llAction.clickElement("web_btn_IncreaseRP");

				break;

			case "Increase RP from next due":
				llAction.clickElement("web_btn_IncreaseRPNextDue");

				break;
			case "Decrease RP from next due":
				llAction.clickElement("web_btn_DecreaseRP");

				break;
			}

			if (hParams.get("WarningErrorMessage2") != null && hParams.get("WarningErrorMessage2") != "") {

				CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
						hParams.get("WarningErrorMessage2"));

			}

		} catch (Exception ex) {

			dashboard.writeResults();
			LOGGER.log(Level.SEVERE,
					"Exception occured while calling validateInvestmentRegularPremWarning method \n Exception is "
							+ ex.getMessage());
			ex.printStackTrace();
			throw new BPCException("");
		}

	}

	public void validateInvestmentRegularPremAlert(Hashtable<String, String> hParams) throws Exception {

		llAction = new FPMS_Actions();

		try {
			if (llAction.isDisplayed("web_btn_ContinueRP", 10)) {

				llAction.clickElement("web_btn_ContinueRP");
			}
			llAction.waitUntilElementPresent("web_tbl_BenefitAlteration");
			dashboard.writeResults();
			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_BenefitAlteration", "Benefit");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_BenefitAlteration",
					hParams.get("BenefitCode"), BenefitalterCol);
			
			if (llAction.getRowCountInTable("web_tbl_BenefitAlteration") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitAlteration", BenefitalterRow, BenefitalterCol - 2, "input");
			}
			
			dashboard.setStepDetails("Benefit Alteration Item before change is chosen",
					"Benefit Alteration item should be selected", "N/A");
			dashboard.writeResults();

			String click = hParams.get("IncreaseDecreaseEffectivefrom");
			switch (click) {

			case "Increase RP from last Anniversary":
				llAction.clickElement("web_btn_IncreaseRP");

				break;

			case "Increase RP from next due":
				llAction.clickElement("web_btn_IncreaseRPNextDue");

				break;
			case "Decrease RP from next due":
				llAction.clickElement("web_btn_DecreaseRP");

				break;
			}
			llAction.waitUntilLoadingCompletes();

			if (llAction.isDisplayed("web_btn_ContinueRP", 10)) {

				llAction.clickElement("web_btn_ContinueRP");
			}

			captureBeforeAndAfterChange("BEFORECHANGE");

			llAction.enterValue("web_txt_newRP", hParams.get("NewInvalidInvestmentRegularPremium"));

			llAction.clickElement("web_btn_ConfirmRP");

			captureBeforeAndAfterChange("AFTERCHANGE");

			if (hParams.get("WarningErrorMessage3") != null && hParams.get("WarningErrorMessage3") != "") {

				CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
						hParams.get("WarningErrorMessage3"));
			}
			llAction.acceptAlert();
			llAction.enterValue("web_txt_newRP", hParams.get("NewInvestmentRegularPremium"));

			llAction.clickElement("web_btn_ConfirmRP");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {

				llAction.clickElement("web_btn_ContinueRP");
				llAction.waitUntilLoadingCompletes();
			}
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("After successfully entering new regular premium",
					"New Regular Premium should be entered", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_submitRP");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {

				llAction.clickElement("web_btn_ContinueRP");
				llAction.waitUntilLoadingCompletes();
			}
			captureBeforeAndAfterChange("AFTERCHANGE");
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();

			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage5") != null && hParams.get("WarningErrorMessage5") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage5"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(new BPCException(ex));
		}

	}

	public void validateInvestmentRegularPremWarning(Hashtable<String, String> hParams) throws Exception {

		llAction = new FPMS_Actions();

		try {

			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage1"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilElementPresent("web_tbl_BenefitAlteration");
			dashboard.writeResults();
			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_BenefitAlteration", "Benefit");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_BenefitAlteration",
					hParams.get("BenefitCode"), BenefitalterCol);

			if (llAction.getRowCountInTable("web_tbl_BenefitAlteration") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitAlteration", BenefitalterRow, BenefitalterCol - 2, "input");
			}
			
			dashboard.setStepDetails("Benefit Alteration Item before change is chosen",
					"Benefit Alteration item should be selected", "N/A");
			dashboard.writeResults();

			String click = hParams.get("IncreaseDecreaseEffectivefrom");
			switch (click) {

			case "Increase RP from last Anniversary":
				llAction.clickElement("web_btn_IncreaseRP");

				break;

			case "Increase RP from next due":
				llAction.clickElement("web_btn_IncreaseRPNextDue");

				break;
			case "Decrease RP from next due":
				llAction.clickElement("web_btn_DecreaseRP");

				break;
			}

			if (hParams.get("WarningErrorMessage2") != null && hParams.get("WarningErrorMessage2") != "") {
				CSDHelper.getInstance().validateWarningMessages("web_txt_ErrorWarningCancellation",
						hParams.get("WarningErrorMessage2"));
			}

		} catch (Exception ex) {

			throw new BPCException(new BPCException(ex));
		}

	}

	public void validateInvestmentRegularPremError(Hashtable<String, String> hParams) throws Exception {

		llAction = new FPMS_Actions();

		try {
			if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {

				CSDHelper.getInstance().validateWarningMessages("web_txt_ErrorWarningCancellation",
						hParams.get("WarningErrorMessage1"));
			}

		} catch (Exception ex) {

			throw new BPCException(new BPCException(ex));
		}

	}

	public void validateInvestmentRPforDelistedFunds(Hashtable<String, String> hParams) throws Exception {

		llAction = new FPMS_Actions();

		try {
			increaseDecreaseRegularPrem(hParams);
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage3") != null && hParams.get("WarningErrorMessage3") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage3"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			dashboard.setStepDetails("After successfully entering new regular premium",
					"New Regular Premium should be entered", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_submitRP");

			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WarningErrorMessage4") != null && hParams.get("WarningErrorMessage4") != "") {

				CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg",
						hParams.get("WarningErrorMessage4"));
			}
		} catch (Exception ex) {

			throw new BPCException(new BPCException(ex));
		}

	}
}
