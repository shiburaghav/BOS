package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class Contact extends BusinessComponent {
	private FPMS_Actions llAction;
	private static final String RESIDENTIAL= "Residential";
	private DashboardHandler dashboardHandler;

	public Contact() {
		llAction = new FPMS_Actions();
		dashboardHandler = DashboardHandler.getInstance();
	}
	public void addContactInformation(Hashtable<String, String> hParams) throws Exception{
		try {
			llAction.selectTab("Other Contact");
			/*if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				llAction.selectTab("contact");
			}*/
			llAction.waitUntilLoadingCompletes();

			if(llAction.isEnabled("web_lst_HomeCountry")){
				llAction.selectByVisibleText("web_lst_HomeCountry", hParams.get("HomeNoCode"));
				llAction.enterValue("web_txt_HomeTelephone", hParams.get("HomeNo"));
			}
			llAction.selectByVisibleText("web_lst_BusinessTelCode", hParams.get("OfficeCountryCode"));
			llAction.enterValue("web_txt_BusinessNo", hParams.get("OfficeNo"));
			llAction.selectByVisibleText("web_lst_FaxCode", hParams.get("FaxCountryCode"));
			llAction.enterValue("web_txt_FaxNo", hParams.get("FaxNo"));
			if(llAction.isEnabled("web_lst_la_TelCode")){
				llAction.selectByVisibleText("web_lst_la_TelCode", hParams.get("HandphoneCode"));
				llAction.sendkeyStroke("web_lst_la_TelCode", Keys.ENTER);
				llAction.enterValue("web_txt_la_handNo", hParams.get("HandPhoneNo"));
				llAction.sendkeyStroke("web_txt_la_handNo", Keys.ENTER);
			}
			llAction.clickElement("web_addr_btn_apply");
			llAction.waitUntilLoadingCompletes();
			dashboardHandler.setStepDetails("Enter Other Contact Details.","Mobile and residence numbers are entered.",
					"N/A");
			dashboardHandler.writeResults();
			

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	//Divya:14/02/2019
	public void addResidentialAddress(Hashtable<String, String> hParams) throws Exception{
		try {
			llAction.selectTab("Other Address");
			llAction.waitUntilLoadingCompletes();
			llAction.selectByVisibleText("web_lst_ContactType", hParams.get("ContactType"));
			if(hParams.get("ContactType").equalsIgnoreCase(RESIDENTIAL))
				llAction.selectByVisibleText("web_addr_lst_CountryofAddress", hParams.get("CountryofAddress_Res"));
			llAction.enterValue("web_addr_txt_line1", hParams.get("Line1_Res"));
			llAction.enterValue("web_addr_txt_line2", hParams.get("Line2_Res"));
			llAction.enterValue("web_addr_txt_line3", hParams.get("Line3_Res"));
			llAction.enterValue("web_addr_txt_line4", hParams.get("Line4_Res"));
			llAction.enterValue("web_addr_txt_line5", hParams.get("Line5_Res"));
			llAction.enterValue("web_addr_txt_line6", hParams.get("Line6_Res"));
			llAction.enterValue("web_addr_txt_postalCodeRes", hParams.get("PostalCode_Res"));
			llAction.clickElement("web_addr_btn_apply");
			llAction.waitUntilLoadingCompletes();
			dashboardHandler.setStepDetails("Enter residential address Details.", "Residential address is entered", "N/A");
			dashboardHandler.writeResults();
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void addAddress(Hashtable<String, String> hParams) throws Exception {
		try {

			// llAction.handleCertificateErrors();
			// llAction.switchtoChildWindow(
			// FPMSConstants.WINDOW_TITLE_CORRESPONDENCE_ADDRESS, "");
			// llAction.maximizeWindow();
			//	llAction.waitUntilElementPresent("web_addr_lst_CountryofAddress");
			llAction.selectByVisibleText("web_addr_lst_CountryofAddress", hParams.get("CountryCode"));
			String contactType = hParams.get("AddrressContactType");
			String addressIndicator = hParams.get("AddressIndicator");
			String addressType = hParams.get("AddressType");
			String contactTypeWidget = "web_addr_lst_contactType";

			if (llAction.isDisplayed(contactTypeWidget, 5)) {
				llAction.selectByVisibleText(contactTypeWidget, contactType);
			}

			llAction.selectByVisibleText("web_addr_lst_addressIndicator", addressIndicator);

			if (addressIndicator.equalsIgnoreCase(FPMSConstants.ADDRESS_INDICATOR_LOCAL)) {

				llAction.selectByVisibleText("web_addr_lst_addressType", addressType);
			}

			if (addressType.equalsIgnoreCase(FPMSConstants.ADDRESS_TYPE_FORMATTED)) {
				llAction.enterValue("web_addr_txt_postalCode", hParams.get("PostalCode"));
				llAction.enterValue("web_addr_lnk_block", hParams.get("AddressBlock"));

			} else {
				llAction.enterValue("web_addr_txt_postalCode2", hParams.get("PostalCode"));
				llAction.enterValue("web_addr_txt_line1", hParams.get("Line1"));

				//Deepa_08022019: Line 2, 3, 4, 5 and 6 added; 
				llAction.enterValue("web_addr_txt_line2", hParams.get("Line2"));
				llAction.enterValue("web_addr_txt_line3", hParams.get("Line3"));
				llAction.enterValue("web_addr_txt_line4", hParams.get("Line4"));
				llAction.enterValue("web_addr_txt_line5", hParams.get("Line5"));
				llAction.enterValue("web_addr_txt_line6", hParams.get("Line6"));

			}
			/*
			 * if (contactType .equalsIgnoreCase(FPMSConstants.ADDRESS_TYPE_CORRESPONDENCE)
			 * && hParams.get("SameAddrIndCheckBox").equalsIgnoreCase("Y")) {
			 * 
			 * llAction.checkBox_Check("web_checkBox_SameforResidentialAddress"); }
			 */
			//Divya: 14/02
			if (hParams.get("SameAddrIndCheckBox").equalsIgnoreCase("Y")) {
				llAction.checkBox_Check("web_addr_checkBox_SameforResidential");
				llAction.clickElement("web_addr_btn_apply");
				llAction.waitUntilLoadingCompletes();
				DashboardHandler.getInstance().writeToDashboard(4, "Enter Correspondence address", "Correspondence address details are entered.",
						"N/A");
			}else {
				llAction.clickElement("web_addr_btn_apply");
				DashboardHandler.getInstance().writeToDashboard(4, "Enter Correspondence address", "Correspondence address details are entered.",
						"N/A");
				addResidentialAddress(hParams);

			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

}
