package ge.fpms.main.bpc.bcp.templates.directcredit;

public class DirectCredit {

	private Header Header;
	private Details[] Details;
	private Summary Summary;
	
	public Header getHeader() {
		return Header;
	}
	public void setHeader(Header header) {
		Header = header;
	}
	public Details[] getDetails() {
		return Details;
	}
	public void setDetails(Details[] details) {
		Details = details;
	}
	public Summary getSummary() {
		return Summary;
	}
	public void setSummary(Summary summary) {
		Summary = summary;
	}
	
	
}
