package ge.fpms.main.bpc.nbu;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;


public abstract class BusinessComponent {
	FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	
	public BusinessComponent() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}

	public void searchPolicy(String policyId, String tblElementKey) throws Exception{
		searchPolicy( policyId,  tblElementKey,  "web_txt_DetailReg_PolicyNumber");
	}
	
	public void searchPolicy(String policyId, String tblElementKey, String policNumberElementId) throws Exception{
		
		searchPolicy(policyId, tblElementKey, policNumberElementId, "Policy Number");
	}
	
	public void searchPolicy(String policyId, String tblElementKey, String policNumberElementId, String columnName) throws Exception{
		if(policyHandler.isPolicyEmpty()){
			policyHandler.getPolicy().setPolicyNo(policyId);
		}
		
		
		
		String policyNo = policyHandler.getPolicy().getPolicyNo();
		if(!StringUtils.isEmpty(policyNo)){
			llAction.enterValue(policNumberElementId, policyNo);
			Utils.sleep(3);
			llAction.clickElement("web_txt_DetailReg_Search");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails(
							"Search for policy   "
									+ policyHandler.getPolicy()
											.getPolicyNo(),
							"The policy should be avaialble in Search Results. ",
							"N/A");
			dashboard.writeResults();
			
			llAction.waitUntilLoadingCompletes();
			
			int colPos = llAction.GetColumnPositionInTable(tblElementKey, columnName);
			int rowPos = llAction.GetRowPositionInTable(tblElementKey, policyHandler.getPolicy().getPolicyNo(), colPos);
			llAction.SelectRowInTable(tblElementKey, rowPos, colPos,"a");
			
			llAction.waitUntilLoadingCompletes();
		}
		else{
			throw new BPCException("Search policy failed as policy number is not defined");
		}
		
	}

	
	
	public String getApplicationCurrentDate(){
		String applicationDate = "";
		try {
			applicationDate = llAction.getText("web_txt_application_date_time");
		
		applicationDate = Utils.formatDateTime(applicationDate, FPMSConstants.DATE_FORMAT);
		} catch (Exception e) {
			new BPCException(e);
		}
		return applicationDate;
	}
	
}
