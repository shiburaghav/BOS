package ge.fpms.main.bpc.nbu;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.components.Party;

public class Registration extends BusinessComponent {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	
	
	public Registration() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	/**
	 * searches for a party
	 * @param windowName
	 * @param partyNumberId
	 * @param partyType
	 * @param partyName
	 */
	protected void searchParty(String windowName, String partyNumberId,
			String partyType, String partyName) {
		try {
			//Divya:added certError handling for Nominee and other roles
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(windowName);
			llAction.waitUntilLoadingCompletes();
			llAction.maximizeWindow();
			Utils.sleep(5);
			llAction.enterValue("web_txt_NBDSearchParty_PartyIDType", partyType);
			llAction.enterValue("web_txt_NBDSearchParty_PartyName", partyName);
			llAction.enterValue("web_txt_NBDSearchParty_PartyID",partyNumberId);
			llAction.clickElement("web_Btn_PartySearch");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails(windowName, windowName + " should be entered", "N/A");
			dashboard.writeResults();
		
			llAction.handleCertificateErrors();
			llAction.waitUntilLoadingCompletes();
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	/**
	 * create party (Proposer or LifeAssured) // NOT READY FOR USE. THIS IS JUST A PLACE HOLDER FOR CREATING PARTY FROM INITIAL REG
	 * @param partyId
	 * @throws Exception
	 */
	protected void createParty(String partyId) throws Exception{
		Party partyObj = new Party();
		try {
			partyObj.creatParty(partyId);
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	public boolean isOrganization(String companyIndicator){
		boolean companyInd = false;
		if(!StringUtils.isEmpty(companyIndicator) && companyIndicator.equalsIgnoreCase("Y")){
			companyInd = true;
			
		}
		return companyInd;
	}
}
