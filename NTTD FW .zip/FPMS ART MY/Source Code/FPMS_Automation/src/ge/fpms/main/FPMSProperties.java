package ge.fpms.main;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.nttdata.app.ARTProperties;
import com.nttdata.core.handler.DashboardHandler;

public class FPMSProperties extends ARTProperties {

	private static final String JSON_FOLDER = "json";

	private static FPMSProperties obj;

	private final String REGION_SINGAPORE_CODE = "SG";
	private final String REGION_MALAYSIA_CODE = "MY";
	private final String REGION_SINGAPORE = "Singapore";
	private final String REGION_MALAYSIA = "Malaysia";
	private final String NBU_EXTRACT_TEMPLATE = "NBU Extraction.xlsx";
	private final String CSD_EXTRACT_TEMPLATE = "CSD Extraction.xlsx";
	private final String LIABILITY_FILE_NAME = "ClaimsLiabilityInput.xlsx";
	private final String IE_DRIVER = "IEDriverServer.exe";
	private final String BIN_FOLDER = "bin";
	private final String INPUT_FILES = "Input_Files";

	private FPMSProperties() {
		super();
	}

	public static FPMSProperties getInstance() {
		if (obj == null) {
			obj = new FPMSProperties();

		}
		return obj;
	}

	public String getRegion() {
		String region = getProperty("region").equalsIgnoreCase(REGION_SINGAPORE_CODE) ? REGION_SINGAPORE
				: REGION_MALAYSIA;
		return region;
	}

	public String getNBUExtractTemplate() {
		return pathToJoin(new String[] { getTemplatesLocation(), FOLDER_DELIMITER, NBU_EXTRACT_TEMPLATE }).toString();
	}

	public String getCSDExtractTemplate() {
		return pathToJoin(new String[] { getTemplatesLocation(), FOLDER_DELIMITER, CSD_EXTRACT_TEMPLATE }).toString();
	}

	/*public String getLiabilitiesFileLocation() {
		return pathToJoin(
				new String[] { getTestDataFolderPath(getProperty("Settings.Module")),getProperty("Settings.Module"), FOLDER_DELIMITER, LIABILITY_FILE_NAME })
						.toString();
	}*/
	
	public String getLiabilitiesFileLocation() {
		return pathToJoin(new String[]{getTestDataFolderPath(System.getProperty("Settings.Module")),FOLDER_DELIMITER,LIABILITY_FILE_NAME}).toString();
	}

	@Override
	public String getDriverPath() {
		return pathToJoin(
				new String[] { getProjectLocation(), FOLDER_DELIMITER, BIN_FOLDER, FOLDER_DELIMITER, IE_DRIVER })
						.toString();
	}

	public String getNBUExtractionPath() throws Exception {
		String timestamp = new SimpleDateFormat("ddMMYYHHmm").format(new Date());
		String ouputFileFolderPath=System.getProperty("Settings.ART Downloads")+ File.separator + System.getProperty("Settings.Run Name") + File.separator + FPMSConstants.OUTPUTFILES_FOLDER ;
		DashboardHandler.getInstance().createDirStruct(ouputFileFolderPath);
		
		return pathToJoin(new String[] { System.getProperty("Settings.ART Downloads"), File.separator,
				System.getProperty("Settings.Run Name"), File.separator, FPMSConstants.OUTPUTFILES_FOLDER,
				File.separator, FPMSConstants.NBUEXTRACTION_FILE_BASENAME, FPMSConstants.NAME_SEPERATOR, timestamp,
				FPMSConstants.EXCELFILE_FORMAT });
	}

	public String getCSDExtractionPath() throws Exception {
		String ouputFileFolderPath=System.getProperty("Settings.ART Downloads")+ File.separator + System.getProperty("Settings.Run Name") + File.separator + FPMSConstants.OUTPUTFILES_FOLDER ;
		DashboardHandler.getInstance().createDirStruct(ouputFileFolderPath);
		
		return pathToJoin(new String[] { System.getProperty("Settings.ART Downloads"), File.separator,
				System.getProperty("Settings.Run Name"), File.separator, FPMSConstants.OUTPUTFILES_FOLDER,
				File.separator, FPMSConstants.CSDEXTRACTION_FILE_BASENAME, FPMSConstants.EXCELFILE_FORMAT });
	}
	
	public String getInputFilesPath() {
		return pathToJoin(
				new String[] { System.getProperty("Settings.ART Downloads"),File.separator, INPUT_FILES })
						.toString();
	}

	public String getJsonPath(String fileName) {
		return pathToJoin(new String[]{getConfigurationLocation(),FOLDER_DELIMITER,JSON_FOLDER,FOLDER_DELIMITER,fileName}).toString();
	}
}
