package ge.fpms.main.bpc.bcp.templates.lockbox;


public class LockBox {

	private Header Header;
	private Details[] Details;
	private Summary Summary;
	
	public Header getHeader() {
		return Header;
	}

	public void setFH(Header Header) {
		this.Header = Header;
	}

	public Details[] getDetails() {
		return Details;
	}

	public void setDetails(Details[] details) {
		Details = details;
	}

	public Summary getSummary() {
		return Summary;
	}

	public void setSummary(Summary summary) {
		Summary = summary;
	}

}
