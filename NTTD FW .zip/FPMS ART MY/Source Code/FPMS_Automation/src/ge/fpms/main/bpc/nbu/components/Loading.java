package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.nttdata.common.util.Utils;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;

public class Loading {

	private static FPMS_Actions llAction = new FPMS_Actions();

	private static void fillLoadingInfo(String loadingOption, String loadingType, String loadingBlock,
			Hashtable<String, String> hParams) throws Exception {
		switch (loadingOption.toUpperCase()) {
		case "HEALTH LOADING":
			if (Integer.parseInt(loadingBlock) > 1) {
				Utils.editXpath("web_uw_btn_loadingAddLayer", "web_uw_btn_" + loadingOption + "",
						new String[] { "healthTable" });
				llAction.clickElement("web_uw_btn_" + loadingOption + "");
			}
			llAction.checkBox_Check("web_uw_chk_HealthLoading");

			Utils.editXpath("web_txt_health_LifeExtraMortality", "web_txt_health_LifeExtraMortalityLayers",
					new String[] { loadingBlock });
			llAction.enterValue("web_txt_health_LifeExtraMortalityLayers", hParams.get("LifeExtraMortality"));

			Utils.editXpath("web_txt_health_TPDExtraMortality", "web_txt_health_TPDExtraMortalityLayers",
					new String[] { loadingBlock });
			llAction.enterValue("web_txt_health_TPDExtraMortalityLayers", hParams.get("TPDExtraMortality"));

			Utils.editXpath("web_txt_health_DreadDiseaseExtraMortality",
					"web_txt_health_DreadDiseaseExtraMortalityLayers", new String[] { loadingBlock });
			llAction.enterValue("web_txt_health_DreadDiseaseExtraMortalityLayers",
					hParams.get("DreadDiseaseExtraMorbidity"));

			Utils.editXpath("web_txt_health_EMValue", "web_txt_health_EMValueLayers", new String[] { loadingBlock });
			llAction.enterValue("web_txt_health_EMValueLayers", hParams.get("EMValue"));

			Utils.editXpath("web_txt_HealthLoadingEMRateReCalIND", "web_txt_HealthLoadingEMRateReCalINDLayers",
					new String[] { loadingBlock });
			llAction.enterValue("web_txt_HealthLoadingEMRateReCalINDLayers", hParams.get("EMRateRe-CalIND"));

			Utils.editXpath("web_txt_LoadingDurationDummy", "web_txt_healthLoadingDuration",
					new String[] { "A" + loadingBlock });
			llAction.enterValue("web_txt_healthLoadingDuration", hParams.get("Duration"));

			LoadingType.enterSpecificLoadingType("healthTable", "A" + loadingBlock, loadingType, hParams);
			break;
		case "OCCUPATION LOADING":
			if (Integer.parseInt(loadingBlock) > 1) {
				Utils.editXpath("web_uw_btn_loadingAddLayer", "web_uw_btn_" + loadingOption + "",
						new String[] { "occupationTable" });
				llAction.clickElement("web_uw_btn_" + loadingOption + "");
			}
			llAction.checkBox_Check("web_uw_chk_occupationLoading");
			Utils.editXpath("web_txt_LoadingDurationDummy", "web_txt_occupationLoadingDuration",
					new String[] { "B" + loadingBlock });
			llAction.enterValue("web_txt_occupationLoadingDuration", hParams.get("Duration"));

			LoadingType.enterSpecificLoadingType("occupationTable", "B" + loadingBlock, loadingType, hParams);
			break;
		case "AVOCATION LOADING":
			if (Integer.parseInt(loadingBlock) > 1) {
				Utils.editXpath("web_uw_btn_loadingAddLayer", "web_uw_btn_" + loadingOption + "",
						new String[] { "avocationTable" });
				llAction.clickElement("web_uw_btn_" + loadingOption + "");
			}
			llAction.checkBox_Check("web_uw_chk_avocationLoading");
			Utils.editXpath("web_txt_LoadingDurationDummy", "web_txt_avocationLoadingDuration",
					new String[] { "C" + loadingBlock });
			llAction.enterValue("web_txt_avocationLoadingDuration", hParams.get("Duration"));

			LoadingType.enterSpecificLoadingType("avocationTable", "C" + loadingBlock, loadingType, hParams);
			break;
		case "RESIDENTIAL LOADING":
			if (Integer.parseInt(loadingBlock) > 1) {
				Utils.editXpath("web_uw_btn_loadingAddLayer", "web_uw_btn_" + loadingOption + "",
						new String[] { "residentialTable" });
				llAction.clickElement("web_uw_btn_" + loadingOption + "");
			}
			llAction.checkBox_Check("web_uw_chk_residentialLoading");
			Utils.editXpath("web_txt_LoadingDurationDummy", "web_txt_residentialLoadingDuration",
					new String[] { "D" + loadingBlock });
			llAction.enterValue("web_txt_residentialLoadingDuration", hParams.get("Duration"));

			LoadingType.enterSpecificLoadingType("residentialTable", "D" + loadingBlock, loadingType, hParams);
			break;
		case "AVIATION LOADING":
			if (Integer.parseInt(loadingBlock) > 1) {
				Utils.editXpath("web_uw_btn_loadingAddLayer", "web_uw_btn_" + loadingOption + "",
						new String[] { "aviationTable" });
				llAction.clickElement("web_uw_btn_" + loadingOption + "");
			}
			llAction.checkBox_Check("web_uw_chk_aviationLoading");
			Utils.editXpath("web_txt_LoadingDurationDummy", "web_txt_aviationLoadingDuration",
					new String[] { "E" + loadingBlock });
			llAction.enterValue("web_txt_aviationLoadingDuration", hParams.get("Duration"));

			LoadingType.enterSpecificLoadingType("aviationTable", "E" + loadingBlock, loadingType, hParams);
			break;
		case "OTHER LOADING":
			if (Integer.parseInt(loadingBlock) > 1) {
				Utils.editXpath("web_uw_btn_loadingAddLayer", "web_uw_btn_" + loadingOption + "",
						new String[] { "otherTable" });
				llAction.clickElement("web_uw_btn_" + loadingOption + "");
			}
			llAction.checkBox_Check("web_uw_chk_otherLoading");
			Utils.editXpath("web_txt_LoadingDurationDummy", "web_txt_otherLoadingDuration",
					new String[] { "F" + loadingBlock });
			llAction.enterValue("web_txt_otherLoadingDuration", hParams.get("Duration"));

			LoadingType.enterSpecificLoadingType("otherTable", "F" + loadingBlock, loadingType, hParams);
			break;
		}
	}

	public static Hashtable<String, String> enterLoading(Hashtable<String, String> hParams, int benefitNumber) throws Exception {
		Hashtable<String, String> hTable = new Hashtable<String, String>();
		try {
			JSONParser parser = new JSONParser();
			String loadingData = hParams.get("LoadingDetailsBenefit"+(benefitNumber+1)+"");
			JSONArray json = (JSONArray) parser.parse(loadingData);
			for (Object obj : json) {
				if (obj instanceof JSONObject) {
					JSONObject jsonobj = (JSONObject) obj;
					hTable.put("Loading Option", (String) jsonobj.get("LoadingOption"));
					int noOfLayers = Integer.parseInt(((String) jsonobj.get("NoOfLayers")));
					if (((String) jsonobj.get("LoadingOption")).equals("Health Loading")) {
						for (int i = 1; i <= noOfLayers; i++) {

							JSONObject layerObj = (JSONObject) jsonobj.get("Layer" + i + "");

							hTable.put("AmountOrTimes", (String) layerObj.get("AmountOrTimes"));
							hTable.put("Duration", (String) layerObj.get("Duration"));
							hTable.put("LifeExtraMortality", (String) layerObj.get("Life Extra Mortality"));
							hTable.put("TPDExtraMortality", (String) layerObj.get("TPD Extra Mortality"));
							hTable.put("DreadDiseaseExtraMorbidity",
									(String) layerObj.get("Dread Disease Extra Morbidity"));
							hTable.put("EMValue", (String) layerObj.get("EM Value"));
							hTable.put("EMRateRe-CalIND", (String) layerObj.get("EM Rate Re-Cal IND"));

							fillLoadingInfo(jsonobj.get("LoadingOption").toString().toUpperCase(),(String)layerObj.get("LoadingType"),
							Integer.toString(i), hTable);
						}
					} else {
						for (int i = 1; i <= noOfLayers; i++) {
							JSONObject layerObj = (JSONObject) jsonobj.get("Layer" + i + "");
							hTable.put("AmountOrTimes", (String) layerObj.get("AmountOrTimes"));
							hTable.put("Duration", (String) layerObj.get("Duration"));
							fillLoadingInfo(jsonobj.get("LoadingOption").toString().toUpperCase(),(String)layerObj.get("LoadingType"),
							Integer.toString(i), hTable);
						}
					}
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
		return hTable;
	}

}
