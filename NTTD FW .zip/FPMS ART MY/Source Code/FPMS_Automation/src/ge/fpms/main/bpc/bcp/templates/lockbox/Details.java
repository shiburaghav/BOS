package ge.fpms.main.bpc.bcp.templates.lockbox;


import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Details implements IPaymentSection {
	private Type recordType;
	private Type transactionDate;
	private Type transSerialNo;
	private Type billType;
	private Type filler2;
	private Type geCode;
	private Type paidAmt;
	private Type chequeNo;
	private Type formOfColl;
	private Type chequeCode;
	private Type bankCode;
	private Type tellerBranch;
	private Type tellerCode;
	private Type transCode;
	
	
	private Type date;
	private Type bankAccount;
	private Type depositDate;
	private Type policyNo;
	private Type filler;
	
	public static final int FIELD_COUNT = 19;

	public Details(){
		
	}
	
	
	public Type getRecordType() {
		return recordType;
	}


	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}


	public Type getTransactionDate() {
		return transactionDate;
	}


	public void setTransactionDate(Type transactionDate) {
		this.transactionDate = transactionDate;
	}


	public Type getTransSerialNo() {
		return transSerialNo;
	}


	public void setTransSerialNo(Type transSerialNo) {
		this.transSerialNo = transSerialNo;
	}


	public Type getBillType() {
		return billType;
	}


	public void setBillType(Type billType) {
		this.billType = billType;
	}


	public Type getFiller2() {
		return filler2;
	}


	public void setFiller2(Type filler2) {
		this.filler2 = filler2;
	}


	public Type getGeCode() {
		return geCode;
	}


	public void setGeCode(Type geCode) {
		this.geCode = geCode;
	}


	public Type getPaidAmt() {
		return paidAmt;
	}


	public void setPaidAmt(Type paidAmt) {
		this.paidAmt = paidAmt;
	}


	public Type getChequeNo() {
		return chequeNo;
	}


	public void setChequeNo(Type chequeNo) {
		this.chequeNo = chequeNo;
	}


	public Type getFormOfColl() {
		return formOfColl;
	}


	public void setFormOfColl(Type formOfColl) {
		this.formOfColl = formOfColl;
	}


	public Type getChequeCode() {
		return chequeCode;
	}


	public void setChequeCode(Type chequeCode) {
		this.chequeCode = chequeCode;
	}


	public Type getBankCode() {
		return bankCode;
	}


	public void setBankCode(Type bankCode) {
		this.bankCode = bankCode;
	}


	public Type getTellerBranch() {
		return tellerBranch;
	}


	public void setTellerBranch(Type tellerBranch) {
		this.tellerBranch = tellerBranch;
	}


	public Type getTellerCode() {
		return tellerCode;
	}


	public void setTellerCode(Type tellerCode) {
		this.tellerCode = tellerCode;
	}


	public Type getTransCode() {
		return transCode;
	}


	public void setTransCode(Type transCode) {
		this.transCode = transCode;
	}


	public Type getDate() {
		return date;
	}


	public void setDate(Type date) {
		this.date = date;
	}


	public Type getBankAccount() {
		return bankAccount;
	}


	public void setBankAccount(Type bankAccount) {
		this.bankAccount = bankAccount;
	}


	public Type getDepositDate() {
		return depositDate;
	}


	public void setDepositDate(Type depositDate) {
		this.depositDate = depositDate;
	}


	public Type getPolicyNo() {
		return policyNo;
	}


	public void setPolicyNo(Type policyNo) {
		this.policyNo = policyNo;
	}


	public Type getFiller() {
		return filler;
	}


	public void setFiller(Type filler) {
		this.filler = filler;
	}


	public Details(Type[] type) {
		super();
		this.recordType = new Type(type[0].getSize(), type[0].getDataType(),
				type[0].getValue(), type[0].getAlignment(),
				type[0].getPaddingChar());
		
		this.transactionDate = new Type(type[1].getSize(),
				type[1].getDataType(), type[1].getValue(),
				type[1].getAlignment(), type[1].getPaddingChar());
		
		this.transSerialNo = new Type(type[2].getSize(),
				type[2].getDataType(), type[2].getValue(),
				type[2].getAlignment(), type[2].getPaddingChar());
		
		this.billType = new Type(type[3].getSize(),
				type[3].getDataType(), type[3].getValue(),
				type[3].getAlignment(), type[3].getPaddingChar());
		
		this.filler = new Type(type[4].getSize(),
				type[4].getDataType(), type[4].getValue(),
				type[4].getAlignment(), type[4].getPaddingChar());
		
		this.geCode = new Type(type[5].getSize(),
				type[5].getDataType(), type[5].getValue(),
				type[5].getAlignment(), type[5].getPaddingChar());
		
		this.paidAmt = new Type(type[6].getSize(),
				type[6].getDataType(), type[6].getValue(),
				type[6].getAlignment(), type[6].getPaddingChar());
		this.chequeNo = new Type(type[7].getSize(),
				type[7].getDataType(), type[7].getValue(),
				type[7].getAlignment(), type[7].getPaddingChar());
		this.formOfColl = new Type(type[8].getSize(),
				type[8].getDataType(), type[8].getValue(),
				type[8].getAlignment(), type[8].getPaddingChar());
		this.chequeCode = new Type(type[9].getSize(), type[9].getDataType(),
				type[9].getValue(), type[9].getAlignment(),
				type[9].getPaddingChar());
		
		this.bankCode = new Type(type[10].getSize(),
				type[10].getDataType(), type[10].getValue(),
				type[10].getAlignment(), type[10].getPaddingChar());
		
		this.tellerBranch = new Type(type[11].getSize(),
				type[11].getDataType(), type[11].getValue(),
				type[11].getAlignment(), type[11].getPaddingChar());
		
		this.tellerCode = new Type(type[12].getSize(), type[12].getDataType(),
				type[12].getValue(), type[12].getAlignment(),
				type[12].getPaddingChar());
		
		this.transCode = new Type(type[13].getSize(),
				type[13].getDataType(), type[13].getValue(),
				type[13].getAlignment(), type[13].getPaddingChar());
		
		
		this.date = new Type(type[11].getSize(),
				type[14].getDataType(), type[14].getValue(),
				type[14].getAlignment(), type[14].getPaddingChar());
		
		this.bankAccount = new Type(type[15].getSize(), type[15].getDataType(),
				type[15].getValue(), type[15].getAlignment(),
				type[15].getPaddingChar());
		
		this.depositDate = new Type(type[16].getSize(),
				type[16].getDataType(), type[16].getValue(),
				type[16].getAlignment(), type[16].getPaddingChar());
		this.policyNo = new Type(type[17].getSize(),
				type[17].getDataType(), type[17].getValue(),
				type[17].getAlignment(), type[17].getPaddingChar());
		
		this.filler2 = new Type(type[18].getSize(), type[18].getDataType(),
				type[18].getValue(), type[18].getAlignment(),
				type[18].getPaddingChar());
		
		
	}

	public int[] getAttributesSize() {
		return new int[] {recordType.getSize(),transactionDate.getSize(),transSerialNo.getSize(),
				billType.getSize(),filler.getSize(),geCode.getSize(),paidAmt.getSize(),chequeNo.getSize(),
				formOfColl.getSize(),chequeCode.getSize(),bankCode.getSize(),tellerBranch.getSize(),
				tellerCode.getSize(),transCode.getSize(),date.getSize(),bankAccount.getSize(),
				depositDate.getSize(),policyNo.getSize(),filler2.getSize()};
	}

	
	public String getName() {
		return "2";
	}

	

	public String toString() {
		String details = new StringBuilder().append(recordType.toString()).append(transactionDate.toString()).append(transSerialNo.toString())
						.append(billType.toString()).append(filler.toString()).append(geCode.toString()).append(
						paidAmt.toString()).append(chequeNo.toString()).append(formOfColl.toString()).append(chequeCode.toString()).append(
						bankCode.toString()).append(tellerBranch.toString()).append(tellerCode.toString()).append(transCode.toString()).append(
						date.toString()).append(bankAccount.toString()).append(depositDate.toString()).append(policyNo.toString()).append(filler2.toString()).toString();
		
		return details;
	}

	public Type[] getAllAttributes() {
		return new Type[] { recordType,transactionDate,transSerialNo,billType,filler,
				geCode,paidAmt,chequeNo,formOfColl,chequeCode,bankCode,tellerBranch,
				tellerCode,transCode,date,bankAccount,depositDate,policyNo,filler2,};
	}
	public int getFieldCount(){
		return FIELD_COUNT ;
	}
}
