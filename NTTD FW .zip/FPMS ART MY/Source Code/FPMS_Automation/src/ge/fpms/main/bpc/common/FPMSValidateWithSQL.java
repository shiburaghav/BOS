package ge.fpms.main.bpc.common;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSProperties;

public class FPMSValidateWithSQL {
	private FPMSProperties fileProperties;
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	XSSFRow row;
	XSSFCell cell;

	public FPMSValidateWithSQL() {

		fileProperties = FPMSProperties.getInstance();
	}

	public void validateWithSQL(Hashtable<String, String> hParams) {
		try {
			HashMap<String, String> expectedHash = new HashMap<String, String>();
			HashMap<String, String> actualHash = new HashMap<String, String>();

			List<HashMap<String, String>> hashExpectedList = new ArrayList<HashMap<String, String>>();
			List<HashMap<String, String>> hashActualList = new ArrayList<HashMap<String, String>>();

			String inputFilesPath = fileProperties.getInputFilesPath();
			workbook = new XSSFWorkbook(new File(inputFilesPath + "\\FundTransaction.xlsx"));
			int noOfSheets = workbook.getNumberOfSheets();
			switch (hParams.get("QueryType").toUpperCase()) {
			case "FUNDTRANSACTION":
				for (int i = 0; i < noOfSheets; i++) {
					if (workbook.getSheetName(i).contains("Expected")) {
						for (int j = 1; j < workbook.getSheetAt(i).getPhysicalNumberOfRows(); j++) {
							expectedHash = new HashMap<String, String>();
							expectedHash.put("Policy_Number", workbook.getSheetAt(i).getRow(j).getCell(0).toString());
							expectedHash.put("Plan_Code", workbook.getSheetAt(i).getRow(j).getCell(1).toString());
							expectedHash.put("Allocate_Type", workbook.getSheetAt(i).getRow(j).getCell(2).toString());
							expectedHash.put("Trans_Date", workbook.getSheetAt(i).getRow(j).getCell(3).toString());
							expectedHash.put("Amount", workbook.getSheetAt(i).getRow(j).getCell(4).toString());
							expectedHash.put("Price_Effective_Date",
									workbook.getSheetAt(i).getRow(j).getCell(5).toString());
							expectedHash.put("PLD", workbook.getSheetAt(i).getRow(j).getCell(6).toString());
							expectedHash.put("MISC_Debt", workbook.getSheetAt(i).getRow(j).getCell(7).toString());

							hashExpectedList.add(expectedHash);
						}
					} else if (workbook.getSheetName(i).contains("Actuals")) {
						for (int j = 1; j < workbook.getSheetAt(i).getPhysicalNumberOfRows(); j++) {
							actualHash = new HashMap<String, String>();

							actualHash.put("Policy_Number", workbook.getSheetAt(i).getRow(j).getCell(0).toString());
							actualHash.put("Plan_Code", workbook.getSheetAt(i).getRow(j).getCell(1).toString());
							actualHash.put("Allocate_Type", workbook.getSheetAt(i).getRow(j).getCell(2).toString());
							actualHash.put("Trans_Date", workbook.getSheetAt(i).getRow(j).getCell(3).toString());
							actualHash.put("Amount", workbook.getSheetAt(i).getRow(j).getCell(4).toString());
							actualHash.put("Price_Effective_Date",
									workbook.getSheetAt(i).getRow(j).getCell(5).toString());
							actualHash.put("PLD", workbook.getSheetAt(i).getRow(j).getCell(6).toString());
							actualHash.put("MISC_Debt", workbook.getSheetAt(i).getRow(j).getCell(7).toString());

							hashActualList.add(actualHash);
						}
					}
				}
				break;
			case "DEDUCTION":
				break;
			}
			checkAnswers(hashExpectedList, hashActualList);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void checkAnswers(List<HashMap<String, String>> expectedHMap, List<HashMap<String, String>> actualHMap) {
		try {
			String inputFilesPath = fileProperties.getInputFilesPath();
			XSSFWorkbook workbook = new XSSFWorkbook(new File(inputFilesPath + "\\FundTransaction.xlsx"));
			int noOfCells = 0;
			for (int i = 0; i < expectedHMap.size(); i++) {
				for (HashMap.Entry<String, String> entry : actualHMap.get(i).entrySet()) {
					String expected = expectedHMap.get(i).get(entry.getKey());
					String actual = entry.getValue();
					if (!expected.equalsIgnoreCase(actual)) {
						XSSFSheet sheet = workbook.getSheetAt(1);
						for (int j = 1; j < sheet.getPhysicalNumberOfRows(); j++) {
							if(workbook.getSheetAt(1).getRow(j) == null) {
								XSSFRow tempRow = workbook.getSheetAt(1).createRow(j);
								for(int h = 0; h < noOfCells; h++) {
									XSSFCell cell = workbook.getSheetAt(1).getRow(j).getCell(h);
									XSSFCellStyle style = workbook.createCellStyle();
									style.setFillBackgroundColor(IndexedColors.RED.index);
									style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
									cell.setCellStyle(style);
								}
							}else {
								for (int k = 0; k < workbook.getSheetAt(1).getRow(j).getPhysicalNumberOfCells(); k++) {
									noOfCells = workbook.getSheetAt(1).getRow(j).getPhysicalNumberOfCells();
									if (workbook.getSheetAt(1).getRow(j).getCell(k).toString()
											.equalsIgnoreCase(actual.toString())) {
										if (workbook.getSheetAt(1).getRow(j).getCell(k).toString()
												.equalsIgnoreCase(actual)) {
											XSSFCell cell = workbook.getSheetAt(1).getRow(j).getCell(k);
											XSSFCellStyle style = workbook.createCellStyle();
											style.setFillBackgroundColor(IndexedColors.RED.index);
											style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
											cell.setCellStyle(style);
										}
									}
								}
							}
						}
					}
				}
				FileOutputStream fileOut = new FileOutputStream(inputFilesPath + "\\FundTransaction1.xlsx");
				workbook.write(fileOut);
				fileOut.close();
			}
			workbook.close();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
