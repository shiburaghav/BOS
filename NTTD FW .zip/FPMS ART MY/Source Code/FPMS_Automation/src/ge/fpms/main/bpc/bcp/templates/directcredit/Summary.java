package ge.fpms.main.bpc.bcp.templates.directcredit;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Summary implements IPaymentSection {
	
	private Type recordType;
	private Type acceptedCount;
	private Type acceptedAmount;
	private Type rejectedCount;
	private Type rejectedAmount;
	private Type returnedCount;
	private Type returnedAmount;
	private Type totalCount;
	private Type totalAmount; 
	private Type sFiller; 


	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getAcceptedCount() {
		return acceptedCount;
	}

	public void setAcceptedCount(Type acceptedCount) {
		this.acceptedCount = acceptedCount;
	}

	public Type getAcceptedAmount() {
		return acceptedAmount;
	}

	public void setAcceptedAmount(Type acceptedAmount) {
		this.acceptedAmount = acceptedAmount;
	}

	public Type getRejectedCount() {
		return rejectedCount;
	}

	public void setRejectedCount(Type rejectedCount) {
		this.rejectedCount = rejectedCount;
	}

	public Type getRejectedAmount() {
		return rejectedAmount;
	}

	public void setRejectedAmount(Type rejectedAmount) {
		this.rejectedAmount = rejectedAmount;
	}

	public Type getReturnedCount() {
		return returnedCount;
	}

	public void setReturnedCount(Type returnedCount) {
		this.returnedCount = returnedCount;
	}

	public Type getReturnedAmount() {
		return returnedAmount;
	}

	public void setReturnedAmount(Type returnedAmount) {
		this.returnedAmount = returnedAmount;
	}

	public Type getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Type totalCount) {
		this.totalCount = totalCount;
	}

	public Type getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Type totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Type getsFiller() {
		return sFiller;
	}

	public void setsFiller(Type sFiller) {
		this.sFiller = sFiller;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(), acceptedCount.getSize(), acceptedAmount.getSize(), 
				rejectedCount.getSize(), rejectedAmount.getSize(), returnedCount.getSize(), returnedAmount.getSize(), 
				totalCount.getSize(), totalAmount.getSize(),  sFiller.getSize(), 
		};
	}

	public void setParamaters(String[] buffer) {
		recordType.setValue(buffer[0]);
		acceptedCount.setValue(buffer[1]);
		acceptedAmount.setValue(buffer[2]);
		rejectedCount.setValue(buffer[3]);
		rejectedAmount.setValue(buffer[4]);
		returnedCount.setValue(buffer[5]);
		returnedAmount.setValue(buffer[6]);
		totalCount.setValue(buffer[7]);
		totalAmount.setValue(buffer[8]); 
		sFiller.setValue(buffer[9]); 
	}

	public String getName() {
		return "03";
	}

	public String toString() {

		return new StringBuffer().append(getRecordType().toString()).append(getAcceptedCount().toString()).append(getAcceptedAmount().toString())
				.append(getRejectedCount().toString()).append(getRejectedAmount().toString()).append(getReturnedCount().toString())
				.append(getReturnedAmount().toString()).append(getTotalCount().toString()).append(getTotalAmount().toString())
				.append(getsFiller().toString()).toString();
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}

}
