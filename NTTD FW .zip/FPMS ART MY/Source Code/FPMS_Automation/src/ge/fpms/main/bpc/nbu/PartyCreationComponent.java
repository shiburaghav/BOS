package ge.fpms.main.bpc.nbu;

import ge.fpms.main.bpc.nbu.components.Party;
import ge.fpms.main.actions.FPMS_Actions;

import java.util.Hashtable;

import com.nttdata.framework.exceptions.BPCException;
public class PartyCreationComponent extends BusinessComponent
{
	public void PartyCreation(Hashtable<String, String> hParams) throws Exception
	{
		try
		{
			llAction = new FPMS_Actions();
			Party partyObj=new Party();
			partyObj.createParties(hParams.get("ListOfPartyIds"));
			
		}
		catch(Exception ex)
		{
			throw new BPCException(ex);
		}
	}
}



	


	