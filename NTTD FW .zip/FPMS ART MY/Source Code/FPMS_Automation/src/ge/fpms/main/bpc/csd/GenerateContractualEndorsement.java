package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import com.sun.xml.internal.fastinfoset.stax.events.Util;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;


public class GenerateContractualEndorsement {

	private FPMS_Actions llAction;

	private DashboardHandler dashboard;

	public GenerateContractualEndorsement() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void generateContractualEndorsement(Hashtable<String, String> hParams) throws Exception {
		try {
			String mainEndorsement=hParams.get("MainEndorsement");
			String riderEndorsement=hParams.get("RiderEndorsement");
			String otherClause=hParams.get("OtherClause");
			String[] allriders=hParams.get("Riders").split("\\|");
			String [] allExistingvariables =  hParams.get("ExistingClauseVariables").split("\\|");
			String [] allClausevalues =  hParams.get("ReplacedClauseValues").split("\\|");
			llAction.selectMenuItem("Customer Service", "Generate Contractual Endorsement");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_GCE_policyNo", hParams.get("PolicyNumber"));
			dashboard.setStepDetails("Enter Policy Number to be searched ",
					"Policy Number is entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Search");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_GCE_riskEffectiveDate",hParams.get("RiskEffectiveDate"));
			if(!Util.isEmptyString(mainEndorsement)) {
			String[] mainEndorsements=mainEndorsement.split(FPMSConstants.COMMA_SEPERATOR);
			for(int i=0;i<mainEndorsements.length;i++)
			{
				Utils.editXpath("web_checkbox_mainEndorsementDummy", "web_GCE_" + mainEndorsements[i] + "", new String[] {mainEndorsements[i]});
				llAction.clickElement("web_GCE_" + mainEndorsements[i] + "");
			}
			}

			String[] riderEndorsements=riderEndorsement.split(FPMSConstants.COMMA_SEPERATOR);
			for(int i=0;i<riderEndorsements.length;i++)
			{
				Utils.editXpath("web_checkbox_riderEndorsementOptionDummy", "web_GCE_" + riderEndorsements[i] + "", new String[] {riderEndorsements[i]});
				llAction.clickElement("web_GCE_" + riderEndorsements[i] + "");
				String[] riders=allriders[i].split(FPMSConstants.COMMA_SEPERATOR);
				for(int j=0;j<riders.length;j++)
				{
					Utils.editXpath("web_lst_riderEndorsementRiderDummy", "web_GCE_" + riders[j] + "",
							new String[] {riderEndorsements[i]});
					llAction.selectByVisibleText("web_GCE_" + riders[j] + "",riders[j]);
					Utils.editXpath("web_btn_riderEndorsementAddDummy", "web_btn_riderEndorsementAdd", new String[] {riderEndorsements[i]});
					llAction.clickElement("web_btn_riderEndorsementAdd");

				}
			}
			
			if(!llAction.getText("web_txt_RecordNotFound").equalsIgnoreCase(FPMSConstants.RECORDNOTFOUND))
			{
				int rowCount=llAction.getRowCountInTable("web_table_CancellationOfBenefits");

				for(int i=1;i<rowCount;i++)
				{
					Utils.editXpath("web_checkbox_cancellation_Option_Dummy", "web_checkbox_cancellation_Option", new String[] {String.valueOf(i)} );
					llAction.clickElement("web_checkbox_cancellation_Option");
				}
			}
			
			if(!Util.isEmptyString(otherClause)) {
			String[] otherClauses=otherClause.split(FPMSConstants.COMMA_SEPERATOR);
			for(int c=0;c<otherClauses.length;c++)
			{
			llAction.selectByVisibleText("web_lst_otherClause",otherClauses[c]);
			llAction.clickElement("web_btn_OtherClauseAdd");
			llAction.handleCertificateErrors();
			llAction.maximizeWindow();
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_OTHERCLAUSE);
			String englishClause=llAction.getText("web_txt_EnglishClause");
			String bmClause=llAction.getText("web_txt_BMClause");
			String [] existingvariables = allExistingvariables[c].split(FPMSConstants.COMMA_SEPERATOR);
			String [] clausevalues =  allClausevalues[c].split(FPMSConstants.COMMA_SEPERATOR);
			for(int i=0;i<existingvariables.length;i++)
			{
				englishClause=englishClause.replace(existingvariables[i], clausevalues[i]);
				bmClause=bmClause.replace(existingvariables[i], clausevalues[i]);
			}
			llAction.enterValue("web_txt_EnglishClause", englishClause);
			llAction.enterValue("web_txt_BMClause", bmClause);
			dashboard.setStepDetails("Fill existing clause variables ",
					"Existing clause variables are replaced with desired values", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_mySubmit");
			llAction.switchtoDefaultWindow();
			}
			}
			
			dashboard.setStepDetails("Enter Contractual Endorsement Information",
					"Contractual Endorsement Information is entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_PartyChanges_btn_Submit");
			dashboard.setStepDetails("Submit Contractual Endorsement Information",
					"Main menu is displayed", "N/A");
			dashboard.writeResults();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}
}

