package ge.fpms.main.bpc.bcp.templates;

public interface IPaymentType {

	public  final String DEFAULT_RETURN_CODE = "01";
	public  final String DEFAULT_RESPONSE_CODE = "F000";
	
	public final String GIRO_INPUT_FILENAME = "H2HDDS100052";
	public  final String GIRO_OUTPUT_FILE_NAME = "GELADAT.dat";
	
	public final String LOCKBOX_INPUT_FILENAME = "H2HDDS100052";
	public  final String LOCKBOX_OUTPUT_FILE_NAME = "OCBC%%.txt";
	
	public final String BILL_TYPE_LOAN = "L";
	public final String BILL_TYPE_PREMIUM = "P";
	
	public  final String LOCK_BOX_SHEET_NAME = "LOCKBOX";
	public  final String FILLER = " ";
	
	public final String DC_INPUT_FILENAME = "IBGFPMSPAY";
	public  final String DC_OUTPUT_FILE_NAME = "MY_GIRO_Mgt_Payroll_Status_Download_%%%###_IBGFPMSPAY%%##.txt";
	
	public final String SUCCESS_INDICATOR_Y = "Y";
	
	public final String SUCCESS_INDICATOR_N = "N";
	
	public final String DEFAULT_DC_SUCCESS_CODE = "00";
	
	public final String DEFAULT_DC_REJECT_CODE = "00";
	
	public String toString();
	
}
