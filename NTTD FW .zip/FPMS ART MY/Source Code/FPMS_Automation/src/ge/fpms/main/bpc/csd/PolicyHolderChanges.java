package ge.fpms.main.bpc.csd;
import ge.fpms.main.actions.FPMS_Actions;
import java.util.Hashtable;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;

import ge.fpms.main.bpc.csd.components.CSDHelper;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class PolicyHolderChanges {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	
	public PolicyHolderChanges() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	/*
	 * Name: ChangePolicyHolder_SearchSelectParty Purpose: Search And Select Party
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void ChangePolicyHolder_SearchSelectParty(Hashtable<String, String> hParams) throws Exception {
		try {
			dashboard.setStepDetails("Validate if Party is Not Dead Warning Message is captured",
					"Policy should display the Warning Message", "N/A");
			dashboard.writeResults();
			if (llAction.isDisplayed("web_PolicyChanges_btn_Continue", 5)) {
				if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage1"));
					llAction.clickElement("web_PolicyChanges_btn_Continue");
				} else {
					llAction.clickElement("web_PolicyChanges_btn_Continue");
				}
			}

			String PartyName = hParams.get("PolicyHolderPartyName");
			String PartyID = hParams.get("PolicyHolderPartyID");

			llAction.clickElement("web_PolicyChanges_btn_Entry");
			llAction.waitUntilLoadingCompletes();
			Utils.sleep(8);
			llAction.switchtoChildWindow("Party Identification");

			llAction.switchtoFrame("", "iframe0");
			llAction.enterValue("web_PolicyChanges_txt_PartyName", PartyName);
			llAction.enterValue("web_PolicyChanges_txt_PartyID", PartyID);

			dashboard.setStepDetails("Enter Part Name and Party ID",
					"User should be able to search with Party Name and ID", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_PolicyChanges_btn_Next");
			llAction.waitUntilLoadingCompletes();

			int colPos = llAction.GetColumnPositionInTable("web_PolicyChanges_tbl_PartySearch", "Party Status");
			int rowPos = llAction.GetRowPositionInTable("web_PolicyChanges_tbl_PartySearch", "Active", colPos);
			llAction.SelectRowInTable("web_PolicyChanges_tbl_PartySearch", rowPos, colPos - 7, "a");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Select the Party from the search results",
					"User should be able to navigated to Search and Maintain Party Page", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_PolicyChanges_btn_SubmitPartySelection");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: SelectPartyAddressAndSubmit Purpose: Select Party Address And Submit
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void ChangePolicyHolder_SelectAddressAndSubmit(Hashtable<String, String> hParams) throws Exception {
		try {

			dashboard.setStepDetails("Select the Address from the available address for the party",
					"User should be able to select the required address", "N/A");
			dashboard.writeResults();

			llAction.SelectRowInTable("web_PolicyChanges_tbl_SelectAddress", 2, 1, "input");
			llAction.clickElement("web_PolicyChanges_btn_SubmitAddressSelection");
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Select the Address" ,
					"Address should be selected successfully", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_PolicyChanges_btn_SubmitChangePolicyHolder");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Validate if the newly selected party name is updated as the new policy holder" ,
					"New party name should be displayed as a change in the table below the actual policy holder", "N/A");
			dashboard.writeResults();

			if (llAction.isDisplayed("web_PolicyChanges_btn_Continue", 5)) {
				dashboard.setStepDetails("Select the Address" ,
						"Address should be selected successfully", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_PolicyChanges_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			}
						
			dashboard.setStepDetails("Click on Submit button" ,
					"Application Entry screen should be displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Submit_ApplicationEntry");
			llAction.waitUntilLoadingCompletes();

			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				llAction.clickElement("web_btn_ContinueRP");
				llAction.waitUntilLoadingCompletes();
			}
			
			dashboard.setStepDetails("Validate if the policy status is changed inforce",
					"Policy status should be changed to inforce", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_PolicyChanges_btn_backToMain");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: ChangeTerm Purpose: Change Term Apportionment Parameters: hParams
	 * Return Value: NA Exception: BPCException
	 */
	public void ChangeTerm(Hashtable<String, String> hParams) throws Exception {
		try {
			String BenefitCode = hParams.get("BenefitCode");
			String Yearageofcoverageterm = hParams.get("Yearageofcoverageterm");
			String Yearageofpremiumterm = hParams.get("Yearageofpremiumterm");
			if (llAction.isDisplayed("web_PolicyChanges_btn_Continue", 5)) {
				llAction.clickElement("web_PolicyChanges_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			}

			int colPos = llAction.GetColumnPositionInTable("web_ChangeTerm_tbl_SearchBenefit", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_ChangeTerm_tbl_SearchBenefit", BenefitCode, colPos);
			llAction.SelectRowInTable("web_ChangeTerm_tbl_SearchBenefit", rowPos, 1, "input");

			llAction.clickElement("web_ChangeTerm_btn_ChangeTerm");
			llAction.waitUntilLoadingCompletes();

			llAction.enterValue("web_ChangeTerm_txt_AgeCoverageTerm", Yearageofcoverageterm);
			llAction.enterValue("web_ChangeTerm_txt_AgePremiumTerm", Yearageofpremiumterm);

			dashboard.setStepDetails("Enter new YearAgeofCoverageTerm and YearAgeofPremiumTerm",
					"User should be able to enter new YearAgeofCoverageTerm and YearAgeofPremiumTerm", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_ChangeTerm_btn_ProductInfoSave");
			llAction.waitUntilLoadingCompletes();
			
			//change term submit
			llAction.clickElement("web_btn_ChangeTerm_Submit");
			llAction.waitUntilLoadingCompletes();
			
			//modify handling fee submit
			llAction.clickElement("web_ChangeTerm_btn_HandlingFeeSubmit");
			llAction.waitUntilLoadingCompletes();			
			CSDHelper.getInstance().endOfTransaction();		

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: ChangeTerm Purpose: ChangeSurvivalorCashBonus Apportionment Parameters:
	 * hParams Return Value: NA Exception: BPCException
	 */
	public void ChangeSurvivalorCashBonus(Hashtable<String, String> hParams) throws Exception {
		try {

			/*
			 * if(llAction.isContinueButtonDisplayed("web_PolicyChanges_btn_Continue")) {
			 * llAction.clickElement("web_PolicyChanges_btn_Continue");
			 * llAction.waitUntilLoadingCompletes(); }
			 */

			String BenefitCode = hParams.get("BenefitCode");
			String cashBonusOption = hParams.get("CashBonusOption");
			String cbTerm=hParams.get("CBTerm");
			String sbTerm=hParams.get("SBTerm");
			String survivalBenefitOption = hParams.get("SurvivalBenefitOption");
			int colPos = llAction.GetColumnPositionInTable("web_ChangeBonus_tbl_SearchBenefit", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_ChangeBonus_tbl_SearchBenefit", BenefitCode, colPos);
			llAction.SelectRowInTable("web_ChangeBonus_tbl_SearchBenefit", rowPos, 1, "input");

			if (!StringUtils.isEmpty(cashBonusOption)) {
				llAction.selectByVisibleText("web_ChangeBonus_lst_CashBonus", cashBonusOption);
				llAction.sendkeyStroke("web_ChangeBonus_lst_CashBonus", Keys.ENTER);
			}
			
			if (!StringUtils.isEmpty(cbTerm)) {
				llAction.enterValue("web_txt_CBTerm", cbTerm);
			}

			if (!StringUtils.isEmpty(survivalBenefitOption)) {
				llAction.selectByVisibleText("web_ChangeBonus_lst_SurvivalBenefit", survivalBenefitOption);
				llAction.sendkeyStroke("web_ChangeBonus_lst_SurvivalBenefit", Keys.ENTER);
			}
			if (!StringUtils.isEmpty(sbTerm)) {
				llAction.enterValue("web_txt_SBTerm", sbTerm);
			}
			llAction.move_to_element("web_ChangeBonus_btn_SubmitCHangeBonus");
			dashboard.setStepDetails("Validate if the valid option is selected in the dropdown",
					"valid option should be selected in the dropdown", "N/A");
			dashboard.writeResults();


			llAction.clickElement("web_ChangeBonus_btn_SubmitCHangeBonus");

			if (llAction.isDisplayed("web_PolicyChanges_btn_Continue", 5)) {
				llAction.clickElement("web_PolicyChanges_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			}
			dashboard.setStepDetails("Application Entry screen should be displayed",
					"Application Entry screen is displayed", "N/A");
			dashboard.writeResults();
			
			llAction.clickElement("web_btn_Submit_ApplicationEntry");
			llAction.waitUntilLoadingCompletes();			
			CSDHelper.getInstance().checkApplicationStatus();
			llAction.waitUntilLoadingCompletes();

			

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void ValidateApplicationStatus(String webElementKey, String applicationStatus) throws Exception {
		try {
			if (llAction.getText(webElementKey).toLowerCase().contains(applicationStatus.toLowerCase())) {
				dashboard.setStepDetails(applicationStatus + " Should be populated", "Message is validated",
						"N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(applicationStatus + "message is invalid/Submit was not successful");
				dashboard.writeResults();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

}
