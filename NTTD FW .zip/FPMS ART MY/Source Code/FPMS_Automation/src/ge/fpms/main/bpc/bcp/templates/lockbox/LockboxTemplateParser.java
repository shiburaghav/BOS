package ge.fpms.main.bpc.bcp.templates.lockbox;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.bpc.bcp.templates.IPaymentType;
import ge.fpms.main.bpc.bcp.templates.PaymentTemplatesParse;
import ge.fpms.main.bpc.bcp.templates.Type;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.nttdata.common.util.ColumnHeader;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.framework.exceptions.BPCException;

public class LockboxTemplateParser extends PaymentTemplatesParse{

	private LockBox lockbox;
	private ArrayList<Details> detailList;
	private Details initalDR;
	private String outputFilePath;
	private BillType loan;
	private BillType premium ;
	private BillType bankAssurance;
	
	public LockboxTemplateParser() {
		 super();
		 detailList = new ArrayList<Details>();
		 loan = new BillType();
		 premium = new BillType(); 
		 bankAssurance = new BillType();
	}
	/**
	 * parseGiro - for parsing giro files
	 * @param params - parameters from testdata
	 * @throws Exception 
	 */
	public void processLockBoxTemplate(Hashtable<String, String> params) throws Exception {
		String jsonTemplate = FPMSProperties.getInstance().getJsonPath("lockbox.json");
		loadObject(jsonTemplate);	
		
		updateAttributes(params);
		
		createNewFile(params.get("OutputFile"));
	}
	
	private void createDetails(String[] attributesValue) throws Exception {
		try {

				Type[] attributes = initalDR.getAllAttributes();
				Type[] newAttributes = new Type[Details.FIELD_COUNT];
				for(int i=0;i<Details.FIELD_COUNT;i++){
					newAttributes[i] = new Type(attributes[i].getSize(),
							attributes[i].getDataType(), attributesValue[i],
							attributes[i].getAlignment(),
							attributes[i].getPaddingChar());
				}				
				detailList.add(getRecordCount(), new Details(newAttributes));
			}
		catch (Exception e) {
			throw new BPCException(e);
		}
	}


	@Override
	public void createNewFile(String outputFile) throws Exception {
		try {
			outputFilePath = getLockboxReturnFilePath();
			
			BufferedWriter out = new BufferedWriter(new FileWriter(outputFilePath));
			out.write(lockbox.getHeader().toString()); out.newLine();
			for(Details det : lockbox.getDetails()){
				out.write(det.toString()); out.newLine();
			}
			
			out.write(lockbox.getSummary().toString());
			out.close();
			
		} catch (Exception e) {
			throw new BPCException(e);
		}

				
	}

	@Override
	public void updateAttributes(Hashtable<String, String> params)
			throws Exception {
		try {
			// Updating Details Section
			initalDR = lockbox.getDetails()[0];
			String policyNumber = params.get("PolicyNumber");
			String headerXnDate = null, bankAccount = null ; int totalPolicies = 0; 
		
			if(!StringUtils.isEmpty(policyNumber))
			{
				String[] tdPolicies = policyNumber.split(",");
				totalPolicies = tdPolicies.length;
				for (int i = 0; i < tdPolicies.length; i++) {	
						
					Hashtable<String, String> lockbox = getLockboxData(tdPolicies[i]);
					headerXnDate = lockbox.get("HeaderXnDate").replace("/","");
					bankAccount = lockbox.get("BankAccount");
					String pAmt = lockbox.get("PaidAmt").replace(".","");
					String detailsAttr [] = new String[]{initalDR.getName(),headerXnDate,String.valueOf(i+1),lockbox.get("BillType"),IPaymentType.FILLER,
							initalDR.getGeCode().getValue(),pAmt,lockbox.get("ChequeNo"),lockbox.get("FormOfColl"),lockbox.get("ChequeCode"),
							lockbox.get("BankCode"),lockbox.get("TellerBranch"),lockbox.get("TellerCode"),lockbox.get("TransCode"),
							lockbox.get("Date").replace("/",""),bankAccount,lockbox.get("DepositDate").replace("/",""),tdPolicies[i],IPaymentType.FILLER};
					createDetails(detailsAttr);	
					updateBillAmount(lockbox.get("BillType"),Integer.parseInt(pAmt));
					setRecordCount(i+1);
				}
				
			}

			//updating header
			lockbox.getHeader().getHeaderXNDate().setValue(headerXnDate);
			lockbox.getHeader().getTotalPolicies().setValue(String.valueOf(totalPolicies));
			lockbox.getHeader().getBankAccount().setValue(bankAccount);
			//lockbox.getHeader().getExtractionTime().setValue("");
			//updating details
			lockbox.setDetails(detailList.toArray(new Details[0]));
			//updating Summary
			createSummary();
			

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	/**
	 * load the GIRO Structure using the JSON template
	 * @param jsonTemplate
	 */
	private void loadObject(String jsonTemplate) throws Exception {
		try {

			Gson gson = new Gson();
			lockbox = gson.fromJson(new FileReader(jsonTemplate), LockBox.class);			
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}
	

	private void createSummary() throws Exception {		
		int totalTransactionCnt = loan.getCount() + premium.getCount() + bankAssurance.getCount();
		int totalTransactionAmt = loan.getAmount() + premium.getAmount() + bankAssurance.getAmount();
		
		lockbox.getSummary().getTotTransactions().setValue(String.valueOf(totalTransactionCnt) );
		lockbox.getSummary().getTotalAmtPaid().setValue(String.valueOf(totalTransactionAmt) + "00");
		lockbox.getSummary().getTotLoan().setValue(String.valueOf(loan.getCount()));
		lockbox.getSummary().getTotalLoanAmt().setValue(String.valueOf(loan.getAmount()) + "00");
		lockbox.getSummary().getTotPrem().setValue(String.valueOf(premium.getCount()));
		lockbox.getSummary().getTotalPremAmt().setValue(String.valueOf(premium.getAmount()) + "00");
		
		lockbox.getSummary().getTotBans().setValue(String.valueOf(bankAssurance.getCount()));
		lockbox.getSummary().getTotBansAmt().setValue(String.valueOf(bankAssurance.getAmount()) + "00");
	}

	
	public String getLockboxReturnFilePath() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMdd");
		String date =  ((LocalDate.now().format(dtf)));
		return System.getProperty("Settings.ART Downloads") + File.separator + IPaymentType.LOCKBOX_OUTPUT_FILE_NAME.replace("%%", /*date*/"0404");
	}
	
	public Hashtable<String, String> getLockboxData(String pNumber) {
		DataHandler dataHandler = new DataHandler();
		Hashtable<String, String> giroData = dataHandler.getTestData(IPaymentType.LOCK_BOX_SHEET_NAME,
				FPMSProperties.getInstance().getTestDataFilePath(FPMSConstants.MODULE_BCPBATCH),
				ColumnHeader.getColumnHeader(IPaymentType.LOCK_BOX_SHEET_NAME), pNumber, "PolicyNumber");
		return giroData;
	}
	
	
	private void updateBillAmount (String billType, int amount){
		switch(billType){
		case IPaymentType.BILL_TYPE_LOAN:
			loan.setAmount(amount);
			break;
		case IPaymentType.BILL_TYPE_PREMIUM:
			premium.setAmount(amount);
			break;
		default:
			bankAssurance.setAmount(amount);
				
		}
		
	}
	public static void main(String[] args)  {
		
		/*String dwlLoad ="C:\\Users\\suchitraravindran\\Documents\\FPMS\\MY\\H2HDDS10005228082018001.dat";
		String output = "D:\\FPMS_ART\\";
		Hashtable<String, String> params = new Hashtable<String, String>();
		params.put("InputFile", dwlLoad);
		params.put("OutputFile", output);
		params.put("PolicyNumber", "0073120962");
		params.put("Amount", "5700");
		params.put("ReturnCode", "05");
		
		try {
			new LockboxTemplateParser().processLockBoxTemplate(params);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	
	@Override
	public void beginParse(String line) throws Exception {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void parse(String line) throws Exception {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void endParse(String line) throws Exception {
		// TODO Auto-generated method stub
		
	}

}