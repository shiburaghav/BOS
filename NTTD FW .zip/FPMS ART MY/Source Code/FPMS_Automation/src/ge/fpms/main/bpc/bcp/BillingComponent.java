package ge.fpms.main.bpc.bcp;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.ArtRobot;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;

public class BillingComponent {

	private  FPMS_Actions actions;
	private DashboardHandler dashboard;
	
	public BillingComponent() {
		actions = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();	
	}
	
	public void performCPFExtractionGenerateFile(Hashtable<String, String> hParams) throws Exception{
		
		actions.selectMenuItem("Billing","Perform CPF Extraction","Perform CPF Extraction - Generate File");
		actions.waitUntilLoadingCompletes();
		if(actions.isDisplayed("web_billing_dwl_cpf_file_type", 3)){
			actions.selectByVisibleText("web_billing_dwl_cpf_file_type",hParams.get("FileType"));
		}
		actions.selectByVisibleText("web_batchJob_dwl_cpf_pay_method",hParams.get("PaymentMethod"));
		actions.enterValue("web_batchJob_dwl_cpf_batchno",hParams.get("BatchNo"));
		
		dashboard.setStepDetails("Perform CPF Extraction Generate File ", "File Type : " + hParams.get("FileType") + " Payment Method : " + hParams.get("PaymentMethod") ,"N/A");
		dashboard.writeResults();
		
		actions.clickElement("web_billing_dwl_cpf_generate_btn");
		actions.waitUntilLoadingCompletes();
		
		if(actions.isDisplayed("web_billing_continue_btn",3)){
			actions.clickElement("web_billing_continue_btn");
			actions.waitUntilLoadingCompletes();
			
		}

		if(actions.isDisplayed("web_billing_dwl_cpf_generate_success_txt",6)){
			dashboard.setStepDetails("Perform CPF Extraction Generate File - " + hParams.get("FileType") + hParams.get("PaymentMethod") , "Generate is successfull","N/A");
			dashboard.writeResults();
			actions.clickElement("web_billing_exit_btn");
			actions.waitUntilLoadingCompletes();
		}else{
			dashboard.setFailStatus(new BPCException("Perform CPF Extraction Generate File - " + hParams.get("FileType") + hParams.get("PaymentMethod") + " - Generate failed!!"));
		}
	}
	public void performCPFExtractionDownloadFile(Hashtable<String, String> hParams) throws Exception{
		
		actions.selectMenuItem("Billing","Perform CPF Extraction","Perform CPF Extraction - Download File");
		actions.waitUntilLoadingCompletes();
		if(actions.isDisplayed("web_billing_dwl_cpf_file_type", 3)){
			actions.selectByVisibleText("web_billing_dwl_cpf_file_type",hParams.get("FileType"));
		}
		actions.selectByVisibleText("web_batchJob_dwl_cpf_pay_method",hParams.get("PaymentMethod"));
		actions.enterValue("web_batchJob_dwl_cpf_batchno",hParams.get("BatchNo"));
		actions.enterValue("web_billing_dwl_generate_date",hParams.get("GenerationDate"));
		

		dashboard.setStepDetails("Perform CPF Extraction - Download File " + hParams.get("FileType") + hParams.get("PaymentMethod")," About to click on search" ,"N/A");
		dashboard.writeResults();
		
		actions.clickElement("web_batchJob_dwl_cpf_search_btn");
		actions.waitUntilLoadingCompletes();
		
		List<WebElement> elements = actions.findElementsByXpath("web_batchJob_dwl_cpf_table_option_btn", new String[] {hParams.get("BankCode")});
		if(elements.size() > 0){
			for(WebElement e : elements){
				e.click();
				break;
			}
			dashboard.setStepDetails("Perform CPF Extraction - Download File " + hParams.get("FileType") + hParams.get("PaymentMethod")," About to download file" ,"N/A");
			dashboard.writeResults();
			actions.clickElementJs("web_batchJob_dwl_download_btn");

			Utils.sleep(2);		
			ArtRobot.saveFile();
			Utils.sleep(2);	
			dashboard.setStepDetails("Perform CPF Extraction - Download File " + hParams.get("FileType") + hParams.get("PaymentMethod")," File has been downloaded" ,"N/A");
			dashboard.writeResults();
			
			actions.clickElement("web_billing_exit_btn");
			actions.waitUntilLoadingCompletes();
		}else{
			dashboard.setFailStatus(new BPCException("Perform CPF Extraction - Download File - No matching record found with the bank code provided!!"));
		}
	}
	public void uploadCPFReturnFile(Hashtable<String, String> hParams) throws Exception{
			
			actions.selectMenuItem("Billing","Upload CPF File");
			actions.waitUntilLoadingCompletes();
			actions.enterValue("web_batchJob_upload_cc_batchno",hParams.get("BatchNo"));
			actions.selectByValue("web_batchJob_upload_bank_code",hParams.get("BankCode"));
			dashboard.setStepDetails("Upload CPF File  ","About to click on search" ,"N/A");
			dashboard.writeResults();
			actions.clickElement("web_batchJob_dwl_cpf_search_btn");
			actions.waitUntilLoadingCompletes();
			
			List<WebElement> elements = actions.findElementsByXpath("web_batchJob_dwl_cpf_table_option_btn", new String[] {hParams.get("BankCode")});
			if(elements.size() > 0){
				for(WebElement e : elements){
					e.click();
					break;
				}
				
				actions.enterValue("web_batchJob_upload_cc_browseBtn",hParams.get("UploadFilePath"));
				actions.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
				actions.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
				if(actions.isEnabled("web_batchJob_upload_cc_submitBtn")){
					dashboard.setStepDetails("Upload CPF File  ","About to submit the file uploaded" ,"N/A");
					dashboard.writeResults();
					actions.clickElement("web_batchJob_upload_cc_submitBtn");
					actions.waitUntilLoadingCompletes();
					actions.clickElement("web_billing_exit_btn");
					actions.waitUntilLoadingCompletes();
				}else{
					dashboard.setFailStatus(new BPCException("Upload CPF File - Submit button not enabled. Check the file uploaded is valid!!"));
				}
				
			}else{
				dashboard.setFailStatus(new BPCException("Upload CPF File - No matching record found with the bank code provided!!"));
			}	
	}
	
	public void performCPFReconciliationGenerateFile(Hashtable<String, String> hParams) throws Exception{
		actions.selectMenuItem("Billing","Perform CPF Reconciliation"," Perform CPF Reconciliation - Generate File");
		actions.waitUntilLoadingCompletes();
		
		if(actions.isDisplayed("web_billing_reconcilation_cutoffdate")){
		actions.enterValue("web_billing_reconcilation_cutoffdate",hParams.get("CutoffDate"));
		}
		actions.selectByVisibleText("web_batchJob_dwl_cpf_pay_method",hParams.get("PaymentMethod"));
		actions.selectByValue("web_batchJob_upload_bank_code",hParams.get("BankCode"));
		
		dashboard.setStepDetails("Perform CPF Reconciliation Generate File ", " Payment Method : " + hParams.get("PaymentMethod") + " Bankcode :" +hParams.get("BankCode"),"N/A");
		dashboard.writeResults();
		
		actions.clickElement("web_billing_reconcilation_generate_btn");
		actions.waitUntilLoadingCompletes();
		
		if(actions.isDisplayed("web_billing_continue_btn",3)){
			actions.clickElement("web_billing_continue_btn");
		}
		actions.acceptAlert((long)1);
		dashboard.setStepDetails("Perform CPF Reconciliation Generate File" ,"Alert is acepted - Generate Successful", "N/A");
		dashboard.writeResults();
		Utils.sleep(2);
		
		actions.clickElement("web_query_benefitInfo_exit");
		actions.waitUntilLoadingCompletes();
	}
	
	public void performCPFReconciliationDownloadFile(Hashtable<String, String> hParams) throws Exception{
		actions.selectMenuItem("Billing","Perform CPF Reconciliation"," Perform CPF Reconciliation - Download File");
		actions.waitUntilLoadingCompletes();
		
		if(actions.isDisplayed("web_billing_reconcilation_cutoffdate")){
		actions.enterValue("web_billing_reconcilation_cutoffdate",hParams.get("CutoffDate"));
		}
		actions.selectByVisibleText("web_batchJob_dwl_cpf_pay_method",hParams.get("PaymentMethod"));
		actions.selectByValue("web_batchJob_upload_bank_code",hParams.get("BankCode"));
		actions.enterValue("web_billing_reconcilation_generate_dt_txt",hParams.get("GenerationDate"));
		
		dashboard.setStepDetails("Perform CPF Reconciliation Download File ", " Payment Method : " + hParams.get("PaymentMethod") + " Bankcode :" +hParams.get("BankCode"),"N/A");
		dashboard.writeResults();
		
		actions.clickElement("web_batchJob_dwl_cpf_search_btn");
		actions.waitUntilLoadingCompletes();
		
		List<WebElement> elements = actions.findElementsByXpath("web_batchJob_dwl_cpf_table_option_btn", new String[] {hParams.get("BankCode")});
		if(elements.size() > 0){
			for(WebElement e : elements){
				e.click();
				break;
			}
			dashboard.setStepDetails("Perform CPF Reconciliation - Download File " + hParams.get("FileType") + hParams.get("PaymentMethod")," About to download file" ,"N/A");
			dashboard.writeResults();
			actions.clickElementJs("web_batchJob_dwl_download_btn");

			Utils.sleep(2);		
			ArtRobot.saveFile();
			Utils.sleep(2);	
			dashboard.setStepDetails("Perform CPF Reconciliation - Download File " + hParams.get("FileType") + hParams.get("PaymentMethod")," File has been downloaded" ,"N/A");
			dashboard.writeResults();
			
			actions.clickElement("web_query_benefitInfo_exit");
			actions.waitUntilLoadingCompletes();
		}else{
			dashboard.setFailStatus(new BPCException("Perform CPF Reconciliation - Download File - No matching record found with the bank code provided!!"));
		}
	}
	
	public void queryCPFRecordsPendingExtraction(Hashtable<String, String> hParams) throws Exception{
		actions.selectMenuItem("Billing","Query CPF Records Pending Extraction");
		actions.waitUntilLoadingCompletes();
		
		actions.clickElement("web_billing_query_cpf_prepare_btn");
		actions.waitUntilLoadingCompletes();
		dashboard.setStepDetails("Query CPF Records Pending Extraction" ,"Preparation complete" ,"N/A");
		dashboard.writeResults();
		
		actions.clickElement("web_billing_query_cpf_search_btn");
		actions.waitUntilLoadingCompletes();
		
		actions.selectByVisibleText("web_batchJob_dwl_cpf_pay_method",hParams.get("PaymentMethod"));
		actions.selectByVisibleText("web_billing_query_cpf_premiumSource",hParams.get("PremiumSource"));
		actions.selectByVisibleText("web_billing_query_cpf_transcationType",hParams.get("FileType"));		
		actions.selectByValue("web_batchJob_upload_bank_code",hParams.get("BankCode"));
		dashboard.setStepDetails("Query CPF Records Pending Extraction" ,"About to click on submit button" ,"N/A");
		dashboard.writeResults();
		actions.clickElement("web_billing_query_cpf_submit_btn");
		actions.waitUntilLoadingCompletes();
		
		actions.clickElement("web_billing_exit_btn");
		actions.waitUntilLoadingCompletes();
	}
	
	public void GIROUploadApproval(Hashtable<String, String> hParams) throws Exception{
		actions.selectMenuItem("Billing","GIRO Upload Approval");
		actions.waitUntilLoadingCompletes();
		actions.enterValue("web_billing_giro_update_batch_no",hParams.get("BatchNo"));
		actions.enterValue("web_billing_giro_deductiondt",hParams.get("GenerationDate"));
		
		actions.clickElement("web_billing_giro_search");
		actions.waitUntilLoadingCompletes();
		dashboard.setStepDetails("GIRO Upload Approval", "Search button clicked" ,"N/A");
		dashboard.writeResults();

		actions.clickElement("web_billing_giro_approve_btn");
		actions.waitUntilLoadingCompletes();
		//check for approve successfully message
		dashboard.setStepDetails("GIRO Upload Approval", "Approved Successfully" ,"N/A");
		dashboard.writeResults();
		
		actions.clickElement("web_billing_exit_btn");
		actions.waitUntilLoadingCompletes();
	}
	
	public void CPFSAStaticReconcilation(Hashtable<String, String> hParams) throws Exception{
		actions.selectMenuItem("Billing","CPF SA Static/Reconciliation Upload");
		actions.waitUntilLoadingCompletes();
		
		if(actions.isDisplayed("web_billing_dwl_cpf_file_type", 3)){
			actions.selectByVisibleText("web_billing_dwl_cpf_file_type",hParams.get("FileType"));
		}
		actions.enterValue("web_batchJob_upload_cc_browseBtn",hParams.get("UploadFilePath"));
		actions.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
		actions.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
		dashboard.setStepDetails("CPF SA Static Reconcilation", "File is uploaded. About to validate" ,"N/A");
		dashboard.writeResults();
		
		if(actions.isEnabled("web_batchJob_upload_cc_validateBtn")){
			actions.clickElement("web_batchJob_upload_cc_validateBtn");
			dashboard.setStepDetails("CPF SA Static Reconcilation", "File is valid. About to submit" ,"N/A");
			dashboard.writeResults();
			if(actions.isEnabled("web_billing_cpf_submit_btn")){
				actions.clickElement("web_billing_cpf_submit_btn");
				actions.waitUntilLoadingCompletes();
				actions.clickElement("web_billing_exit_btn");
				actions.waitUntilLoadingCompletes();
			}else{
				dashboard.setFailStatus(new BPCException("CPF SA Static Reconcilation - Validate Failed!! - File is invalid!!"));
			}
		}else{
			dashboard.setFailStatus(new BPCException("CPF SA Static Reconcilation - Validate Failed!! - File is invalid!!"));
		}
		
	}
	

}
