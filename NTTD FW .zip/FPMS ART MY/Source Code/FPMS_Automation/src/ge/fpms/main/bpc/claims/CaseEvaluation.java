package ge.fpms.main.bpc.claims;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.ColumnHeader;
import com.nttdata.common.util.Utils;
import com.nttdata.core.components.table.TableColumn;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.Claims;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class CaseEvaluation extends BusinessComponent {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private final String LIABILITY_SHEET = "Liability";
	private Claims caseHandler;
	private Claims claims;

	public CaseEvaluation() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		claims = Claims.getInstance();
	}

	public void claimChecklist(Hashtable<String, String> hParams) throws Exception {

		try {
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CASE_EVALUATION, "");
			llAction.switchtoDefaultContent();
			llAction.switchtoFrame("main");

			llAction.clickElement("web_evaluation_btn_checklist");

			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CLAIM_DOCUMENT_LIST);
			llAction.maximizeWindow();
			dashboard.setStepDetails("Checklist button is clicked", "Checklist page is displayed", "N/A");
			dashboard.writeResults();
			int checklistCount = llAction.getRowCountInTable("web_evaluation_tbl_claimChecklist");
			int optionCol = llAction.GetColumnPositionInTable("web_evaluation_tbl_claimChecklist", "Option");
			for (int i = 1; i < checklistCount; i++) {
				llAction.enterTextInTable("web_evaluation_tbl_claimChecklist", i + 1, optionCol,
						FPMSConstants.CHECKLIST_OPTION, "/span/select");
			}
			dashboard.setStepDetails("Select \"Y\" from the drop down list for all claim check list",
					"All checklist Options should be marked as \"Y\"", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_evaluation_btn_confirm");
			System.out.println("CaseEvaluation.claimChecklist()");

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * approveCase - this can be called to approve case and submit, exit to mainmenu
	 * For accident claims, there is no submit for approval button, it will call
	 * Submit=>Exit to Pool=>Exit to Main Menu. For other claims, it will call
	 * Submit for Approval=>Approval=>Submit=>Exit to Pool=>Exit to Main Menu
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void approveCase(Hashtable<String, String> hParams) throws Exception {
		long timeOut = (long) 5;
		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CASE_EVALUATION, "");
		llAction.switchtoDefaultContent();
		llAction.switchtoFrame("main");
		if (llAction.isDisplayed("web_evaluation_submit_ilpSellDate", 5)) {
			WebElement webElement = llAction.returnWebElement("web_evaluation_submit_ilpSellDate");
			String readonly = webElement.getAttribute("readonly");
			if (!"true".equals(readonly)) {
				llAction.enterValue("web_evaluation_submit_ilpSellDate",
						hParams.get("AdmissionPriceEffectiveDateILPProduct"));
				dashboard.setStepDetails("Adminssion Price Effective Date should be entered",
						"Adminssion Price Effective Date should is entered ", "N/A");
				dashboard.writeResults();
			}
		}

		if (llAction.isDisplayed("web_evaluation_btn_save", 5)) {
			if (llAction.isEnabled("web_evaluation_btn_save")) {
				llAction.clickElement("web_evaluation_btn_save");
				llAction.handleMultipleAlerts(timeOut);
				llAction.waitUntilLoadingCompletes();				
				dashboard.setStepDetails("Adminssion Price Effective Date should be saved",
						"Adminssion Price Effective Date should is saved ", "N/A");
				dashboard.writeResults();
			}
		}
		
		if (llAction.isDisplayed("web_evaluation_btn_submit_approval", 5)) {
			llAction.clickElement("web_evaluation_btn_submit_approval");
			llAction.handleMultipleAlerts(timeOut);
			llAction.waitUntilLoadingCompletes();

			String caseResult = llAction.getText("web_evaluation_confirmation_txt").trim();
			if (caseResult.equalsIgnoreCase(FPMSConstants.CASE_EVALUATED)) {
				dashboard.setStepDetails("Evaluation Confirmation ",
						"Case is evaluated successfully - result : '" + caseResult + "' ", "N/A");
				dashboard.writeResults();
			}
			dashboard.setStepDetails(
					"Click Submit for Approval button Evaluation Confirmation screen should be displayed",
					"Evaluation Confirmation screen should is displayed with ", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_evaluation_btn_approval");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click Approval button Evaluation Screen should be displayed",
					"Evaluation screen is displayed", "N/A");
			dashboard.writeResults();
			submit(hParams.get("CaseResult"));

		} else {
			submit(hParams.get("CaseResult"));
		}

	}

	private void submit(String caseResult) throws Exception {

		try {
			long timeOut = 5;
			llAction.switchtoDefaultContent();
			llAction.switchtoFrame("main");
			// Need to switch frame
			llAction.clickElement("web_evaluation_btn_submit");

			llAction.handleMultipleAlerts(timeOut);
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Submit button Case Status should be displayed and Validated",
					"Case Status should is displayed and Validated", "N/A");
			dashboard.writeResults();
			String caseApprovalResult = llAction.getText("web_evaluation_approval_caseResult_txt").trim();
			if (caseApprovalResult.equalsIgnoreCase(caseResult)) {
				dashboard.setStepDetails("Case Approval Result",
						"Case Result displayed as  '" + caseResult + "' successfully ", "N/A");
				dashboard.writeResults();
			} else {

				dashboard.setFailStatus(new BPCException("Failed to approve the case .. "));
				dashboard.writeResults();
			}

			llAction.clickElement("web_evaluation_btn_exit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Exit button is clicked", "Claims Processing Pool screen is diplayed", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_evaluation_btn_exitToMainMenu");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Exit to Mainmenu", "Main menu screen is diplayed", "N/A");
			dashboard.writeResults();
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	/**
	 * @deprecated This method will be removed after testing approveCase method
	 *             which is handling the two different flows Submit for approval and
	 *             Submit
	 * @param hParams
	 * @throws Exception
	 */
	public void submitCaseAndExit(Hashtable<String, String> hParams) throws Exception {

		try {
			long timeOut = (long) 5;
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CASE_EVALUATION, "");
			llAction.switchtoDefaultContent();
			llAction.switchtoFrame("main");

			llAction.clickElement("web_evaluation_btn_submit");
			llAction.waitUntilLoadingCompletes();

			if (llAction.isAlertDisplayed(timeOut)) {
				dashboard.setStepDetails("Submit button is clicked",
						"Case information is updated successfully popup is diplayed", "N/A");
				dashboard.writeResults();
				llAction.acceptAlert();
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Accept the alert",
						"Approval Case Result screen with approve case done message is diplayed", "N/A");
				dashboard.writeResults();
				llAction.handleMultipleAlerts(timeOut);

				// if (llAction.isAlertDisplayed(timeOut))
				// llAction.acceptAlert();
				// if (llAction.isAlertDisplayed(timeOut))
				// llAction.acceptAlert();

				String caseResult = llAction.getText("web_evaluation_approval_caseResult_txt").trim();
				if (caseResult.equalsIgnoreCase(hParams.get("CaseResult"))) {
					dashboard.setStepDetails("Case Result should be displayed ", "Case Result is '" + caseResult + "' ",
							"N/A");
					dashboard.writeResults();
				}
				llAction.clickElement("web_evaluation_btn_exit");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Exit button is clicked", "Claims Processing Pool screen is diplayed", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_evaluation_btn_exitToMainMenu");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Exit to Mainmenu", "Main menu screen is diplayed", "N/A");
				dashboard.writeResults();
			} else {

				dashboard.setFailStatus(new BPCException("Case information is not updated successfully"));
				dashboard.writeResults();
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void evaluateCase(Hashtable<String, String> hParams) throws Exception {

		//llAction.clickElement("web_evaluation_btn_evaluation");
		
	//	if (caseHandler.getCaseNumber().isEmpty()) {
		//caseHandler.setCaseNumber(hParams.get("CaseNumber"));
		//}
		//String caseNumber = caseHandler.getCaseNumber();
		String caseNumber = hParams.get("CaseNumber");

		int colPos = llAction.GetColumnPositionInTable("web_tbl_ClaimsProcessingPool_searchResults", "Case Number");
		int rowPos = llAction.GetRowPositionInTable("web_tbl_ClaimsProcessingPool_searchResults", caseNumber,
				colPos);
		llAction.SelectRowInTable("web_tbl_ClaimsProcessingPool_searchResults", rowPos, colPos, "a");
		llAction.waitUntilLoadingCompletes();	
		
		Utils.sleep(2);
		llAction.switchtoFrame("left");
		dashboard.setStepDetails("Claim Evaluation screen should be displayed",
				"Claim Evaluation screen should is displayed", "N/A");
		dashboard.writeResults();
		List<WebElement> allParents = llAction.findElements("web_evaluation_expand_tree_lnk");
		for (int j = 0; j < allParents.size(); j++) {

			WebElement parent = allParents.get(j);

			Hashtable<String, String> childElementPath = ARTProperties.guiMap.get("web_div_childnode_name");
			String childPath = childElementPath.get(childElementPath.keySet().toArray()[0]);
			childPath = childPath.replace("0", String.valueOf(j));

			List<WebElement> allChildren = llAction.findElementsByXpath(childPath);

			for (int i = 0; i < allChildren.size(); i++) {
				WebElement element = allChildren.get(i);
				browseCase(parent);
				llAction.clickElementJs(element);// selecting the product
				// switching to main frame for evaluating product details
				llAction.switchtoDefaultContent();
				llAction.switchtoFrame("main");
				llAction.waitUntilLoadingCompletes();
				addComputationDetails(hParams.get("ClaimDecision"), hParams);
				llAction.switchtoDefaultContent();
				llAction.switchtoFrame("left");

				// reinitializing the list as after swtiching between frames, it is throwing
				// staleElementexception
				allChildren = llAction.findElementsByXpath(childPath);
				allParents = llAction.findElements("web_evaluation_expand_tree_lnk");
				parent = allParents.get(j);
			}
		}
		List<WebElement> allParentPolicies = llAction.findElements("web_evaluation_click_policy");
		allParents = llAction.findElements("web_evaluation_expand_tree_lnk");
		for (int j = 0; j < allParents.size(); j++) {
			WebElement parent = allParents.get(j);
			WebElement parentPolicy = allParentPolicies.get(j);
			browseCase(parent);
			llAction.clickElementJs(parentPolicy);
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoDefaultContent();
			llAction.switchtoFrame("main");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Policy details should be displayed", "Policy details should be displayed", "N/A");
			dashboard.writeResults();
			llAction.switchtoDefaultContent();
			llAction.switchtoFrame("left");
			allParentPolicies = llAction.findElements("web_evaluation_click_policy");
			allParents = llAction.findElements("web_evaluation_expand_tree_lnk");
		}

		llAction.switchtoDefaultContent();
		llAction.switchtoFrame("main");
		dashboard.setStepDetails("Claim case for all the product should be " + hParams.get("ClaimDecision"),
				"Claim case for all the product is admit", "N/A");
		dashboard.writeResults();
		llAction.switchtoDefaultContent();
		llAction.switchtoFrame("left");
		llAction.clickElement("web_evaluation_tree_parent");
		llAction.switchtoDefaultContent();
		llAction.waitUntilLoadingCompletes();
	}

	private void addComputationDetails(String claimDecision, Hashtable<String, String> hParams) throws BPCException {
		try {
			Long timeOut = (long) 10;
			boolean isComputationTableUpdated = false;

			isComputationTableUpdated = compute(hParams);

			if (isComputationTableUpdated) {
				llAction.clickElement("web_ep_computation_details_compute_button");
				llAction.handleMultipleAlerts(timeOut);
				llAction.waitUntilLoadingCompletes();

			} else {
				dashboard.setStepDetails("Case Evaluation ", "No liabilities enabled for this product", "N/A");
				dashboard.writeResults();
			}
			if (StringUtils.isEmpty(claimDecision)) {
				dashboard.setFailStatus(new BPCException("Failed to evaluate the case as claim Decision is empty"));
				dashboard.writeResults();
			} else {
				llAction.selectByVisibleText("web_ep_computation_details_decision_list", claimDecision);
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_select_inforce", 1)) {
					if (llAction.isEnabled("web_select_inforce")) {
						llAction.selectByVisibleText("web_select_inforce", hParams.get("ToInforceproduct"));
						llAction.isAlertDisplayed(timeOut);
					}
				}
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_select_" + claimDecision, 5)) {
					llAction.selectByVisibleText("web_select_" + claimDecision, hParams.get("PendingReason"));
				}
				dashboard.setStepDetails("Compute and enter claim evaluation details",
						"Claim Evaluation with details screen should is displayed", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_ep_computation_details_save_button");
				llAction.handleMultipleAlerts(timeOut);
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}

	private boolean compute(Hashtable<String, String> hParams) throws Exception {
		try {
			/*
			 * if (llAction.isEnabled("web_ep_computation_details_compute_button")) {
			 * List<String> liabilityNames = new ArrayList<String>();
			 * liabilityNames.add(llAction.getText("web_liablity_first_checkbox")); return
			 * computeWithoutDisablity(liabilityNames); } else { return false; }
			 */
			boolean computeWithoutDisablitybool = false;
			List<String> liabilityNames = hParams.get("LiabiltyName").isEmpty() ? new ArrayList<String>()
					: Arrays.asList(hParams.get("LiabiltyName").split(","));
			if (llAction.isEnabled("web_ep_computation_details_compute_button")) {
				if (liabilityNames.size() > 0) {
					for (String liabilityName : liabilityNames) {
						Utils.editXpath("web_liablity_allcolumns_element", "checkLiablityExist",
								new String[] { liabilityName, Integer.toString(1), "checkbox" });
						if (!llAction.isDisplayed("checkLiablityExist", 4)) {
							liabilityNames = new ArrayList<String>();
							liabilityNames.add(llAction.getText("web_liablity_first_checkbox"));
							computeWithoutDisablity(liabilityNames.get(0));
							computeWithoutDisablitybool = true;
							break;
						} else {
							computeWithoutDisablity(liabilityName);
							computeWithoutDisablitybool = true;
						}
					}

				} else {
					String lName = llAction.getText("web_liablity_first_checkbox");
					liabilityNames = new ArrayList<String>();
					liabilityNames.add(lName);
					computeWithoutDisablity(liabilityNames.get(0));
					computeWithoutDisablitybool = true;
				}
			} else {
				computeWithoutDisablitybool = false;
			}
			return computeWithoutDisablitybool;
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private boolean computeWithoutDisablity(String liabilityName) throws Exception {
		// As the computation table structure is different for accident claim and
		// others, there are two paths to compuatation table-
		// look for INCURRED AMOUNT header and decide if need to take a different path.
		boolean isComputationTableUpdated = false;
		try {
			if (!liabilityName.isEmpty()) {
				boolean selected = false;
				Hashtable<String, String> liability = getliability(liabilityName);
				if (!liability.isEmpty()) {
					List<TableColumn> columnNames = llAction.getColumnHeaders("web_ep_computation_details_table", 1);
					for (TableColumn columnName : columnNames) {
						if (columnName.getName().trim().equalsIgnoreCase("Option")) {
							Utils.editXpath("web_liablity_allcolumns_element", "select_option", new String[] {
									liabilityName, Integer.toString(columnName.getIndex()), "checkbox" });
							if (llAction.returnWebElement("select_option").isEnabled()) {
								llAction.checkBox_Check("select_option");
								selected = true;
								isComputationTableUpdated = true;
							}
						} else if (selected == true && columnName.getName().trim().equalsIgnoreCase("Parameter")) {
							Utils.editXpath("web_liablity_input_element_withoutdiv", "get_input_from_column",
									new String[] { liabilityName, Integer.toString(columnName.getIndex()) });
							if (llAction.isDisplayed("get_input_from_column", 1)) {
								List<WebElement> inputElements = llAction.returnWebElements("get_input_from_column");
								String[] parameters = liability.get("Parameter").split(",");
								for (int len = 0; len < inputElements.size(); len++) {
									Utils.editXpath("web_liablity_input_element_tabledata", "get_text_field_toenter",
											new String[] { liabilityName, Integer.toString(columnName.getIndex()),
													Integer.toString(len + 1) });
									if (parameters.length == inputElements.size()) {
										llAction.enterValue("get_text_field_toenter", parameters[len]);
										llAction.waitUntilLoadingCompletes();
									} else {
										llAction.enterValue("get_text_field_toenter", liability.get("Parameter"));
										llAction.waitUntilLoadingCompletes();
									}
								}
							}

						} else if (selected == true && columnName.getName().trim().equalsIgnoreCase("Remarks")) {
							Utils.editXpath("web_liablity_input_element_withoutdiv", "get_input_from_column_remarks",
									new String[] { liabilityName, Integer.toString(columnName.getIndex()) });
							if (llAction.isDisplayed("get_input_from_column_remarks", 1)) {
								List<WebElement> inputElements = llAction
										.returnWebElements("get_input_from_column_remarks");
								if (inputElements.size() > 0) {
									Utils.editXpath("web_liablity_input_element_withoutdiv",
											"get_text_field_toenter_remarks",
											new String[] { liabilityName, Integer.toString(columnName.getIndex()) });
									llAction.enterValue("get_text_field_toenter_remarks", liability.get("Remarks"));
									llAction.waitUntilLoadingCompletes();
								}
							}
						} else if (selected == true
								&& columnName.getName().trim().equalsIgnoreCase("Incurred Amount")) {
							Utils.editXpath("web_liablity_allcolumns_element", "get_input_from_column_incurredAmount",
									new String[] { liabilityName, Integer.toString(columnName.getIndex()), "text" });
							if (llAction.isDisplayed("get_input_from_column_incurredAmount", 1)) {
								List<WebElement> inputElements = llAction
										.returnWebElements("get_input_from_column_incurredAmount");
								if (inputElements.size() > 0) {
									Utils.editXpath("web_liablity_input_element_withoutdiv",
											"get_text_field_toenter_incurredAmount",
											new String[] { liabilityName, Integer.toString(columnName.getIndex()) });
									llAction.enterValue("get_text_field_toenter_incurredAmount",
											liability.get("IncurredAmount"));
									llAction.waitUntilLoadingCompletes();
								}
							}
						}
					}
				} else {
					dashboard.setFailStatus(
							new BPCException("Could not find the " + liabilityName + " liablity test data sheet"));
				}
			}

		} catch (Exception ex)

		{
			throw new BPCException(ex);
		}
		return isComputationTableUpdated;
	}

	@Deprecated
	private boolean computeIncurredAmountRecords(String computationTable) throws Exception {

		boolean isComputationTableUpdated = false;
		List<String> liabilityName = llAction.GetAllTextUnderColumnInTable(computationTable, 3);

		int i = 0, rIndx = 2;

		// for (int i=0,rIndx = 2;i<liabilityName.size();i++,rIndx++) {
		WebElement option = llAction.getElementAt(computationTable, rIndx, 1, "/input[@name='option']");
		if (option.isEnabled()) {
			Hashtable<String, String> liability = getliability(liabilityName.get(i));
			String incurredAmt = liability.get("IncurredAmount");
			if ((!liability.isEmpty()) && (!StringUtils.isEmpty(incurredAmt))) {
				if (!option.isSelected()) {
					option.click();
					Utils.sleep(1);
				}
				llAction.enterTextInTable(computationTable, rIndx, 4, liability.get("NoOfDays"),
						"/input[@name='noOfDays']");
				llAction.enterTextInTable(computationTable, rIndx, 5, incurredAmt, "/input[@name='incurredAmt']");
				Utils.sleep(2);
				try {
					WebElement disableRate = llAction.getElementAt(computationTable, rIndx, 6, "/div/input[2]");
					// if(disableRate.getAttribute("name").equals("pvl60")){
					if (disableRate.getText().length() > 0) {
						disableRate.sendKeys(Keys.chord(Keys.CONTROL, "a"), liability.get("Parameter"));
					} else {
						disableRate.sendKeys(liability.get("Parameter"));
					}
					// llAction.enterTextInTable(computationTable, rIndx, 6,
					// liability.get("Parameter"),"/div/input[2]");
					// }
				} catch (Exception e) {
					// Can throw an exception as in some cases this element is not found
					// and so do not want to propograte this error.
				}

				llAction.enterTextInTable(computationTable, rIndx, 8, liability.get("Remarks"),
						"/input[@name='remarks']");
				isComputationTableUpdated = true;
			}
		}
		// }

		return isComputationTableUpdated;
	}

	private Hashtable<String, String> getliability(String liabilityName) {
		DataHandler dataHandler = new DataHandler();
		System.out.println(FPMSProperties.getInstance().getLiabilitiesFileLocation());
		Hashtable<String, String> liability = dataHandler.getTestData(LIABILITY_SHEET,
				FPMSProperties.getInstance().getLiabilitiesFileLocation(),
				ColumnHeader.getColumnHeader(LIABILITY_SHEET), liabilityName, "LiabilityName");

		return liability;
	}

	private void browseCase(WebElement parent) {
		// String childWebElementNode = "web_div_childnode_name";
		WebElement img = parent.findElement(By.tagName("img"));
		img.getAttribute("src").contains("Tplus");
		try {
			if (img.getAttribute("src").contains("Tplus")) {
				llAction.sendkeyStroke("web_evaluation_expand_tree_lnk", Keys.ENTER);
				llAction.clickElementJs(parent);
				llAction.waitUntilLoadingCompletes();
				Utils.sleep(2);
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}

	public int findColumnIndex(String tableName, String headerName) throws Exception {
		int cIndex = -1;
		ArrayList<TableColumn> computationColnHeaders = llAction.getColumnHeaders(tableName, 1);
		for (TableColumn coln : computationColnHeaders) {
			if (coln.getName().equalsIgnoreCase(headerName)) {
				cIndex = coln.getIndex();
				break;
			}
		}

		return cIndex;

	}
	
	
	public void makeApprovalDecision(Hashtable<String, String> hParams) throws Exception {
		long timeOut = (long) 5;
		
		int colPos = llAction.GetColumnPositionInTable("web_tbl_ClaimsProcessingPool_searchResults", "Case Number");
		int rowPos = llAction.GetRowPositionInTable("web_tbl_ClaimsProcessingPool_searchResults", hParams.get("CaseNumber"),
				colPos);
		llAction.SelectRowInTable("web_tbl_ClaimsProcessingPool_searchResults", rowPos, colPos, "a");
		llAction.waitUntilLoadingCompletes();	
		
		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CASE_APPROVAL, "");
		llAction.switchtoDefaultContent();
		llAction.switchtoFrame("main");		
		llAction.waitUntilLoadingCompletes();
		
		llAction.selectByVisibleText("web_list_approvalDecision",hParams.get("ApprovalDecision"));
		dashboard.setStepDetails("Select  "+ hParams.get("ApprovalDecision") + " value",
				"Option is selected.", "N/A");
		dashboard.writeResults();		
		llAction.handleMultipleAlerts(timeOut);
		llAction.waitUntilLoadingCompletes();		

		llAction.clickElement("web_btn_approveCase_submit");
		llAction.handleMultipleAlerts(timeOut);
		llAction.waitUntilLoadingCompletes();
		dashboard.setStepDetails("Click Submit button",
				"Home page is displayed", "N/A");
		dashboard.writeResults();	
		String caseResult = hParams.get("CaseResult");
		String caseApprovalResult = llAction.getText("web_evaluation_approval_caseResult_txt").trim();
		if (caseApprovalResult.equalsIgnoreCase(caseResult)) {
			dashboard.setStepDetails("Case Approval Result",
					"Case Result displayed as  '" + caseResult + "' successfully ", "N/A");
			dashboard.writeResults();
		} else {

			dashboard.setFailStatus(new BPCException("Failed to approve the case .. "));
			dashboard.writeResults();
		}

		llAction.clickElement("web_evaluation_btn_exit");
		llAction.waitUntilLoadingCompletes();
		dashboard.setStepDetails("Exit button is clicked", "Claims Processing Pool screen is diplayed", "N/A");
		dashboard.writeResults();

		llAction.clickElement("web_evaluation_btn_exitToMainMenu");
		llAction.waitUntilLoadingCompletes();
		dashboard.setStepDetails("Exit to Mainmenu", "Main menu screen is diplayed", "N/A");
		dashboard.writeResults();

		} 
	}

	
	
	
