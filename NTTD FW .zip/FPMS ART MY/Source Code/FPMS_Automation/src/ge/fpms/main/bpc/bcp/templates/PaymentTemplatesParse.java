package ge.fpms.main.bpc.bcp.templates;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.stream.Stream;

import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.nttdata.framework.exceptions.BPCException;

public abstract class PaymentTemplatesParse {
	
	private int recordCount;
	
	public PaymentTemplatesParse() {
		recordCount = 0;
	}

	public void processTemplateFile(Hashtable<String, String> hParams) throws Exception {
		
		try {
			
			parseFile(hParams);
			
			updateAttributes(hParams);
			
			createNewFile(hParams.get("OutputFile"));
			
		} catch (JsonIOException | JsonSyntaxException  e) {
			throw new BPCException(e);
		}
	}
	
	public void parseTemplate(Hashtable<String, String> hParams) throws Exception {
		
		parseFile(hParams);
	}
	
	private void parseFile(Hashtable<String, String> hParams) throws Exception{

			try (Stream<String> stream = Files.lines(Paths.get(hParams
					.get("InputFile")))) {

				Iterator<String> iterator = stream.iterator();
				String line = iterator.next();
				beginParse(line);

				while (iterator.hasNext()) {
					line = iterator.next();
					parse(line);
					recordCount++;

					//System.out.println("TemplateParser.parse() line : " + line);
				}
				endParse(line);
			} catch (IOException e) {
				throw new BPCException(e);
			}
	}
	public int getRecordCount() {
		return recordCount;
	}
	
	/**
	 * beginParse - parse header section
	 * @throws Exception 
	 */
	public abstract void beginParse(String line) throws Exception;
	
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	/**
	 * parse - parse each line from inputfile
	 * @throws Exception 
	 */
	public abstract void parse(String line) throws Exception;
	
	/**
	 * parse - summary section
	 */
	public abstract void endParse(String line) throws Exception;
	/**
	 * create the new file after updation
	 * @param outputFile
	 */
	public abstract void createNewFile(String outputFile )throws Exception;
	
	/**
	 * updateAttributes - update attributes based on the template/testdata
	 * @param params
	 */
	public abstract void updateAttributes(Hashtable<String, String> params)throws Exception;
}
