package ge.fpms.main.bpc.csd;
import ge.fpms.main.actions.FPMS_Actions;

import java.util.Hashtable;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class SmokerIndChanges {

	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	
	public SmokerIndChanges() {
		dashboard = DashboardHandler.getInstance();
	}	
	/*
	 * Name: SmokerIndChanges_SearchSelectParty Purpose: Search And Select Party
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void SmokerIndChanges_SearchSelectParty (Hashtable<String, String> hParams) throws Exception {
		try {
			
			String IndicatorType = hParams.get("IndicatorType");
			
			String PartyName = hParams.get("PartySmokerName");
			String PartyID = hParams.get("PartySmokerID");
			
			llAction.selectMenuItem("NBD", "Search Party");
			llAction.waitUntilLoadingCompletes();
			
			llAction.enterValue("web_PartyChanges_txt_PartyName", PartyName);
			llAction.enterValue("web_PartyChanges_txt_IDNumber", PartyID);
			
			dashboard.setStepDetails("Enter Part Name and Party ID" ,
					"User should be able to enter Party Name and ID", "N/A");
			dashboard.writeResults();
			
			llAction.clickElement("web_PartyChanges_btn_SearchandEdit");
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Click on Search and Edit" ,
					"Application should display the search results", "N/A");
			dashboard.writeResults();
			
			int colPos = llAction.GetColumnPositionInTable("web_PartyChanges_tbl_PartyTable", "ID Number");
			int rowPos = llAction.GetRowPositionInTable("web_PartyChanges_tbl_PartyTable", PartyID, colPos);
			llAction.SelectRowInTable("web_PartyChanges_tbl_PartyTable", rowPos, colPos-6, "a");
			
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Click on any hyperlink in the search results for the corresponding party" ,
					"Application should navigate Create and Maintain Party Page", "N/A");
			dashboard.writeResults();
			
			switch(IndicatorType.toUpperCase())
			{
			case "SMOKER":
				SmokerIndChanges_UpdatePartyInformation(hParams);
				break;
			case "FOREIGNER":
				ForeignerIndChanges_UpdatePartyInformation(hParams);
				break;
			}
			
			llAction.clickElement("web_PartyChanges_btn_Submit");
			llAction.waitUntilLoadingCompletes();
			if(llAction.isDisplayed("web_PartyChanges_btn_Continue", 5))
			{
				llAction.clickElement("web_PartyChanges_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			}
			llAction.clickElement("web_PartyChanges_btn_Exit");
			llAction.waitUntilLoadingCompletes();
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	/*
	 * Name: SmokerIndChanges_UpdatePartyInformation Purpose: Update Party Information
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void SmokerIndChanges_UpdatePartyInformation(Hashtable<String, String> hParams) throws Exception {
		try {
			String Ind = hParams.get("IndicatorValue");
			SmokerIndChanges_ChangePartyRole(hParams);
			
			llAction.move_to_element("web_PartyChanges_lst_SmokerInd");
			llAction.selectByVisibleText("web_PartyChanges_lst_SmokerInd", Ind);
			
			dashboard.setStepDetails("Update Party Smoker Ind to "+Ind+"" ,
					"User should be able to update party Smoker Ind", "N/A");
			dashboard.writeResults();
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	/*
	 * Name: ForeignerIndChanges_UpdatePartyInformation Purpose: Update Party Information
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void ForeignerIndChanges_UpdatePartyInformation(Hashtable<String, String> hParams) throws Exception {
		try {
			String Ind = hParams.get("IndicatorValue");
			
			llAction.move_to_element("web_PartyChanges_lst_ForeignerInd");
			llAction.selectByVisibleText("web_PartyChanges_lst_ForeignerInd", Ind);
			
			dashboard.setStepDetails("Update Party Foreigner Ind to "+Ind+"" ,
					"User should be able to update party Foreigner Ind", "N/A");
			dashboard.writeResults();
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: SmokerIndChanges_ChangePartyRole Purpose: Change Party Role
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void SmokerIndChanges_ChangePartyRole(Hashtable<String, String> hParams) throws Exception {
		try {

			String PartyRole = hParams.get("PartyChangesRoles");
			
			llAction.move_to_element("web_PartyChanges_lst_PartyRoles");
			llAction.selectByVisibleText("web_PartyChanges_lst_PartyRoles", PartyRole);
			llAction.clickElement("web_PartyChanges_txt_PartyDOB");
			
			dashboard.setStepDetails("Update Party Role to "+PartyRole+"" ,
					"User should be able to update party role", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: ChangeSmokerStatus Purpose: Change Party Role
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void ChangeSmokerStatus(Hashtable<String, String> hParams) throws Exception {
		try {

			String StartDate = hParams.get("SmokerStatusStartDate");
			String PartyID = hParams.get("PartySmokerID");
			
			int colPos = llAction.GetColumnPositionInTable("web_PolicyChanges_tbl_SmokerIndPartyInfo", "ID number");
			int rowPos = llAction.GetRowPositionInTable("web_PolicyChanges_tbl_SmokerIndPartyInfo", PartyID, colPos);
			llAction.SelectRowInTable("web_PolicyChanges_tbl_SmokerIndPartyInfo", rowPos, colPos-4, "input");
			
			if(StartDate.equalsIgnoreCase("Commencement"))
			{
				llAction.clickElement("web_SmokerInd_btn_commencement");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Click on Change smoker status or Foreigner Indicator from commencement date" ,
						"User should be able to click on the button", "N/A");
				dashboard.writeResults();
			}
			else
			{
				llAction.clickElement("web_SmokerInd_btn_Immediate");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Click on Change smoker status or Foreigner Indicator immediately button" ,
						"User should be able to click on the button", "N/A");
				dashboard.writeResults();
			}
			
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_PolicyChanges_btn_ChangeSmokerStatusSubmit");
			llAction.waitUntilLoadingCompletes();
			
			if(llAction.isDisplayed("web_PolicyChanges_btn_Continue", 5))
			{
				llAction.clickElement("web_PolicyChanges_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			}
			
			llAction.clickElement("web_btn_Submit_ApplicationEntry");
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Validate if Policy Status is In Force" ,
					"Policy Status should be In Force", "N/A");
			dashboard.writeResults();
			
			llAction.clickElement("web_PolicyChanges_btn_backToMain");
			llAction.waitUntilLoadingCompletes();
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
