package ge.fpms.main.bpc.claims;

import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class Disbursement extends BusinessComponent {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public Disbursement() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	

	public void updateDisbursementPlan(Hashtable<String, String> hParams) throws Exception {
		// Utils.sleep(6);
		llAction.switchtoDefaultContent();
		llAction.switchtoFrame("main");
		llAction.clickElement("web_disbursement_btn_disbursementPlan");
		llAction.switchtoDefaultContent();
		llAction.waitUntilLoadingCompletes();
		llAction.switchtoFrame("rightFrame");
		llAction.waitUntilLoadingCompletes();
		llAction.switchtoDefaultContent();
		llAction.switchtoFrame("leftFrame");
		dashboard.setStepDetails("Disbursement Plan button is clicked", "Disbursement Plan Summary displayed", "N/A");
		dashboard.writeResults();

		List<WebElement> allPolicies = llAction.findElements("web_disbursementPlan_policies_tree_lnk");
		if (allPolicies.size() == 0) {
			dashboard.setFailStatus(new BPCException("Disbursement Plan - Failed to find policies.. "));
			dashboard.writeResults();
		} else {
			String settlementOption = hParams.get("SettlementOption");
			String pendingPayment = hParams.get("PendingPayment");
			String instalmentType = hParams.get("InstalmentType");
			String estimatedPaymentDate = hParams.get("EstimatedPaymentDate");
			String paymentSectionCode = hParams.get("PaymentSectionCode");
			String remarks = hParams.get("Remarks");
			String pendingReason = hParams.get("PendingReason");

			for (int j = 0; j < allPolicies.size(); j++) {
				// Click on each policy
				WebElement policy = allPolicies.get(j);
				llAction.clickElementJs(policy);
				// llAction.waitUntilLoadingCompletes();

				llAction.switchtoDefaultContent();
				llAction.switchtoFrame("rightFrame");
				llAction.waitUntilLoadingCompletes();

				int rowCount = llAction.getRowCountInTable("web_disbursement_tbl_benefitAllocation");
				int payeeCol = llAction.GetColumnPositionInTable("web_disbursement_tbl_benefitAllocation", "Payee");
				String text1 = llAction.GetTextFromTable("web_disbursement_tbl_benefitAllocation", 2, 1);
				if (!text1.equalsIgnoreCase("Record Not Found")) {
					for (int i = 1; i < rowCount; i++) {
						llAction.SelectRowInTable("web_disbursement_tbl_benefitAllocation", i + 1, payeeCol, "a");
						llAction.waitUntilLoadingCompletes();

						if (!StringUtils.isEmpty(settlementOption)) {
							llAction.selectByVisibleText("web_disbursement_lst_settlementOption", settlementOption);
							dashboard.setStepDetails("Disbursement Plan displayed", "Selected settlement Option",
									"N/A");
							dashboard.writeResults();
						}
						llAction.selectByVisibleText("web_disbursement_paymentmethod", hParams.get("Paymentmethod"));
						if (!StringUtils.isEmpty(pendingPayment)) {
							llAction.selectByVisibleText("web_evaluation_disbursement_ispending",
									hParams.get("PendingPayment"));
							dashboard.setStepDetails("Disbursement Plan displayed", "Selected pending payement", "N/A");
							dashboard.writeResults();
						}
						//Other MY specific fields.
						if (!StringUtils.isEmpty(instalmentType)) {
							if(instalmentType.equalsIgnoreCase("Instalment"))
								llAction.clickElement("web_radio_instalmentType_Instalment");
							else
								llAction.clickElement("web_radio_instalmentType_lumpsum");
							dashboard.setStepDetails("Select Instalment type ", "Selected instalment type", "N/A");
							dashboard.writeResults();
						}
						
						if (!StringUtils.isEmpty(estimatedPaymentDate)) {						
							llAction.enterValue("web_radio_instalmentType_Instalment", estimatedPaymentDate);					
							dashboard.setStepDetails("Select estimated payment date ", "Selected estimated payment date", "N/A");
							dashboard.writeResults();
						}
						
						if (!StringUtils.isEmpty(paymentSectionCode)) {						
							llAction.selectByVisibleText("web_list_paymentSectionCode", paymentSectionCode);					
							dashboard.setStepDetails("Select payment section code ", "Selected payment section code", "N/A");
							dashboard.writeResults();
						}
						
						if (!StringUtils.isEmpty(remarks)) {						
							llAction.enterValue("web_radio_instalmentType_Instalment", remarks);					
							dashboard.setStepDetails("Enter Remarks", "Remarks entered", "N/A");
							dashboard.writeResults();
						}
						
						if (!StringUtils.isEmpty(pendingReason)) {	
							llAction.selectByVisibleText("web_list_pendingreason",
									pendingReason);											
							dashboard.setStepDetails("Enter pending reason ", "pending reason selected", "N/A");
							dashboard.writeResults();
						}
					
						llAction.clickElement("web_evaluation_disbursement_save");
						llAction.handleMultipleAlerts((long) 0);
						llAction.waitUntilLoadingCompletes();
						llAction.clickElement("web_evaluation_txt_close");
						llAction.waitUntilLoadingCompletes();

					}
					dashboard.setStepDetails("Disbursement amount and pending status should be updated",
							"Disbursement amount and pending status is updated", "N/A");
					dashboard.writeResults();
				}
				else
				{
					dashboard.setStepDetails("Products are not found for disbursement amount",
							"No records found", "N/A");
					dashboard.writeResults();
				}
				
				llAction.switchtoDefaultContent();
				llAction.switchtoFrame("leftFrame");
				allPolicies = llAction.findElements("web_disbursementPlan_policies_tree_lnk");

			}

			llAction.clickElement("web_disbursementPlan_caseNumber_tree_lnk");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Disbursement amount and Allocated amount should be updated for claim case",
					"Disbursement amount and Allocated amount should is updated for claim case", "N/A");
			dashboard.writeResults();
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CASE_EVALUATION, "");
			llAction.switchtoDefaultContent();
			llAction.switchtoFrame("main");
			llAction.clickElement("web_evaluation_btn_exitToPool");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoChildWindow("Claim Processing Pool");
			llAction.clickElement("web_evaluation_btn_exitToMainMenu");
			llAction.waitUntilLoadingCompletes();
		}
	}
	
	public void changeDisbursementPlan(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("Claim", "Change Disbursement Plan");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_ClaimsProcessingPool_CaseNumber", hParams.get("CaseNumber"));// Enter Case Number
			llAction.sendkeyStroke("web_txt_ClaimsProcessingPool_CaseNumber", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			PolicyHandler policyHandler = new PolicyHandler();
			policyHandler.getPolicy().setPolicyNo(hParams.get("PolicyNumber"));
			llAction.selectByVisibleText("web_select_disbursement_policynumber", hParams.get("PolicyNumber")); // Select policy Number
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Enter case number and select required policy",
					"Case details should be loaded successfully", "N/A");
			dashboard.writeResults();
			Utils.editXpath("web_link_disbursement_payee", "ClickOnPayee", new String[] {hParams.get("InstallmentType"),hParams.get("Payee")});
			llAction.clickElement("ClickOnPayee");// Click on payee hyper link
			llAction.switchtoChildWindow("Disbursement Plan");
			llAction.maximizeWindow();
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow("Disbursement Plan");
			llAction.waitUntilLoadingCompletes();	
			
			dashboard.setStepDetails("Disbursement plan should be displayed for the payee"+hParams.get("Payee"),
					"Disbursement plan is displayed successfully", "N/A");
			dashboard.writeResults();
			
			if (hParams.get("InstallmentType").equalsIgnoreCase("Lump Sum")) {
				llAction.selectByVisibleText("web_disbursement_paymentmethod", hParams.get("PaymentMethod"));// Change payment method
				llAction.selectByVisibleText("web_select_disbursement_paymentsectioncode", hParams.get("PaymentSectionCode"));// Change Selection code
				llAction.selectByVisibleText("web_select_disbursement_pendingpayment", hParams.get("PendingPayment"));// Pending payment
				llAction.selectByVisibleText("web_select_disbursement_pendingreason", hParams.get("PendingReason"));// Pending reason
				dashboard.setStepDetails("Lump sum details should be entered",
						"Lump sum details are accepted", "N/A");
				dashboard.writeResults();
			}
			else if(hParams.get("InstallmentType").equalsIgnoreCase("Installment"))
			{
				llAction.clickElement("web_btn_disbursement_installmentplan");// Click Installment Plan Detail
				llAction.waitUntilLoadingCompletes();
				String[] datestochek = hParams.get("DatesTobeChecked").isEmpty()?new String[] {}:hParams.get("DatesTobeChecked").split(",");
				String[] datestoUnchek = hParams.get("DatesTobeUnChecked").isEmpty()?new String[] {}:hParams.get("DatesTobeUnChecked").split(",");
				if(datestochek.length>0)
				{
					for(int i=0;i<datestochek.length;i++)
					{
						Utils.editXpath("web_chkbox_disbursement_installmentplan", "CheckUnpaidRecords"+i, new String[] { datestochek[i]});
						llAction.checkBox_Check("CheckUnpaidRecords"+i);
					}
				}
				if(datestoUnchek.length>0)
				{
					for(int i=0;i<datestoUnchek.length;i++)
					{
						Utils.editXpath("web_chkbox_disbursement_installmentplan", "UnCheckUnpaidRecords"+i, new String[] { datestoUnchek[i]});
						llAction.checkBox_Check("UnCheckUnpaidRecords"+i);
					}
				}
				dashboard.setStepDetails("Installment details should be entered",
						"Installment details are accepted", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_evaluation_btn_save");// Save
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Installment details should be saved",
						"Installment details is saved successfully", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_evaluation_txt_close");// Close
				llAction.waitUntilLoadingCompletes();
			}
			llAction.clickElement("web_evaluation_btn_save");// Save
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Disbursement plan should be saved",
					"Disbursement plan is saved successfully", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_evaluation_txt_close");// Close
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoDefaultWindow();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on close button change disbursement plan screen should be displayed",
					"Change disbursement plan screen is saved successfully", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_evaluation_btn_exitToMainMenu");
			llAction.waitUntilLoadingCompletes();
			

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
