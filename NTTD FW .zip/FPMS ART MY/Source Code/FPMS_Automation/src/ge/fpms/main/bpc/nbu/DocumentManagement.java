package ge.fpms.main.bpc.nbu;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;

public class DocumentManagement {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;

	public DocumentManagement() {
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	public void publishOrIssueDoc(Hashtable<String, String> hParams) throws Exception {
		searchLetter(hParams);
		String[] docsToBeSelected = hParams.get("TemplateName").split(",");
		for (String doc : docsToBeSelected) {
			selectLetter(doc);
			performActionOnLetter(doc, hParams);
		}
	}

	/*
	 * Name: SearchLetter Purpose: Navigate to Search Document Page from the Main
	 * Page and Search a Document based on Main Category, Sub Category, Template
	 * Name and Policy. Parameters: Parameter Hash table Return Value: NA Exception:
	 * BPCException Added By: ManjuPrasad 0n 27/11/2018
	 */
	public void searchLetter(Hashtable<String, String> hParams) throws Exception {
		String policyNumber;
		String mainCategory = hParams.get("MainCategory");
		String subCategory = hParams.get("SubCategory");
		try {
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			String URL = llAction.getCurrentURL();
			if (!URL.contains("/ls/mainMenu.do")) {
				String[] parts = URL.split("/ls");
				String toReplace = "/ls/mainMenu.do";
				URL = parts[0] + toReplace;
				llAction.navigatetoUrl(URL);
			}

			llAction.selectMenuItem("Document Management", "Publish_Issue_Document");
			llAction.waitUntilLoadingCompletes();
			if (mainCategory.isEmpty() == false) {
				llAction.selectByVisibleText("web_dm_lst_DMSMainCategory", mainCategory);
			}
			Utils.sleep(3);
			if (subCategory.isEmpty() == false) {
				llAction.selectByVisibleText("web_dm_lst_DMSSubCategory", subCategory);
			}
			Utils.sleep(3);
			if (policyNumber.isEmpty() == false) {
				llAction.clickElement("web_dm_txt_DMSPolicyNo");
				llAction.enterValue("web_dm_txt_DMSPolicyNo", policyNumber);
			}
			Utils.sleep(3);
			dashboard.setStepDetails("Click on Search Button",
					"Page refreshes and Displays all the documents based on the Search Criteria", "N/A");
			llAction.clickElement("web_dm_btn_DMSSearch");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void selectLetter(String templateName) throws Exception {
		try {
			String TableFirstRowData = llAction.getText("web_dm_tbl_DMSDocListRow");
			if (StringUtils.isEmpty(TableFirstRowData)) {
				if (templateName.toUpperCase().equals("ALL")) {
					llAction.checkBox_Check("web_dm_check_DMSDocListAll");
					llAction.waitUntilLoadingCompletes();
				} else {
					int colPos = llAction.GetColumnPositionInTable("web_dm_tbl_DMSDocList", "Template Name");
					int rowPos = llAction.GetRowPositionInTable("web_dm_tbl_DMSDocList", templateName, colPos);
					llAction.SelectRowInTable("web_dm_tbl_DMSDocList", rowPos, 1, "input");
				}
				dashboard.setStepDetails("Validate if the required letters are selected",
						"The required letters should be selected", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setStepDetails("No Documents to select from the Document List",
						"No Documents to select from the Document List", "N/A");
				dashboard.writeResults();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void closeLetter(Hashtable<String, String> hParams) throws Exception {
		String policyNumber;
		String mainCategory = hParams.get("MainCategory");
		String subCategory = hParams.get("SubCategory");
		// String templateName = hParams.get("TemplateName");
		try {

			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			llAction.selectMenuItem("Document Management", "Document_With_Reply");
			llAction.waitUntilLoadingCompletes();
			if (mainCategory.isEmpty() == false) {
				llAction.selectByVisibleText("web_drp_lst_MainCategory", mainCategory);
				llAction.waitUntilLoadingCompletes();
			}
			if (subCategory.isEmpty() == false) {
				llAction.selectByVisibleText("web_drp_lst_SubCategory", subCategory);
				llAction.waitUntilLoadingCompletes();
			}
			/*
			 * if (templateName.isEmpty() == false) {
			 * llAction.selectByVisibleText("web_drp_lst_TemplateName", templateName);
			 * llAction.waitUntilLoadingCompletes(); }
			 */
			if (policyNumber.isEmpty() == false) {
				llAction.clickElement("web_drp_txt_PolicyNo");
				llAction.enterValue("web_dm_txt_DMSPolicyNo", policyNumber);
				llAction.waitUntilLoadingCompletes();
			}
			llAction.move_to_element("web_drp_btn_Search");
			llAction.clickElement("web_drp_btn_Search");
			dashboard.setStepDetails("Click on Search Button",
					"Page refreshes and Displays all the documents based on the Search Criteria", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();

			String TableFirstRowData = llAction.getText("web_drp_tbl_DocListRow");
			if (StringUtils.isEmpty(TableFirstRowData)) {
				llAction.move_to_element("web_drp_check_DocListAll");
				llAction.clickElement("web_drp_check_DocListAll");

				llAction.move_to_element("web_drp_btn_CloseCase");
				llAction.clickElement("web_drp_btn_CloseCase");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Click on Close Case Button", "Page refreshes and Closes All Documents",
						"N/A");
				dashboard.writeResults();
			} else {
				dashboard.setStepDetails("No Documents to select from the Document List",
						"No Documents to select from the Document List", "N/A");
				dashboard.writeResults();
			}

			llAction.clickElement("web_drp_btn_Exit");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void performActionOnLetter(String templateName, Hashtable<String, String> hParams) throws Exception {
		String ActionOnSelectedLetters = StringUtils.EMPTY;
		try {
			String TableFirstRowData = llAction.getText("web_dm_tbl_DMSDocListRow");
			
			/*if (templateName.equalsIgnoreCase("Standard Letter of Query")) {
				ActionOnSelectedLetters = hParams.get("ActionOnSLQ");
			} else if (templateName.equalsIgnoreCase("Letter Of Conditions Of Acceptance Malaysia")) {
				ActionOnSelectedLetters = hParams.get("ActionOnLCA");
			}*/
			
			if (StringUtils.isEmpty(TableFirstRowData)) {
				llAction.clickElement("web_dm_btn_DMSPrintLocal");
				Utils.sleep(15);
				llAction.switchtoSecondWindow();
				llAction.handleCertificateErrors();
				Utils.sleep(15);
				llAction.closeCurrentWindow();
				Utils.sleep(10);
				llAction.switchtoDefaultWindow();
			}
			
			/*if (StringUtils.isEmpty(TableFirstRowData)) {
				switch (ActionOnSelectedLetters.toUpperCase()) {
				case "DEFAULTISSUE":
					dashboard.setStepDetails("Click on DEFAULT ISSUE Button", "User Should be able to see the PDF",
							"N/A");
					llAction.clickElement("web_dm_btn_DMSDefaultIssue");
					llAction.waitUntilLoadingCompletes();
					llAction.switchtoSecondWindow();
					llAction.handleCertificateErrors();
					Utils.sleep(20);
					dashboard.writeResults();
					llAction.closeCurrentWindow();
					break;
				case "PRINTLOCAL":
					llAction.clickElement("web_dm_btn_DMSPrintLocal");
					llAction.waitUntilLoadingCompletes();
					llAction.switchtoSecondWindow();
					llAction.handleCertificateErrors();
					Utils.sleep(20);
					llAction.closeCurrentWindow();
					break;
				case "PRINTINEDMS":
					// TODO To be Enhanced if any TC Requires
					break;
				case "EMAIL":
					// TODO To be Enhanced if any TC Requires
					break;
				case "PUBLISH":
					llAction.clickElement("web_dm_btn_Publish");
					llAction.waitUntilLoadingCompletes();
					break;
				case "PUBLISHALL":
					llAction.clickElement("web_dm_btn_PublishAll");
					llAction.waitUntilLoadingCompletes();
					break;
				}
			}*/
			llAction.clickElement("web_dm_btn_DMSExit");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
