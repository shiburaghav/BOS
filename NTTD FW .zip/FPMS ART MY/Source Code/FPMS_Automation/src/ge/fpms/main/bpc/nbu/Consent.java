package ge.fpms.main.bpc.nbu;

import java.util.Hashtable;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;

public class Consent {
	/*
	 * Name: Health Warranty & Consent 
	 * Purpose: To update Consent Indicator and Warranty Expiry Date
	 *  @author: Sahil Singh 0n 16/01/2018
	 */
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	public Consent() {
		dashboard = DashboardHandler.getInstance();
		llAction = new FPMS_Actions();
	}

	public void updateConsent(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		try {
			llAction.selectMenuItem("NBD", "Health Warranty & Consent");
			llAction.enterValue("web_txt_CommonQueryPolicyNumber", hParams.get("PolicyNo"));
			llAction.clickElement("web_dm_btn_DMSSearch");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Policy is searched", "Policy should be searched", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_ConsentIndicator", hParams.get("ConsentGivenInd"));
			dashboard.setStepDetails("Consent Indicator is updated", "Consent Indicator should be updated", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_txt_ConsentGivenDate");
			llAction.enterValue("web_txt_ConsentGivenDate",  hParams.get("ConsentGivenDate"));
			llAction.clickElement("web_btn_Detail_Reg_Submit");
			llAction.waitUntilLoadingCompletes();
			dashboard.writeResults();
			llAction.clickElement("web_uw_btn_UWSPExit");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_ConsentCancel");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void updateWarrantyDate(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		try {
			llAction.selectMenuItem("NBD", "Health Warranty & Consent");
			llAction.enterValue("web_txt_CommonQueryPolicyNumber", hParams.get("PolicyNo"));
			llAction.clickElement("web_dm_btn_DMSSearch");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Policy is searched", "Policy should be searched", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_WarrantyExpiryDate", hParams.get("WarrantyExpiryDate"));
			dashboard.setStepDetails("Health Warranty Expiry date is updated",
					"Health Warranty Expiry date should be updated", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Detail_Reg_Submit");
			llAction.waitUntilLoadingCompletes();
			dashboard.writeResults();
			llAction.clickElement("web_uw_btn_UWSPExit");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_ConsentCancel");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

}
