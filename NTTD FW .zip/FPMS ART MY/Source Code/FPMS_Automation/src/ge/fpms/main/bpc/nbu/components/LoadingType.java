package ge.fpms.main.bpc.nbu.components;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;

import ge.fpms.main.actions.FPMS_Actions;

public class LoadingType{	
	
	private static FPMS_Actions llAction = new FPMS_Actions();

	public static void enterSpecificLoadingType(String loadingTable, String loadingBlock, String loadingType, Hashtable<String, String> hParams) throws Exception {
		
		switch(loadingType) {
		case "1":
			Utils.editXpath("web_uw_txt_loadingType", "web_uw_txt_loadingType1", new String[] {loadingTable, loadingBlock});
			llAction.enterValue("web_uw_txt_loadingType1", "1");
			llAction.sendkeyStroke("web_uw_txt_loadingType1", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_txt_LoadingTypeExtraParaDummy", "web_txt_LoadingType1ExtraParaDummy", new String[] { loadingTable, loadingBlock });
			llAction.enterValue("web_txt_LoadingType1ExtraParaDummy", hParams.get("AmountOrTimes"));
			break;
		case "2":
			Utils.editXpath("web_uw_txt_loadingType", "web_uw_txt_loadingType2", new String[] {loadingTable, loadingBlock});
			llAction.enterValue("web_uw_txt_loadingType2", "2");
			llAction.sendkeyStroke("web_uw_txt_loadingType2", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_txt_LoadingTypeExtraParaDummy", "web_txt_LoadingType2ExtraParaDummy", new String[] { loadingTable, loadingBlock });
			llAction.enterValue("web_txt_LoadingType2ExtraParaDummy", hParams.get("AmountOrTimes"));
			break;
		case "3":
			Utils.editXpath("web_uw_txt_loadingType", "web_uw_txt_loadingType3", new String[] {loadingTable, loadingBlock});
			llAction.enterValue("web_uw_txt_loadingType3", "3");
			llAction.sendkeyStroke("web_uw_txt_loadingType3", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_txt_LoadingTypeExtraParaDummy", "web_txt_LoadingTypeExtraParaDummy3", new String[] { loadingTable, loadingBlock });
			llAction.enterValue("web_txt_LoadingTypeExtraParaDummy3", hParams.get("AmountOrTimes"));
			break;
		case "4":
			Utils.editXpath("web_uw_txt_loadingType", "web_uw_txt_loadingType4", new String[] {loadingTable, loadingBlock});
			llAction.enterValue("web_uw_txt_loadingType4", "4");
			llAction.sendkeyStroke("web_uw_txt_loadingType4", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_txt_LoadingTypeExtraParaDummy", "web_txt_LoadingType4ExtraParaDummy", new String[] { loadingTable, loadingBlock });
			llAction.enterValue("web_txt_LoadingType4ExtraParaDummy", hParams.get("AmountOrTimes"));
			break;
		case "5":
			Utils.editXpath("web_uw_txt_loadingType", "web_uw_txt_loadingType5", new String[] {loadingTable, loadingBlock});
			llAction.enterValue("web_uw_txt_loadingType5", "5");
			llAction.sendkeyStroke("web_uw_txt_loadingType5", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			break;
		case "6":
			Utils.editXpath("web_uw_txt_loadingType", "web_uw_txt_loadingType6", new String[] {loadingTable, loadingBlock});
			llAction.enterValue("web_uw_txt_loadingType6", "6");
			llAction.sendkeyStroke("web_uw_txt_loadingType6", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_txt_LoadingTypeExtraParaDummy", "web_txt_LoadingType6ExtraParaDummy", new String[] { loadingTable, loadingBlock });
			llAction.enterValue("web_txt_LoadingType6ExtraParaDummy", hParams.get("AmountOrTimes"));
			break;
		case "7":
			Utils.editXpath("web_uw_txt_loadingType", "web_uw_txt_loadingType7", new String[] {loadingTable, loadingBlock});
			llAction.enterValue("web_uw_txt_loadingType7", "7");
			llAction.sendkeyStroke("web_uw_txt_loadingType7", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_txt_LoadingTypeExtraParaDummy", "web_txt_LoadingType7ExtraParaDummy", new String[] { loadingTable, loadingBlock });
			llAction.enterValue("web_txt_LoadingType7ExtraParaDummy", hParams.get("AmountOrTimes"));
			break;
		}
	}
	
}
