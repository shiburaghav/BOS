package ge.fpms.main.bpc.nbu;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.components.BenefitsComponent;
import ge.fpms.main.bpc.nbu.components.Payment;

public class DetailRegistrationComponent extends Registration {
	private static final String SEARCH_PARTY = "Search";
	private static final String CREATE_PARTY = "Create";
	private static final String MULTIPLE_PARTY = "Multiple";
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;

	public DetailRegistrationComponent() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();

	}

	public void DetailRegistration(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("NBD", "Detail Registration");
			searchPolicy(hParams.get("PolicyNo"), "web_detail_tbl_PolicyList", "web_txt_DetailReg_PolicyNumber");
			llAction.switchtoFrame(1);

			llAction.waitUntilLoadingCompletes();

			addBasicInfo(hParams);
			updateProposerInformation(hParams);
			Utils.sleep(3);
			llAction.switchtoDefaultWindow();

			updateLAInformation(hParams);
			Utils.sleep(3);
			llAction.switchtoDefaultWindow();
			llAction.switchtoFrame(1);

			Payment payment = new Payment();
			payment.addPayment(hParams);

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);

			// addDirectCreditInformation(hParams);
			// llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			// llAction.switchtoFrame(1);

			llAction.clickElementJs("web_link_Benefit");
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_PRODUCT_INFO, "");
			llAction.maximizeWindow();
			BenefitsComponent benefitsComp = new BenefitsComponent();
			benefitsComp.addBenefits(hParams);
			llAction.switchtoDefaultWindow();
			llAction.switchtoFrame(1);

			if (Integer.parseInt(hParams.get("NoOfRiders")) > 0 && !StringUtils.isEmpty(hParams.get("NoOfRiders"))) {
				benefitsComp = new BenefitsComponent();
				benefitsComp.addRiderDetails(hParams);
				llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
				llAction.switchtoFrame(1);
			}

			if (Integer.parseInt(hParams.get("NoOfWaivers")) > 0 && !StringUtils.isEmpty(hParams.get("NoOfWaivers"))) {
				benefitsComp = new BenefitsComponent();
				benefitsComp.addWaiverDetails(hParams);
				llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
				llAction.switchtoFrame(1);
			}
			
			handleBaseQuestion(hParams, "insured_list");

			if (hParams.get("AddNominee").equalsIgnoreCase("Y")) {
				addAllNominee(hParams);
				updateAddressInformation("beneficiary_list");
			}
			if (hParams.get("AddTrustee").equalsIgnoreCase("Y")) {
				addAllTrustee(hParams);
				updateAddressInformation("trustee_list");
			}
			if (hParams.get("AddBeneficialOwner").equalsIgnoreCase("Y")) {
				addAllBeneficialOwners(hParams);
				updateAddressInformation("bene_owner_list");
			}
			if (hParams.get("AddCPAS").equalsIgnoreCase("Y")) {
				addAllConnectedParty(hParams);
				updateAddressInformation("connPartyAndAuthSign_list");
			}
			if (hParams.get("ROPApplicable").equalsIgnoreCase("Y")) {
				editROP(hParams);
				llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
				llAction.switchtoFrame(1);
			}

			// llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			// llAction.switchtoFrame(1);
			llAction.clearText("web_txt_pendingCause");
			llAction.enterValue("web_txt_pendingCause", hParams.get("PendingReason"));

			llAction.enterValue("web_dr_txt_verifcation", hParams.get("Verification_Ind"));
			dashboard.setStepDetails("Validate if Yes\\No is Entered for Verfication",
					"Value should be entered as per testdata", hParams.get("Verification_Ind"));
			dashboard.writeResults();
			llAction.clickElementJs("web_btn_Detail_Reg_Submit");

			llAction.handleMultipleAlerts((long) 5);

			llAction.waitUntilLoadingCompletes();
			llAction.clickElementJs("web_btn_Detail_Reg_Exit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Submit and Exit", "User should be navigated to Home Page", "");
			dashboard.writeResults();
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void updateProposerInformation(Hashtable<String, String> hParams) throws Exception {

		addAdress();

		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
		llAction.switchtoFrame(1);
		llAction.clickElement("web_lnk_CRS_ViewEdit_Proposer");
		llAction.handleCertificateErrors();
		llAction.switchtoSecondWindow();
		addCrsInfo(hParams);
	}

	private void addNominee(String partyNumberId, String partyType, String partyName, String relationShipWithLA,
			String sharePercent) throws Exception {
		try {
			llAction.clickElement("web_btn_nomineeAdd");
			Utils.sleep(4);
			llAction.handleCertificateErrors();
			searchParty(FPMSConstants.WINDOW_TITLE_NOMINEE, partyNumberId, partyType, partyName);
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_EX_CUSTOMER_INFORMATION);
			Utils.editXpath("web_radio_selectExistingParty", "web_radio_selectNominee",
					new String[] { partyName.toUpperCase() });
			llAction.clickElement("web_radio_selectNominee");
			llAction.clickElement("web_btn_PartySubmit");
			Utils.sleep(5);

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_NOMINEE);
			llAction.maximizeWindow();
			llAction.enterValue("web_txt_sharePercent", sharePercent);
			llAction.sendkeyStroke("web_txt_sharePercent", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_Relationship_otherRoles", relationShipWithLA);
			llAction.sendkeyStroke("web_txt_Relationship_otherRoles", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_mySubmit");
			Utils.sleep(10);
			if (llAction.getNoOfActiveWindows() > 1) {
				if (llAction.isDisplayed("web_btn_continue", 5)) {
					llAction.clickElement("web_btn_continue");
				}
			}
			llAction.switchtoDefaultWindow();
			llAction.switchtoFrame(1);
			dashboard.setStepDetails("Enter Nominee information ",
					"The required information of Nominee should be entered. ", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void addAllNominee(Hashtable<String, String> hParams) throws Exception {

		String nomineePartyIndicator = hParams.get("NomineePartyInd");
		String[] allNomineePartyIds = hParams.get("NomineePartyIds").split(FPMSConstants.COMMA_SEPERATOR);
		String[] nomineePartyType = hParams.get("NomineePartyIDType").split(FPMSConstants.COMMA_SEPERATOR);
		String[] nomineePartyId = hParams.get("NomineePartyIDNumber").split(FPMSConstants.COMMA_SEPERATOR);
		String[] nomineePartyName = hParams.get("NomineePartyName").split(FPMSConstants.COMMA_SEPERATOR);
		String[] relationship = hParams.get("RelationshipwithLifeAssured").split(FPMSConstants.COMMA_SEPERATOR);
		String[] sharePercent = hParams.get("SharePercent").split(FPMSConstants.COMMA_SEPERATOR);

		if (nomineePartyIndicator.equalsIgnoreCase(CREATE_PARTY)) {
			for (String partyId : allNomineePartyIds) {
				createParty(partyId);
			}
		} else if (nomineePartyIndicator.equalsIgnoreCase(SEARCH_PARTY)) {

			for (int i = 0; i < relationship.length; i++) {
				String id = policyHandler.getPolicy().getNomineeId(i);
				if (StringUtils.isEmpty(id)) {
					policyHandler.getPolicy().setNominee(nomineePartyId[i], nomineePartyName[i]);
					id = nomineePartyId[i];
				}

				addNominee(id, nomineePartyType[i], policyHandler.getPolicy().getNomineeName(id), relationship[i],
						sharePercent[i]);
			}

		} else if (nomineePartyIndicator.equalsIgnoreCase(MULTIPLE_PARTY)) {
			int i = 0;
			for (String partyId : allNomineePartyIds) {

				if (StringUtils.isEmpty(partyId)) {
					addNominee(nomineePartyId[i], nomineePartyType[i], nomineePartyName[i], relationship[i],
							sharePercent[i]);
				} else {
					createParty(partyId);
				}

			}
		}
	}

	private void addBeneficialOwner(String partyNumberId, String partyType, String partyName,
			String relationShipWithProposer) throws Exception {
		try {
			llAction.clickElement("web_btn_beneficialOwnerAdd");
			Utils.sleep(4);
			llAction.handleCertificateErrors();
			searchParty(FPMSConstants.WINDOW_TITLE_BENEFICIAL_OWNER, partyNumberId, partyType, partyName);
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_EX_CUSTOMER_INFORMATION);
			Utils.editXpath("web_radio_selectExistingParty", "web_radio_selectBeneficiary",
					new String[] { partyName.toUpperCase() });
			llAction.clickElement("web_radio_selectBeneficiary");
			llAction.clickElementJs("web_btn_PartySubmit");
			Utils.sleep(5);
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_BENEFICIAL_OWNER);
			llAction.enterValue("web_txt_Relationship_otherRoles", relationShipWithProposer);
			llAction.sendkeyStroke("web_txt_Relationship_otherRoles", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			llAction.clickElementJs("web_btn_mySubmit");
			Utils.sleep(10);
			if (llAction.getNoOfActiveWindows() > 1) {
				if (llAction.isDisplayed("web_btn_continue", 5)) {
					llAction.clickElement("web_btn_continue");
				}
			}
			llAction.switchtoDefaultWindow();
			llAction.switchtoFrame(1);
			dashboard.setStepDetails("Enter Beneficial Owner information ",
					"The required information of Beneficial Owner should be entered. ", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void addAllBeneficialOwners(Hashtable<String, String> hParams) throws Exception {
		String boPartyIndicator = hParams.get("BOPartyInd");
		String[] allboPartyIds = hParams.get("BOPartyIds").split(FPMSConstants.COMMA_SEPERATOR);
		String[] boPartyType = hParams.get("BOPartyIDType").split(FPMSConstants.COMMA_SEPERATOR);
		String[] boPartyId = hParams.get("BOPartyIDNumber").split(FPMSConstants.COMMA_SEPERATOR);
		String[] boPartyName = hParams.get("BOPartyName").split(FPMSConstants.COMMA_SEPERATOR);
		String[] relationship = hParams.get("BORelationshipwithProposer").split(FPMSConstants.COMMA_SEPERATOR);
		if (boPartyIndicator.equalsIgnoreCase(CREATE_PARTY)) {
			for (String partyId : allboPartyIds) {
				createParty(partyId);
			}
		} else if (boPartyIndicator.equalsIgnoreCase(SEARCH_PARTY)) {

			for (int i = 0; i < relationship.length; i++) {
				String id = policyHandler.getPolicy().getBeneficialOwnerId(i);
				if (StringUtils.isEmpty(id)) {
					policyHandler.getPolicy().setBeneficialOwner(boPartyId[i], boPartyName[i]);
					id = boPartyId[i];
				}

				addBeneficialOwner(id, boPartyType[i], policyHandler.getPolicy().getBeneficialOwnerName(id),
						relationship[i]);
			}

		} else if (boPartyIndicator.equalsIgnoreCase(MULTIPLE_PARTY)) {
			int i = 0;
			for (String partyId : allboPartyIds) {

				if (StringUtils.isEmpty(partyId)) {
					addBeneficialOwner(boPartyId[i], boPartyType[i], boPartyName[i], relationship[i]);
				} else {
					createParty(partyId);
				}

			}
		}
	}

	private void addTrustee(String partyNumberId, String partyType, String partyName) throws Exception {
		try {
			llAction.clickElement("web_btn_trusteeAdd");
			Utils.sleep(4);
			llAction.handleCertificateErrors();
			searchParty(FPMSConstants.WINDOW_TITLE_TRUSTEE, partyNumberId, partyType, partyName);
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_EX_CUSTOMER_INFORMATION);
			Utils.editXpath("web_radio_selectExistingParty", "web_radio_selectTurstee",
					new String[] { partyName.toUpperCase() });
			llAction.clickElement("web_radio_selectTurstee");
			llAction.clickElementJs("web_btn_PartySubmit");
			Utils.sleep(5);
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_TRUSTEE);
			llAction.clickElementJs("web_btn_mySubmit");
			Utils.sleep(10);
			if (llAction.getNoOfActiveWindows() > 1) {
				if (llAction.isDisplayed("web_btn_continue", 5)) {
					llAction.clickElement("web_btn_continue");
				}
			}
			llAction.switchtoDefaultWindow();
			llAction.switchtoFrame(1);
			dashboard.setStepDetails("Enter Trustee information ",
					"The required information of Trustee should be entered. ", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void addAllTrustee(Hashtable<String, String> hParams) throws Exception {

		String trusteePartyIndicator = hParams.get("TrusteePartyInd");
		String[] alltrusteePartyIds = hParams.get("TrusteePartyIds").split(FPMSConstants.COMMA_SEPERATOR);
		String[] trusteePartyType = hParams.get("TrusteePartyIDType").split(FPMSConstants.COMMA_SEPERATOR);
		String[] trusteePartyId = hParams.get("TrusteePartyIDNumber").split(FPMSConstants.COMMA_SEPERATOR);
		String[] trusteePartyName = hParams.get("TrusteePartyName").split(FPMSConstants.COMMA_SEPERATOR);
		// String [] relationship =
		// hParams.get("BORelationshipwithProposer").split(FPMSConstants.COMMA_SEPERATOR);
		if (trusteePartyIndicator.equalsIgnoreCase(CREATE_PARTY)) {
			for (String partyId : alltrusteePartyIds) {
				createParty(partyId);
			}
		} else if (trusteePartyIndicator.equalsIgnoreCase(SEARCH_PARTY)) {
			for (int i = 0; i < trusteePartyName.length; i++) {

				String id = policyHandler.getPolicy().getTrusteeId(i);

				if (StringUtils.isEmpty(id)) {
					policyHandler.getPolicy().setTrustee(trusteePartyId[i], trusteePartyName[i]);
					id = trusteePartyId[i];
				}

				addTrustee(id, trusteePartyType[i], policyHandler.getPolicy().getTrusteeName(id));
			}

		} else if (trusteePartyIndicator.equalsIgnoreCase(MULTIPLE_PARTY)) {
			int i = 0;
			for (String partyId : alltrusteePartyIds) {

				if (StringUtils.isEmpty(partyId)) {
					addTrustee(trusteePartyId[i], trusteePartyType[i], trusteePartyName[i]);
				} else {
					createParty(partyId);
				}

			}
		}

	}

	public void editROP(Hashtable<String, String> hParams) throws Exception {
		try {
			
			String tblElementKey = "web_lnk_LA";

			String[] policyNumber = hParams.get("ROPPolicyNumber").split(FPMSConstants.COMMA_SEPERATOR);
			String[] policyStatus = hParams.get("ROPPolicyStatus").split(FPMSConstants.COMMA_SEPERATOR);
			String[] indicator = hParams.get("ROPIndicator").split(FPMSConstants.COMMA_SEPERATOR);
			String[] type = hParams.get("ROPType").split(FPMSConstants.COMMA_SEPERATOR);
			String[] source = hParams.get("ROPSource").split(FPMSConstants.COMMA_SEPERATOR);
			String[] remarks = hParams.get("ROPRemarks").split(FPMSConstants.COMMA_SEPERATOR);
			String[] formCodesList = hParams.get("FormCodeList").split(FPMSConstants.COMMA_SEPERATOR);

			llAction.clickElement("web_btn_Edit_ROP");
			llAction.handleCertificateErrors();
			String windowName = FPMSConstants.WINDOW_TITLE_ROP;
			llAction.switchtoChildWindow(windowName, "");
			llAction.maximizeWindow();
			llAction.selectByVisibleText("web_lst_ROP_Applicable", hParams.get("ROPApplicable"));
			int PolicyNumberCol = llAction.GetColumnPositionInTable("web_tbl_ROP", "Policy Number");
			int PolicyStatusCol = llAction.GetColumnPositionInTable("web_tbl_ROP", "Policy Status");
			int ROPIndicatorCol = llAction.GetColumnPositionInTable("web_tbl_ROP", "ROP Indicator");
			int ROPTypeCol = llAction.GetColumnPositionInTable("web_tbl_ROP", "ROP Type");
			int SourceCol = llAction.GetColumnPositionInTable("web_tbl_ROP", "Source");
			int RemarksCol = llAction.GetColumnPositionInTable("web_tbl_ROP", "Remarks");

			for (int i = 0; i < policyNumber.length; i++) {
				llAction.enterTextInTable("web_tbl_ROP", i + 2, PolicyNumberCol, policyNumber[i], "/input");
				llAction.enterTextInTable("web_tbl_ROP", i + 2, PolicyStatusCol, policyStatus[i], "/select");
				llAction.enterTextInTable("web_tbl_ROP", i + 2, ROPIndicatorCol, indicator[i], "/select");
				llAction.enterTextInTable("web_tbl_ROP", i + 2, ROPTypeCol, type[i], "/select");
				llAction.enterTextInTable("web_tbl_ROP", i + 2, SourceCol, source[i], "/select");
				llAction.enterTextInTable("web_tbl_ROP", i + 2, RemarksCol, remarks[i], "/input");

				if (i < policyNumber.length - 1)
					llAction.clickElement("web_btn_ROP_Add");

			}
			llAction.clickElement("web_btn_DataEntry_Submit");
			// llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Enter ROP information ", "The required information of ROP should be entered. ",
					"N/A");
			dashboard.writeResults();
			// llAction.closeWindow(FPMSConstants.WINDOW_TITLE_ROP);
			llAction.switchtoDefaultWindow();
			llAction.switchtoFrame(1);
			
			int declarationDetailColPos = llAction.GetColumnPositionInTable(tblElementKey, "Address");
			int rowCount = llAction.getRowCountInTable(tblElementKey);
			for (int i = 2; i <= rowCount; i++) {
				llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
				llAction.switchtoFrame(1);
				String text = llAction.GetTextFromTable(tblElementKey, i, declarationDetailColPos, "/a");
				if (text.equalsIgnoreCase("N")) {
					llAction.SelectRowInTable(tblElementKey, i, declarationDetailColPos, "a");
					llAction.handleCertificateErrors();
					llAction.waitUntilLoadingCompletes();
					llAction.switchtoChildWindow("Declaration Information");
					llAction.maximizeWindow();
					
					Utils.editXpath("web_dr_chkBx_DeclarationInd", "web_dr_chkBx_CSTPSpecialRemarks", new String[] { "CSTP Special Remarks" });
					llAction.checkBox_Check("web_dr_chkBx_CSTPSpecialRemarks");
					
					Utils.editXpath("web_dr_chkBx_DeclarationInd", "web_dr_chkBx_MissingCompulsoryForms", new String[] { "Missing Compulsory Forms" });
					llAction.checkBox_Check("web_dr_chkBx_MissingCompulsoryForms");
					
					for(int j = 0; j < formCodesList.length; j++) {
						llAction.clickElement("web_dr_btn_AddFormCode");
						int colPos = llAction.GetColumnPositionInTable("web_dr_tbl_formCode", "Form Code");
						llAction.enterTextInTable("web_dr_tbl_formCode", j+2, colPos, formCodesList[i], "/span/select");
					}
					llAction.clickElement("web_dr_btn_SubmitDeclarativeDetail");
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
					llAction.switchtoFrame(1);
				}
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	@Deprecated
	private void addProposerInformation(Hashtable<String, String> hParams) throws Exception {

		llAction.clickElement("web_lnk_Poposer_ProposerName");

		llAction.handleCertificateErrors();
		String windowName = FPMSConstants.WINDOW_TITLE_IDV_PROPOSER_INFOMATION;
		if (isOrganization(hParams.get("CompanyInd"))) {
			windowName = FPMSConstants.WINDOW_TITLE_COMPANY_PROPOSAL_INFORMATION;
		}
		llAction.switchtoChildWindow(windowName, "");
		llAction.maximizeWindow();

		dashboard.setStepDetails("Enter Proposer information ",
				"The required information of Proposer should be entered. ", "N/A");
		dashboard.writeResults();

		llAction.clickElement("web_btn_mySubmit");

		Utils.sleep(5);

		llAction.closeWindow(windowName);

	}

	public void addCrsInfo(Hashtable<String, String> hParams, boolean isProposer) throws Exception {
		try {
			// if(!StringUtils.isEmpty(hParams.get("SelfCertDate"))){

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			String elementName = isProposer ? "web_lnk_CRS_ViewEdit_Proposer" : "web_lnk_CRS_ViewEdit_LA";
			llAction.clickElement(elementName);
			llAction.handleCertificateErrors();

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CRS, "");
			llAction.maximizeWindow();
			Utils.sleep(2);
			if (!llAction.isDisplayed("web_txt_norecords")) {
				llAction.clickElement("web_radio_crsSelector");
				// llAction.enterValue("web_txt_CRS_SelfCertDate", hParams.get("SelfCertDate"));
				dashboard.setStepDetails("Enter CRS information ",
						"The required information of CRS should be entered. ", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_addr_btn_submit");
			} else {
				llAction.clickElement("web_btn_crs_exit");
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void addCrsInfo(Hashtable<String, String> hParams) throws Exception {
		try {

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CRS, "");
			llAction.maximizeWindow();
			Utils.sleep(2);
			if (llAction.isDisplayed("web_txt_norecords", 5)) {
				llAction.clickElement("web_radio_crsSelector");
				dashboard.setStepDetails("Enter CRS information ",
						"The required information of CRS should be entered. ", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_addr_btn_submit");
			} else {
				llAction.clickElement("web_btn_crs_exit");
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void addLAInformation(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			llAction.clickElementJs("web_lnk_lifeAssuredName");

			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_LA_INFORMATION, "");
			llAction.maximizeWindow();
			Utils.sleep(3);

			dashboard.setStepDetails("Enter Life insured information ",
					"The required information of life insured should be entered. ", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_la_Submit");
			Utils.sleep(5);
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void addDirectCreditInformation(Hashtable<String, String> hParams) throws Exception {

		try {

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);

			llAction.clickElement("web_lnk_DirectCredit");

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DIRECT_CREDIT, "");
			llAction.maximizeWindow();

			llAction.enterValue("web_txt_BankAcNo", "29356000");
			llAction.enterValue("web_txt_BranchCode", "1980");
			dashboard.setStepDetails("Enter Direct Credit", "Direct Credit Information has been entered. ", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_Save");

		} catch (Exception ex) {
			DashboardProperties.gBPCStatus = 1; // set the business component
			// status to fail
			// LOGGER.log(Level.SEVERE,
			// "Exception occured while calling Detail Reg method \n Exception is " +
			// ex.getMessage());
			throw new BPCException("");
		}

	}

	@Deprecated
	public void addBenefits(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			llAction.clickElementJs("web_link_Benefit");

			llAction.handleCertificateErrors();

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_PRODUCT_INFO, "");

			llAction.maximizeWindow();

			// llAction.returnWebElement(webElementKey)

			llAction.enterValue("web_txt_CoverageYr", hParams.get("CoverageTerm"));
			llAction.enterValue("web_txt_PremiumTrm", hParams.get("PremiumTerm"));

			// llAction.enterValue("web_txt_MarketingDiscount", "");

			String s = llAction.getAttribute("web_txt_vl_PcalMthd", "value");
			if (s.equalsIgnoreCase("1")) {
				llAction.enterValue("web_txt_SumAssured", hParams.get("BasicSumAssured"));
			} else {
				llAction.enterValue("web_txt_PremiumAmt", hParams.get("PremiumAmount"));
			}
			dashboard.setStepDetails("Enter Benefit Details", "Benefit Details Information has been entered. ", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_saveBn");

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void addAdress() throws Exception {
		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
		llAction.switchtoFrame(1);
		String addressLnk = "web_addr_lnk_proposer";
		String s = llAction.getText(addressLnk);
		if (s.equalsIgnoreCase("N")) {
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			llAction.scrollToElement(llAction.getElement("web_addr_table_proposer"));
			Utils.sleep(3);
			llAction.clickElementJs(addressLnk);
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CORRESPONDENCE_ADDRESS, "");
			llAction.maximizeWindow();
			llAction.clickElement("web_Radio_AddressRecNumber");
			// llAction.selectByVisibleText("web_addr_lst_CountryofAddress",
			// hParams.get("CountryCode"));
			// llAction.clickElement("web_addr_btn_apply");
			Utils.sleep(2);
			dashboard.setStepDetails("Address is entered", "Adress should be added Successfully", "N/A");
			dashboard.writeResults();
			// Address ov = new Address();
			// ov.createAddressComponent(hParams);
			llAction.clickElement("web_addr_btn_submit");
		}
	}

	private void updateLAInformation(Hashtable<String, String> hParams) throws BPCException {

		String tblElementKey = "web_lnk_LA";

		try {
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			int addressColPos = llAction.GetColumnPositionInTable(tblElementKey, "Address");
			int crsColPos = llAction.GetColumnPositionInTable(tblElementKey, "CRS Info");
			int rowCount = llAction.getRowCountInTable(tblElementKey);
			for (int i = 2; i <= rowCount; i++) {
				llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
				llAction.switchtoFrame(1);
				String text = llAction.GetTextFromTable(tblElementKey, i, addressColPos, "/a");
				
				if (text.equalsIgnoreCase("N")) {
					llAction.handleCertificateErrors();
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
					llAction.switchtoFrame(1);
					// llAction.scrollToElement(llAction.getElement("web_addr_table_proposer")); NOT
					// SURE IF REQUIRED
					// Utils.sleep(3);
					llAction.SelectRowInTable(tblElementKey, i, addressColPos, "a");
					llAction.handleCertificateErrors();
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CORRESPONDENCE_ADDRESS, "");
					llAction.maximizeWindow();
					llAction.clickElement("web_Radio_AddressRecNumber");
					Utils.sleep(2);
					dashboard.setStepDetails("Address is entered", "Adress should be added Successfully", "N/A");
					dashboard.writeResults();
					llAction.clickElement("web_addr_btn_submit");
					Utils.sleep(5);
					
				}
				// CRS - VIEW/EDIT
				llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
				llAction.switchtoFrame(1);
				llAction.SelectRowInTable(tblElementKey, i, crsColPos, "a");
				llAction.handleCertificateErrors();
				addCrsInfo(hParams);
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void SubmitForVerification(Hashtable<String, String> hParams) throws Exception {
		try {

			if (hParams.get("Verification_Ind").equalsIgnoreCase("Y")) {
				llAction = new FPMS_Actions();
				llAction.selectMenuItem("NBD", "Verification");

				llAction.waitUntilLoadingCompletes();
				/*
				 * llAction.enterValue("web_txt_Verification_PolicyNo",
				 * hParams.get("PolicyNo")); llAction.waitUntilLoadingCompletes();
				 * llAction.clickElement("web_btn_Verification_Search");
				 * llAction.waitUntilLoadingCompletes();
				 * dashboard.setStepDetails("Policy Number is entered",
				 * "Policy Number should be searched Successfully", "N/A");
				 * dashboard.writeResults();
				 * 
				 * llAction.clickElementJs("web_btn_Verification_PolicyNo");
				 * llAction.waitUntilLoadingCompletes();
				 */

				searchPolicy(hParams.get("PolicyNo"), "web_tbl_Src_Policy");
				// Utils.sleep(5);
				// llAction.switchtoFrame(1);
				llAction.switchtoFrame("Xpath", "web_btn_Verification_VerificationFrame");
				dashboard.setStepDetails("Policy details are displayed",
						"Policy details should be displayed Successfully", "N/A");
				dashboard.writeResults();
				llAction.clickElementJs("web_btn_Verification_Submit");
				dashboard.setStepDetails("Policy is verified successfully", "Policy should be verified Successfully",
						"N/A");
				dashboard.writeResults();
				String url = llAction.getCurrentURL();
				while (!url.toLowerCase().contains("queryproofingpool.do")) {
					Utils.sleep(5);
					url = llAction.getCurrentURL();
				}
				llAction.clickElement("web_btn_Verification_Exit");
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void deleteAllFundCodes() throws Exception {
		try {
			if (llAction.isDisplayed("web_chkBox_fundCodes", 5)) {
				Hashtable<String, String> hMap = ARTProperties.guiMap.get("web_chkBox_fundCodes");
				String temp = hMap.get(hMap.keySet().toArray()[0]);
				List<WebElement> chkBoxFundCodes = llAction.findElementsByXpath(temp);
				for (WebElement chkBoxFundCode : chkBoxFundCodes) {
					if (!chkBoxFundCode.isSelected()) {
						chkBoxFundCode.click();
					}
				}
				llAction.clickElement("web_btn_deleteFunds");
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void investmentStrategy(Hashtable<String, String> hParams) throws Exception {
		try {
			String[] fundCodes = hParams.get("FundCodes").split(FPMSConstants.COMMA_SEPERATOR);
			String[] addYearFrom = hParams.get("PolicyYearFrom").split(FPMSConstants.COMMA_SEPERATOR);
			String[] addYearTo = hParams.get("PolicyYearTo").split(FPMSConstants.COMMA_SEPERATOR);
			String[] fundsPercentage1 = hParams.get("FundsPercentage1").split(FPMSConstants.COMMA_SEPERATOR);
			String[] fundsPercentage2 = hParams.get("FundsPercentage2").split(FPMSConstants.COMMA_SEPERATOR);
			List<WebElement> fundCodesTxtBoxes1 = new ArrayList<WebElement>();
			List<WebElement> fundCodesTxtBoxes2 = new ArrayList<WebElement>();

			deleteAllFundCodes();
			llAction.clickElement("web_btn_investmentStrategy");
			llAction.waitUntilLoadingCompletes();
			if (Integer.parseInt(hParams.get("InvestmentStrategyCode")) != 7) {
				llAction.enterValue("web_txt_investstrategycode", hParams.get("InvestmentStrategyCode"));
				llAction.clickElement("web_btn_Verification_Submit");
			} else {
				llAction.enterValue("web_txt_investstrategycode", hParams.get("InvestmentStrategyCode"));
				llAction.sendkeyStroke("web_txt_investstrategycode", Keys.ENTER);
				for (int i = 0; i < fundCodes.length; i++) {
					Utils.editXpath("web_tbl_selectFund", "web_tbl_selectFund" + fundCodes[i] + "",
							new String[] { (fundCodes[i]) });
					llAction.clickElement("web_tbl_selectFund" + fundCodes[i] + "");
				}
				llAction.clickElement("web_btn_Select");
				llAction.waitUntilLoadingCompletes();

				for (int i = 1; i < addYearFrom.length; i++) {
					llAction.clickElement("web_btn_addYear");
				}

				for (int i = 0; i < addYearFrom.length; i++) {
					Utils.editXpath("web_txt_fromYear", "web_txt_fromYear" + (i + 1) + "",
							new String[] { Integer.toString(i + 2) });
					llAction.enterValue("web_txt_fromYear" + (i + 1) + "", addYearFrom[i]);
				}

				for (int i = 0; i < addYearTo.length; i++) {
					Utils.editXpath("web_txt_toYear", "web_txt_toYear" + (i + 1) + "",
							new String[] { Integer.toString(i + 2) });
					llAction.enterValue("web_txt_toYear" + (i + 1) + "", addYearTo[i]);
				}

				Utils.editXpath("web_txt_fundCodesEnterIS", "web_txt_fundCodesEnterIS1", new String[] { "2" });
				fundCodesTxtBoxes1 = llAction.findElements("web_txt_fundCodesEnterIS1");

				Utils.editXpath("web_txt_fundCodesEnterIS", "web_txt_fundCodesEnterIS2", new String[] { "3" });
				fundCodesTxtBoxes2 = llAction.findElements("web_txt_fundCodesEnterIS2");

				for (int i = 0; i < fundCodesTxtBoxes1.size(); i++) {
					fundCodesTxtBoxes1.get(i).clear();
					fundCodesTxtBoxes1.get(i).sendKeys(fundsPercentage1[i]);
				}

				for (int j = 0; j < fundCodesTxtBoxes2.size(); j++) {
					fundCodesTxtBoxes2.get(j).clear();
					fundCodesTxtBoxes2.get(j).sendKeys(fundsPercentage2[j]);
				}

			}
			llAction.clickElement("web_btn_PartySubmit");

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void addBaseQuestionInfo(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.switchtoChildWindow(FPMSConstants.BASE_QUESTION_PROPOSAL_FORM, "");
			llAction.maximizeWindow();
			Utils.sleep(2);
			llAction.selectByVisibleText("web_lst_ProposalFormType", hParams.get("DE_ProposalFormType"));
			Utils.sleep(2);
			dashboard.setStepDetails("Enter Base Question information ",
					"The required information of Base Question should be entered. ", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_ProposalformSubmit");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			Utils.sleep(5);

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void addBasicInfo(Hashtable<String, String> hParams) throws Exception {

		try {

			llAction.enterValue("web_txt_submissionDate", hParams.get("DE_SubmissionDateFrom"));
			llAction.enterValue("web_txt_proposalDate", hParams.get("DE_ProposalDate"));
			llAction.enterValue("web_txt_commenceDate", hParams.get("DE_CommencementDate"));
			llAction.enterValue("web_txt_iacNo", hParams.get("DE_IACNo"));
			llAction.enterValue("web_txt_originCode", hParams.get("DE_OriginCode"));
			llAction.enterValue("web_txt_maturityRetInd", hParams.get("DE_MaturityRetainedInd"));
			llAction.enterValue("web_txt_dispatchType", hParams.get("DE_DespatchType"));
			llAction.enterValue("web_txt_currency", hParams.get("DE_Currency"));
			// Added to enable Trustee button
			llAction.enterValue("web_txt_TrustPolicyInd", hParams.get("DE_TrustPolicyIND"));
			llAction.sendkeyStroke("web_txt_TrustPolicyInd", Keys.ENTER);
			llAction.enterValue("web_txt_discountType", hParams.get("DE_DiscountType"));
			llAction.enterValue("web_txt_paymentFrequency", hParams.get("DE_PaymentFrequency"));
			llAction.enterValue("web_txt_Fact_Find_Ind", hParams.get("DE_FactFindINDLife"));
			llAction.enterValue("web_list_NBD_BI_IniPremiumAmt", hParams.get("DE_InitialPremiumAmount"));
			llAction.enterValue("web_txt_employerContri", hParams.get("DE_EmployerContribution"));
			llAction.enterValue("web_txt_ExpectedDueDate", hParams.get("DE_ExpectedDueDate"));
			llAction.sendkeyStroke("web_txt_ExpectedDueDate", Keys.ENTER);
			dashboard.setStepDetails("Enter Basic Information ", "The required information should be entered. ", "N/A");
			dashboard.writeResults();

		} catch (Exception e) {
			throw new BPCException(e);
		}

	}

	private void addConnectedParty(String partyNumberId, String partyType, String partyName, String relationShipWithCompany,
			String role, String controllingType) throws Exception {
		try {
			llAction.clickElement("web_btn_addConnParty");
			Utils.sleep(4);
			llAction.handleCertificateErrors();
			searchParty(FPMSConstants.ConnectedParties, partyNumberId, partyType, partyName);
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_EX_CUSTOMER_INFORMATION);
			Utils.editXpath("web_radio_selectExistingParty", "web_radio_selectConnParty",
					new String[] { partyName.toUpperCase() });
			llAction.clickElement("web_radio_selectConnParty");
			llAction.clickElement("web_btn_PartySubmit");
			Utils.sleep(5);

			llAction.switchtoChildWindow(FPMSConstants.ConnectedParties);
			llAction.maximizeWindow();
			llAction.enterValue("web_txt_relationshipWithComp", relationShipWithCompany);
			llAction.selectByVisibleText("web_ir_lst_connectedPartyRole", role);
			llAction.selectByVisibleText("web_ir_lst_connectedPartyControlling", controllingType);
			llAction.clickElement("web_btn_mySubmit");
			Utils.sleep(10);
			if (llAction.getNoOfActiveWindows() > 1) {
				if (llAction.isDisplayed("web_btn_continue", 5)) {
					llAction.clickElement("web_btn_continue");
				}
			}
			llAction.switchtoDefaultWindow();
			llAction.switchtoFrame(1);
			dashboard.setStepDetails("Enter Connected Party information ",
					"The required information of Connected Party should be entered. ", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void addAllConnectedParty(Hashtable<String, String> hParams) throws Exception {

		String connectedPartyIndicator = hParams.get("CPASPartyInd");
		String[] allConnectedPartyIds = hParams.get("CPASPartyIds").split(FPMSConstants.COMMA_SEPERATOR);
		String[] connectedPartyType = hParams.get("CPASPartyIDType").split(FPMSConstants.COMMA_SEPERATOR);
		String[] connectedPartyId = hParams.get("CPASPartyIDNumber").split(FPMSConstants.COMMA_SEPERATOR);
		String[] connectedPartyName = hParams.get("CPASPartyName").split(FPMSConstants.COMMA_SEPERATOR);
		String[] relationship = hParams.get("CPASRelationshipwithCompany").split(FPMSConstants.COMMA_SEPERATOR);
		String[] role = hParams.get("CPASRole").split(FPMSConstants.COMMA_SEPERATOR);
		String[] typeOfControlling = hParams.get("CPASTypeofcontrolling").split(FPMSConstants.COMMA_SEPERATOR);

		if (connectedPartyIndicator.equalsIgnoreCase(CREATE_PARTY)) {
			for (String partyId : allConnectedPartyIds) {
				createParty(partyId);
			}
		} else if (connectedPartyIndicator.equalsIgnoreCase(SEARCH_PARTY)) {

			for (int i = 0; i < relationship.length; i++) {
				String id = policyHandler.getPolicy().getConnectedPartyId(i);
				if (StringUtils.isEmpty(id)) {
					policyHandler.getPolicy().setConnectedParty(connectedPartyId[i], connectedPartyName[i]);
					id = connectedPartyId[i];
				}
				addConnectedParty(id, connectedPartyType[i], policyHandler.getPolicy().getConnectedPartyName(id), relationship[i],
						role[i], typeOfControlling[i]);
			}

		} else if (connectedPartyIndicator.equalsIgnoreCase(MULTIPLE_PARTY)) {
			int i = 0;
			for (String partyId : allConnectedPartyIds) {

				if (StringUtils.isEmpty(partyId)) {
					addConnectedParty(connectedPartyId[i], connectedPartyType[i], connectedPartyName[i], relationship[i],
							role[i], typeOfControlling[i]);
				} else {
					createParty(partyId);
				}
			}
		}
	}
	
	private void updateAddressInformation(String tableID) throws Exception {
		try {
			List<WebElement> elements = new ArrayList<WebElement>();
			Utils.editXpath("web_de_amendAddressLink", "web_de_amendAddressLink"+tableID+"", new String[]{ tableID });
			elements = llAction.findElements("web_de_amendAddressLink"+tableID+"");
			for(WebElement ele: elements) {
				if(ele.getText().equalsIgnoreCase("N")) {
					ele.click();
					llAction.handleCertificateErrors();
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CORRESPONDENCE_ADDRESS, "");
					llAction.maximizeWindow();
					llAction.clickElement("web_Radio_AddressRecNumber");
					Utils.sleep(2);
					dashboard.setStepDetails("Address is entered", "Adress should be added Successfully", "N/A");
					dashboard.writeResults();
					llAction.clickElement("web_addr_btn_submit");
					Utils.sleep(5);
					llAction.switchtoDefaultWindow();
					llAction.switchtoFrame(1);
				}
			}
		}catch(Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void handleBaseQuestion(Hashtable<String, String> hParams, String tableID) {
		try {
			List<WebElement> elements = new ArrayList<WebElement>();
			Utils.editXpath("web_de_amendBaseQuestionLink", "web_de_amendBaseQuestionLink"+tableID+"", new String[]{ tableID });
			elements = llAction.findElements("web_de_amendBaseQuestionLink"+tableID+"");
			for(WebElement ele: elements) {
				if(ele.getText().equalsIgnoreCase("N")) {
					ele.click();
					addBaseQuestionInfo(hParams);
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
					llAction.switchtoFrame(1);
				}
			}
		}catch(Exception ex) {
			throw new BPCException(ex);
		}
	}
}
