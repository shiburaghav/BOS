package ge.fpms.main.bpc.nbu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.components.AMLAdmin;
import ge.fpms.main.bpc.nbu.components.Loading;

/**
 * @author 010_MPG
 */
public class PerformUnderwriting extends BusinessComponent {
	FPMS_Actions llAction = new FPMS_Actions();
	DocumentManagement docMgt = new DocumentManagement();
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	AMLAdmin amlAdmin = new AMLAdmin();

	public PerformUnderwriting() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	public void Underwriting(Hashtable<String, String> hParams) throws Exception {
		try {
			// amlAdmin.authorisationHRCByPass(hParams);
			UnderwritingSearchPolicy(hParams);
			enterBasicInformation(hParams);

			String endorsementCode = hParams.get("EndorsementCode");
			String exclusionCode = hParams.get("ExclusionCode");
			String conditionCode = hParams.get("ConditionCode");
			String freeText = hParams.get("FreeText");
			String reviewPeriod = hParams.get("ReviewPeriod");

			if (hParams.get("AmendROP").equalsIgnoreCase("Y")) {
				editRop(hParams);
			}
			if (hParams.get("EnterFACRequest").equalsIgnoreCase("Y")) {
				applyFac(hParams);
			}
			if (hParams.get("EnterLIA").equalsIgnoreCase("Y")) {
				liaICD9RecordMaintainance(hParams);
			}

			if (!StringUtils.isEmpty(hParams.get("EndorsementCode"))) {
				enterCodes("ENDORSEMENT", endorsementCode, new Hashtable<String, String>());
			}

			if (!StringUtils.isEmpty(hParams.get("ConditionCode"))) {
				enterCodes("CONDITION", conditionCode, new Hashtable<String, String>());
			}

			if (!StringUtils.isEmpty(hParams.get("ExclusionCode"))) {
				Hashtable<String, String> hMap = new Hashtable<String, String>();
				String laName = hParams.get("LifeAssured");

				if (policyHandler.getPolicy().getAllLifeAssured().size() > 0) {
					laName = policyHandler.getPolicy().getLifeAssuredName("1");
				}
				hMap.put("LifeAssured", laName);
				hMap.put("ReviewPeriod", reviewPeriod);
				hMap.put("FreeText", freeText);
				enterCodes("EXCLUSION", exclusionCode, hMap);
			}
			String bypassRTwithCIFIND = hParams.get("BypassRTwithCIFIND");
			enterOrSelectText("Select", "web_uw_list_byPassRTCifIndi", bypassRTwithCIFIND);
			updateCRSFollowUpIndi(hParams.get("CRSIndiciaFollowUpIND"));

			MakeUnderwritingBenefitDecision(hParams);
			if(hParams.get("HandleSLQ").equalsIgnoreCase("Y")) {
				llAction.clickElement("web_uw_btn_PrepareQueryLetter");
				llAction.waitUntilLoadingCompletes();
				llAction.switchtoChildWindow("Certificate Error: Navigation Blocked");
				llAction.handleCertificateErrors();
				llAction.switchtoChildWindow("Search SLQ");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Click on Prepare Query Letter button Displayed on Underwriting Decision Page",
						"User should be Navigated to Search SLQ Page", "N/A");
				dashboard.writeResults();
				if (!llAction.isDisplayed("web_uw_tbl_UWSearchSLQDocListCheckAll", 5)) {
					createQueryLetter(hParams);
					performAction(hParams);
				}else {
					Utils.editXpath("web_uw_DocList_SelectQueryLetter", "web_uw_DocList_SLQLetter", new String[] { "Standard Letter of Query" });
					llAction.checkBox_Check("web_uw_DocList_SLQLetter");
					performAction(hParams);
				}
			}else {
				ExitToHomePage(hParams);
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Search a Policy in Underwriting Sharing Pool
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void UnderwritingSearchPolicy(Hashtable<String, String> hParams) throws Exception {
		String policyNumber = null;
		try {
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			llAction.selectMenuItem("NBD", "underwriting");
			llAction.clickElement("web_uw_txt_PolicyNo");
			llAction.enterValue("web_uw_txt_PolicyNo", policyNumber);
			Utils.sleep(5);
			llAction.clickElement("web_uw_btn_Search");
			llAction.waitUntilLoadingCompletes();
			llAction.move_to_element("web_uw_tbl_USPSearchPolicyList");
			System.out.println("PerformUnderwriting.UnderwritingSearchPolicy() policyNumber : " + policyNumber);

			int colPos = llAction.GetColumnPositionInTable("web_uw_tbl_USPSearchPolicyList", "Policy No.");
			int rowPos = llAction.GetRowPositionInTable("web_uw_tbl_USPSearchPolicyList", policyNumber, colPos);
			llAction.SelectRowInTable("web_uw_tbl_USPSearchPolicyList", rowPos, colPos, "a");

			llAction.waitUntilElementPresent("web_uw_check_UnderwritingOption_SelectAll");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("In Underwriting Sharing Pool Search for Policy Number  " + policyNumber,
					"The Policy Should be Available in Search Results. ", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Enter Basic Information on Underwriting Main Screen
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void enterBasicInformation(Hashtable<String, String> hParams) throws Exception {
		try {
			String commencementDate = hParams.get("CommencementDate");
			String riskCommencementDate = hParams.get("RiskCommencementDate");
			String paymentFrequency = hParams.get("PaymentFrequency");
			String discountType = hParams.get("DiscountType");
			String maximumallowablelimitperpolicy = hParams.get("Maximumallowablelimitperpolicy");
			String aPILPRemarks = hParams.get("APILPRemarks");
			String underwritingLoadingReason = hParams.get("UnderwritingLoadingReason");
			String underwritingComment = hParams.get("UnderwritingComment");

			String bypassRTwithCIFIND = hParams.get("BypassRTwithCIFIND");
			String consentGivenIND = hParams.get("ConsentGivenIND");
			String appealIND = hParams.get("AppealIND");
			String specialCommIND = hParams.get("SpecialCommIND");
			String manualEscalationIND = hParams.get("ManualEscalationIND");
			String underwriterExcalateTo = hParams.get("UnderwriterExcalateTo");

			enterOrSelectText("Enter", "web_uw_txt_CommencementDate", commencementDate);
			enterOrSelectText("Enter", "web_uw_txt_RiskCommencementDate", riskCommencementDate);
			enterOrSelectText("Enter", "web_uw_txt_PaymentFrequency", paymentFrequency);
			enterOrSelectText("Enter", "web_uw_txt_DiscountType", discountType);
			enterOrSelectText("Enter", "web_uw_txt_Maximumlimitperpolicy", maximumallowablelimitperpolicy);
			enterOrSelectText("Enter", "web_uw_txt_APILPRemarks", aPILPRemarks);
			enterOrSelectText("Enter", "web_uw_txt_UnderwritingLoadingReason", underwritingLoadingReason);
			enterOrSelectText("Enter", "web_uw_txt_UnderwritingComment", underwritingComment);
			enterOrSelectText("Enter", "web_uw_txt_consentGivenIndi", consentGivenIND);
			enterOrSelectText("Enter", "web_uw_txt_appealIndi", appealIND);
			enterOrSelectText("Enter", "web_uw_txt_specialCommIndi", specialCommIND);
			enterOrSelectText("Enter", "web_uw_txt_manuEscIndi", manualEscalationIND);
			enterOrSelectText("Enter", "web_uw_txt_uwEscaUsertext", underwriterExcalateTo);

			dashboard.setStepDetails("Basic Information entered", "Policy Details should be entered Successfully",
					"N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Name: EditRop Purpose: Adding Rop Information sheet Return Value: N/A
	 * Exception: BPC Exception on component execution fail Author : Sridhar
	 */
	public void editRop(Hashtable<String, String> hParams) throws Exception {
		try {
			String[] ropPolicyNumber = hParams.get("ROPPolicyNumber").split(",");
			String[] policyStatus = hParams.get("PolicyStatus").split(",");
			String[] ropIndicators = hParams.get("ROPIndicator").split(",");
			String[] ropTypes = hParams.get("ROPType").split(",");
			String[] sources = hParams.get("Source").split(",");
			String[] remarks = hParams.get("Remarks").split(",");
			String ropApplicable = hParams.get("ROPApplicable");
			
			llAction.clickElement("web_uw_btn_EditRop");
			llAction.waitUntilLoadingCompletes();
			llAction.handleCertificateErrors();
			llAction.waitUntilLoadingCompletes();
			llAction.maximizeWindow();
			
			llAction.selectByVisibleText("web_lstROPApplicable", ropApplicable);
			
			int noOfRows = llAction.getRowCountInTable("web_tbl_ropTable");
			int colPolicyNumberPos = llAction.GetColumnPositionInTable("web_tbl_ropTable", "Policy Number");
			int colPolicyStatus = llAction.GetColumnPositionInTable("web_tbl_ropTable", "Policy Status");
			int colPolicyROPIndi = llAction.GetColumnPositionInTable("web_tbl_ropTable", "ROP Indicator");
			int colROPType = llAction.GetColumnPositionInTable("web_tbl_ropTable", "ROP Type");
			int colSource = llAction.GetColumnPositionInTable("web_tbl_ropTable", "Source");
			int colRemarks = llAction.GetColumnPositionInTable("web_tbl_ropTable", "Remarks");
			
			for(int i = 1; i <= noOfRows-1; i++) {
				llAction.enterTextInTable("web_tbl_ropTable", i+1, colPolicyNumberPos, ropPolicyNumber[i-1], "/input");
				llAction.enterTextInTable("web_tbl_ropTable", i+1, colPolicyStatus, policyStatus[i-1], "/select");
				llAction.enterTextInTable("web_tbl_ropTable", i+1, colPolicyROPIndi, ropIndicators[i-1], "/select");
				llAction.enterTextInTable("web_tbl_ropTable", i+1, colROPType, ropTypes[i-1], "/select");
				llAction.enterTextInTable("web_tbl_ropTable", i+1, colSource, sources[i-1], "/select");
				llAction.enterTextInTable("web_tbl_ropTable", i+1, colRemarks, remarks[i-1], "/input");
			}
			
			dashboard.setStepDetails("ROP Information edited. Validate if System Accepts new values Successfully", "System should Accept new values Successfully", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_uw_btn_Ropsubmit");
			llAction.switchtoDefaultWindow();
		}
		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Select a Benefit for Underwriting Decision Table. Click on Make Benefits
	 * Decision Button.
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void MakeUnderwritingBenefitDecision(Hashtable<String, String> hParams) throws Exception {
		try {
			String[] UnderwritingDecisions = hParams.get("UnderwritingDecision").split(",");
			String[] advantageProgramIND = hParams.get("AdvantageProgramIND").split(",");
			String Option = hParams.get("BenefitNametobeunderwritten");

			if (Option.toUpperCase().equals("ALL")) {
				llAction.move_to_element("web_uw_check_UnderwritingOption_SelectAll");
				llAction.checkBox_Check("web_uw_check_UnderwritingOption_SelectAll");

				dashboard.setStepDetails(
						"Click on Select All Checkbox Displayed Under Underwriting Decision - Benefits Table",
						"All the Benefits Listed Under Underwriting Decision - Benefits Table should be Selected  ",
						"N/A");
				dashboard.writeResults();
			} else {
				String[] Options = Option.split(",");

				for (int i = 0; i < Options.length; i++) {
					Utils.editXpath("web_uw_DecisionBenefitName", "web_uw_" + Options[i] + "",
							new String[] { Options[i] });
					llAction.checkBox_Check("web_uw_" + Options[i] + "");

					llAction.move_to_element("web_uw_btn_MBenefitDec");
					llAction.clickElement("web_uw_btn_MBenefitDec");

					llAction.waitUntilElementPresent("web_uw_txt_UWDec");
					llAction.waitUntilLoadingCompletes();

					switch (UnderwritingDecisions[i].trim().toUpperCase()) {
					case "ACCEPTED":
						llAction.move_to_element("web_uw_txt_UWDec");
						llAction.enterValue("web_uw_txt_UWDec", "1");
						llAction.sendkeyStroke("web_uw_txt_UWDec", Keys.ENTER);
						dashboard.setStepDetails("Accept the Underwriting by entering 1",
								"User should be able to enter 1 and Accept the Underwriting  ", "N/A");
						dashboard.writeResults();
						break;
					case "DECLINED":
						llAction.move_to_element("web_uw_txt_UWDec");
						llAction.enterValue("web_uw_txt_UWDec", "4");
						llAction.sendkeyStroke("web_uw_txt_UWDec", Keys.ENTER);
						dashboard.setStepDetails("Decline the Underwriting by entering 4",
								"User should be able to enter 4 and Decline the Underwriting  ", "N/A");
						dashboard.writeResults();
						break;
					case "POSTPONED":
						llAction.move_to_element("web_uw_txt_UWDec");
						llAction.enterValue("web_uw_txt_UWDec", "3");
						llAction.sendkeyStroke("web_uw_txt_UWDec", Keys.ENTER);
						llAction.enterValue("web_uw_txt_UWReasonDesc", "001");
						llAction.sendkeyStroke("web_uw_txt_UWReasonDesc", Keys.ENTER);
						dashboard.setStepDetails("Postpone the Underwriting by entering 3",
								"User should be able to enter 3 and Postpone the Underwriting  ", "N/A");
						dashboard.writeResults();
						break;
					case "CONDITIONALLY ACCEPTED":
						llAction.move_to_element("web_uw_txt_UWDec");
						llAction.enterValue("web_uw_txt_UWDec", "2");
						llAction.clickElement("web_uw_txt_UWPreviousUnderwriter");
						
						
						if (hParams.get("EnterLoadingInfo").toUpperCase().equals("Y")) {
							EnterExtraLoading(hParams, i);
						}
						 

						if (hParams.get("EnterRestrictCover").toUpperCase().equals("Y")) {
							restrictCover(hParams, i);
						}
						if (hParams.get("EnterLIEN").toUpperCase().equals("Y")) {
							EnterLienInformation(hParams, i);
						}

						dashboard.setStepDetails("Conditionally Accept the Underwriting by entering 2",
								"User should be able to enter 2 and Conditionally Accept the Underwriting  ", "N/A");
						dashboard.writeResults();
						break;
					}
					if(!StringUtils.isEmpty(hParams.get("AdvantageProgramIND"))) {
						llAction.enterValue("web_txt_advantageIND", advantageProgramIND[i]);
						llAction.sendkeyStroke("web_txt_advantageIND", Keys.ENTER);
					}
					

					llAction.clickElement("web_uw_btn_SubmitUWDec");
					llAction.waitUntilAlertisShown();
					llAction.acceptAlert();
					llAction.waitUntilLoadingCompletes();

					dashboard.setStepDetails("Validate if user is navigated to Underwrting Decision Page",
							"User should be navigated to Underwrting Decision Page", "N/A");
					dashboard.writeResults();
					if (llAction.isDisplayed("web_btn_continue", 5)) {
						llAction.clickElement("web_btn_continue");
						llAction.waitUntilLoadingCompletes();
					}
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Click on Prepare Query Letter Button and Generate a New SLQ by clicking on
	 * Create Button
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void PrepareQueryLetter(Hashtable<String, String> hParams) throws Exception {
		String[] medicalReqCodes = hParams.get("MedicalRequirementCode").split(",");
		String[] quesCodes = hParams.get("QuestionnaireCode").split(",");
		String[] otherQueryCodes = hParams.get("OtherQueryCode").split(",");
		try {
			UnderwritingSearchPolicy(hParams);
			llAction.move_to_element("web_uw_btn_PrepareQueryLetter");
			llAction.clickElement("web_uw_btn_PrepareQueryLetter");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoChildWindow("Certificate Error: Navigation Blocked");
			llAction.ClickOnOverideLink();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Prepare Query Letter button Displayed on Underwriting Decision Page",
					"User should be Navigated to Search SLQ Page", "N/A");
			dashboard.writeResults();
			llAction.waitUntilElementPresent("web_uw_btn_CreateSLQ");
			llAction.switchtoChildWindow("Search SLQ");
			llAction.clickElement("web_uw_btn_CreateSLQ");
			llAction.waitUntilLoadingCompletes();
			llAction.waitUntilElementPresent("web_uw_txt_GenSLQMedReqCode");
			llAction.switchtoChildWindow("Generation of SLQ");
			dashboard.setStepDetails("Click on Create button Displayed on Search SLQ Page",
					"User should be Navigated to Generation of SLQ Page", "N/A");
			dashboard.writeResults();
			llAction.maximizeWindow();
			for (String MedReqCode : medicalReqCodes) {
				llAction.enterValue("web_uw_txt_GenSLQMedReqCode", MedReqCode);
				llAction.sendkeyStroke("web_uw_txt_GenSLQMedReqCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_uw_lst_MedQuesCodeRole", hParams.get("MedQuestionToRole"));
				llAction.clickElement("web_uw_btn_GenSLQMedCodeAdd");
				llAction.waitUntilLoadingCompletes();
			}
			for (String QuesCode : quesCodes) {
				llAction.enterValue("web_uw_txt_GenSLQQuesCode", QuesCode);
				llAction.sendkeyStroke("web_uw_txt_GenSLQQuesCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_uw_btn_queryLetterAddForm", 5)
						&& !StringUtils.isEmpty(hParams.get("FormName"))) {
					addFormNames(hParams);
					addFormQuestions(hParams);
				}
				llAction.selectByVisibleText("web_uw_lst_QuesCodeRole", hParams.get("QuestionToRole"));
				llAction.clickElement("web_uw_btn_GenSLQQuesCodeAdd");
				llAction.waitUntilLoadingCompletes();
			}
			for (String otherQueryCode : otherQueryCodes) {
				llAction.enterValue("web_uw_txt_GenSLQOtherQuesCode", otherQueryCode);
				llAction.sendkeyStroke("web_uw_txt_GenSLQOtherQuesCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_uw_txt_otherQuesEnglishText", 5)) {
					llAction.enterValue("web_uw_txt_otherQuesEnglishText", hParams.get("EnglishText"));
				}
				if (llAction.isDisplayed("web_uw_txt_otherQuesBahasaText", 5)) {
					llAction.enterValue("web_uw_txt_otherQuesBahasaText", hParams.get("BahasaText"));
				}
				llAction.selectByVisibleText("web_uw_lst_OtherCodeRole", hParams.get("OtherQueryToRole"));
				llAction.clickElement("web_uw_btn_GenSLQOtherQuesAdd");
				llAction.waitUntilLoadingCompletes();
			}

			dashboard.setStepDetails("Enter Questionnaire Codes and Click on Publish Query Letter button",
					"User should be able to enter the Questionnaire Codes and System should Close Generation of SLQ Pop-Up Screen",
					"N/A");
			llAction.clickElement("web_uw_btn_GenSLQPublish");
			llAction.waitUntilLoadingCompletes();
			dashboard.writeResults();
			llAction.switchtoChildWindow("Search SLQ");
			dashboard.writeResults();
			llAction.clickElement("web_uw_btn_SearchSLQExit");
			llAction.sleep(6);
			llAction.switchtoDefaultWindow();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Internal Method to enter form names in Prepare query letter
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	private void addFormNames(Hashtable<String, String> hParams) throws Exception {
		String[] formNames = hParams.get("FormName").split(",");
		for (int i = 0; i < formNames.length; i++) {
			llAction.clickElement("web_uw_btn_queryLetterAddForm");
		}

		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get("web_uw_list_FormName");
		String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]);
		List<WebElement> ele = llAction.findElementsByXpath(temp);

		for (int j = 0; j < ele.size(); j++) {
			Select select = new Select(ele.get(j));
			select.selectByVisibleText(formNames[j]);
		}
	}

	/**
	 * Internal Method to enter form question no in Prepare query letter
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	private void addFormQuestions(Hashtable<String, String> hParams) throws Exception {
		String[] formQuestions = hParams.get("FormQuestion").split(",");

		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get("web_uw_txt_newQuestionNos");
		String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]);
		List<WebElement> ele = llAction.findElementsByXpath(temp);

		for (int j = 0; j < ele.size(); j++) {
			ele.get(j).click();
			ele.get(j).clear();
			ele.get(j).sendKeys(formQuestions[j]);
			ele.get(j).sendKeys(Keys.ENTER);
			Utils.sleep(2);
			llAction.waitUntilLoadingCompletes();
		}
	}

	/**
	 * Select and Enter Extra Loading Info
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void EnterExtraLoading(Hashtable<String, String> hParams, int benefitNumber) throws Exception {
		try {
			llAction.clickElement("web_uw_btn_extraloading");
			llAction.waitUntilLoadingCompletes();
			Loading.enterLoading(hParams, benefitNumber);
			llAction.clickElement("web_uw_btn_calcExtraPremAmt");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_btn_loadingSubmit");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			/*
			 * llAction.clickElement("web_uw_btn_SubmitUWDec");
			 * llAction.waitUntilAlertisShown(); llAction.acceptAlert();
			 * llAction.waitUntilLoadingCompletes();
			 */
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Enter Lien Information for Conditionally Accepted Benefit Information
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void EnterLienInformation(Hashtable<String, String> hParams, int benefitNumber) throws Exception {
		String[] LienTypes = hParams.get("LienType").split(",");
		String[] EMValues = hParams.get("LienEMValue").split(",");
		String[] LienPercentages = hParams.get("LienPercentageFactor").split(",");
		try {
			llAction.clickElement("web_uw_btn_UWEnterLien");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_txt_LienType");
			llAction.enterValue("web_uw_txt_LienType", LienTypes[benefitNumber]);
			llAction.clickElement("web_uw_txt_EMValue");
			llAction.enterValue("web_uw_txt_EMValue", EMValues[benefitNumber]);
			llAction.clickElement("web_uw_txt_LienPercentage");
			llAction.enterValue("web_uw_txt_LienPercentage", LienPercentages[benefitNumber]);

			dashboard.setStepDetails(
					"Enter LienType: " + LienTypes[benefitNumber] + ", EM Value: " + EMValues[benefitNumber]
							+ ", Lien Percentage: " + LienPercentages[benefitNumber] + " and CLick on Submit Button ",
					"User should be able to enter the values and User should be Navigated to Underwiriting Main Screen",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_uw_txt_TotalLienAmt");
			dashboard.setStepDetails("Validate if Lien Information is Entered", "Lien Information should be enterd",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_uw_btn_UWLienSubmit");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			/*
			 * llAction.clickElement("web_uw_btn_SubmitUWDec");
			 * llAction.waitUntilAlertisShown(); llAction.acceptAlert();
			 * llAction.waitUntilLoadingCompletes(); SaveExitToHomePage(hParams);
			 */
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Validate Underwriting Decision Status after/before Making a Underwriting
	 * Decision
	 * 
	 * @param hParams
	 * @return boolean
	 * @throws Exception
	 */
	public boolean ValidateUnderwritingDecision(Hashtable<String, String> hParams) throws Exception {
		boolean Status = false;
		String[] expectedStatus = hParams.get("UnderwritingDecision").split(",");
		String[] docsSelected = hParams.get("BenefitNametobeunderwritten").split(",");
		int colUnderwritingDecisionPos = llAction.GetColumnPositionInTable("web_uw_tbl_UWBenefitsList",
				"Underwriting Decision");
		int colBenefitNamePos = llAction.GetColumnPositionInTable("web_uw_tbl_UWBenefitsList", "Benefit Name");
		try {
			for (int i = 0; i < docsSelected.length; i++) {
				int rowBenefitNamePos = llAction.GetRowPositionInTableByPartialTextMatch("web_uw_tbl_UWBenefitsList",
						docsSelected[i], colBenefitNamePos);
				String actualStatus = llAction.GetTextFromTable("web_uw_tbl_UWBenefitsList", rowBenefitNamePos,
						colUnderwritingDecisionPos);
				if (actualStatus.equalsIgnoreCase(expectedStatus[i])) {
					dashboard.setStepDetails(
							"Validate if status is " + expectedStatus[i] + " for Benefit " + docsSelected[i] + "",
							"The Expected Benefit Status should be " + expectedStatus[i] + "", "N/A");
					dashboard.writeResults();
				} else {
					dashboard.setFailStatus(new BPCException("The Actual Benefit Status is " + actualStatus));
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
		return Status;
	}

	/**
	 * Submit and Exit from Underwriting Main Screen
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void ExitToHomePage(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.waitUntilLoadingCompletes();
			llAction.isDisplayed("web_uw_btn_SubmitUWmain", 5);
			llAction.clickElement("web_uw_btn_SubmitUWmain");

			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();

			/*
			 * if (llAction.isEnabled("web_uw_btn_SubmitUWmain")) {
			 * llAction.clickElement("web_uw_btn_SubmitUWmain");
			 * llAction.waitUntilAlertisShown(); llAction.acceptAlert();
			 * llAction.waitUntilLoadingCompletes(); }
			 */

			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
			}

			if (llAction.isDisplayed("web_uw_btn_UWInForceInfoExit", 5)) {
				dashboard.setStepDetails("Validate if Policty Status is displayed",
						"Policty Status Should be displayed", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_uw_btn_UWInForceInfoExit");
				llAction.waitUntilLoadingCompletes();
			}

			if (llAction.isDisplayed("web_uw_btn_UWSPBack", 5)) {
				dashboard.setStepDetails("Validate if Policty Status is displayed",
						"Policty Status Should be displayed", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_uw_btn_UWSPBack");
				llAction.waitUntilLoadingCompletes();
			}

			llAction.isDisplayed("web_uw_btn_UWSPExit", 5);
			llAction.clickElement("web_uw_btn_UWSPExit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Save and Exit from Underwriting Main Screen
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void SaveExitToHomePage(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.clickElement("web_uw_btn_UWSaveAndExit");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_btn_UWSPExit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Method to Validate Risk Aggregation - SPP SA exceed Error Message Need to be
	 * enhanced if there are scenarios related to validating more error messages in
	 * Underwriting Main Screen
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void validateUnderwritingErrorMessage(Hashtable<String, String> hParams) throws Exception {
		try {
			amlAdmin.authorisationHRCByPass(hParams);
			UnderwritingSearchPolicy(hParams);
			llAction.isDisplayed("web_uw_btn_SubmitUWmain", 5);
			llAction.clickElement("web_uw_btn_SubmitUWmain");

			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_table_UnderwrtingWarningMessage", 5)) {
				String warningMessage = llAction.getText("web_table_UnderwrtingWarningMessage");
				if (warningMessage.contains("SPP SA exceed")) {
					dashboard.setStepDetails("Validate if SPP SA Exceed error message is displayed",
							"Error Message should be displayed", "");
					dashboard.writeResults();
					SaveExitToHomePage(hParams);
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Enter Endorsement Code and Condition Code and Exclusion Code
	 * 
	 * @param codeType
	 * @param codes
	 * @throws Exception
	 */
	public void enterCodes(String codeType, String code, Hashtable<String, String> exclusionOtherParams)
			throws Exception {
		switch (codeType.trim().toUpperCase()) {
		case "ENDORSEMENT":
			llAction.clickElement("web_btn_addEndoCode");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_UW_endorsementCode", code);
			llAction.sendkeyStroke("web_txt_UW_endorsementCode", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			break;
		case "CONDITION":
			llAction.clickElement("web_btn_addCondCode");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_UW_conditionCode", code);
			llAction.sendkeyStroke("web_txt_UW_conditionCode", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			break;
		case "EXCLUSION":
			llAction.clickElement("web_btn_addExclCode");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_UW_exclusionCode", code);
			llAction.sendkeyStroke("web_txt_UW_exclusionCode", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();

			if (exclusionOtherParams.size() != 0) {
				if (exclusionOtherParams.containsKey("LifeAssured")) {
					llAction.selectByVisibleText("web_txt_UW_insuredId", exclusionOtherParams.get("LifeAssured"));
					llAction.sendkeyStroke("web_txt_UW_insuredId", Keys.ENTER);
					llAction.waitUntilLoadingCompletes();
				}
				if (exclusionOtherParams.containsKey("FreeText")) {
					llAction.enterValue("web_txt_UW_freeText", exclusionOtherParams.get("FreeText"));
					llAction.sendkeyStroke("web_txt_UW_freeText", Keys.ENTER);
					llAction.waitUntilLoadingCompletes();
				}
				if (exclusionOtherParams.containsKey("ReviewPeriod")) {
					llAction.enterValue("web_txt_UW_reviewNum", exclusionOtherParams.get("ReviewPeriod"));
					llAction.sendkeyStroke("web_txt_UW_reviewNum", Keys.ENTER);
					llAction.waitUntilLoadingCompletes();
				}
			}
			break;
		}
	}

	public void applyFac(Hashtable<String, String> hParams) throws Exception {
		String Benefitcode = hParams.get("BenefitName");

		if ((Benefitcode != null) && (Benefitcode != "")) {
			int colPos = llAction.GetColumnPositionInTable("web_uw_tbl_underwritingdec", "Benefit Name");
			int rowPos = llAction.GetRowPositionInTable("web_uw_tbl_underwritingdec", hParams.get("BenefitName"),
					colPos);
			llAction.SelectRowInTable("web_uw_tbl_underwritingdec", rowPos, colPos - 1, "input");
		} else {
			llAction.clickElement("web_uw_chk_All");
		}
		llAction.clickElement("web_uw_btn_ApplyFac");
		llAction.waitUntilLoadingCompletes();
		llAction.handleCertificateErrors();
		llAction.switchtoChildWindow("Enter or Amend Facultative Reinsurance Request");
		dashboard.setStepDetails("Click on the ApplyFac ",
				"System should Enter or Amend Facultative Reinsurance Request window ", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_uw_btn_AddRequset");
		llAction.waitUntilLoadingCompletes();
		llAction.enterValue("web_uw_txt_facRequest", hParams.get("FacRequest"));
		llAction.clickElement("web_uw_btn_submitRequest");
		llAction.waitUntilLoadingCompletes();
		int colPos = llAction.GetColumnPositionInTable("web_uw_tbl_ExistingRequest", "Request Status");
		int rowPos = llAction.getRowCountInTable("web_uw_tbl_ExistingRequest");
		String RequestStatus = llAction.GetTextFromTable("web_uw_tbl_ExistingRequest", rowPos, colPos, "input");
		if (RequestStatus.equalsIgnoreCase("Waiting for Fac Arrangement")) {
			llAction.SelectRowInTable("web_uw_tbl_ExistingRequest", rowPos, colPos - 6, "input");
			llAction.clickElement("web_uw_btn_FacReinsurance");
			llAction.waitUntilLoadingCompletes();
			int colPo = llAction.GetColumnPositionInTable("web_uw_tbl_facArrangment", hParams.get("FacRequest"));
			int rowPo = llAction.getRowCountInTable("web_uw_tbl_facArrangment");
			llAction.SelectRowInTable("web_uw_tbl_facArrangment", rowPo, colPo - 5, "input");
			llAction.clickElement("web_uw_btn_facArrangment");
			llAction.waitUntilLoadingCompletes();
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow("null");
			llAction.selectByVisibleText("web_uw_lst_Treatycode", hParams.get("TreatyCode"));
			llAction.enterValue("web_uw_txt_CedingPercentage", hParams.get("CodingPercentage"));
			llAction.selectByVisibleText("web_uw_lst_ReinsurerCode", hParams.get("ReInsurerCode"));
			llAction.enterValue("web_uw_txt_sharePercentagetext", hParams.get("SharingPercentage"));
			llAction.selectByVisibleText("web_uw_lst_erIndi", hParams.get("ER Ind"));
			llAction.enterValue("web_uw_txt_erLimit", hParams.get("ERLimit"));
			llAction.selectByVisibleText("web_uw_lst_insuredStatus", hParams.get("PreferredInd"));
			llAction.clickElement("web_uw_btn_saveButton");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoChildWindow("Facultative Request");
			llAction.clickElement("web_uw_btn_Exit");
		}
	}

	public void cancelFacArrangement(Hashtable<String, String> hParams) throws Exception {

		String Benefitcode = hParams.get("BenefitName");

		if ((Benefitcode != null) && (Benefitcode != "")) {

			int colPos = llAction.GetColumnPositionInTable("web_uw_tbl_underwritingdec", "Benefit Name");
			int rowPos = llAction.GetRowPositionInTable("web_uw_tbl_underwritingdec", hParams.get("BenefitName"),
					colPos);
			llAction.SelectRowInTable("web_uw_tbl_underwritingdec", rowPos, colPos - 1, "input");
		} else {
			llAction.clickElement("web_uw_chk_All");
		}
		llAction.clickElement("web_uw_btn_ApplyFac");

		llAction.waitUntilLoadingCompletes();
		llAction.handleCertificateErrors();
		llAction.switchtoChildWindow("Enter or Amend Facultative Reinsurance Request");
		dashboard.setStepDetails("Click on the ApplyFac ",
				"System should Enter or Amend Facultative Reinsurance Request window ", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_uw_btn_AddRequset");
		llAction.waitUntilLoadingCompletes();
		llAction.enterValue("web_uw_txt_facRequest", hParams.get("FacRequest"));
		llAction.clickElement("web_uw_btn_submitRequest");
		llAction.waitUntilLoadingCompletes();
		int colPos = llAction.GetColumnPositionInTable("web_uw_tbl_ExistingRequest", "Request Status");
		int rowPos = llAction.getRowCountInTable("web_uw_tbl_ExistingRequest");
		String RequestStatus = llAction.GetTextFromTable("web_uw_tbl_ExistingRequest", rowPos, colPos, "");
		if (RequestStatus.equalsIgnoreCase("Waiting for Fac Arrangement")) {
			llAction.SelectRowInTable("web_uw_tbl_ExistingRequest", rowPos, colPos - 6, "input");
			llAction.clickElement("web_uw_btn_FacReinsurance");
			llAction.waitUntilLoadingCompletes();
			int colPo = llAction.GetColumnPositionInTable("web_uw_tbl_facArrangment", hParams.get("FacRequest"));
			int rowPo = llAction.getRowCountInTable("web_uw_tbl_facArrangment");

			llAction.SelectRowInTable("web_uw_tbl_facArrangment", rowPo, colPo - 5, "input");
			llAction.clickElement("web_uw_btn_cancelButton");
			llAction.waitUntilLoadingCompletes();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			String Status = llAction.GetTextFromTable("web_uw_tbl_facArrangment", rowPos, colPos + 1, "");
			if (Status.equalsIgnoreCase("FacArrangement Cancelled")) {
				dashboard.setStepDetails("Status ", "Succesfully FacArrangement Cancelled ", "N/A");
				dashboard.writeResults();

			} else {
				dashboard.setStepDetails("Status ", "failed to FacArrangement Cancel ", "N/A");
				dashboard.writeResults();
			}

		}
	}

	public void enterOrSelectText(String action, String key, String value) throws Exception {
		switch (action.toUpperCase()) {
		case "SELECT":
			llAction.selectByVisibleText(key, value);
			break;
		case "ENTER":
			llAction.enterValue(key, value);
			break;
		}
		llAction.sendkeyStroke(key, Keys.ENTER);
		llAction.waitUntilLoadingCompletes();
	}

	/**
	 * Enter Restrict Cover
	 * 
	 * @param hParams
	 */
	public void restrictCover(Hashtable<String, String> hParams, int benefitNumber) throws Exception {
		try {

			String[] reducedSAUnits = hParams.get("ReducedSAUnit").split(",");
			String[] coverageTermTypes = hParams.get("CoverageTermType").split(",");
			String[] coverageTerms = hParams.get("CoverageTerm").split(",");
			String[] premiumTermTypes = hParams.get("PremiumTermType").split(",");
			String[] premiumPayemtTerms = hParams.get("PremiumPayemtTerm").split(",");

			llAction.clickElement("web_uw_btn_restrictCover");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_uw_txt_reducedSAUnit", reducedSAUnits[benefitNumber]);

			llAction.enterValue("web_uw_txt_CoverageTermType", coverageTermTypes[benefitNumber]);
			llAction.sendkeyStroke("web_uw_txt_CoverageTermType", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_uw_txt_CoverageTerm", coverageTerms[benefitNumber]);

			llAction.enterValue("web_uw_txt_PremiumTermType", premiumTermTypes[benefitNumber]);
			llAction.sendkeyStroke("web_uw_txt_PremiumTermType", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_uw_txt_PremiumTerm", premiumPayemtTerms[benefitNumber]);

			llAction.clickElement("web_uw_restrictCoverSubmit");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * Enter LIA ICD9 record Maintenance Info
	 * 
	 * @param hParams
	 */
	public void liaICD9RecordMaintainance(Hashtable<String, String> hParams) throws Exception {
		try {
			int colPos = llAction.GetColumnPositionInTable("web_tbl_LIAICD9Records", "Life Assured");
			llAction.SelectRowInTable("web_tbl_LIAICD9Records", 2, colPos + 7, "a");
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow("LIA/ICD9 Record Maintenance");
			llAction.maximizeWindow();
			llAction.switchtoFrame(0);
			llAction.clickElement("web_btn_AddLIAInfo");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoDefaultContent();
			llAction.enterValue("web_txt_LIAInfoMedicalCode1", hParams.get("LIAMedicalCode1"));
			llAction.sendkeyStroke("web_txt_LIAInfoMedicalCode1", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_liaInfoSubmit");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoFrame(0);
			llAction.clickElement("web_uw_liaInfoExit");
			Utils.sleep(3);
			llAction.switchtoDefaultWindow();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void updateCRSFollowUpIndi(String indicatorValue) throws Exception {
		try {
			int colPos = llAction.GetColumnPositionInTable("web_tbl_FATCA_CRS_Info", "CRS Info ");
			int rowCount = llAction.getRowCountInTable("web_tbl_FATCA_CRS_Info");
			for(int i = 2; i <= rowCount; i++ ) {
				llAction.SelectRowInTable("web_tbl_FATCA_CRS_Info", i, colPos, "a");
				llAction.handleCertificateErrors();
				llAction.switchtoChildWindow("CRS");
				llAction.maximizeWindow();
				llAction.selectByVisibleText("web_lstCRSFollowUpIndicator", indicatorValue);
				llAction.clickElement("web_btn_SubmitCRSIndi");
				llAction.switchtoDefaultWindow();
			}
		} catch (Exception ex) {

		}
	}

	public void createQueryLetter(Hashtable<String, String> hParams) throws Exception {
		String[] medicalReqCodes = hParams.get("MedicalRequirementCode").split(",");
		String[] quesCodes = hParams.get("QuestionnaireCode").split(",");
		String[] otherQueryCodes = hParams.get("OtherQueryCode").split(",");
		hParams.put("ActionOnSelectedLetters", StringUtils.EMPTY); //Setting it in the code. Not coming from the Test Data Sheet
		try {
			llAction.waitUntilElementPresent("web_uw_btn_CreateSLQ");
			llAction.switchtoChildWindow("Search SLQ");
			llAction.clickElement("web_uw_btn_CreateSLQ");
			llAction.waitUntilLoadingCompletes();
			llAction.waitUntilElementPresent("web_uw_txt_GenSLQMedReqCode");
			llAction.switchtoChildWindow("Generation of SLQ");
			dashboard.setStepDetails("Click on Create button Displayed on Search SLQ Page",
					"User should be Navigated to Generation of SLQ Page", "N/A");
			dashboard.writeResults();
			llAction.maximizeWindow();
			for (String MedReqCode : medicalReqCodes) {
				llAction.enterValue("web_uw_txt_GenSLQMedReqCode", MedReqCode);
				llAction.sendkeyStroke("web_uw_txt_GenSLQMedReqCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_uw_lst_MedQuesCodeRole", hParams.get("MedQuestionToRole"));
				llAction.clickElement("web_uw_btn_GenSLQMedCodeAdd");
				llAction.waitUntilLoadingCompletes();
			}
			for (String QuesCode : quesCodes) {
				llAction.enterValue("web_uw_txt_GenSLQQuesCode", QuesCode);
				llAction.sendkeyStroke("web_uw_txt_GenSLQQuesCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_uw_btn_queryLetterAddForm", 5)
						&& !StringUtils.isEmpty(hParams.get("FormName"))) {
					addFormNames(hParams);
					addFormQuestions(hParams);
				}
				llAction.selectByVisibleText("web_uw_lst_QuesCodeRole", hParams.get("QuestionToRole"));
				llAction.clickElement("web_uw_btn_GenSLQQuesCodeAdd");
				llAction.waitUntilLoadingCompletes();
			}
			for (String otherQueryCode : otherQueryCodes) {
				llAction.enterValue("web_uw_txt_GenSLQOtherQuesCode", otherQueryCode);
				llAction.sendkeyStroke("web_uw_txt_GenSLQOtherQuesCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_uw_txt_otherQuesEnglishText", 5)) {
					llAction.enterValue("web_uw_txt_otherQuesEnglishText", hParams.get("EnglishText"));
				}
				if (llAction.isDisplayed("web_uw_txt_otherQuesBahasaText", 5)) {
					llAction.enterValue("web_uw_txt_otherQuesBahasaText", hParams.get("BahasaText"));
				}
				llAction.selectByVisibleText("web_uw_lst_OtherCodeRole", hParams.get("OtherQueryToRole"));
				llAction.clickElement("web_uw_btn_GenSLQOtherQuesAdd");
				llAction.waitUntilLoadingCompletes();
			}

			dashboard.setStepDetails("Enter Questionnaire Codes and Click on Publish Query Letter button",
					"User should be able to enter the Questionnaire Codes and System should Close Generation of SLQ Pop-Up Screen",
					"N/A");
			
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void performAction(Hashtable<String, String> hParams)throws Exception{
		try {
			List<WebElement> webElements = new ArrayList<WebElement>();
			String actionToBePerformed = hParams.get("ActionOnSLQ");
			switch(actionToBePerformed.toUpperCase()) {
			case "CLOSE":
				llAction.clickElement("web_uw_btn_GenSLQPublish");
				llAction.waitUntilLoadingCompletes();
				llAction.switchtoChildWindow("Search SLQ");
				llAction.clickElement("web_uw_btn_SearchSLQExit");
				llAction.sleep(6);
				llAction.switchtoDefaultWindow();
				llAction.clickElement("web_uw_btn_UWSaveAndExit");
				llAction.waitUntilAlertisShown();
				llAction.acceptAlert();
				llAction.waitUntilLoadingCompletes();
				
				docMgt.publishOrIssueDoc(hParams);
				UnderwritingSearchPolicy(hParams);
				llAction.clickElement("web_uw_btn_PrepareQueryLetter");
				llAction.waitUntilLoadingCompletes();
				llAction.switchtoChildWindow("Certificate Error: Navigation Blocked");
				llAction.handleCertificateErrors();
				llAction.switchtoChildWindow("Search SLQ");
				llAction.waitUntilLoadingCompletes();
				Utils.editXpath("web_uw_DocList_SelectQueryLetter", "web_uw_DocList_SLQLetter", new String[] { "Standard Letter of Query" });
				llAction.checkBox_Check("web_uw_DocList_SLQLetter");
				
				llAction.clickElement("web_btn_uw_QueryLetter_QueryReply");
				llAction.waitUntilLoadingCompletes();
				
				if(!StringUtils.isEmpty(hParams.get("ReceviedDate"))) {
					Utils.editXpath("web_txt_uw_QueryLetter_closingDates", "web_txt_uw_QueryLetter_received", new String[] {"Received Date", "receivedDates"});
					webElements = llAction.findElements("web_txt_uw_QueryLetter_received");
					for(int i = 0; i < webElements.size(); i++) {
						webElements.get(i).sendKeys(hParams.get("ReceviedDate"));
					}
				}else {
					Utils.editXpath("web_txt_uw_QueryLetter_closingDates", "web_txt_uw_QueryLetter_waived", new String[] {"Waive Date", "waiveDates"});
					webElements = llAction.findElements("web_txt_uw_QueryLetter_waived");
					for(int i = 0; i < webElements.size(); i++) {
						webElements.get(i).sendKeys(hParams.get("WaiveDate"));
					}
				}
				llAction.clickElement("web_txt_uw_QueryLetter_Submit");
				Utils.sleep(3);
				llAction.switchtoChildWindow("Search SLQ");
				llAction.clickElement("web_uw_btn_SearchSLQExit");
				llAction.sleep(6);
				llAction.switchtoDefaultWindow();
				ExitToHomePage(hParams);
				break;
			case "PUBLISH":
				llAction.clickElement("web_uw_btn_GenSLQPublish");
				llAction.waitUntilLoadingCompletes();
				llAction.switchtoChildWindow("Search SLQ");
				llAction.clickElement("web_uw_btn_SearchSLQExit");
				llAction.sleep(6);
				llAction.switchtoDefaultWindow();
				SaveExitToHomePage(hParams);
				break;
			case "ISSUE":
				llAction.clickElement("web_uw_btn_GenSLQPublish");
				llAction.waitUntilLoadingCompletes();
				llAction.switchtoChildWindow("Search SLQ");
				llAction.clickElement("web_uw_btn_SearchSLQExit");
				llAction.sleep(6);
				llAction.switchtoDefaultWindow();
				SaveExitToHomePage(hParams);
				docMgt.publishOrIssueDoc(hParams);
				break;
			}
			
		}catch(Exception ex) {
			throw new BPCException(ex);
		}
	}
}
