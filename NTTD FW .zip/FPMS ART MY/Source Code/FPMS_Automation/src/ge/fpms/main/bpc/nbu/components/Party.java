package ge.fpms.main.bpc.nbu.components;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;

import com.nttdata.common.util.ColumnHeader;
import com.nttdata.common.util.RandomString;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.actions.FPMS_Actions;

public class Party {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	private String sheetName;
	private static final String PROPOSER = "Proposer";
	private static final String LIFE_ASSURED = "Life Assured";
	private static final String NOMINEE = "Nominee";
	private static final String BENEFICIAL_OWNER = "Beneficial Owner";
	private static final String Trustee = "Trustee";
	private static final String ORGANIZATION = "Organization";
	private PolicyHandler policyHandler;

	public Party() {
		dashboard = DashboardHandler.getInstance();
		sheetName = ColumnHeader.Party.toString();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	public void createParties(String partyIds) throws Exception {
		if (!StringUtils.isEmpty(partyIds)) {
			String[] partyIdList = partyIds.split(",");
			if (partyIdList != null && partyIdList.length > 0) {

				for (String id : partyIdList) {
					creatParty(id);
				}
			}
		} else {
			throw new BPCException("Create party failed!!");
		}
	}

	public Hashtable<String, String> getPartyData(String partyId) {
		DataHandler dataHandler = new DataHandler();

		Hashtable<String, String> partyData = dataHandler.getTestData(sheetName,
				FPMSProperties.getInstance().getTestDataFilePath(System.getProperty("Settings.Module")),
				ColumnHeader.getColumnHeader(sheetName), partyId, "PID");

		return partyData;
	}

	public void creatParty(String partyId) throws Exception {
		Hashtable<String, String> partyData = getPartyData(partyId);
		try {

			String partyType = partyData.get("PI_PartyType");
			fillPartyBasicDetails(partyData);
			fillPartyAdditionalDetails(partyData);
			Contact obj = new Contact();
			obj.addAddress(partyData);
			obj.addContactInformation(partyData);
			addAccountInformation(partyData);
			llAction.selectTab("CRS");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5))
				llAction.clickElement("web_btn_continue");
			llAction.waitUntilLoadingCompletes();
			if (partyType.equalsIgnoreCase("Organization")) {
				CrsOrganization c = new CrsOrganization();
				c.fillCrsInfo(partyData);
			} else {
				CRS c = new CRS();
				c.fillCrsInfo(partyData);
			}
			llAction.switchtoFrame(0);
			llAction.clickElementJs("web_btn_exit");
			// exitparty(partyData);
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoDefaultWindow();
		} catch (Exception e) {
			throw new BPCException("Create party failed!!");
		}
	}

	public void exitparty(Hashtable<String, String> hParams) {
		try {
			if (hParams.get("PI_PartyType").equalsIgnoreCase(ORGANIZATION))
				llAction.clickElementJs("web_btn_CreateParty");
			else {
				llAction.clickElementJs("web_btn_exit");
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void selectPartyType(String partyType) {
		if (!StringUtils.isEmpty(partyType) && partyType.equalsIgnoreCase("Organization")) {
			try {
				llAction.selectByVisibleText("web_lst_party_type", partyType);
				llAction.sendkeyStroke("web_lst_party_type", Keys.ENTER);
			} catch (Exception e) {
				throw new BPCException(e);
			}
		}
	}

	public void fillPartyBasicDetails(Hashtable<String, String> hParams) throws Exception {
		try {

			String role = hParams.get("PartyRole").toUpperCase().replace(" ", "_");
			String type = hParams.get("PI_PartyType").toUpperCase().trim();
			String nationality = hParams.get("P_Nationality");
			long currentTimeMillis = System.currentTimeMillis();
			String randomStr = RandomString.randomString(4).toUpperCase();
			String name = hParams.get("PI_Name");
			/*
			 * Deepa_08022019: Removed code for 'id': Need to look into it! String id =
			 * role+ FPMSConstants.NAME_SEPERATOR + hParams.get("PI_IDNumber") + "_ID_" +
			 * currentTimeMillis;
			 * 
			 * String id = hParams.get("PI_IDNumber") + "_ID_" + currentTimeMillis;
			 */
			String id = hParams.get("PI_IDNumber");
			System.out.println(id);
			name = nationality.equalsIgnoreCase(FPMSConstants.NAT_SINGAPOREAN) ? hParams.get("PI_Name") : name;
			id = nationality.equalsIgnoreCase(FPMSConstants.NAT_SINGAPOREAN) ? hParams.get("PI_IDNumber") : id;
			if (role.equalsIgnoreCase(PROPOSER)) {
				policyHandler.updatePolicy("ProposerName", name);
				policyHandler.updatePolicy("ProposerId", id);
			} else if (role.equalsIgnoreCase(LIFE_ASSURED.replace(" ", "_"))) {
				policyHandler.getPolicy().setLifeAssured(id, name);

			} else if (role.equalsIgnoreCase(NOMINEE)) {
				policyHandler.getPolicy().setNominee(id, name);

			} else if (role.equalsIgnoreCase(BENEFICIAL_OWNER)) {
				policyHandler.getPolicy().setBeneficialOwner(id, name);

			} else if (role.equalsIgnoreCase(Trustee)) {
				policyHandler.getPolicy().setTrustee(id, name);
			}

			System.out.println("Party.fillPartyBasicDetails() partyid : " + id);
			System.out.println("Party.fillPartyBasicDetails() partyName : " + name);

			llAction.selectMenuItem("Party", "Maintain First Party");
			llAction.waitUntilElementPresent("web_lst_NewParty_IndividualPartyCategory");
			if (type.equalsIgnoreCase(ORGANIZATION)) {
				selectPartyType(hParams.get("PI_PartyType"));
				llAction.switchtoFrame(0);
				dashboard.setStepDetails("Enter First Party Information.", "First party information entered.", "N/A");
				dashboard.writeResults();
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_btn_CreateOrganization");

			} else {
				llAction.switchtoFrame(0);
				// llAction.enterValue("web_txt_personName",hParams.get("PI_Name"));
				llAction.enterValue("web_txt_personName", name); // appending
				// random
				// string
				llAction.selectByVisibleText("web_lst_gender", hParams.get("PI_Gender"));
				llAction.enterValue("web_txt_DOB", hParams.get("PI_DOB"));
				llAction.enterValue("web_txt_idNumber", id);
				llAction.selectByVisibleText("web_lst_IdType", hParams.get("PI_IDTypeNational"));
				dashboard.setStepDetails("Enter First Party Information.", "First party information entered.", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_CreateParty");

			}

			llAction.waitUntilLoadingCompletes();
			llAction.switchtoDefaultWindow();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void verify_Party(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("Party", "Search Party");
			llAction.waitUntilElementPresent("web_txt_SearchParty_PartyName");
			llAction.enterValue("web_txt_SearchParty_PartyName", policyHandler.getPolicy().getProposerName());
			llAction.clickElement("web_btn_seachOnly");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Search Party",
					"Party name should entered and clicked on Search Party succesffully", "N/A");
			dashboard.writeResults();

			if (llAction.isDisplayed("web_btn_continue", 5))
				llAction.clickElement("web_btn_continue");
			llAction.waitUntilLoadingCompletes();

			llAction.clickElementJs("web_lnk_SearchPartyViewParty");

			if (llAction.isDisplayed("web_btn_continue", 5))
				llAction.clickElement("web_btn_continue");
			llAction.waitUntilLoadingCompletes();
			verifyPartySection(hParams);
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	private void verifyPartySection(Hashtable<String, String> hParams) throws Exception {
		try {

			llAction.waitUntilElementPresent("web_txt_personName");
			String partyName = llAction.getAttribute("web_txt_personName", "value");
			if (partyName.equalsIgnoreCase(policyHandler.getPolicy().getProposerName())) {
				dashboard.setStepDetails("Verify Party Name", "Party name should be " + partyName, "N/A");
				dashboard.writeResults();

			}
			String gender = llAction.getSelectedOption("web_lst_gender");
			if (gender.equalsIgnoreCase(hParams.get("PI_Gender"))) {
				dashboard.setStepDetails("Verify Party Gender", "Party Gender should be " + gender, "N/A");
				dashboard.writeResults();
			}

			String dob = llAction.getAttribute("web_txt_DOB", "value");
			if (dob.equalsIgnoreCase(hParams.get("PI_DOB"))) {
				dashboard.setStepDetails("Verify Date of Birth", "Date of Birth verified succesffuly", "N/A");
				dashboard.writeResults();
			}

			llAction.selectTab("Contact");
			llAction.waitUntilLoadingCompletes();

			llAction.waitUntilElementPresent("web_lable_CorrespondanceAddress");
			String actual_correspondaceAddress = llAction.getText("web_lable_CorrespondanceAddress");

			if (actual_correspondaceAddress.equalsIgnoreCase(hParams.get("C_L1") + ", " + hParams.get("C_L2") + ", "
					+ hParams.get("C_PC") + ", " + hParams.get("PI_IDType").toUpperCase())) // Rasheed to set in test
			// data
			{
				dashboard.setStepDetails("Verify Correspondance Address",
						"Correspondance Address should be " + actual_correspondaceAddress, "N/A");
				dashboard.writeResults();
			}

			llAction.selectTab("CRS");
			llAction.waitUntilLoadingCompletes();

			llAction.waitUntilElementPresent("web_table_CRS_CountryofTaxResidence");

			String getCountryOfTaxResidence = llAction.getText("web_table_CRS_CountryofTaxResidence");
			dashboard.setStepDetails("Verify CRS", "CRS Country of Tax Residence should be " + getCountryOfTaxResidence,
					"N/A");
			if (getCountryOfTaxResidence.equalsIgnoreCase(hParams.get("C_Town"))) {

				dashboard.writeResults();
			}

			dashboard.setStepDetails("Certification Recieved Date", "Certification recieved date should be displayed",
					"N/A");
			String certificationRecvdDate = llAction.getAttribute("web_txt_CRSSelfCertifcationRecievedDate", "value");
			if (certificationRecvdDate.equalsIgnoreCase(hParams.get("CRS_TaxR"))) {

				dashboard.writeResults();
			}

			llAction.clickElement("web_btn_seacrchParty_Exit");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void fillPartyAdditionalDetails(Hashtable<String, String> hParams) throws Exception// create_and_Maintain_Party_Step2
	// page
	{
		try {

			llAction = new FPMS_Actions();
			String type = hParams.get("PI_PartyType").toUpperCase().trim();
			llAction.selectByVisibleText("web_lst_Party_Role", hParams.get("PartyRole"));
			if (type.equalsIgnoreCase(ORGANIZATION)) {
				llAction.enterValue("web_txt_OrganizationName", hParams.get("PI_Name"));
				llAction.selectByVisibleText("web_lst_OrganizationType", hParams.get("OrganizationType"));
				llAction.selectByVisibleText("web_lst_OrganizationIDType", hParams.get("PI_IDTypeNational"));
				llAction.enterValue("web_txt_OrganizationIdNum", hParams.get("PI_IDNumber"));
				llAction.selectByVisibleText("web_lst_CountryofAddress", hParams.get("RegisteredCountry"));
				llAction.selectByVisibleText("web_lst_HRCCode", hParams.get("P_HRCCode"));
				llAction.selectByVisibleText("web_lst_PersonalDataSharingInternal",
						hParams.get("PersonalDataSharing_Internal"));
				llAction.selectByVisibleText("web_lst_PersonalDataSharingThirdParty",
						hParams.get("PersonalDataSharing_3rdParty"));
				llAction.selectByVisibleText("web_lst_EntityClassification", hParams.get("EntityClassification"));
				llAction.selectByVisibleText("web_lst_USFollowUp", hParams.get("P_FIND"));
			} else {
				llAction.selectByVisibleText("web_lst_IssuanceCountry", hParams.get("PI_CountryofIssuance"));
				llAction.enterValue("web_txt_Party_IDExpiryDate", hParams.get("IdExpiryDate"));
				llAction.enterValue("web_txt_la_Finexpdate", hParams.get("FinExpiryDate"));
				// Deepa_07022019: added code for Alias name
				llAction.enterValue("web_txt_alias", hParams.get("PI_Alias"));
				llAction.selectByVisibleText("web_lst_BirthCountry", hParams.get("P_COB"));
				llAction.selectByVisibleText("web_lst_CourtessyTitle", hParams.get("P_Title"));
				// llAction.selectByVisibleText("web_lst_Party_Foreign_Ind",
				// hParams.get("P_ForeignerIndicator"));
				llAction.selectByVisibleText("web_lst_Party_PR_Ind", hParams.get("P_PRIndicator"));

				llAction.selectByVisibleText("web_lst_Nationality", hParams.get("P_Nationality"));
				llAction.selectByVisibleText("web_lst_MaritalStatus", hParams.get("P_Mstatus"));
				llAction.selectByVisibleText("web_lst_Religion", hParams.get("P_Religion"));
				llAction.selectByVisibleText("web_lst_Race", hParams.get("P_Race"));
				llAction.selectByVisibleText("web_lst_HRCCode", hParams.get("P_HRCCode"));

				// Deepa_07022019: added code for personal data sharing internal and 3rd party
				llAction.selectByVisibleText("web_lst_PersonalDataSharingInternal",
						hParams.get("PersonalDataSharing_Internal"));
				llAction.selectByVisibleText("web_lst_PersonalDataSharingThirdParty",
						hParams.get("PersonalDataSharing_3rdParty"));

				// New additions

				if (hParams.get("PartyRole").equals(FPMSConstants.PROPOSER_ROLE)
						|| hParams.get("PartyRole").equals(FPMSConstants.LA_ROLE)) {
					llAction.selectByVisibleText("web_lst_ProofofAge", hParams.get("ProofOfAge"));
					llAction.selectByVisibleText("web_lst_la_CountryRes", hParams.get("CountryOfResidence"));
					Utils.sleep(2);

					llAction.enterValue("web_txt_la_height", hParams.get("Height_M"));
					Utils.sleep(2);
					llAction.enterValue("web_txt_la_weight", hParams.get("Weight_KG"));
					Utils.sleep(2);
					llAction.selectByVisibleText("web_txt_smoking", hParams.get("Smoking_IND"));
					Utils.sleep(2);

					llAction.enterValue("web_txt_JobCategoryId", hParams.get("Occupation"));
					llAction.selectByVisibleText("web_lst_PreferredLifeIND", hParams.get("PreferredLifeIND"));
					Utils.sleep(2);

					llAction.enterValue("web_txt_BasicInformation_AnnualIncome", hParams.get("AnnualIncome"));

					Utils.sleep(3);
				}
			}
			llAction.clickElement("web_pc_btn_Apply");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Enter first party details in Party tab Step2.",
					"The first party details are entered.", "N/A");
			dashboard.writeResults();

			llAction.selectTab("contact");
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				llAction.selectTab("contact");
			}
			llAction.waitUntilLoadingCompletes();
			/*
			 * if (llAction.isDisplayed("web_btn_continue", 5)) {
			 * llAction.clickElement("web_btn_continue");
			 * llAction.waitUntilLoadingCompletes(); }
			 */
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void searchPartyByPolicy(Hashtable<String, String> hParams) throws Exception {

		if (policyHandler.isPolicyEmpty()) {
			policyHandler.getPolicy().setPolicyNo(hParams.get("PolicyNo"));
		}
		String policyNo = policyHandler.getPolicy().getPolicyNo();
		try {
			llAction = new FPMS_Actions();
			llAction.selectMenuItem("Party", "Search Party");
			llAction.clickElementJs("web_radio_radioName2");
			llAction.enterValue("web_text_PolicyNo", policyNo);
			llAction.sendkeyStroke("web_text_PolicyNo", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_Btn_Search&Edit");
			dashboard.setStepDetails("Click Search and Edit button", "System should show relevant search results.",
					"N/A");
			dashboard.writeResults();
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void LinkGIRO(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			String giroRole = hParams.get("GIRORole");
			String tblGiroSearchElementKey = "web_detail_GiroSearchtblParty";
			int cPos = llAction.GetColumnPositionInTable(tblGiroSearchElementKey, "Insurance Role");
			int rPos = llAction.GetRowPositionInTable(tblGiroSearchElementKey, giroRole, cPos);
			llAction.SelectRowInTable(tblGiroSearchElementKey, rPos, cPos + 1, "a");
			llAction.waitUntilLoadingCompletes();
			llAction.maximizeWindow();
			dashboard.setStepDetails("Click on hyperlink of Party Rec No.",
					"System should display Create and Maintain Party - step 2  screen.", "N/A");
			dashboard.writeResults();
			// Selecting Payer from Roles
			llAction.clickLinkByText("Roles");
			if (policyHandler.isPolicyEmpty()) {
				policyHandler.getPolicy().setPolicyNo(hParams.get("PolicyNo"));
			}
			llAction.waitUntilLoadingCompletes();
			String tblElementKey = "web_detail_Girotbl_PolicyList";
			int colPos = llAction.GetColumnPositionInTable(tblElementKey, "Insurance Role");
			int rowPos = llAction.GetRowPositionInTable(tblElementKey, giroRole, colPos);
			llAction.SelectRowInTable(tblElementKey, rowPos, colPos - 1, "a");
			llAction.waitUntilLoadingCompletes();
			llAction.selectByIndex("web_lst_AccountRecNo", 1);
			dashboard.setStepDetails("Select Account Rec No. dropdownlist",
					"System should accept the selected details.", "N/A");
			dashboard.writeResults();
			llAction.scrolldown();
			llAction.clickElement("web_Btn_Submit_Party");
			dashboard.setStepDetails("Click Submit button.", "System should displays  Inquiry Party screen.", "N/A");
			dashboard.writeResults();
			llAction.switchtoChildWindow("Inquiry Party");
			llAction.waitUntilElementPresent("web_searchpartyBtn_Exit_Party");
			llAction.clickElement("web_searchpartyBtn_Exit_Party");
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void updateparty(Hashtable<String, String> hParams, String role) throws Exception {

		if (role.equalsIgnoreCase("Life Assured")) {
			int colPos = llAction.GetColumnPositionInTable("web_am_tbl_LifeAssured", "Name");

			List<String> LAList = llAction.GetAllTextUnderColumnInTable("web_am_tbl_LifeAssured", colPos, "");
			for (int i = 0; i < LAList.size(); i++) {

				llAction.SelectRowInTable("web_am_tbl_LifeAssured", i + 2, colPos, "a");
				llAction.waitUntilLoadingCompletes();
				llAction.handleCertificateErrors();
				llAction.waitUntilLoadingCompletes();
				llAction.switchtoChildWindow("Life Assured Information");
				llAction.maximizeWindow();
				String[] height = hParams.get("Height").split(FPMSConstants.COMMA_SEPERATOR);
				String[] weight = hParams.get("Weight").split(FPMSConstants.COMMA_SEPERATOR);
				llAction.enterValue("web_txt_height", height[i]);
				llAction.enterValue("web_txt_weight", weight[i]);
				llAction.clickElement("web_benefits_mySubmit");
				llAction.switchtoChildWindow("Amendment");
				llAction.switchtoFrame(1);
			}

		}
	}

	private void addAccountInformation(Hashtable<String, String> hParams) {
		try {
			if(!StringUtils.isEmpty(hParams.get("AccountNo"))) {
				llAction.clickLinkByText("Account");
				dashboard.setStepDetails("Click on Accounts tab", "System should display Bank Account screen.", "N/A");
				dashboard.writeResults();

				String[] accountNo = hParams.get("AccountNo").split(FPMSConstants.COMMA_SEPERATOR);
				String[] bankCode = hParams.get("BankCode").split(FPMSConstants.COMMA_SEPERATOR);
				String[] branchCode = hParams.get("BranchCode").split(FPMSConstants.COMMA_SEPERATOR);
				String[] actHolderName = hParams.get("AccountHolderFullName").split(FPMSConstants.COMMA_SEPERATOR);
				String[] holderID = hParams.get("AccountHolderID").split(FPMSConstants.COMMA_SEPERATOR);
				String[] self = hParams.get("Self").split(FPMSConstants.COMMA_SEPERATOR);
				String[] debitcredit = hParams.get("Debit/Credit").split(FPMSConstants.COMMA_SEPERATOR);
				String[] accountStatus = hParams.get("AccountStatus").split(FPMSConstants.COMMA_SEPERATOR);
				String[] approvalStatus = hParams.get("AccountApprovalStatus").split(FPMSConstants.COMMA_SEPERATOR);
				String[] idType = hParams.get("AccountHolderIDType").split(FPMSConstants.COMMA_SEPERATOR);
				for (int i = 0; i < accountNo.length; i++) {
					llAction.enterValue("web_txt_AccountNo", accountNo[i]);
					llAction.enterValue("web_txt_BankCode", bankCode[i]);
					llAction.enterValue("web_txt_BranchCode", branchCode[i]);
					llAction.enterValue("web_txt_fullName", actHolderName[i]);
					llAction.enterValue("web_txt_AccountHolderID", holderID[i]);
					llAction.selectByVisibleText("web_lst_Self", self[i]);
					llAction.selectByVisibleText("web_lst_DebitCredit", debitcredit[i]);
					llAction.selectByVisibleText("web_lst_AccountStatus", accountStatus[i]);
					llAction.selectByVisibleText("web_lst_AccountApprovalStatus", approvalStatus[i]);
					llAction.selectByVisibleText("web_lst_AccountHolderIDType", idType[i]);
					llAction.clickElementJs("web_btn_Apply");
					llAction.waitUntilLoadingCompletes();
				}
				dashboard.setStepDetails("Bank Details entered", "Bank Details should be added Successfully", "N/A");
				dashboard.writeResults();
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
}
