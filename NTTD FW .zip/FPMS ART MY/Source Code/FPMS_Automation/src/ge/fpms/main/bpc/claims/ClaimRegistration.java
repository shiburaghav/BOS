package ge.fpms.main.bpc.claims;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.Claims;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.ProductConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.common.FpmsSystem;
import ge.fpms.main.bpc.common.Query;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class ClaimRegistration extends BusinessComponent {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private Claims claims;

	public ClaimRegistration() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		claims = Claims.getInstance();
	}

	public void caseRegistration(Hashtable<String, String> hParams) throws Exception {

		try {
			if (hParams.get("ProductType").equalsIgnoreCase(ProductConstants.ILP)) {
				claims.setSysDate(setSystemDate(getFundTransactionDate(hParams)));
			} else {
				claims.setSysDate(getSystemDate());
			}
			searchForLifeAssured(hParams);
			enterClaiminformation(hParams);
			enterReporterInformationandsubmit(hParams);
			submitAndCaptureCaseNumber(hParams);
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void searchForLifeAssured(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("Claim", "Case Registration");
			llAction.clickElement("web_registration_link_lifeassurename");
			llAction.waitUntilLoadingCompletes();
			llAction.handleCertificateErrors();
			llAction.waitUntilLoadingCompletes();

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_SearchLA);
			llAction.enterValue("web_registration_txt_policynumber", hParams.get("PolicyNumber"));
			llAction.sendkeyStroke("web_registration_txt_policynumber", Keys.ENTER);			
			llAction.clickElement("web_registration_btn_search");
			llAction.waitUntilLoadingCompletes();	
			Utils.editXpath("web_registration_radio_lifeAssured", "Select_Life_assured", new String[] {hParams.get("LifeAssured")});
			llAction.clickElement("Select_Life_assured");
			dashboard.setStepDetails("Click on submit after selecting life assured ", "Life assured should be selected", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_registration_btn_submit");
			llAction.switchtoChildWindow("Case Registration");
		}

		catch (Exception ex) {
			ex.printStackTrace();
			throw new BPCException(ex);
		}
	}

	public void enterClaiminformation(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.sendkeyStroke("web_registration_link_lifeassurename", Keys.ENTER);
			Utils.sleep(2);

			String eventDate = hParams.get("EventDate");
			String notificationDate = hParams.get("NotificationDate");
			if (StringUtils.isEmpty(eventDate) && !claims.isSysDateEmpty()) {
				eventDate = claims.getSysDate();
			}
			if (StringUtils.isEmpty(notificationDate) && !claims.isSysDateEmpty()) {
				notificationDate = claims.getSysDate();
			}

			llAction.enterValue("web_registration_txt_eventdate", eventDate);
			llAction.selectByVisibleText("web_registration_lst_typeofclaim", hParams.get("TypeOfClaim"));
			llAction.waitUntilLoadingCompletes();
			llAction.waitUntilElementPresent("web_registration_txt_notificationdate");
			llAction.enterValue("web_registration_txt_notificationdate", notificationDate);			
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			ex.printStackTrace();
			throw new BPCException(ex);
		}
	}

	public void enterReporterInformationandsubmit(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.enterValue("web_registration_txt_reportername", hParams.get("ReporterName"));
			llAction.selectByVisibleText("web_registration_lst_reportvia", hParams.get("ReportVia"));
			llAction.selectByVisibleText("web_registration_lst_relationwith", hParams.get("RelationWithLifeAssured"));
			llAction.enterValue("web_registration_txt_contactnumber", hParams.get("ContactNumber"));
			llAction.enterValue("web_registration_txt_hpnumber", hParams.get("HPNumber1"));
			llAction.selectByVisibleText("web_registration_lst_sms", hParams.get("SMS1"));
			llAction.enterValue("web_registration_txt_emailaddress", hParams.get("EmailAddress"));
			llAction.enterValue("web_registration_txt_address", hParams.get("Address"));
			llAction.enterValue("web_registration_txt_postalcode", hParams.get("PostalCode"));
			llAction.enterValueWithoutClear("web_registration_branchReceived", hParams.get("BranchReceived"));
			llAction.enterValueWithoutClear("web_registration_txt_agentSMS", hParams.get("AgentSMS"));
			llAction.enterValueWithoutClear("web_registration_txt_claimOfficer", hParams.get("ClaimOfficer"));
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void submitAndCaptureCaseNumber(Hashtable<String, String> hParams) throws Exception {
		try {
			Long timeout = (long) 0;
			dashboard.setStepDetails("Fill in the required details for case registration",
					"System should accept input details", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_registration_btn_submit");
			llAction.acceptAlert(timeout);
			llAction.waitUntilLoadingCompletes();
			String CaseDetails = llAction.getText("web_registration_successMsg");
			String CaseNumber = CaseDetails.substring(CaseDetails.indexOf("Individual:") + "Case Number".length(), CaseDetails.length()).trim();
			Claims clm = FPMSManager.getInstance().getCaseHandler();
			clm.setCaseNumber(CaseNumber);
			dashboard.setStepDetails("Capture claim case number",
					"Case number is created  '" + CaseNumber + "' Successfully", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_registration_btn_exit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public String setSystemDate(String effectiveDate) throws Exception {
		FpmsSystem system = new FpmsSystem();
		system.changeSystemDate(effectiveDate);
		return effectiveDate;
	}

	public String getSystemDate() throws Exception {
		String sysDate = llAction.getText("web_span_systemDateTime").split(" ")[0];
		Format formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(sysDate);
		sysDate = formatter.format(date1);
		return sysDate;
	}

	public String getFundTransactionDate(Hashtable<String, String> hParams) throws Exception {
		Query query = new Query();
		String effectiveDate = query.queryCSInfo_TransactionDate(hParams);
		return effectiveDate;
	}
}
