package ge.fpms.main.bpc.nbu;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.components.Party;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class InitialRegistrationComponent extends Registration {
	private static final String SEARCH_PARTY = "Search";
	private static final String CREATE_PARTY = "Create";
	private static final String MULTIPLE_PARTY = "Multiple";
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	
	public InitialRegistrationComponent() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}
	
	public void InitialRegistration(Hashtable<String, String> hParams) throws Exception {
		try {
			enterBasicInformation(hParams);
			String proposerPartyIndicator = hParams.get("PartyInd");
		
			boolean thirdParty = (!StringUtils.isEmpty(hParams.get("ThirdPartyInd"))) && hParams.get("ThirdPartyInd").equalsIgnoreCase("Y") ? true : false;
			
			if(proposerPartyIndicator.equalsIgnoreCase(SEARCH_PARTY)){
				addProposer(hParams);
			}else if(proposerPartyIndicator.equalsIgnoreCase(CREATE_PARTY)){
				createParty(hParams.get("ProposerPartyIds"));
			}
			
			addAllLifeAssured(hParams, thirdParty);
			addPaymentMethod(hParams);
			addCommission(hParams);
			addComment(hParams);
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	/**
	 * Add a proposer
	 * @param hParams
	 */
	private void addProposer(Hashtable<String, String> hParams) {
		try {
			String companyIndicator = hParams.get("CompanyInd");
			boolean companyInd = isOrganization(companyIndicator);
			String proposerName = hParams.get("ProposerPartyName");
			String proposerId = hParams.get("ProposerPartyIDNumber");
			if (StringUtils.isEmpty(policyHandler.getPolicy().getProposerId()) && !StringUtils.isEmpty(proposerId))
			{
				policyHandler.getPolicy().setProposerName(proposerName);
				policyHandler.getPolicy().setProposerId(proposerId);
			}
			if (companyInd) {
				loadCompanyProposalInformation(companyIndicator);
			} else {
				loadIndividualProposalInformation(hParams);
			}

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_INITIAL_REGISTRATION);
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	/**
	 * loadCompanyProposalInformation - Here company is the proposer
	 * @param companyIndicator
	 * @param companyName
	 * @param companyId
	 */
	private void loadCompanyProposalInformation(String companyIndicator) {

		try {
			llAction.enterValue("web_text_CompanyInd", companyIndicator);

			llAction.clickElementJs("web_btn_AddProposer");
			llAction.waitUntilLoadingCompletes();
			llAction.handleCertificateErrors();
			llAction.waitUntilLoadingCompletes();
			searchByCompanyID(policyHandler.getPolicy().getProposerName(),policyHandler.getPolicy().getProposerId());
			llAction.waitTillAllPopUpWindowsClosed();
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}
	/**
	 * loadIndividualProposalInformation - Here proposer is an individual
	 * @param hParams
	 */
	private void loadIndividualProposalInformation(Hashtable<String, String> hParams){
	
			try {
				llAction.clickElementJs("web_btn_AddProposer");
			
				llAction.waitUntilLoadingCompletes();
				llAction.handleCertificateErrors();
				llAction.waitUntilLoadingCompletes();
				searchIndividualProposer(hParams);
				llAction.waitTillAllPopUpWindowsClosed();
			} catch (Exception e) {
			
				throw new BPCException(e);
			}
	
	}
	/**
	 * Basic information of initial registration
	 * @param hParams
	 * @throws Exception
	 */
	private void enterBasicInformation(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("NBD", "Initial Registration", "Initial Reg");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_list_NBD_BI_ProposalNo1", hParams.get("ProposalNo"));

			String proposalDate = hParams.get("ProposalDate");
			if(StringUtils.isEmpty(proposalDate)){
				proposalDate = getApplicationCurrentDate();
			}
			llAction.enterValue("web_list_NBD_BI_ProposalDate", proposalDate);

			llAction.enterValue("web_txt_NBD_BI_IACNo", hParams.get("IACNo"));

			llAction.enterValue("web_list_NBD_BI_MainBCode1", hParams.get("MainBenefitCode"));

			llAction.enterValue("web_list_NBD_BI_BSumAssured", hParams.get("BasicSumAssured"));

			llAction.enterValue("web_list_NBD_BI_IniPremiumAmt", hParams.get("InitialPremiumAmount"));

			llAction.enterValue("web_list_NBD_BI_PayFreq1", hParams.get("PaymentFrequency"));

			llAction.enterValue("web_txt_Fact_Find_Ind", hParams.get("FactFindInd"));

			//llAction.enterValue("web_txt_CKAResult", hParams.get("CKAResult"));
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Basic Information entered",
					"Policy Details should be entered Successfully", "N/A");
			dashboard.writeResults();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * searchByCompanyID - search for a proposer - company
	 * @param companyName
	 * @param companyId
	 * @throws Exception
	 */
	private void searchByCompanyID(String companyName, String companyId) throws Exception {
		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_COMPANY_PROPOSAL_INFORMATION);
		
		llAction.enterValue("web_txt_company_name",companyName);
		llAction.clickElement("web_btn_company_search");
		dashboard.setStepDetails("Company Proposer Information",
				"Company Proposer Information should be entered", "N/A");
		dashboard.writeResults();
		llAction.waitUntilLoadingCompletes();
		llAction.handleCertificateErrors();
		llAction.waitUntilLoadingCompletes();
		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_EX_COMPANY_PROPOSAL_INFORMATION);
		Utils.sleep(5);
		int colPos = llAction.GetColumnPositionInTable("web_tbl_search_company", "name",2);
		int rowPos = llAction.GetRowPositionInTable("web_tbl_search_company",companyName, colPos, 2);
		llAction.SelectRowInTable("web_tbl_search_company", rowPos, colPos-3, "input");
		llAction.clickElement("web_btn_PartySubmit");
		Utils.sleep(5);
		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_COMPANY_PROPOSAL_INFORMATION);
		Utils.sleep(5);
		llAction.clickElement("web_txt_company_submit_button");
		
		if (llAction.isDisplayed("web_btn_continue", 5)) {
			llAction.clickElement("web_btn_continue");
			llAction.waitUntilLoadingCompletes();
		}
	}
	
	
	/**
	 * searchIndividualProposer - search for an individual proposer
	 * @param hParams
	 * @throws Exception
	 */
	
	private void searchIndividualProposer(Hashtable<String, String> hParams) throws Exception {
		try {
		
			searchParty(FPMSConstants.WINDOW_TITLE_IDV_PROPOSER_INFOMATION, policyHandler.getPolicy().getProposerId(),
			hParams.get("ProposerPartyIDType"), policyHandler.getPolicy().getProposerName());
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_EX_CUSTOMER_INFORMATION);
			Utils.sleep(5);
			Utils.editXpath("web_radio_selectExistingParty", "web_radio_selectProposer",
					new String[] { policyHandler.getPolicy().getProposerName().toUpperCase() });
			llAction.clickElement("web_radio_selectProposer");
			
			
			
			/*int colPos = llAction.GetColumnPositionInTable("web_ExistingCustInfo_CustCount", "name",2);
			int rowPos = llAction.GetRowPositionInTable("web_ExistingCustInfo_CustCount", policyHandler.getPolicy().getProposerName(), colPos, 2);
			llAction.SelectRowInTable("web_ExistingCustInfo_CustCount", rowPos, colPos-3, "input");*/
			
			//llAction.clickElementJs("web_radio_radioName1");

			llAction.clickElement("web_btn_PartySubmit");
			Utils.sleep(5);
			/*
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
			}*/
			llAction.switchtoChildWindow("Individual Proposer Information");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_mySubmit");
			
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				//llAction.waitUntilLoadingCompletes();
			}
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	/**
	 * addAllLifeAssured - there can be more than one LA in case of third party.
	 * @param hParams
	 * @param thirdParty
	 * @throws Exception
	 */
	private void addAllLifeAssured(Hashtable<String, String> hParams, boolean thirdParty) throws Exception {
		FPMSManager manager = FPMSManager.getInstance();
		if (thirdParty) {
			llAction.enterValue("web_txt_thirdparty_ind", hParams.get("ThirdPartyInd"));
			String laPartyIndicator = hParams.get("LAPartyInd");
			String []allLaPartyIds = hParams.get("LAPartyIds").split(FPMSConstants.COMMA_SEPERATOR);
					
				String [] laPartyType =  hParams.get("LAPartyIDType").split(FPMSConstants.COMMA_SEPERATOR);
				String [] laPartyId =  hParams.get("LAPartyIDNumber").split(FPMSConstants.COMMA_SEPERATOR);
				String [] laPartyName =  hParams.get("LAName").split(FPMSConstants.COMMA_SEPERATOR);
				String [] relationship =  hParams.get("RelationshipwithProposer").split(FPMSConstants.COMMA_SEPERATOR);
				
				if(laPartyIndicator.equalsIgnoreCase(CREATE_PARTY) ) {
					for(String partyId : allLaPartyIds){
						createParty(partyId);
					}
				}else if(laPartyIndicator.equalsIgnoreCase(SEARCH_PARTY))
				{
			
					for(int i=0; i<relationship.length;i++){
						String id = policyHandler.getPolicy().getLifeAssuredId(i);
						if(StringUtils.isEmpty(id)){
							policyHandler.getPolicy().setLifeAssured(laPartyId[i],laPartyName[i]);
							id = laPartyId[i];
						}
						
						addLifeAssured(id, laPartyType[i], policyHandler.getPolicy().getLifeAssuredName(id), relationship[i]);
					}
				
				}
				else if(laPartyIndicator.equalsIgnoreCase(MULTIPLE_PARTY)){
					int i=0;
					for(String partyId : allLaPartyIds){
						
						if(StringUtils.isEmpty(partyId)){
							addLifeAssured(laPartyId[i], laPartyType[i], laPartyName[i], relationship[i]);
						}else{
							createParty(partyId);
						}
						
					}
				}
			}
			else {
				addLifeAssured(policyHandler.getPolicy().getProposerId(), hParams.get("ProposerPartyIDType"), policyHandler.getPolicy().getProposerName(), hParams.get("RelationshipwithProposer"));
			}

	}
	/**
	 * add a single LA
	 * @param partyNumberId
	 * @param partyType
	 * @param partyName
	 * @param relationShipWithProposer
	 * @throws Exception
	 */
	private void addLifeAssured(String partyNumberId,
			String partyType, String partyName, String relationShipWithProposer) throws Exception {
		try {
			//Utils.sleep(6);
			
			llAction.waitUntilElementPresent("web_Btn_AddLifeAssured");
			llAction.clickElement("web_Btn_AddLifeAssured");
			llAction.waitUntilLoadingCompletes();
			llAction.handleCertificateErrors();
			searchParty(FPMSConstants.WINDOW_TITLE_LA_INFORMATION, partyNumberId, partyType, partyName);
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_EX_CUSTOMER_INFORMATION);
			Utils.editXpath("web_radio_selectExistingParty", "web_radio_addLifeAssured",
					new String[] { partyName.toUpperCase() });
			llAction.clickElement("web_radio_addLifeAssured");
			llAction.clickElementJs("web_btn_PartySubmit");
			Utils.sleep(6);

			// Add LA Information
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_LA_INFORMATION);
			llAction.enterValue("web_txt_Relationship_with_Proposer", relationShipWithProposer);
			dashboard.setStepDetails("Life Assured details",
					"Entered Life Assured Details successfully entered.", "N/A");
			dashboard.writeResults();
			Utils.sleep(2);
			llAction.clickElementJs("web_btn_lifeassured_submit");
			Utils.sleep(10);
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
			}
			Utils.sleep(6);
			if (llAction.isDisplayed("web_btn_continue", 5))
				llAction.clickElement("web_btn_continue"); 
			llAction.closeWindow(FPMSConstants.WINDOW_TITLE_LA_INFORMATION);
			llAction.switchtoDefaultWindow();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}


	private void addCommission(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.enterValue("web_txt_SplitCommissionInd", hParams.get("SplitCommissionInd"));
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void addComment(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.enterValue("web_txt_Initial_Reg_Comment", FPMSConstants.COMMENT_INITIAL_REG);

			llAction.clickElement("web_text_InitialRegistration_submit");
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();

			String policyDetails = llAction.getText("web_lbl_successMsg");
			String policyNumber = policyDetails
					.substring(policyDetails.indexOf("Policy No is") + "Policy No is".length(), policyDetails.length())
					.trim();

			policyHandler.getPolicy().setPolicyNo(policyNumber);
			dashboard.setStepDetails("Initial registration completed",
					"Policy Number is created  '" + policyNumber + "' Successfully", "N/A");
			dashboard.writeResults();

			Utils.sleep(4);
			llAction.clickElement("web_btn_initialRegistration_Back");

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void addPaymentMethod(Hashtable<String, String> hParams) throws Exception{
		llAction.selectByVisibleText("web_ir_lst_PaymentMode", hParams.get("IR_PaymentMethod"));
	}
}
