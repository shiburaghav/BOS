package ge.fpms.main.bpc.csd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class PartialWithdraw {
	private FPMS_Actions llAction;

	private DashboardHandler dashboard;

	public PartialWithdraw() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void FillPartialWithdrawFundsByUnits(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			int colPos = llAction.GetColumnPositionInTable("web_tbl_BenefitInformation", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_BenefitInformation", hParams.get("BenefitCode"),
					colPos);
			if (llAction.getRowCountInTable("web_tbl_BenefitInformation") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitInformation", rowPos, colPos - 2, "input");
			}
			CSDHelper.getInstance().captureChange("Partial Withdraw", "BeforeChange");
			llAction.clickElement("web_btn_PartialWithdrawByUnits");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();
			llAction.waitUntilLoadingCompletes();
			int fundCount = llAction.getRowCountInTable("web_tbl_WithdrawFundByUnits");
			int unitsCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByUnits", "Withdraw units");
			int currentUnitsCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByUnits", "Current Units");
			List<String> currentUnits = llAction.GetAllTextUnderColumnInTable("web_tbl_WithdrawFundByUnits",
					currentUnitsCol, "/input");
			int j = 1;
			for (int i = 1; i < fundCount; i++)

			{
				if (!(currentUnits.get(i - 1)).equals("0.00")) {
					String withdrawUnits = hParams.get(FPMSConstants.WITHDRAWUNITS + j);
					if (withdrawUnits != null) {
						llAction.enterTextInTable("web_tbl_WithdrawFundByUnits", i + 1, unitsCol, withdrawUnits,
								"/input");
						llAction.sendkeyStroke("web_txt_WithdrawUnits", Keys.ENTER);
						llAction.waitUntilLoadingCompletes();
					}
					j++;
				}
			}
			dashboard.setStepDetails("Enter Withdraw units for Partial withdraw",
					"Withdraw units for Partial withdraw are entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Submit_FundInfo");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("Partial Withdraw", "AfterChange");
			llAction.clickElement("web_btn_Submit_PartialWithdraw");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void FillPartialWithdrawFundsByValue(Hashtable<String, String> hParams) throws Exception {

		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			int colPos = llAction.GetColumnPositionInTable("web_tbl_BenefitInformation", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_BenefitInformation", hParams.get("BenefitCode"),
					colPos);
			if (llAction.getRowCountInTable("web_tbl_BenefitInformation") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitInformation", rowPos, colPos - 2, "input");
			}
			CSDHelper.getInstance().captureChange("Partial Withdraw", "BeforeChange");
			llAction.clickElement("web_btn_PartialWithdrawByValue");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();
			llAction.waitUntilLoadingCompletes();
			int fundCount = llAction.getRowCountInTable("web_tbl_WithdrawFundByValue");
			int valueCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByValue", "Withdraw Value");
			int currentUnitsCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByValue", "Current Units");
			List<String> currentUnits = llAction.GetAllTextUnderColumnInTable("web_tbl_WithdrawFundByValue",
					currentUnitsCol, "/input");
			int j = 1;
			for (int i = 1; i < fundCount; i++)

			{
				if (!(currentUnits.get(i - 1)).equals("0.00")) {
					String withdrawValue = hParams.get(FPMSConstants.WITHDRAWVALUE + j);
					if (withdrawValue != null) {
						llAction.enterTextInTable("web_tbl_WithdrawFundByValue", i + 1, valueCol, withdrawValue,
								"/input");
						llAction.sendkeyStroke("web_tbl_WithdrawFundByValue", Keys.ENTER);
						llAction.waitUntilLoadingCompletes();
					}
					j++;
				}
			}
			dashboard.setStepDetails("Enter Withdraw Value for Partial withdraw",
					"Withdraw Value for Partial withdraw are entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Submit_PartialWithdraw");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();// unexpected warnings or invalid test data is handled here
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("Partial Withdraw", "AfterChange");
			llAction.clickElement("web_btn_Submit_PartialWithdraw");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void FillPartialWithdrawFundsValidatePolicyalteration(Hashtable<String, String> hParams) throws Exception {
		try {
			String message1 = hParams.get("WarningErrorMessage1");/* Get expected warning message from Test Data */
			String message2 = hParams.get("WarningErrorMessage2");
			String withdrawMethod = hParams.get("Withdrawby");
			// To validate error messages after Enter Information
			if (message1 != null && message1 != "") {
				CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message1);
			}
			if (llAction.isDisplayed("web_btn_continue", 5))
				llAction.clickElement("web_btn_continue");// unexpected warning messages are handled here
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			int colPos = llAction.GetColumnPositionInTable("web_tbl_BenefitInformation", "Benefit");

			int rowPos = llAction.GetRowPositionInTable("web_tbl_BenefitInformation", hParams.get("BenefitCode"),
					colPos);
			if (llAction.getRowCountInTable("web_tbl_BenefitInformation") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitInformation", rowPos, colPos - 2, "input");
			}
			if (withdrawMethod.equalsIgnoreCase(FPMSConstants.WITHDRAWBYVALUE)) {
				CSDHelper.getInstance().captureChange("Partial Withdraw", "BeforeChange");
				llAction.clickElement("web_btn_PartialWithdrawByValue");
				llAction.waitUntilLoadingCompletes();
				// To validate error messages after Partial Withdraw By Value button
				if (message2 != null && message2 != "") {
					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message2);
				}
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");// unexpected warning messages are handled here
				llAction.waitUntilLoadingCompletes();
				int fundCount = llAction.getRowCountInTable("web_tbl_WithdrawFundByValue");
				int valueCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByValue", "Withdraw Value");
				int currentUnitsCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByValue", "Current Units");
				List<String> currentUnits = llAction.GetAllTextUnderColumnInTable("web_tbl_WithdrawFundByValue",
						currentUnitsCol, "/input");
				int j = 1;
				for (int i = 1; i < fundCount; i++)

				{
					if (!(currentUnits.get(i - 1)).equals("0.00")) {
						String withdrawValue = hParams.get(FPMSConstants.WITHDRAWVALUE + j);
						if (withdrawValue != null) {
							llAction.enterTextInTable("web_tbl_WithdrawFundByValue", i + 1, valueCol, withdrawValue,
									"/input");
							llAction.sendkeyStroke("web_tbl_WithdrawFundByValue", Keys.ENTER);
							llAction.waitUntilLoadingCompletes();
						}
						j++;
					}

				}
				dashboard.setStepDetails("Enter Withdraw Value for Partial withdraw",
						"Withdraw Value for Partial withdraw are entered", "N/A");
				dashboard.writeResults();
				// Utils.sleep(5); commented after code review
				llAction.clickElement("web_btn_Submit_PartialWithdraw");// submitting the values entered
				llAction.waitUntilLoadingCompletes();
			} else {
				CSDHelper.getInstance().captureChange("Partial Withdraw", "BeforeChange");
				llAction.clickElement("web_btn_PartialWithdrawByUnits");
				llAction.waitUntilLoadingCompletes();
				// To validate error messages after Partial Withdraw By Units button
				if (message2 != null && message2 != "") {

					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message2);

				}
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");// unexpected warning messages are handled here
				llAction.waitUntilLoadingCompletes();
				int fundCount = llAction.getRowCountInTable("web_tbl_WithdrawFundByUnits");
				int unitsCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByUnits", "Withdraw units");
				int currentUnitsCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByUnits", "Current Units");
				List<String> currentUnits = llAction.GetAllTextUnderColumnInTable("web_tbl_WithdrawFundByUnits",
						currentUnitsCol, "/input");
				int j = 1;
				for (int i = 1; i < fundCount; i++)

				{
					if (!(currentUnits.get(i - 1)).equals("0.00")) {
						String withdrawUnits = hParams.get(FPMSConstants.WITHDRAWUNITS + j);
						if (withdrawUnits != null) {
							llAction.enterTextInTable("web_tbl_WithdrawFundByUnits", i + 1, unitsCol, withdrawUnits,
									"/input");
							llAction.sendkeyStroke("web_txt_WithdrawUnits", Keys.ENTER);
							llAction.waitUntilLoadingCompletes();
						}
						j++;
					}
				}
				dashboard.setStepDetails("Enter Withdraw units for Partial withdraw",
						"Withdraw units for Partial withdraw are entered", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_Submit_FundInfo");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Submit the fund values entered",
						"Submit button is clicked after entering the fund details", "N/A");
				dashboard.writeResults();
			}
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				{
					llAction.clickElement("web_btn_continue");// unexpected warning messages or invalid test data are
					// handled here
					llAction.waitUntilLoadingCompletes();
				}
			}

			CSDHelper.getInstance().captureChange("Partial Withdraw", "AfterChange");
			llAction.clickElement("web_btn_Submit_PartialWithdraw");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				if (message2 != null && message2 != "") {

					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message2);
				}
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
			}
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validatePendingTransactionFunds(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			String message1 = hParams.get("WarningErrorMessage1");/* Get expected warning message from Test Data */
			String message2 = hParams.get("WarningErrorMessage2");
			String funds = hParams.get("DelistedFundCodes");
			String withdrawMethod = hParams.get("Withdrawby");
			// To validate error messages after Enter Information
			if (message1 != null && message1 != "") {
				CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message1);
			}
			if (llAction.isDisplayed("web_btn_continue", 5))
				llAction.clickElement("web_btn_continue");// unexpected warning messages are handled here
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			int colPos = llAction.GetColumnPositionInTable("web_tbl_BenefitInformation", "Benefit");

			int rowPos = llAction.GetRowPositionInTable("web_tbl_BenefitInformation", hParams.get("BenefitCode"),
					colPos);
			if (llAction.getRowCountInTable("web_tbl_BenefitInformation") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitInformation", rowPos, colPos - 2, "input");
			}
			if (withdrawMethod.equalsIgnoreCase(FPMSConstants.WITHDRAWBYVALUE)) {
				CSDHelper.getInstance().captureChange("Partial Withdraw", "BeforeChange");
				llAction.clickElement("web_btn_PartialWithdrawByValue");
				llAction.waitUntilLoadingCompletes();
				// To validate error messages after Partial Withdraw By Value button
				if (message2 != null && message2 != "") {
					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message2);
				}
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");// unexpected warning messages are handled here
				llAction.waitUntilLoadingCompletes();
				int fundCount = llAction.getRowCountInTable("web_tbl_WithdrawFundByValue");
				int fundCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByValue", "Fund Code");
				int valueCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByValue", "Withdraw Value");
				List<String> fundCodeList = new ArrayList<String>();
				String[] parts = funds.split(",");
				fundCodeList = Arrays.asList(parts);
				int validatedfunds = 0;
				for (int j = 0; j < fundCodeList.size(); j++) {
					for (int i = 1; i < fundCount; i++) {
						String tableFundCode = llAction.GetTextFromTable("web_tbl_WithdrawFundByValue", i + 1, fundCol);
						if (tableFundCode.trim().equalsIgnoreCase(fundCodeList.get(j)))

						{
							WebElement withdrawValue = llAction.getElementAt("web_tbl_WithdrawFundByValue", i + 1,
									valueCol, "/input");
							if (withdrawValue.getAttribute("readOnly").equalsIgnoreCase("true"))
								validatedfunds++;
						}
					}
				}
				if (validatedfunds == fundCodeList.size()) {
					dashboard.setStepDetails(" Withdraw Values for Partial withdraw are not editable",
							"Withdraw Values should not be editable for delisted funds ", "N/A");
					dashboard.writeResults();
				} else {
					dashboard.setFailStatus(new BPCException("Withdraw Values are editable for delisted funds"));
					dashboard.writeResults();
				}
			}

			else {
				CSDHelper.getInstance().captureChange("Partial Withdraw", "BeforeChange");
				llAction.clickElement("web_btn_PartialWithdrawByUnits");
				llAction.waitUntilLoadingCompletes();
				int fundCount = llAction.getRowCountInTable("web_btn_PartialWithdrawByUnits");
				int fundCol = llAction.GetColumnPositionInTable("web_btn_PartialWithdrawByUnits", "Fund Code");
				int unitsCol = llAction.GetColumnPositionInTable("web_tbl_WithdrawFundByUnits", "Withdraw units");
				List<String> fundCodeList = new ArrayList<String>();
				String[] parts = funds.split(",");
				fundCodeList = Arrays.asList(parts);
				int validatedfunds = 0;
				for (int j = 0; j < fundCodeList.size(); j++) {
					for (int i = 1; i < fundCount; i++) {
						String tableFundCode = llAction.GetTextFromTable("web_btn_PartialWithdrawByUnits", i + 1,
								fundCol);
						if (tableFundCode.trim().equalsIgnoreCase(fundCodeList.get(j)))

						{
							WebElement withdrawValue = llAction.getElementAt("web_btn_PartialWithdrawByUnits", i + 1,
									unitsCol, "/input");
							if (withdrawValue.getAttribute("readOnly").equalsIgnoreCase("true"))
								validatedfunds++;
						}
					}
				}
				if (validatedfunds == fundCodeList.size()) {
					dashboard.setStepDetails(" Withdraw Units for Partial withdraw are not editable",
							"Withdraw Units should not be editable for delisted funds ", "N/A");
					dashboard.writeResults();
				} else {
					dashboard.setFailStatus(new BPCException("Withdraw Units are editable for delisted funds"));
					dashboard.writeResults();
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateBlackoutPeriod(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			String message = hParams.get("WarningErrorMessage-PartialWithdrawSubmit");
			if (llAction.isDisplayed("web_btn_continue", 5))
				llAction.clickElement("web_btn_continue");// unexpected warning messages are handled here
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			int colPos = llAction.GetColumnPositionInTable("web_tbl_BenefitInformation", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_BenefitInformation", hParams.get("BenefitCode"),
					colPos);
			if (llAction.getRowCountInTable("web_tbl_BenefitInformation") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitInformation", rowPos, colPos - 2, "input");
			}
			CSDHelper.getInstance().captureChange("Partial Withdraw", "BeforeChange");
			llAction.clickElement("web_btn_partialWithdraw");
			if (llAction.isAlertDisplayed()) {
				dashboard.setStepDetails("Validity Date should not be a future date pop up is displayed ",
						"Validity Date should not be a future date pop up should be displayed", "N/A");
				dashboard.writeResults();
				llAction.acceptAlert();
				llAction.waitUntilLoadingCompletes();
			}
			// To validate error messages after Partial Withdraw By Value button
			if (llAction.isDisplayed("web_btn_continue", 5))
				llAction.clickElement("web_btn_continue");// unexpected warning messages are handled here
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_totalWithdrawalAmount", hParams.get("TotalWithdrawalAmount"));
			llAction.sendkeyStroke("web_txt_totalWithdrawalAmount", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Enter Total Withdrawal Amount", "Total Withdrawal Amount is entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Submit_PartialWithdraw");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				{
					llAction.clickElement("web_btn_continue");// unexpected warning messages or invalid test data are
					// handled here
					llAction.waitUntilLoadingCompletes();
				}
			}

			CSDHelper.getInstance().captureChange("Partial Withdraw", "AfterChange");
			llAction.clickElement("web_btn_Submit_PartialWithdraw");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				if (message != null && message != "") {

					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message);
				}
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
			}
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}
	public void partialWithdrawByFundCode(Hashtable<String, String> hParams) throws Exception {
		try {
			String withdrawMethod = hParams.get("Withdrawby");
			String[] fundCodes=hParams.get("FundCodes").split(FPMSConstants.COMMA_SEPERATOR);
			String[] withdrawValues=hParams.get("WithdrawValues").split(FPMSConstants.COMMA_SEPERATOR);
			String[] withdrawUnits=hParams.get("WithdrawUnits").split(FPMSConstants.COMMA_SEPERATOR);
			String[] fundCodesTupa=hParams.get("FundCodesTupa").split(FPMSConstants.COMMA_SEPERATOR);
			String[] withdrawValuesTupa=hParams.get("WithdrawValuesTupa").split(FPMSConstants.COMMA_SEPERATOR);
			String[] withdrawUnitsTupa=hParams.get("WithdrawUnitsTupa").split(FPMSConstants.COMMA_SEPERATOR);
			CSDHelper.getInstance().handleContinueButton();
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			int colPos = llAction.GetColumnPositionInTable("web_tbl_BenefitInformation", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_BenefitInformation", hParams.get("BenefitCode"),
					colPos);
			if (llAction.getRowCountInTable("web_tbl_BenefitInformation") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitInformation", rowPos, colPos - 2, "input");
			}
			CSDHelper.getInstance().captureChange("Partial Withdraw", "BeforeChange");
			if (withdrawMethod.equalsIgnoreCase(FPMSConstants.WITHDRAWBYVALUE)) {

				llAction.clickElement("web_btn_PartialWithdrawByValue");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().handleContinueButton();
				for(int i=0;i<fundCodes.length;i++)
				{
					Utils.editXpath("web_txt_WithdrawValueDummy", "web_withdraw_" + fundCodes[i] + "", new String[] {fundCodes[i]});
					llAction.enterValue("web_withdraw_" + fundCodes[i] + "",withdrawValues[i]);
					llAction.sendkeyStroke("web_withdraw_" + fundCodes[i] + "", Keys.ENTER);
					llAction.waitUntilLoadingCompletes();
				}
				if(llAction.isDisplayed("web_lst_waiveWithdrawalCharge", 2))
				{
					llAction.selectByVisibleText("web_lst_waiveWithdrawalCharge", hParams.get("WaiveWithdrawalCharge"));
					for(int i=0;i<fundCodesTupa.length;i++)
					{
						Utils.editXpath("web_txt_WithdrawValueTupaDummy", "web_withdrawTupa_" + fundCodesTupa[i] + "", new String[] {fundCodesTupa[i]});
						llAction.enterValue("web_withdrawTupa_" + fundCodesTupa[i] + "",withdrawValuesTupa[i]);
						llAction.sendkeyStroke("web_withdrawTupa_" + fundCodesTupa[i] + "", Keys.ENTER);
						llAction.waitUntilLoadingCompletes();
					}
				}	
			} else {
				llAction.clickElement("web_btn_PartialWithdrawByUnits");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().handleContinueButton();
				for(int i=0;i<fundCodes.length;i++)
				{
					Utils.editXpath("web_txt_WithdrawUnitDummy", "web_withdraw_" + fundCodes[i] + "", new String[] {fundCodes[i]});
					llAction.enterValue("web_withdraw_" + fundCodes[i] + "",withdrawUnits[i]);
					llAction.sendkeyStroke("web_withdraw_" + fundCodes[i] + "", Keys.ENTER);
					llAction.waitUntilLoadingCompletes();
				}
				if(llAction.isDisplayed("web_lst_waiveWithdrawalCharge", 2))
				{
					llAction.selectByVisibleText("web_lst_waiveWithdrawalCharge", hParams.get("WaiveWithdrawalCharge"));
					for(int i=0;i<fundCodesTupa.length;i++)
					{
						Utils.editXpath("web_txt_WithdrawUnitTupaDummy", "web_withdrawTupa_" + fundCodesTupa[i] + "", new String[] {fundCodesTupa[i]});
						llAction.enterValue("web_withdrawTupa_" + fundCodesTupa[i] + "",withdrawUnitsTupa[i]);
						llAction.sendkeyStroke("web_withdrawTupa_" + fundCodesTupa[i] + "", Keys.ENTER);
						llAction.waitUntilLoadingCompletes();
					}
				}	
			}
			dashboard.setStepDetails("Enter Withdraw values/units for Partial withdraw",
					"Withdraw values/units for Partial withdraw are entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Submit_PartialWithdraw");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Submit the fund values entered",
					"Submit button is clicked after entering the fund details", "N/A");
			dashboard.writeResults();
			CSDHelper.getInstance().handleContinueButton();
			CSDHelper.getInstance().captureChange("Partial Withdraw", "AfterChange");
			llAction.clickElement("web_btn_Submit_PartialWithdraw");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();
			CSDHelper.getInstance().endOfTransaction();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

}
