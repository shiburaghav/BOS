package ge.fpms.main.bpc.bcp;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.ReceiveCounterCollections;

public class BCPReceiveCounterCollection extends ReceiveCounterCollections {
	
	FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	private FPMS_Actions fpmsAction;
	
	public BCPReceiveCounterCollection() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	
	public void BCPReceiveCounterCollections(java.util.Hashtable<String, String> hParams) {
		try {
			ReceiveCounterCollection(hParams);
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	public void cancelCollection(Hashtable<String, String> hParams) throws Exception{
		try {
			String policyNumber = StringUtils.EMPTY;
			String amount = hParams.get("Amount");
			String collectType = hParams.get("CancelType");
			String collectReason = hParams.get("CancelReason");
			String collectionDate = hParams.get("CollectionDate");
			String collectionMethod = hParams.get("CollectionMethod");
			
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			
			llAction.selectMenuItem("Collection", "cancel collection");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_CC_txt_policyNumber");
			llAction.enterValue("web_CC_txt_policyNumber", policyNumber);
			
			llAction.clickElement("web_CC_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();
			llAction.clearText("web_txt_TransactionStartDate");
			llAction.clearText("web_txt_TransactionEndDate");
			dashboard.setStepDetails("Validate if the policy displayed in the search results",
					"Policy should be displayed in search results", "");
			dashboard.writeResults();
			
			Utils.editXpath("web_CC_Link_selectPolicy", "web_CC_Link_selectPolicy"+policyNumber+"", new String[] { policyNumber} );
			llAction.clickElement("web_CC_Link_selectPolicy"+policyNumber+"");
			llAction.waitUntilLoadingCompletes();
			
			Utils.editXpath("web_CC_check_CancelCollectionPolicy", "web_CC_check_Policy"+policyNumber+"", new String[] { policyNumber, amount, collectionDate, collectionMethod} );
			llAction.checkBox_Check("web_CC_check_Policy"+policyNumber+"");
			
			llAction.selectByVisibleText("web_CC_lst_cancelType", collectType);
			if(llAction.isEnabled("web_CC_lst_cancelReason")) {		
			llAction.selectByVisibleText("web_CC_lst_cancelReason", collectReason);
			}
			dashboard.setStepDetails("Validate if the amount and cancel type selected",
					"Amount and Cancel Type should be selected as per user", "");
			dashboard.writeResults();			
			llAction.clickElement("web_CC_btn_SubmitCancelCollection");
			llAction.waitUntilLoadingCompletes();
			if(llAction.isDisplayed("web_CC_enterCsUndo", 5)) {
				
				llAction.clickElement("web_CC_enterCsUndo");
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_CC_cancelComment", "Test");
				llAction.clickElement("web_CC_btn_reverseTransaction");
				dashboard.setStepDetails("Peform CS Undo",
						"CS Undo is successful.", "");
				dashboard.writeResults();
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_CC_btn_YesBtn");				
				dashboard.setStepDetails("Cancel Collection Status",
						"Cancel Collection status is shown.", "");
				dashboard.writeResults();				
			}
			String text = llAction.getText("web_CC_lable_successMessage");
			if(text.equals("Cancel collection is successful.")) {
				dashboard.setStepDetails("Validate the success message",
						"Cancel collection is successful.", "");
				dashboard.writeResults();
				llAction.clickElement("web_CC_btn_Return");
				llAction.waitUntilLoadingCompletes();
			}else {
				dashboard.setFailStatus(new BPCException("Cancel Collection not successful"));
			}
		}catch(Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateAmountAllocated(String collectType, String amountCollected) {
		int colPos;
		try {
			/*colPos = llAction.GetColumnPositionInTable("web_rcc_tbl_collectionAllocation", "Collect type");
			int rowPos = llAction.GetRowPositionInTable("web_rcc_tbl_collectionAllocation", collectType, colPos);
			WebElement e = llAction.getElementAt("web_rcc_tbl_collectionAllocation", rowPos, colPos - 1, "/input");
			String amtAllocated = e.getAttribute("value");
			if (!amtAllocated.equals(amountCollected)) {
				DashboardHandler.getInstance().setFailStatus(new BPCException("Amount Collected is not equal to Amount Allocated "));
			}*/
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	public void singleDraw(Hashtable<String, String> hParams) {
		fpmsAction = new FPMS_Actions();
		try {
			fpmsAction.selectMenuItem("Collection", "Receive Counter Collection");
			DashboardHandler.getInstance().setStepDetails("Select Receive Counter Collection from Colections menu",
					"The Receive Counter Collection search page is displayed.", "N/A");
			DashboardHandler.getInstance().writeResults();
			searchPolicy(hParams.get("PolicyNumber"));
			llAction.clickElement("web_rcc_btn_SingleDraw");
			llAction.enterValue("web_EB_txt_ExtractionDueDate", hParams.get("Extractiondate"));
			llAction.clickElement("web_CC_btn_SubmitCancelCollection");
			DashboardHandler.getInstance().setStepDetails("Extraction Date is entered",
					"Extraction Date is entered successfully", "N/A");
			DashboardHandler.getInstance().writeResults();
		} catch (Exception e) {
			throw new BPCException(e);
		}
		
	}
	
	public void performWaiver(Hashtable<String, String> hParams) {
		fpmsAction = new FPMS_Actions();
		try {
			String policyNumber = hParams.get("PolicyNumber");
			String interestWaiverType = hParams.get("WaiverTypeInterest");
			String nonInterestWaiverType = hParams.get("WaiverTypeNonInterest");
			String interestWaiverAmount = hParams.get("Amount");
			String nonInterestWaiverAmount = hParams.get("Amount2");
			
			
			fpmsAction.selectMenuItem("Collection", "perform waiver");
			DashboardHandler.getInstance().setStepDetails("Select Perform Waiver from Colections menu",
					"Perform Waiver search page is displayed.", "N/A");
			DashboardHandler.getInstance().writeResults();
			llAction.enterValue("web_EB_txt_PolicyNumber",hParams.get("PolicyNumber"));
			llAction.sendkeyStroke("web_EB_txt_PolicyNumber", Keys.TAB);
			
			llAction.clickElement("web_EB_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();
			DashboardHandler.getInstance().setStepDetails("Search Policy",
					"Policy search is successfull.", "N/A");
			DashboardHandler.getInstance().writeResults();
			
			int colPos = llAction.GetColumnPositionInTable("web_PW_tbl_SearchResults", "Policy Number");
			int rowPos = llAction.GetRowPositionInTable("web_PW_tbl_SearchResults", policyNumber, colPos);
			llAction.SelectRowInTable("web_PW_tbl_SearchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WaiverTypeInterest") != null && hParams.get("WaiverTypeInterest") != "") {
			Utils.editXpath("web_PW_check_InterestCharging", "web_PW_check_InterestCharging"+policyNumber+"", new String[] { interestWaiverType, "checkbox" } );
			llAction.checkBox_Check("web_PW_check_InterestCharging"+policyNumber+"");
			Utils.editXpath("web_PW_check_InterestCharging", "web_PW_check_InterestCharging"+policyNumber+"", new String[] { interestWaiverType, "text" } );
			llAction.enterValue("web_PW_check_InterestCharging"+policyNumber+"", interestWaiverAmount);
			DashboardHandler.getInstance().setStepDetails("Interest Charging Waiver type selected",
					"Interest Charging Waiver type selected successfully.", "N/A");
			DashboardHandler.getInstance().writeResults();
			}
			if (hParams.get("WaiverTypeNonInterest") != null && hParams.get("WaiverTypeNonInterest") != "") {
			Utils.editXpath("web_PW_check_Non-InterestCharging", "web_PW_check_Non-InterestCharging"+policyNumber+"", new String[] { nonInterestWaiverType, "checkbox" } );
			llAction.checkBox_Check("web_PW_check_Non-InterestCharging"+policyNumber+"");
			Utils.editXpath("web_PW_check_Non-InterestCharging", "web_PW_check_Non-InterestCharging"+policyNumber+"", new String[] { nonInterestWaiverType, "text" } );
			llAction.enterValue("web_PW_check_Non-InterestCharging"+policyNumber+"", nonInterestWaiverAmount);
			DashboardHandler.getInstance().setStepDetails("Non Interest Charging Waiver type selected",
					"Non Interest Charging Waiver type selected successfully.", "N/A");
			DashboardHandler.getInstance().writeResults();
			}
			
			llAction.selectByVisibleText("web_PW_selectWaiverReason", hParams.get("WaiverReason"));
			DashboardHandler.getInstance().setStepDetails("Waiver reason selected",
					"Waiver reason selected successfully.", "N/A");
			DashboardHandler.getInstance().writeResults();
			llAction.clickElement("web_EB_btn_SubmitExtraction");
			llAction.acceptAlert();
			llAction.clickElement("web_EB_btn_ExtractionExit");
			
			
		} catch (Exception e) {
			throw new BPCException(e);
		}
		
	}
	
	
}
