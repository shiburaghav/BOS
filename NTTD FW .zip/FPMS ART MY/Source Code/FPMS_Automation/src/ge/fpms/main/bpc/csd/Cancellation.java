package ge.fpms.main.bpc.csd;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import org.openqa.selenium.Keys;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class Cancellation {

	/*
	 * Name: Cancellation Purpose: Navigate to CS module from the Main Page and
	 * Cancel a policy Parameters:Parameter Hash table Return Value: NA Exception:
	 * BPCException
	 * 
	 * @author: Sahil Singh 0n 19/12/2018
	 */

	// private final static Logger LOGGER =
	// Logger.getLogger(Cancellation.class.getName());

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public Cancellation() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void cancelPolicy(Hashtable<String, String> hParams) throws Exception {
		try {
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage1"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilElementPresent("web_txt_ValidateDate");
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			dashboard.writeResults();
			if (hParams.get("BenefitCode") != null && hParams.get("BenefitCode") != "") {
				int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_BenefitSelCancellation", "Benefit");
				int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_BenefitSelCancellation",
						hParams.get("BenefitCode"), BenefitalterCol);
				llAction.SelectRowInTable("web_tbl_BenefitSelCancellation", BenefitalterRow, BenefitalterCol - 2,
						"input");
			} else {
				llAction.checkBox_Check("web_checkbox_SelectAll");
				List<String> reason = llAction.GetAllTextUnderColumnInTable("web_tbl_BenefitSelCancellation", 12);
				List<Integer> rwoIndex = new ArrayList<Integer>();
				String a = "Terminated";
				for (int i = 0; i < reason.size(); i++) {
					if (reason.get(i).equalsIgnoreCase(a)) {
						rwoIndex.add(i + 2);
					}
				}
				for (int index : rwoIndex) {
					llAction.DeSelectRowInTable("web_tbl_BenefitSelCancellation", index, 1, "input");
				}
			}

			dashboard.setStepDetails("Benefit Alteration Item before change is chosen",
					"Benefit Alteration item should be selected", "N/A");
			dashboard.writeResults();
			String s = hParams.get("Cancelfrom");
			String e = "web_btn_" + s.replaceAll(" ", "_").toLowerCase();
			llAction.clickElement(e);
			dashboard.setStepDetails("Cancellation Item is chosen", "Cancellation Item is chosen successfully", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage2") != null && hParams.get("WarningErrorMessage2") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage2"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.selectByVisibleText("web_list_CancelReason", hParams.get("Cancellationreason"));
			llAction.enterValue("web_txt_LapseDate", hParams.get("LapseDate"));
			dashboard.setStepDetails("Cancellation reason is chosen", "Cancellation reason is chosen successfully",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage3") != null && hParams.get("WarningErrorMessage3") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_ErrorWarningCancellation",
							hParams.get("WarningErrorMessage3"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			CSDHelper.getInstance().captureChange("cancelPolicy", "AfterChange");
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage4") != null && hParams.get("WarningErrorMessage4") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage4"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			CSDHelper.getInstance().endOfTransaction();
		} catch (Exception ex) {
			dashboard.writeResults();
			ex.printStackTrace();
			throw new BPCException(
					"Exception occured while calling cancelPolicy method \n Exception is " + ex.getMessage());
		}
	}

	public void validateWarningMessages(String warningMsg, String message) throws Exception {
		try {
			if (warningMsg.contains(message)) { // compare warning messages
				dashboard.setStepDetails(
						message.replaceAll("[^a-zA-Z0-9//s]", "") + "Warning message should be displayed",
						"\"Warning message should be displayed ", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(
						"Warning message " + warningMsg + " from application is not matching with test data");
				dashboard.writeResults();
			}
		} catch (Exception ex) {
			throw new BPCException("Exception occured while calling validateWarningMessages Method \n Exception is "
					+ ex.getMessage());
		}
	}

	public void validateCancelPolicyError(Hashtable<String, String> hParams) throws Exception {
		try {
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage1"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilElementPresent("web_tbl_BenefitSelCancellation");
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			if (hParams.get("BenefitCode") != null && hParams.get("BenefitCode") != "") {
				int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_BenefitSelCancellation", "Benefit");
				int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_BenefitSelCancellation",
						hParams.get("BenefitCode"), BenefitalterCol);
				llAction.SelectRowInTable("web_tbl_BenefitSelCancellation", BenefitalterRow, BenefitalterCol - 2,
						"input");
			} else {
				llAction.checkBox_Check("web_checkbox_SelectAll");
				List<String> reason = llAction.GetAllTextUnderColumnInTable("web_tbl_BenefitSelCancellation", 12);
				List<Integer> rwoIndex = new ArrayList<Integer>();
				String a = "Terminated";
				for (int i = 0; i < reason.size(); i++) {
					if (reason.get(i).equalsIgnoreCase(a)) {
						rwoIndex.add(i + 2);
					}
				}
				for (int index : rwoIndex) {
					llAction.DeSelectRowInTable("web_tbl_BenefitSelCancellation", index, 1, "input");
				}
			}
			dashboard.setStepDetails("Benefit Alteration Item before change is chosen",
					"Benefit Alteration item should be selected", "N/A");
			dashboard.writeResults();
			String s = hParams.get("Cancelfrom");
			String e = "web_btn_" + s.replaceAll(" ", "_").toLowerCase();
			llAction.clickElement(e);
			dashboard.setStepDetails(s + " Cancellation Item is chosen",
					s + " Cancellation Item is chosen successfully", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage2") != null && hParams.get("WarningErrorMessage2") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage2"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.selectByVisibleText("web_list_CancelReason", hParams.get("Cancellationreason"));
			llAction.enterValue("web_txt_LapseDate", hParams.get("LapseDate"));
			dashboard.setStepDetails("Cancellation reason is chosen", "Cancellation reason is chosen successfully",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WarningErrorMessage3") != null && hParams.get("WarningErrorMessage3") != "") {
				CSDHelper.getInstance().validateWarningMessages("web_txt_ErrorWarningCancellation",
						hParams.get("WarningErrorMessage3"));
			}

		} catch (Exception ex) {
			dashboard.writeResults();
			ex.printStackTrace();
			throw new BPCException("Exception occured while calling validateCancelPolicyError method \n Exception is "
					+ ex.getMessage());
		}

	}

	public void validateCancelPolicyEntryError(Hashtable<String, String> hParams) throws Exception {
		try {
			if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {
				String getWarningMsg = llAction.getText("web_txt_ErrorWarningCancellation").trim();
				validateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage1"));
			}
		} catch (Exception ex) {
			dashboard.writeResults();
			ex.printStackTrace();
			throw new BPCException(
					"Exception occured while calling validateCancelPolicyEntryError method \n Exception is "
							+ ex.getMessage());
		}
	}

	public void validateCancelPolicyNoChangeError(Hashtable<String, String> hParams) throws Exception {
		try {
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				llAction.clickElement("web_btn_ContinueRP");
			}
			llAction.clickElement("web_btn_SubmitChangeRP");
			if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {
				String getWarningMsg = llAction.getText("web_txt_ErrorWarningCancellation").trim();
				validateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage1"));
			}
		} catch (Exception ex) {
			dashboard.writeResults();
			ex.printStackTrace();
			throw new BPCException(
					"Exception occured while calling validateCancelPolicyNoChangeError method \n Exception is "
							+ ex.getMessage());
		}
	}

	public void validateCancelPolicyPopUp(Hashtable<String, String> hParams) throws Exception {
		try {
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage1"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilElementPresent("web_tbl_BenefitSelCancellation");
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			dashboard.writeResults();
			llAction.clickElement("web_checkbox_SelectAll");
			dashboard.writeResults();
			String cancelType = hParams.get("Cancelfrom");
			String cancel = "web_btn_" + cancelType.replaceAll(" ", "_").toLowerCase();
			llAction.clickElement(cancel);
			dashboard.setStepDetails("Cancellation Item is chosen", "Cancellation Item is chosen successfully", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				llAction.clickElement("web_btn_ContinueRP");
			}
			llAction.selectByVisibleText("web_list_CancelReason", hParams.get("Cancellationreason"));
			dashboard.setStepDetails("Cancellation reason is chosen", "Cancellation reason is chosen successfully",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_ValidateDate", hParams.get("LapseDate"));
			llAction.sendkeyStroke("web_txt_ValidateDate", Keys.ENTER);
			dashboard.writeResults();
			if (hParams.get("WarningErrorMessage2") != null && hParams.get("WarningErrorMessage2") != "") {
				String getWarningMsg = llAction.getAlertText();
				validateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage2"));
				llAction.dismissAlert();
				// CSDHelper.getInstance().validateWarningMessages(getWarningMsg,
				// hParams.get("WarningErrorMessage2"));
			}
		} catch (Exception ex) {
			dashboard.writeResults();
			ex.printStackTrace();
			throw new BPCException(
					"Exception occured while calling validateCancelPolicyNoChangeError method \n Exception is "
							+ ex.getMessage());
		}
	}

	public void validateCancelPolicyWarning(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			String warningMsg = hParams.get("WarningErrorMessage3");
			String notesMsg = hParams.get("WarningErrorMessage3");
			validateCancelPolicyErrorBeforeSubmit(hParams);
			int commencementDateCol = llAction.GetColumnPositionInTable("web_tbl_BenefitSelCancellation",
					"Commencement date");
			String commencementDate = llAction
					.GetTextFromTable("web_tbl_BenefitSelCancellation", 2, commencementDateCol).trim();
			llAction.enterValue("web_txt_ValidateDate", commencementDate);
			dashboard.setStepDetails("Validity Date is changed to Commencement Date",
					"New Validity Date should be entered", "N/A");
			dashboard.writeResults();
			String s = hParams.get("Cancelfrom");
			String e = "web_btn_" + s.replaceAll(" ", "_").toLowerCase();
			llAction.clickElement(e);
			dashboard.setStepDetails(s + " Cancellation Item is chosen",
					s + " Cancellation Item is chosen successfully", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			llAction.selectByVisibleText("web_list_CancelReason", hParams.get("Cancellationreason"));
			llAction.enterValue("web_txt_lapseDate", hParams.get("LapseDate"));
			dashboard.setStepDetails("Cancellation reason is chosen", "Cancellation reason is chosen successfully",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			String screenName = llAction.getText("web_txt_deleterider_screen_validation").replaceAll("[^a-zA-Z0-9\\s+]",
					" ");
			if (!screenName.equalsIgnoreCase("Surrender cancellation reason entry")) {
				if (llAction.isDisplayed("web_btn_continue", 8)) {
					if (warningMsg != null && warningMsg != "") {
						CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", warningMsg);
						llAction.clickElement("web_btn_continue");
						llAction.waitUntilLoadingCompletes();
					} else {
						llAction.clickElement("web_btn_continue");
						llAction.waitUntilLoadingCompletes();
					}
				}
				llAction.checkBox_Check("web_checkbox_SelectAll_Aferchange");
				llAction.clickElement("web_btn_SubmitChangeRP");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().endOfTransaction();
			} else {
				if (notesMsg != null && notesMsg != "") {
					CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg", notesMsg);
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateCancelPolicyErrorBeforeSubmit(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		try {
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg",
							hParams.get("WarningErrorMessage1"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilElementPresent("web_tbl_BenefitSelCancellation");
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			if (hParams.get("BenefitCode") != null && hParams.get("BenefitCode") != "") {
				int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_BenefitSelCancellation", "Benefit");
				int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_BenefitSelCancellation",
						hParams.get("BenefitCode"), BenefitalterCol);
				llAction.SelectRowInTable("web_tbl_BenefitSelCancellation", BenefitalterRow, BenefitalterCol - 2,
						"input");
			} else {
				llAction.checkBox_Check("web_checkbox_SelectAll");
				List<String> reason = llAction.GetAllTextUnderColumnInTable("web_tbl_BenefitSelCancellation", 12);
				List<Integer> rwoIndex = new ArrayList<Integer>();
				String a = "Terminated";
				for (int i = 0; i < reason.size(); i++) {
					if (reason.get(i).equalsIgnoreCase(a)) {
						rwoIndex.add(i + 2);
					}
				}
				for (int index : rwoIndex) {
					llAction.DeSelectRowInTable("web_tbl_BenefitSelCancellation", index, 1, "input");
				}
			}
			dashboard.setStepDetails("Benefit Alteration Item before change is chosen",
					"Benefit Alteration item should be selected", "N/A");
			dashboard.writeResults();
			String s = hParams.get("Cancelfrom");
			String e = "web_btn_" + s.replaceAll(" ", "_").toLowerCase();

			llAction.clickElement(e);
			dashboard.setStepDetails(s + " Cancellation Item is chosen",
					s + " Cancellation Item is chosen successfully", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WarningErrorMessage2") != null && hParams.get("WarningErrorMessage2") != "") {
				CSDHelper.getInstance().validateWarningMessages("web_txt_ErrorWarningCancellation",
						hParams.get("WarningErrorMessage2"));
			}
		} catch (Exception ex) {

			throw new BPCException(ex);
		}

	}

	public void validateCancelPolicyErrorForValidityDate(Hashtable<String, String> hParams) throws Exception {
		try {
			validateCancelPolicyErrorBeforeSubmit(hParams);
			llAction.enterValue("web_txt_ValidateDate", hParams.get("NewValiditydate"));// added new column in testdata
																						// for validity date
			String c = hParams.get("Cancelfrom");
			String cancel = "web_btn_" + c.replaceAll(" ", "_").toLowerCase();
			llAction.clickElement(cancel);
			llAction.waitUntilLoadingCompletes();
			llAction.selectByVisibleText("web_list_CancelReason", hParams.get("Cancellationreason"));
			llAction.enterValue("web_txt_LapseDate", hParams.get("LapseDate"));
			dashboard.setStepDetails("Cancellation reason is chosen", "Cancellation reason is chosen successfully",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WarningErrorMessage3") != null && hParams.get("WarningErrorMessage3") != "") {
				CSDHelper.getInstance().validateWarningMessages("web_txt_ErrorWarningCancellation",
						hParams.get("WarningErrorMessage3"));
			}

		} catch (Exception ex) {
			throw new BPCException("Exception occured during validateCancelPolicyErrosForValidityDate \n Exception is "
					+ ex.getMessage());
		}
	}

	public void validateCancelationReason(Hashtable<String, String> hParams) throws Exception {
		try {
			validateCancelPolicyErrorBeforeSubmit(hParams);
			List<String> listValues = llAction.getDropDownList("web_list_CancelReason");
			if (!listValues.contains(hParams.get("Cancellationreason"))) {
				llAction.clickElement("web_list_CancelReason");
				dashboard.setStepDetails("Cancellation reason is chosen", "Cancellation reason is not available",
						"N/A");
				dashboard.writeResults();
			} else {
				llAction.clickElement("web_list_CancelReason");
				throw new BPCException("Dropdown value is found in the list");
			}

		} catch (Exception ex) {
			throw new BPCException("Exception occured during validateCancelPolicyErrosForValidityDate \n Exception is "
					+ ex.getMessage());
		}
	}

	public void validateErrorAfterCancellationSubmit(Hashtable<String, String> hParams) throws Exception {
		try {
			validateCancelPolicyError(hParams);
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WarningErrorMessage4") != null && hParams.get("WarningErrorMessage4") != "") {
				CSDHelper.getInstance().validateWarningMessages("web_txt_ErrorWarningCancellation",
						hParams.get("WarningErrorMessage4"));
			}
		} catch (Exception ex) {

			throw new BPCException(ex);
		}
	}
}
