package ge.fpms.main.bpc.csd;
import java.util.Hashtable;
import org.openqa.selenium.Keys;
import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;
import ge.fpms.main.bpc.nbu.ApplicationAccess;

public class Assignment {
	
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	
	public Assignment() {
		dashboard = DashboardHandler.getInstance();
	}
	/*
	 * Name: Add Assignee Purpose: Add Assignee to the policy during change
	 * assignment alteration item Parameters: Change Assignment Test Data sheet
	 * Return Value: N/A Exception: BPC Exception on component execution fail Author
	 * : Shree Ganesh
	 */
	public void AddAssignee(Hashtable<String, String> hParams) throws Exception {
		try {
			changeAssignmentType(hParams);
			llAction.clickElement("web_btn_ca_add_assignee");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Click on add assignee button",
					"Please input party information screen should be displayed", "N/A");
			dashboard.writeResults();

			llAction.switchtoFrame("", "iframe0");

			llAction.enterValue("web_btn_ca_party_name", hParams.get("Name"));
			llAction.clickElement("web_btn_ca_next");

			dashboard.setStepDetails("Enter Party name and click on next button",
					"Party details should be displayed in party list", "N/A");
			dashboard.writeResults();

			int colPos = llAction.GetColumnPositionInTable("web_tbl_ca_party_list", "Name");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_ca_party_list", hParams.get("Name"), colPos);
			llAction.SelectRowInTable("web_tbl_ca_party_list", rowPos, colPos - 2, "a");
			llAction.waitUntilLoadingCompletes();
			Utils.sleep(8);
			dashboard.setStepDetails("Click on corresponding party hyper link",
					"Create and Maintain Party screen should be displayed", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_ca_submit");
			if (llAction.isDisplayed("web_btn_ContinueRP")) {
				llAction.clickElement("web_btn_ContinueRP");
			}
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on submit button",
					"Assignee Information Information screen should be displayed", "N/A");
			dashboard.writeResults();

			llAction.enterValue("web_txt_ca_relationship", hParams.get("RelationshipwithPolicyholder"));
			llAction.sendkeyStroke("web_txt_ca_relationship", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();

			colPos = llAction.GetColumnPositionInTable("web_tbl_ca_address_list", "Address Rec No");
			rowPos = llAction.GetRowPositionInTable("web_tbl_ca_address_list", hParams.get("AddressRecno"), colPos);
			llAction.SelectRowInTable("web_tbl_ca_address_list", rowPos, colPos - 1, "input");

			llAction.waitUntilLoadingCompletes();
			Utils.sleep(8);

			dashboard.setStepDetails("Enter relationship and select address record number",
					"Address should be selected based on record number", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_ca_submit");

			llAction.waitUntilLoadingCompletes();

			llAction.clickElement("web_btn_ca_submit");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Click on submit button",
					"Warning message should be displayed with error message", "N/A");
			dashboard.writeResults();
			
			if (llAction.isDisplayed("web_btn_ContinueRP")) {
				if ( hParams.get("WarningErrorMessage")!=null && hParams.get("WarningErrorMessage")!="" )
				{							
					CSDHelper.getInstance().validateWarningMessages("web_tbl_ca_warning_msg",hParams.get("WarningErrorMessage"));
					llAction.waitUntilLoadingCompletes();				
				}		
				llAction.clickElement("web_btn_ContinueRP");
				dashboard.setStepDetails("Click on continue button",
						"System should navigate to application entry screen with status as completed.", "N/A");
				dashboard.writeResults();
			}
			
			llAction.clickElement("web_btn_SubmitChangeRP");
			CSDHelper.getInstance().endOfTransaction();
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	/*
	 * Name: Delete Assignee Purpose: Delete Assignee to the policy having assignee
	 * during change assignment alteration item Parameters: Change Assignment Test
	 * Data sheet Return Value: N/A Exception: BPC Exception on component execution
	 * fail Author : Shree Ganesh
	 */

	public void DeleteAssignee(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.waitUntilLoadingCompletes();
			int colPos = llAction.GetColumnPositionInTable("web_btn_ca_assignee_table", "Assignee Name");
			int rowPos = llAction.GetRowPositionInTable("web_btn_ca_assignee_table", hParams.get("Name"), colPos);
			llAction.SelectRowInTable("web_btn_ca_assignee_table", rowPos, colPos - 2, "input");
			llAction.waitUntilLoadingCompletes();

			llAction.clickElement("web_btn_ca_delete_assignee");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Delete Assignee button", "Alert message should be displayed.",
					"N/A");
			dashboard.writeResults();

			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Ok button on alert message",
					"Assignment information table should display no records found", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_ca_submit");

			dashboard.setStepDetails("Click on submit button", "Error message should be displayed", "N/A");
			dashboard.writeResults();

			llAction.waitUntilLoadingCompletes();

			CSDHelper.getInstance().validateWarningMessages("web_tbl_ca_error_msg_notes",
					hParams.get("WarningErrorMessage"));

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	/*
	 * Name: Add Assignee and send it for Approval Purpose: Change Assignee to the
	 * policy having change assignment alteration item Parameters: Change Assignment
	 * Test Data sheet Return Value: N/A Exception: BPC Exception on component
	 * execution fail Author : Shree Ganesh
	 */
	public void ChangeAssignment(Hashtable<String, String> hParams) throws Exception {
		try {
			AddAssignee(hParams);
			ApplicationAccess appAccess = new ApplicationAccess();
			Hashtable<String, String> loginParams = appAccess.getAccessParameters();
			appAccess.logout(loginParams);
			appAccess.login(loginParams);

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	/*
	 * Name: Approve Assignee Purpose: Approve assignee added to the policy having
	 * change assignment alteration item Parameters: Change Assignment Test Data
	 * sheet Return Value: N/A Exception: BPC Exception on component execution fail
	 * Author : Shree Ganesh
	 */

	public void ApproveAssignment(Hashtable<String, String> hParams) throws Exception {
		try {
			String applicationStatus = hParams.get("ApplicationStatus");
			llAction.clickElement("web_tbl_ca_back");
			llAction.dismissAlert();
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_ca_submit");
			llAction.waitUntilLoadingCompletes();
			if (llAction.getText("web_tbl_ca_warning_msg").toLowerCase().contains(applicationStatus.toLowerCase())) {
				dashboard.setStepDetails("Click on Submit button in Application Entry Screen "
						+ applicationStatus + " Should be displayed", "Message is validated", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(applicationStatus + "message is invalid/Submit was not successful");
				dashboard.writeResults();
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	/*
	 * Name: Change Assignee information Purpose: Check if the DOB field of assignee
	 * is read only after adding assignee to the policy Parameters: Change
	 * Assignment Test Data sheet Return Value: N/A Exception: BPC Exception on
	 * component execution fail Author : Shree Ganesh
	 */

	public void ChangeAssigneeInfo(Hashtable<String, String> hParams) throws Exception {
		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {
			changeAssignmentType(hParams);
			llAction.clickElement("web_btn_ca_add_assignee");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Click on add assignee button",
					"Please input party information screen should be displayed", "N/A");
			dashboard.writeResults();

			llAction.switchtoFrame("", "iframe0");
			llAction.enterValue("web_btn_ca_party_name", hParams.get("Name"));
			llAction.clickElement("web_btn_ca_next");

			dashboard.setStepDetails("Enter Party name and click on next button",
					"Party details should be displayed in party list", "N/A");
			dashboard.writeResults();

			int colPos = llAction.GetColumnPositionInTable("web_tbl_ca_party_list", "Name");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_ca_party_list", hParams.get("Name"), colPos);
			llAction.SelectRowInTable("web_tbl_ca_party_list", rowPos, colPos - 2, "a");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Click on corresponding party hyper link",
					"Create and Maintain Party screen should be displayed", "N/A");
			dashboard.writeResults();

			String attrValue = llAction.getAttribute("web_btn_ca_change_assignee_dob", "readOnly");
			if (attrValue.equalsIgnoreCase("true")) {
				dashboard.setStepDetails("Date of Birth read only property is "+attrValue,
						"System should not allow to edit Date of Birth value", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setFailStatus(new BPCException("System is allowing to edit Date of Birth value readonly property="+attrValue));

			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: Change Assignment Type Purpose: During adding and changing the assignee
	 * info we need to change the assignment type to absolute. Parameters: Change
	 * Assignment Test Data sheet Return Value: N/A Exception: BPC Exception on
	 * component execution fail Author : Shree Ganesh
	 */

	public void changeAssignmentType(Hashtable<String, String> hParams) throws Exception {
		llAction.waitUntilLoadingCompletes();
		llAction.clickElement("web_btn_ca_change_assignment_type");
		llAction.waitUntilLoadingCompletes();
		llAction.selectByVisibleText("web_dd_ca_change_assignment_type_select", hParams.get("Newassignmenttype"));
		llAction.clickElement("web_btn_ca_submit");
		llAction.waitUntilLoadingCompletes();
		dashboard.setStepDetails("Change assignment type to " + hParams.get("Newassignmenttype"),
				"Assignement Type should be changed to " + hParams.get("Newassignmenttype"), "N/A");
		dashboard.writeResults();
	}

}
