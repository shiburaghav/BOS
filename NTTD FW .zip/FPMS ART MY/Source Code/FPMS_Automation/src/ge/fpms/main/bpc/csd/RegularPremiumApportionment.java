package ge.fpms.main.bpc.csd;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;
import java.math.BigDecimal;
import java.util.Hashtable;
import java.util.List;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class RegularPremiumApportionment {

	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;

	public RegularPremiumApportionment() {
		dashboard = DashboardHandler.getInstance();
	}

	/*
	 * Name: ChangeRegularPremiumApportionment Purpose: Change Regular Premium
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void ChangeRegularPremiumApportionment(Hashtable<String, String> hParams) throws Exception {
		try {
			Utils.sleep(2);
			llAction.waitUntilElementPresent("web_apportionment_txt_validityDate");
			String message = hParams.get("WarningErrorMessage");

			int colPos = llAction.GetColumnPositionInTable("web_apportionment_tbl_mainBenefitInfo", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_apportionment_tbl_mainBenefitInfo",
					hParams.get("BenefitCode"), colPos);
			
			if (llAction.getRowCountInTable("web_apportionment_tbl_mainBenefitInfo") != 2) {
				llAction.SelectRowInTable("web_apportionment_tbl_mainBenefitInfo", rowPos, 1, "input");
			}
			
			dashboard.setStepDetails("Validate if Benefit Code is selected",
					"Benefit Code should be selected", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_apportionment_btn_changeApportionment");
			llAction.waitUntilLoadingCompletes();


			if(llAction.isDisplayed("web_apportionment_btn_Continue", 5))
			{
				llAction.clickElement("web_apportionment_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			}

			changeRPApportCaptureBeforeOrAfterChange("BeforeChange");

			switch ((hParams.get("Fundallocationby").toUpperCase())) {
			case "AMOUNT":
				changeRegularPremiumApportionmentByAmount(hParams);
				break;
			case "PERCENTAGE":
				changeRegularPremiumApportionmentByPercentage(hParams);
				break;
			}

			llAction.clickElement("web_apportionment_btn_submitAppor");
			llAction.waitUntilLoadingCompletes();

			changeRPApportCaptureBeforeOrAfterChange("AfterChange");

			llAction.clickElement("web_apportionment_btn_submitILPChangeAppor");
			llAction.waitUntilLoadingCompletes();
			//Added condition to check if warning message is to be validated
			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
			String getWarningMsg = llAction.getText("web_tbl_Appotionment_Warning_Msg");
			ApportionmentValidateWarningMessages(getWarningMsg, message);
			}

			if (llAction.isDisplayed("web_apportionment_btn_Continue", 5)) {
				llAction.clickElement("web_apportionment_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			}
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: splitIntoParts Purpose: split Into Parts Parameters: Integer - whole
	 * number to be divided into number of Inetger - Parts Return Value: NA
	 * Exception: BPCException
	 */
	private static int[] splitIntoParts(int whole, int parts) {
		int[] arr = new int[parts];
		for (int i = 0; i < arr.length; i++)
			whole -= arr[i] = (whole + parts - i - 1) / (parts - i);
		return arr;
	}

	/*
	 * Name: getNoOfApportionmentEntries Purpose: get Number of Existing
	 * Apportionment Entries Parameters: hParams Return Value: List<String>
	 * Exception: BPCException
	 */
	public int getNoOfApportionmentEntries(Hashtable<String, String> hParams) throws Exception {
		try {
			int count = llAction.getRowCountInTable("web_apportionment_tbl_Entry");
			return count;

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: changeRegularPremiumApportionmentByAmount Purpose: Change Regular
	 * Premium Apportionment ByAmount Parameters: NA Return Value: NA Exception:
	 * BPCException
	 */
	public void changeRegularPremiumApportionmentByAmount(Hashtable<String, String> hParams) throws Exception {
		try {
			Utils.sleep(2);
			llAction.clickElement("web_apportionment_Radio_ByAmount");

			int existingCount = getNoOfApportionmentEntries(hParams) - 1;
			int newCount = existingCount + Integer.parseInt(hParams.get("PremiumApportionmentEntry"));

			String InvestmentPremium = GetValueOfSpecificLabel("web_apportionment_tbl_PolicyDetails",
					"Investment Premium");
			int investmentPremium = Integer.parseInt(InvestmentPremium);

			int[] newEntries = splitIntoParts(investmentPremium, newCount);

			for (int i = 1; i <= Integer.parseInt(hParams.get("PremiumApportionmentEntry")); i++) {
				llAction.enterValue("web_apportionment_txt_AddFund", hParams.get("Addfund" + i + ""));
				Utils.sleep(2);

				llAction.clickElement("web_apportionment_btn_AddFund");
				llAction.waitUntilLoadingCompletes();
				int colPos = llAction.GetColumnPositionInTable("web_apportionment_tbl_Entry", "Amount Apportionment");
				llAction.enterTextInTable("web_apportionment_tbl_Entry", existingCount + 1 + i, colPos, "5", "/input");

			}
			for (int i = 1; i <= newCount; i++) {
				int colPos = llAction.GetColumnPositionInTable("web_apportionment_tbl_Entry", "Amount Apportionment");
				BigDecimal bd = new BigDecimal(newEntries[i - 1]);
				bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
				llAction.enterTextInTable("web_apportionment_tbl_Entry", i + 1, colPos, bd.toString(), "/input");
			}
			dashboard.setStepDetails("The Apportionment Screen after adding all premium apportionment funds",
					"Screenshot Should be Captured and available", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: changeRegularPremiumApportionmentByPercentage Purpose: Change Regular
	 * Premium Apportionment By Percentage Parameters: NA Return Value: NA
	 * Exception: BPCException
	 */
	public void changeRegularPremiumApportionmentByPercentage(Hashtable<String, String> hParams) throws Exception {
		try {
			Utils.sleep(2);
			llAction.clickElement("web_apportionment_Radio_Bypercentage");

			int existingCount = getNoOfApportionmentEntries(hParams) - 1;
			int newCount = existingCount + Integer.parseInt(hParams.get("PremiumApportionmentEntry"));
			int[] newEntries = splitIntoParts(100, newCount);

			for (int i = 1; i <= Integer.parseInt(hParams.get("PremiumApportionmentEntry")); i++) {
				llAction.enterValue("web_apportionment_txt_AddFund", hParams.get("Addfund" + i + ""));
				Utils.sleep(2);

				llAction.clickElement("web_apportionment_btn_AddFund");
				llAction.waitUntilLoadingCompletes();
			}
			for (int i = 1; i <= newCount; i++) {
				int colPos = llAction.GetColumnPositionInTable("web_apportionment_tbl_Entry",
						"Percentage Apportionment");
				BigDecimal bd = new BigDecimal(newEntries[i - 1]);
				bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
				llAction.enterTextInTable("web_apportionment_tbl_Entry", i + 1, colPos, bd.toString(), "/input[2]");
			}
			dashboard.setStepDetails("The Apportionment Screen after adding all premium apportionment funds",
					"Screenshot Should be Captured and available", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: ChangeRPApportCaptureBeforeAndAfterChange Purpose: RPApport Capture
	 * Before And After Change Parameters: ActionType - Capture Before or After the
	 * Changes Return Value: NA Exception: BPCException
	 */
	public void changeRPApportCaptureBeforeOrAfterChange(String ActionType) throws Exception {
		try {
			switch (ActionType.toUpperCase()) {
			case "BEFORECHANGE":
				dashboard.setStepDetails("The Apportionment Screen before adding new premium apportionment entry",
						"Screenshot Should be Captured and available", "N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":
				dashboard.setStepDetails("The Apportionment Screen after adding new premium apportionment entry",
						"Screenshot Should be Captured and available", "N/A");
				dashboard.writeResults();
				break;
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: GetValueOfSpecificLabel Purpose: Get the value of Any label displayed
	 * in Common Query Page Parameters: TableElementKey: Exception: BPCException
	 */
	public String GetValueOfSpecificLabel(String TableElement, String LabelName) throws Exception {
		try {
			Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(TableElement);
			String xPath = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr/td[contains(text(), '"
					+ LabelName + "')]/following-sibling::td";

			WebElement tdWithValue = llAction.findElementByXpath(xPath);
			return tdWithValue.getText();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: ApportionmentValidateWarningMessages Parameters: TableElementKey:
	 * Exception: BPCException
	 */
	public void ApportionmentValidateWarningMessages(String warningMsg, String message) throws Exception {
		try {
			if (warningMsg.toLowerCase().contains(message.toLowerCase())) { // compare warning messages
				dashboard.setStepDetails(message + "Warning message should be displayed",
						"\"Warning message should is displayed ", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(
						"Warning message " + warningMsg + " from application is not matching with test data");
				dashboard.writeResults();
				Utils.sleep(1);
			}
		} catch (Exception ex) {
			throw new BPCException(ex);

		}
	}

	/*
	 * Name: validateChangeRPApportionment Purpose: Validate Change Regular premium
	 * Apportionment with negative scenario Parameters: RPApportionment Test Data
	 * sheet Return Value: N/A Exception: BPC Exception on component execution fail
	 * Author : Divya Sri
	 */
	public void validateChangeRPApportionment(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.waitUntilElementPresent("web_apportionment_txt_validityDate");
			String warningMsg = hParams.get("WarningErrorMessage-FundSubmit");
			String notesMsg = hParams.get("WarningErrorMessage-FundSubmitNotes");
			int colPos = llAction.GetColumnPositionInTable("web_apportionment_tbl_mainBenefitInfo", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_apportionment_tbl_mainBenefitInfo",
					hParams.get("BenefitCode"), colPos);
			if (llAction.getRowCountInTable("web_apportionment_tbl_mainBenefitInfo") != 2) {
			llAction.SelectRowInTable("web_apportionment_tbl_mainBenefitInfo", rowPos, 1, "input");
			}
			CSDHelper.getInstance().captureChange("validateChangeRPApportionment", "BeforeChange");
			llAction.clickElement("web_apportionment_btn_changeApportionment");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_apportionment_btn_Continue", 5)) {
				llAction.clickElement("web_apportionment_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			}
			switch ((hParams.get("Fundallocationby").toUpperCase())) {
			case "AMOUNT":
				validateChangeRPApportionmentByAmount(hParams);
				break;
			case "PERCENTAGE":
				validateChangeRPApportionmentByPercentage(hParams);
				break;
			}
			dashboard.setStepDetails("Premium Apportionment Entry is done", "Amount or Percentage should be entered",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_apportionment_btn_submitAppor");
			llAction.waitUntilLoadingCompletes();
			if (notesMsg != null && notesMsg != "") {
				CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg", notesMsg);
			}
			if (llAction.isDisplayed("web_apportionment_btn_Continue", 5)) {
				if (warningMsg != null && warningMsg != "") {
					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", warningMsg);
				}
				llAction.clickElement("web_apportionment_btn_Continue");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().captureChange("validateChangeRPApportionment", "AfterChange");
				llAction.clickElement("web_apportionment_btn_submitILPChangeAppor");
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_apportionment_btn_Continue", 5)) {
					llAction.clickElement("web_apportionment_btn_Continue");
					llAction.waitUntilLoadingCompletes();
				}
				CSDHelper.getInstance().endOfTransaction();
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateChangeRPApportionmentByPercentage(Hashtable<String, String> hParams) throws Exception {
		try {
			int availableFlag = 0;
			llAction.clickElement("web_apportionment_Radio_Bypercentage");
			for (int i = 1; i <= Integer.parseInt(hParams.get("PremiumApportionmentEntry")); i++) {
				String expectedFundCode = hParams.get("Addfund" + i + "");
				int fundCol = llAction.GetColumnPositionInTable("web_apportionment_tbl_Entry", "Fund Code");
				int percentCol = llAction.GetColumnPositionInTable("web_apportionment_tbl_Entry",
						"Percentage Apportionment");
				List<String> fundCodeList = llAction.GetAllTextUnderColumnInTable("web_apportionment_tbl_Entry",
						fundCol);
				for (String fundCode : fundCodeList) {
					if (fundCode.equals(expectedFundCode)) {
						int fundRow = llAction.GetRowPositionInTable("web_apportionment_tbl_Entry", expectedFundCode,
								fundCol);
						llAction.enterTextInTable("web_apportionment_tbl_Entry", fundRow, percentCol,
								hParams.get("Percentage" + i + ""), "/input[2]");
						availableFlag = 1;
						break;
					}
				}
				if (availableFlag == 0) {
					llAction.enterValue("web_apportionment_txt_AddFund", hParams.get("Addfund" + i + ""));
					llAction.waitUntilLoadingCompletes();
					llAction.sendkeyStroke("web_apportionment_txt_AddFund", Keys.ENTER);
					llAction.clickElement("web_apportionment_btn_AddFund");
					llAction.waitUntilLoadingCompletes();
					int fundRow = llAction.GetRowPositionInTable("web_apportionment_tbl_Entry", expectedFundCode,
							fundCol);
					llAction.enterTextInTable("web_apportionment_tbl_Entry", fundRow, percentCol,
							hParams.get("Percentage" + i + ""), "/input[2]");
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateChangeRPApportionmentByAmount(Hashtable<String, String> hParams) throws Exception {
		try {
			int availableFlag = 0;
			llAction.clickElement("web_apportionment_Radio_ByAmount");
			for (int i = 1; i <= Integer.parseInt(hParams.get("PremiumApportionmentEntry")); i++) {

				String expectedFundCode = hParams.get("Addfund" + i + "");
				int fundCol = llAction.GetColumnPositionInTable("web_apportionment_tbl_Entry", "Fund Code");
				int amountCol = llAction.GetColumnPositionInTable("web_apportionment_tbl_Entry",
						"Amount Apportionment");
				List<String> fundCodeList = llAction.GetAllTextUnderColumnInTable("web_apportionment_tbl_Entry",
						fundCol);
				for (String fundCode : fundCodeList) {
					if (fundCode.equals(expectedFundCode)) {
						int fundRow = llAction.GetRowPositionInTable("web_apportionment_tbl_Entry", expectedFundCode,
								fundCol);
						llAction.enterTextInTable("web_apportionment_tbl_Entry", fundRow, amountCol,
								hParams.get("Amount" + i + ""), "/input");
						availableFlag = 1;
						break;
					}
				}
				if (availableFlag == 0) {
					llAction.enterValue("web_apportionment_txt_AddFund", hParams.get("Addfund" + i + ""));
					llAction.waitUntilLoadingCompletes();
					llAction.sendkeyStroke("web_apportionment_txt_AddFund", Keys.ENTER);
					llAction.clickElement("web_apportionment_btn_AddFund");
					llAction.waitUntilLoadingCompletes();
					int fundRow = llAction.GetRowPositionInTable("web_apportionment_tbl_Entry", expectedFundCode,
							fundCol);
					llAction.enterTextInTable("web_apportionment_tbl_Entry", fundRow, amountCol,
							hParams.get("Amount" + i + ""), "/input");
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
