package ge.fpms.main.bpc.bcp.templates.giro;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.bpc.bcp.templates.IPaymentType;
import ge.fpms.main.bpc.bcp.templates.PaymentTemplatesParse;
import ge.fpms.main.bpc.bcp.templates.Type;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.nttdata.common.util.ColumnHeader;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.framework.exceptions.BPCException;

public class GiroTemplateParser extends PaymentTemplatesParse{

	
	private static final String SHEET_NAME = "GIRO";
	private Giro giro;
	private ArrayList<Details> detailList;
	private Details initalDR;
	private String inputFilePath;
	private String outputFilePath;
	
	public GiroTemplateParser() {
		super();
		detailList = new ArrayList<Details>();
	}
	/**
	 * parseGiro - for parsing giro files
	 * @param params - parameters from testdata
	 * @throws Exception 
	 */
	public void processGiroTemplate(Hashtable<String, String> params) throws Exception {
		inputFilePath = params.get("InputFile");
		String jsonTemplate = FPMSProperties.getInstance().getJsonPath("giro.json");
		loadObject(jsonTemplate);		
		processTemplateFile(params);
	}
	/**
	 * parseGiro - for parsing giro files
	 * @param params - parameters from testdata
	 * @throws Exception 
	 */
	public void parseGiroTemplate(Hashtable<String, String> params) throws Exception {
		String jsonTemplate = FPMSProperties.getInstance().getJsonPath("giro.json");;
		loadObject(jsonTemplate);
		parseTemplate(params);
	}
	@Override
	public void beginParse(String line)  throws Exception{
		parseHeader(line);
		initalDR = giro.getDetails()[0];
	}	
	
	@Override
	public void parse(String line) throws Exception {
		try {

			if (line.startsWith(initalDR.getName())) {
				int startIndex = 0, endIndex = 0;

				int[] attributeSpace = initalDR.getAttributesSize();
				Type[] attributes = initalDR.getAllAttributes();
				Type[] newAttributes = new Type[Details.FIELD_COUNT];
				
				for (int i = 0; i < attributeSpace.length; i++) {
					String value = "";
					endIndex += attributeSpace[i];
					if (endIndex <= line.length()) {
						value = new String(line.substring(startIndex, endIndex));
						startIndex = endIndex;
					} else {
						value = "";
					}
					newAttributes[i] = new Type(attributeSpace[i],
							attributes[i].getDataType(), value,
							attributes[i].getAlignment(),
							attributes[i].getPaddingChar());
				}
				newAttributes[attributes.length] = new Type(initalDR.getDtlBankRefNum().getSize(),
						initalDR.getDtlBankRefNum().getDataType(), "",
						initalDR.getDtlBankRefNum().getAlignment(),
						initalDR.getDtlBankRefNum().getPaddingChar());
				newAttributes[attributes.length + 1] = new Type(initalDR.getDtlDebitStatusCode().getSize(),
						initalDR.getDtlDebitStatusCode().getDataType(), "",
						initalDR.getDtlDebitStatusCode().getAlignment(),
						initalDR.getDtlDebitStatusCode().getPaddingChar());
				newAttributes[attributes.length + 2] = new Type(initalDR.getDtlDebitStsDesc().getSize(),
						initalDR.getDtlDebitStsDesc().getDataType(), "",
						initalDR.getDtlDebitStsDesc().getAlignment(),
						initalDR.getDtlDebitStsDesc().getPaddingChar());
				detailList.add(getRecordCount(), new Details(newAttributes));
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	@Override
	public void endParse(String line) throws Exception {
		giro.setDetails( detailList.toArray(new Details[0]));
		parseFooter(line);
		
	}


	@Override
	public void createNewFile(String outputFile) throws Exception {
		try {
			outputFilePath = getGiroReturnFilePath();
			
			BufferedWriter out = new BufferedWriter(new FileWriter(outputFilePath));
			out.write(giro.getHeader().toString()); out.newLine();
			for(Details det : giro.getDetails()){
				out.write(det.toString()); out.newLine();
			}
			
			out.write(giro.getSummary().toString());
			out.close();
			
		} catch (Exception e) {
			throw new BPCException(e);
		}

				
	}

	@Override
	public void updateAttributes(Hashtable<String, String> params)
			throws Exception {
		try {
			// Updating Details Section
			String policyNumber = params.get("PolicyNumber");
			if(!StringUtils.isEmpty(policyNumber))
			{
				String[] tdPolicies = policyNumber.split(",");
				
				Details dt[] = giro.getDetails();
				for (int i = 0; i < tdPolicies.length; i++) {
	
					for (Details d : dt) {
						Hashtable<String, String> giroData = getGiroData(tdPolicies[i]);
						String dPolicy = d.getDtlRefNo().getValue(); // PolicyNumber
						/*int pol = Integer.valueOf(dPolicy.replace(" ", "0"));
						dPolicy = String.valueOf(pol);
						dPolicy = dPolicy.length() < 8 ? Utils.rightPad(dPolicy, 8,'0') : dPolicy;*/
						int dAmount = Integer.parseInt(d
								.getDtlDebitAmt().getValue()); // Settlement Amount inCents
						int tdAmt = Integer.parseInt(giroData.get("Amount").replace(".", ""));
	
						if (tdPolicies[i].contains(dPolicy) && dAmount == tdAmt) {
							d.getDtlDebitStatusCode().setValue(giroData.get("DebitStatusCode"));
							d.getDtlBankRefNum().setValue(giroData.get("BankRefNum"));
							break;
						}
					}
				}
			}

			// Updating Summary - with accepted/rejected count & amount and
			// transaction count & amount
			int totalAcceptedCount = 0, totalRejectedCount = 0, totalAcceptedAmount = 0, 
					totalRejectedAmount = 0, totalTransactionCount = 0, totalTransactionAmount = 0;

			for (Details d : giro.getDetails()) {
				int dAmount = Integer.parseInt(d.getDtlDebitAmt()
						.getValue());
				if (!d.getDtlDebitStatusCode().getValue().trim()
						.equals(IPaymentType.DEFAULT_RETURN_CODE)) {
					totalRejectedCount++;
					totalRejectedAmount = totalRejectedAmount + dAmount;
				} else {
					totalAcceptedCount++;
					totalAcceptedAmount = totalAcceptedAmount + dAmount;
				}
				totalTransactionCount = totalAcceptedCount + totalRejectedCount;
				totalTransactionAmount = totalAcceptedAmount
						+ totalRejectedAmount;
			}

			giro.getSummary().getCtrDebitAcceptedCnt()
					.setValue(String.valueOf(totalAcceptedCount));
			giro.getSummary().getCtrDebitRejectedCnt()
					.setValue(String.valueOf(totalRejectedCount));
			giro.getSummary().getCtrDebitAcceptedAmt()
					.setValue(String.valueOf(totalAcceptedAmount));
			giro.getSummary().getCtrDebitRejectedAmt()
					.setValue(String.valueOf(totalRejectedAmount));

			giro.getSummary().getCtrBtCount()
					.setValue(String.valueOf(totalTransactionCount));
			giro.getSummary().getCtrBtAmt()
					.setValue(String.valueOf(totalTransactionAmount));
			

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	/**
	 * load the GIRO Structure using the JSON template
	 * @param jsonTemplate
	 */
	private void loadObject(String jsonTemplate) throws Exception {
		try {

			Gson gson = new Gson();
			giro = gson.fromJson(new FileReader(jsonTemplate), Giro.class);			
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}
	
	private void parseHeader(String line) throws Exception {
		try {
			if (line.startsWith(giro.getHeader().getName())) {
				int startIndex = 0, endIndex = 0;
				ArrayList<String> buffer = new ArrayList<String>();
				int[] attributeSpace = giro.getHeader().getAttributesSize();
				for (int i = 0; i < attributeSpace.length; i++) {
					endIndex += attributeSpace[i];
					buffer.add(line.substring(startIndex, endIndex));
					startIndex = endIndex;
				}

				giro.getHeader().setParamaters(buffer);

			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	private void parseFooter(String line) throws Exception {
		if(line.startsWith(giro.getSummary().getName()))
		{
			int startIndex = 0,  endIndex=0;
			int[] attributeSpace = giro.getSummary().getAttributesSize();
			String []attributesValues = new String[attributeSpace.length];
			
			for(int i = 0; i<attributeSpace.length;i++)
			{
				endIndex+=attributeSpace[i];
				
				if(endIndex<=line.length()){
					attributesValues[i] = new String(line.substring(startIndex,endIndex));
					startIndex = endIndex;
				}else{
					break;
				}
			}
			
			giro.getSummary().setParamaters(attributesValues);
		}		
	}

	public String getAllPolicies(int nPolicies) throws Exception{
		Details[] detailsList = giro.getDetails();
		StringBuilder policies = new StringBuilder();
		
		nPolicies = nPolicies > detailsList.length ? detailsList.length :  nPolicies;
		
		for(int i = 0; i < nPolicies ;i++){
			if(i > 0){
				policies.append(FPMSConstants.COMMA_SEPERATOR);
			}
			policies.append(detailsList[i].getDtlRefNo().getValue().trim());
		}
		//System.out.println("GiroTemplateParser.getAllPolicies() : " + policies.toString());
		return policies.toString();
	}
	
	
	public String getInputFilePath() {
		return inputFilePath;
	}
	public String getGiroReturnFilePath() {
		return System.getProperty("Settings.ART Downloads") + File.separator + IPaymentType.GIRO_OUTPUT_FILE_NAME;
	}
	
	public Hashtable<String, String> getGiroData(String pNumber) {
		DataHandler dataHandler = new DataHandler();
		Hashtable<String, String> giroData = dataHandler.getTestData(SHEET_NAME,
				FPMSProperties.getInstance().getTestDataFilePath(FPMSConstants.MODULE_BCPBATCH),
				ColumnHeader.getColumnHeader(SHEET_NAME), pNumber, "PolicyNumber");
		return giroData;
	}
	public static void main(String[] args)  {
		String dwlLoad ="C:\\Users\\suchitraravindran\\Documents\\FPMS\\MY\\H2HDDS10005228082018001.dat";
		String output = "D:\\FPMS_ART\\";
		Hashtable<String, String> params = new Hashtable<String, String>();
		params.put("InputFile", dwlLoad);
		params.put("OutputFile", output);
		params.put("PolicyNumber", "0073120962");
		params.put("Amount", "5700");
		params.put("ReturnCode", "05");
		
		try {
			new GiroTemplateParser().processGiroTemplate(params);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getGiroInputFileName(String bpdate) {
		
		//String batchProcessingDate = Utils.formatDateTime(bpdate, "dd/MM/yyyy", "yyyyMMdd");
		String fileName = IPaymentType.GIRO_INPUT_FILENAME;/* + batchProcessingDate*/

		return fileName;
	}
}