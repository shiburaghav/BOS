package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;

public class CrsOrganization {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	public CrsOrganization() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	public void fillCrsInfo(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();

		try {
			if(!StringUtils.isEmpty(hParams.get("TINNumber"))){
				
				String [] crsCountry =  hParams.get("CRSCountry").split(FPMSConstants.COMMA_SEPERATOR);
				String [] tinNumber =  hParams.get("TINNumber").split(FPMSConstants.COMMA_SEPERATOR);
				String [] tinStartDate =  hParams.get("TINStartDate").split(FPMSConstants.COMMA_SEPERATOR);
				String [] tinEndDate =  hParams.get("TINEndDate").split(FPMSConstants.COMMA_SEPERATOR);
				
				
				int crsCountryCol=llAction.GetColumnPositionInTable("web_tbl_CRS", "Country of Incorporation (Tax)");
				int tinNumCol=llAction.GetColumnPositionInTable("web_tbl_CRS", "GIIN Number");
				int tinStartDateCol=llAction.GetColumnPositionInTable("web_tbl_CRS", "GIIN Start Date");
				int tinEndDateCol =llAction.GetColumnPositionInTable("web_tbl_CRS", "GIIN End Date");
				
				
				for(int i=0;i<crsCountry.length;i++)
				{
					
					llAction.enterTextInTable("web_tbl_CRS", i+2, crsCountryCol, crsCountry[i],"/span/select");
					llAction.enterTextInTable("web_tbl_CRS", i+2, tinNumCol, tinNumber[i],"/input");
					llAction.enterTextInTable("web_tbl_CRS", i+2, tinStartDateCol, tinStartDate[i],"/input");
					llAction.enterTextInTable("web_tbl_CRS", i+2, tinEndDateCol, tinEndDate[i],"/input");
					llAction.clickElement("web_btn_CRS_Apply");
					llAction.waitUntilLoadingCompletes();
					if (llAction.isDisplayed("web_btn_continue", 5)) {
						llAction.clickElement("web_btn_continue");
					}
					}
				dashboard.setStepDetails("Enter CRS Information and apply", "CRS Information is added", "N/A");
				dashboard.writeResults();				
				llAction.enterValue("web_txt_CRS_SelfCertDate", hParams.get("SelfCertDate"));
				llAction.selectByVisibleText("web_txt_CRS_CRSFollowUpIND",hParams.get("CrsIndFollowUp"));
				llAction.selectByVisibleText("web_txt_CRS_ EntityClassification",hParams.get("CrsEntityClassification"));	
			}
			
			else {
				
				String [] DocumentEvidence =  hParams.get("DocumentEvidence").split(FPMSConstants.COMMA_SEPERATOR);
				String [] GIINUnavailableReason =  hParams.get("GIINUnavailableReason").split(FPMSConstants.COMMA_SEPERATOR);
				String [] Comments =  hParams.get("Comments").split(FPMSConstants.COMMA_SEPERATOR);
				int DocumentEvidenceCol =llAction.GetColumnPositionInTable("web_tbl_CRS", "Document Evidence");
				int GIINUnavailableReasonCol =llAction.GetColumnPositionInTable("web_tbl_CRS", "GIIN Unavailable Reason");
				int CommentsCol =llAction.GetColumnPositionInTable("web_tbl_CRS", "Comments");
				
				for(int i=0;i<DocumentEvidence.length;i++) {
				llAction.enterTextInTable("web_tbl_CRS", i+2, GIINUnavailableReasonCol, GIINUnavailableReason[i],"/span/select");
				llAction.enterTextInTable("web_tbl_CRS", i+2, DocumentEvidenceCol, DocumentEvidence[i],"/input");
				llAction.enterTextInTable("web_tbl_CRS", i+2, CommentsCol, Comments[i],"/input");
				llAction.clickElement("web_btn_CRS_Apply");
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_btn_continue", 5)) {
					llAction.clickElement("web_btn_continue");
				}
				
			}
				dashboard.setStepDetails("Enter CRS Information and apply", "CRS Information is added", "N/A");
				dashboard.writeResults();				
				llAction.enterValue("web_txt_CRS_SelfCertDate", hParams.get("SelfCertDate"));
				llAction.selectByVisibleText("web_txt_CRS_CRSFollowUpIND",hParams.get("CrsIndFollowUp"));
				llAction.selectByVisibleText("web_txt_CRS_ EntityClassification",hParams.get("CrsEntityClassification"));	
			}
		
			llAction.clickElement("web_btn_CRS_Submit");
			llAction.waitUntilLoadingCompletes();
			
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}
}


