package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;

public class PolicyManagement {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	private static final String NBREGENERATE="NB Re-generate";
	private static final String CSREGENERATE = "CS Re-generate";
	private static final String CS_INCREMENTAL_REGENERATE = "CS Incremental Re-generate";
	private static final String ENGLISH = "ENGLISH";
	private static final String BAHASA_MALAYSIA = "Bahasa Malaysia ";
	private static final String BOTH_LANGUAGES = "English and Bahasa Malaysia";
	private static final String ELECTRONIC="Electronic";
	private static final String HAND = "Hand";
	private static final String MAIL = "Mail";

	public PolicyManagement() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	public void reverseInforce(Hashtable<String, String> hParams) throws Exception {		
		try {
			String policyNumber = hParams.get("PolicyNo");
			String policyStatus="\"Waiting For Data Entry\"";					
			llAction = new FPMS_Actions();
			llAction.selectMenuItem("NBD", "Reverse Inforce");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_PolicyNo", hParams.get("PolicyNo"));
			dashboard.setStepDetails("Enter Policy number","Policy Number '" + policyNumber +"' is entered","N/A");
			dashboard.writeResults();									
			llAction.clickElement("web_Btn_Submit_Party");
			llAction.waitUntilLoadingCompletes();			
			if (llAction.isDisplayed("web_btn_continue",5)) {
				/*if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
					String getWarningMsg = llAction.getText("web_txt_ErrorWarning").trim();*/						
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
				/*}
				else
				{
					llAction.clickElement("web_btn_ContinueRP");
				}*/
			}
			llAction.clickElement("web_Btn_Submit_Party");
			llAction.waitUntilLoadingCompletes();
			String expectedPolicyStatus = llAction.getText("web_txt_reversePolicyStatus");
			if(llAction.getText("web_txt_reversePolicyStatus").contains(policyStatus)){
				dashboard.setStepDetails("Verify the Reverse Inforce Status of policy in Change Policy Status screen","The ReverseInforce Status of policy should be '" +policyStatus +"'","N/A");
				dashboard.writeResults();
			}else{	
				dashboard.setFailStatus(new BPCException("The ReverseInforce Status of policy has failed"));
				dashboard.setStepDetails("Verify the Reverse Inforce Status of policy in Change Policy Status screen","The ReverseInforce Status of policy has failed. Expected '" +policyStatus +"' and actual:'" + expectedPolicyStatus + "'","N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_return");
				llAction.waitUntilLoadingCompletes();
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void despatchAndAcknowledgement(Hashtable<String, String> hParams) throws Exception {

		try {
			String policyNumber = hParams.get("PolicyNo");
			String serviceBranchRecievedDate = hParams.get("ServiceBranchReceivedDate");
			String dcRepCollectionDate = hParams.get("DCRepCollectionDate");
			String acknowledgementDate = hParams.get("AcknowledgementDate");
			String despatchAndAcknowledgementType = hParams.get("DespatchAndAcknowledgementType");					

			llAction.selectMenuItem("NBD", "Despatch Policy Acknowledgement", "Individual");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_dm_txt_DMSPolicyNo", hParams.get("PolicyNo"));//Enter Policy number
			dashboard.setStepDetails("Enter Policy number","Policy Number '" + policyNumber +"' is entered","N/A");
			dashboard.writeResults();									
			llAction.clickElement("web_Btn_Submit_Party");
			llAction.waitUntilLoadingCompletes();				
			llAction.enterValue("web_txt_UpdtPolicyAcknwldgmnt_Svc_brnch_rcvd_dt", serviceBranchRecievedDate);
			dashboard.setStepDetails("Fill in Service Branch Receive Date",serviceBranchRecievedDate +"' is entered","N/A");
			dashboard.writeResults();	
			llAction.enterValue("web_txt_UpdtPolicyAcknwldgmnt_dc_rep_coll_dt", dcRepCollectionDate);
			dashboard.setStepDetails("Fill in DC Rep Collection Date",dcRepCollectionDate +"' is entered","N/A");
			dashboard.writeResults();	
			llAction.enterValue("web_txt_UpdtPolicyAcknwldgmnt_ack_dt", acknowledgementDate);	
			dashboard.setStepDetails("Fill in Acknowledgement Date", acknowledgementDate +"' is entered","N/A");
			dashboard.writeResults();	
			llAction.clickElement("web_txt_UpdtPolicyAcknwldgmnt_ack_dt");	
			if (llAction.isDisplayed("web_btn_continue",5)) {
				if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
					String getWarningMsg = llAction.getText("web_txt_ErrorWarning").trim();						
					llAction.clickElement("web_btn_continue");
				}
				else
				{
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_Btn_Submit_Party");
			dashboard.setStepDetails("Click on Submit button", "System should back to Select Proposal screen.","N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();

		} catch (Exception e) {
			throw new BPCException(e);
		}

	}


	public void reprintPolicy(Hashtable<String, String> hParams){

		try {

			regeneratePolicySearch(hParams);
			if(llAction.isDisplayed("web_coln_no_rec_found")){
				dashboard.setFailStatus(new BPCException("Reprint policy failed! No record found with the policy no provided."));
			}else{
				dashboard.setStepDetails("Click on Search button", "Policy information table is updated.","N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_reprint_submit");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Click on Submit button", "Policy is reprint submitted successfully.","N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_reprint_return");
				llAction.waitUntilLoadingCompletes();
				llAction.deleteFromCookies(new Cookie("current_module_id","300964"));
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}

	}
	public void regeneratePolicySearch(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("NBD", "Policy Document", "Re-generate");
			llAction.waitUntilLoadingCompletes();
			llAction.addToCookies("current_module_id", "300964");
			llAction.enterValue("web_txt_reprint_policyNo2", hParams.get("PolicyNumber"));
			llAction.sendkeyStroke("web_txt_reprint_policyNo2", Keys.ENTER);
			llAction.clickElement("web_btn_reprint_search");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void regeneratePolicyDocument(Hashtable<String, String> hParams) throws Exception {
		try {

			String option=hParams.get("Option");
			String language=hParams.get("Language");
			String despatchType=hParams.get("DespatchType");
			regeneratePolicySearch(hParams);
			if(llAction.isDisplayed("web_coln_no_rec_found")){
				dashboard.setFailStatus(new BPCException("Search policy failed! No record found with the policy no provided."));
				dashboard.writeResults();
			}else{
				dashboard.setStepDetails("Click on Search button", "Policy information table is updated.","N/A");
				dashboard.writeResults();
				llAction.checkBox_Check("web_checkBox_selectAll");

				/*if(option.equalsIgnoreCase(NBREGENERATE))
			{
				Utils.editXpath("web_radio_RegenerateOption_Dummy", "web_radio_RegenerateOption", new String[] {String.valueOf(2)});
				llAction.clickElement("web_radio_RegenerateOption");
			}else if(option.equalsIgnoreCase(CSREGENERATE))
			{
				Utils.editXpath("web_radio_RegenerateOption_Dummy", "web_radio_RegenerateOption", new String[] {String.valueOf(5)});
				llAction.clickElement("web_radio_RegenerateOption");
			}	else if(option.equalsIgnoreCase(CS_INCREMENTAL_REGENERATE))
			{
				Utils.editXpath("web_radio_RegenerateOption_Dummy", "web_radio_RegenerateOption", new String[] {String.valueOf(4)});
				llAction.clickElement("web_radio_RegenerateOption");
			}*/
				llAction.clickElement("web_radio_NBRegenerate");
				if(language.equalsIgnoreCase(ENGLISH))
				{
					Utils.editXpath("web_radio_Language_Dummy", "web_radio_Language", new String[] {"Y"});
					llAction.clickElement("web_radio_Language");
				}else if(language.equalsIgnoreCase(BAHASA_MALAYSIA))
				{
					Utils.editXpath("web_radio_Language_Dummy", "web_radio_Language", new String[] {"W"});
					llAction.clickElement("web_radio_Language");
				}	else if(language.equalsIgnoreCase(BOTH_LANGUAGES))
				{
					Utils.editXpath("web_radio_Language_Dummy", "web_radio_Language", new String[] {"Z"});
					llAction.clickElement("web_radio_Language");
				}

				if(despatchType.equalsIgnoreCase(ELECTRONIC))
				{
					Utils.editXpath("web_radio_DespatchType_Dummy", "web_radio_DespatchType", new String[] {"I"});
					llAction.clickElement("web_radio_DespatchType");
				}else if(despatchType.equalsIgnoreCase(HAND))
				{
					Utils.editXpath("web_radio_DespatchType_Dummy", "web_radio_DespatchType", new String[] {"H"});
					llAction.clickElement("web_radio_DespatchType");
				}	else if(despatchType.equalsIgnoreCase(MAIL))
				{
					Utils.editXpath("web_radio_DespatchType_Dummy", "web_radio_DespatchType", new String[] {"M"});
					llAction.clickElement("web_radio_DespatchType");
				}
				/*Utils.editXpath("web_radio_Language_Dummy", "web_radio_Language", new String[] {hParams.get("Language")});
				llAction.clickElement("web_radio_Language");
				Utils.editXpath("web_radio_DespatchType_Dummy", "web_radio_DespatchType", new String[] {hParams.get("DespatchType")});
				llAction.clickElement("web_radio_DespatchType");*/
				dashboard.setStepDetails("Choose the required options in Regenerate Policy Document page",
						"Required options are selected", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_PartySubmit");
				llAction.waitUntilLoadingCompletes();
				llAction.deleteFromCookies(new Cookie("current_module_id","300964"));
				dashboard.setStepDetails("Click on Submit",
						"Policy document is regenerated", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_reprint_return");
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_uw_btn_withdrawCancel");
				llAction.waitUntilLoadingCompletes();
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	public void despatchIndividual(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("NBD", "Despatch Policy Acknowledgement", "Individual");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_dm_txt_DMSPolicyNo", hParams.get("PolicyNumber"));
			dashboard.setStepDetails("Enter Policy Number to be searched ",
					"Policy Number is entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_SubmitCRSIndi");
			llAction.waitUntilLoadingCompletes();
			if(llAction.isDisplayed("web_coln_no_rec_found")){
				dashboard.setFailStatus(new BPCException("Search policy failed! No record found with the policy no provided."));
				dashboard.writeResults();
			}else{
				dashboard.setStepDetails("Click on Submit button", "Policy acknowledgement page is displayed.","N/A");
				dashboard.writeResults();
				llAction.enterValue("web_txt_despatchDate", hParams.get("DespatchDate"));
				dashboard.setStepDetails("Enter Despatch date ",
						"Despatch date is entered", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_SubmitCRSIndi");
				llAction.waitUntilLoadingCompletes();
				if(llAction.isDisplayed("web_txt_ErrorMessagenote"))
				{
					dashboard.setFailStatus(new BPCException("Invalid Policy is chosen."));
					dashboard.writeResults();	
				}
				else {
					dashboard.setStepDetails("Click on Submit",
							"Despatch date is updated", "N/A");
					dashboard.writeResults();

					llAction.clickElement("web_uw_btn_withdrawCancel");
					llAction.waitUntilLoadingCompletes();
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	public void despatchBulk(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("NBD", "Despatch Policy Acknowledgement", "Bulk");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_policyIssueStartdate", hParams.get("PolicyIssueStartDate"));
			llAction.enterValue("web_txt_policyIssueEnddate", hParams.get("PolicyIssueEndDate"));
			llAction.clickElement("web_uw_btn_Search");
			if(llAction.isDisplayed("web_coln_no_rec_found")){
				dashboard.setFailStatus(new BPCException("Search policy failed! No record found with policy issue date range provided."));
				dashboard.writeResults();
			}else{
				dashboard.setStepDetails("Enter policy issue date range", "Despatch and Acknowledgement page is displayed.","N/A");
				dashboard.writeResults();
				llAction.enterValue("web_txt_despatchDate", hParams.get("DespatchDate"));
				llAction.clickElement("web_btn_SelectAll");
				dashboard.setStepDetails("Click SelectAll and enter Despatch date", "All policies are selected and despatch date is entered","N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_SubmitCRSIndi");
				llAction.waitUntilLoadingCompletes();
				if(llAction.isDisplayed("web_txt_ErrorMessagenote"))
				{
					dashboard.setFailStatus(new BPCException("Invalid Policy is chosen."));
					dashboard.writeResults();	
				}
				else {
					dashboard.setStepDetails("Click on Submit",
							"Despatch date is updated", "N/A");
					dashboard.writeResults();
					llAction.clickElement("web_uw_btn_withdrawCancel");
					llAction.waitUntilLoadingCompletes();
				}
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void adhocPrinting(Hashtable<String, String> hParams) throws Exception{
		String policyNumber = StringUtils.EMPTY;
		try {
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			llAction.selectMenuItem("NBD", "adhoc_printing");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_adhocprinting_policyNumber", hParams.get("PolicyNo"));
			llAction.clickElement("web_btn_adhocprinting_search");
			llAction.waitUntilLoadingCompletes();
			
			int colPos = llAction.GetColumnPositionInTable("web_chkBox_adhocPrintingSelectPolicy", "Policy No");
			int rowPos = llAction.GetRowPositionInTable("web_chkBox_adhocPrintingSelectPolicy", policyNumber, colPos);
			llAction.SelectRowInTable("web_chkBox_adhocPrintingSelectPolicy", rowPos, colPos-3, "input");
			
			llAction.clickElement("web_btn_PrintPolicy");
			llAction.waitUntilLoadingCompletes();
			
			String successMsg = llAction.getText("web_lbl_successMsg_printpolicy");
			if(successMsg.equals("Policy print/regenerate Successfully !")) {
				dashboard.setStepDetails("Validate if Policy print/regenerate is Successful","Policy print/regenerate is Successful", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_retrunPrintPolicy");
				llAction.waitUntilLoadingCompletes();
			}else {
				dashboard.setFailStatus(new BPCException("Policy print/regenerate Unsuccessfull"));
			}
		}catch(Exception ex) {
			throw new Exception(ex);
		}
	}
}
