package ge.fpms.main.bpc.bcp.templates.lockbox;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Header implements IPaymentSection {
	private Type recordType;
	private Type labelId;
	private Type headerXNDate;
	private Type totalPolicies;
	private Type processingBank;
	private Type procService;
	private Type extractionTime;
	private Type  bankAccount;
	private Type filler;	
	
	public Header() {
	}

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getLabelId() {
		return labelId;
	}

	public void setLabelId(Type labelId) {
		this.labelId = labelId;
	}


	public Type getHeaderXNDate() {
		return headerXNDate;
	}


	public void setHeaderXNDate(Type headerXNDate) {
		this.headerXNDate = headerXNDate;
	}


	public Type getTotalPolicies() {
		return totalPolicies;
	}

	public void setTotalPolicies(Type totalPolicies) {
		this.totalPolicies = totalPolicies;
	}

	public Type getProcessingBank() {
		return processingBank;
	}

	public void setProcessingBank(Type processingBank) {
		this.processingBank = processingBank;
	}

	public Type getProcService() {
		return procService;
	}

	public void setProcService(Type procService) {
		this.procService = procService;
	}

	public Type getExtractionTime() {
		this.extractionTime.setValue(constructExtractionDate());
		return extractionTime;
	}


	public void setExtractionTime(Type extractionTime) {
		this.extractionTime = extractionTime;
	}


	public Type getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(Type bankAccount) {
		this.bankAccount = bankAccount;
	}

	public Type getFiller() {
		return filler;
	}

	public void setFiller(Type filler) {
		this.filler = filler;
	}

	public void setParamaters(ArrayList<String> buffer) {
		
		headerXNDate.setValue(buffer.get(0));
		totalPolicies.setValue(buffer.get(1));
		//extractionTime.setValue(buffer.get(2));
		bankAccount.setValue(buffer.get(2));
	}

	public String getName() {
		return "01";
	}


	public String toString() {
		String headerText =  new StringBuffer().append(recordType.toString()).append(labelId.toString())
				.append(headerXNDate.toString()).append(totalPolicies.toString())
				.append(processingBank.toString()).append(procService.toString())
				.append(getExtractionTime().toString()).append(bankAccount.toString()).append(filler.toString()).toString();
		return headerText;
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}

	@Override
	public int[] getAttributesSize() {
		// TODO Auto-generated method stub
		return null;
	}
	
	private String constructExtractionDate(){
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");
		return ((LocalTime.now().format(dtf))).replace(":", "");
	}
}
