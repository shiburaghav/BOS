package ge.fpms.main.bpc.bcp.templates.lockbox;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Summary implements IPaymentSection {
	
	private Type recordType;
	private Type labelId;
	private Type totTransactions;
	private Type totalAmtPaid;
	private Type totLoan;
	private Type totalLoanAmt;
	
	private Type totPrem;
	private Type totalPremAmt;	
	private Type totBans;
	private Type totBansAmt;
	private Type filler; 

	

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getLabelId() {
		return labelId;
	}

	public void setLabelId(Type labelId) {
		this.labelId = labelId;
	}

	public Type getTotTransactions() {
		return totTransactions;
	}

	public void setTotTransactions(Type totTransactions) {
		this.totTransactions = totTransactions;
	}

	public Type getTotalAmtPaid() {
		return totalAmtPaid;
	}

	public void setTotalAmtPaid(Type totalAmtPaid) {
		this.totalAmtPaid = totalAmtPaid;
	}

	public Type getTotLoan() {
		return totLoan;
	}

	public void setTotLoan(Type totLoan) {
		this.totLoan = totLoan;
	}

	public Type getTotalLoanAmt() {
		return totalLoanAmt;
	}

	public void setTotalLoanAmt(Type totalLoanAmt) {
		this.totalLoanAmt = totalLoanAmt;
	}

	public Type getTotPrem() {
		return totPrem;
	}

	public void setTotPrem(Type totPrem) {
		this.totPrem = totPrem;
	}

	public Type getTotalPremAmt() {
		return totalPremAmt;
	}

	public void setTotalPremAmt(Type totalPremAmt) {
		this.totalPremAmt = totalPremAmt;
	}

	public Type getTotBans() {
		return totBans;
	}

	public void setTotBans(Type totBans) {
		this.totBans = totBans;
	}

	public Type getTotBansAmt() {
		return totBansAmt;
	}

	public void setTotBansAmt(Type totBansAmt) {
		this.totBansAmt = totBansAmt;
	}

	public Type getFiller() {
		return filler;
	}

	public void setFiller(Type filler) {
		this.filler = filler;
	}

	public void setParamaters(String[] buffer) {
	}

	public String getName() {
		return "03";
	}

	public String toString() {

		return new StringBuffer().append(recordType.toString())
				.append(labelId.toString())
				.append(totTransactions.toString())
				.append(totalAmtPaid.toString())
				.append(totLoan.toString())
				.append(totalLoanAmt.toString())
				.append(totPrem.toString())
				.append(totalPremAmt.toString())
				.append(totBans.toString())
				.append(totBansAmt.toString())
				.append(filler.toString()).toString();
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}

	@Override
	public int[] getAttributesSize() {
		// TODO Auto-generated method stub
		return null;
	}

}
