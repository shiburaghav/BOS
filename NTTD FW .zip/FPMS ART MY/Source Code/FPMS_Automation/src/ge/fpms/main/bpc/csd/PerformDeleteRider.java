package ge.fpms.main.bpc.csd;

import ge.fpms.main.actions.FPMS_Actions;

import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.nttdata.core.LL_Actions;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class PerformDeleteRider {

	private final static Logger LOGGER = Logger.getLogger(PerformDeleteRider.class.getName());
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	
	public PerformDeleteRider() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	public void DeleteRider(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.waitUntilElementPresent("web_txt_deleterider_validity_date");
			String benfitcode = hParams.get("BenefitCode");
			String clickActionButtonName = hParams.get("DeleteRiderfrom");
			String cancelationReason = hParams.get("Cancellationreason");
			String applicationStatus = hParams.get("ApplicationStatus");
			String validityDate = hParams.get("Validitydate");

			llAction.enterValue("web_txt_deleterider_validity_date", validityDate);

			int colPos = llAction.GetColumnPositionInTable("web_tbl_deleterider_benefitinfo", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_deleterider_benefitinfo", benfitcode, colPos);
			DeleteRiderCaptureBeforeOrAfterChange("BeforeChange");
			llAction.SelectRowInTable("web_tbl_deleterider_benefitinfo", rowPos, colPos - 2, "input");

			DeleteRiderFromButtonClick(clickActionButtonName);
			llAction.waitUntilLoadingCompletes();

			llAction.selectByVisibleText("web_dd_deleterider_cancellation_reason", cancelationReason);
			dashboard.setStepDetails("Select " + cancelationReason + " From Cancelation Reason",
					"Cancelation Reason should be accepted by the system", "N/A");
			dashboard.writeResults();

			DeleteRiderClickSubmitButton(" ILP Delete Rider screen is shown and Delete Riders Information is displyed");

			llAction.move_to_element("web_txt_deleterider_refundamt");

			DeleteRiderCaptureBeforeOrAfterChange("AfterChange");

			DeleteRiderClickSubmitButton("System should display Modify collection or Refund screen");
			llAction.waitUntilLoadingCompletes();

			DeleteRiderClickSubmitButton("System should display Application Entry screen");
			llAction.waitUntilLoadingCompletes();

			DeleteRiderClickSubmitButton("System should display Display offset fee result screen");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Click on Exit Buttom", "System should show Operation result screen",
					"N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_deleterider_exit_button");
			llAction.waitUntilLoadingCompletes();

			if (llAction.getText("web_txt_fullsurrender_message").toLowerCase().replace("'", "").replace(" ", "")
					.contains(applicationStatus.toLowerCase().replace("'", "").replace(" ", ""))) {
				dashboard.setStepDetails(applicationStatus + " Should be populated", "Message is validated",
						"N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(applicationStatus + "message is invalid/Submit was not successful");
				dashboard.writeResults();
			}

			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_txt_common_back_to_main");
		} catch (Exception ex) {
			DashboardProperties.gBPCStatus = 1; // set the business component status to fail
			dashboard.writeResults();
			LOGGER.log(Level.SEVERE,
					"Exception occured while calling PerformDeleteRider Method \n Exception is " + ex.getMessage());
			throw new BPCException("");
		}
	}

	public void DeleteRiderFromButtonClick(String actionButton) throws Exception {
		try {

			switch (actionButton.toLowerCase()) {
			case "delete unit deduction rider immediately":
				llAction.clickElement("web_btn_deleterider_delete_unit_deduction_rider_immediately");
				break;
			case "delete unit deduction rider from last risk charge date":
				llAction.clickElement("web_btn_deleterider_delete_unit_deduction_rider_from_lastRiskChargeDate");
				break;
			case "delete unit deduction rider from next risk charge date":
				llAction.clickElement("web_btn_deleterider_delete_unit_deduction_rider_from_NextRiskChargeDate");
				break;
			case "delete cash rider immediately":
				llAction.clickElement("web_btn_deleterider_delete_cash_rider_immediately");
				break;
			case "delete cash rider from inception date":
				llAction.clickElement("web_btn_deleterider_delete_cash_rider_from_Inception_date");
				break;
			case "delete cash rider from next due date":
				llAction.clickElement("web_btn_deleterider_delete_cash_rider_from_nextduedate");
				break;
			}
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on " + actionButton,
					"System should display Cancellation reason Entry screen", "N/A");
			dashboard.writeResults();

		} catch (Exception ex) {
			DashboardProperties.gBPCStatus = 1; // set the business component status to fail
			dashboard.writeResults();
			LOGGER.log(Level.SEVERE,
					"Exception occured while calling PerformDeleteRider Method \n Exception is " + ex.getMessage());
			throw new BPCException("");
		}
	}

	public void DeleteRiderClickSubmitButton(String expectedResult) throws Exception {
		try {

			llAction.clickElement("web_btn_deleterider_common_submit_button");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Submit button", expectedResult, "N/A");
			dashboard.writeResults();

		} catch (Exception ex) {
			DashboardProperties.gBPCStatus = 1; // set the business component status to fail
			dashboard.writeResults();
			LOGGER.log(Level.SEVERE,
					"Exception occured while calling PerformDeleteRider Method \n Exception is " + ex.getMessage());
			throw new BPCException("");
		}
	}

	public void DeleteRiderCaptureBeforeOrAfterChange(String ActionType) throws Exception {
		try {
			switch (ActionType.toUpperCase()) {
			case "BEFORECHANGE":
				dashboard.setStepDetails("ILP Delete Rider Before Changes", "Captured changes successfully",
						"N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":
				dashboard.setStepDetails("ILP Delete Rider After Changes", "Captured changes successfully",
						"N/A");
				dashboard.writeResults();
				break;
			}
		} catch (Exception ex) {
			DashboardProperties.gBPCStatus = 1; // set the business component status to fail
			dashboard.writeResults();
			LOGGER.log(Level.SEVERE,
					"Exception occured while calling Underwriting method \n Exception is " + ex.getMessage());
			throw new BPCException("");
		}
	}

}
