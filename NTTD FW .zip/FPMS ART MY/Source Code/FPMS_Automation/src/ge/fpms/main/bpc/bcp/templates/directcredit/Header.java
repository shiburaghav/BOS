package ge.fpms.main.bpc.bcp.templates.directcredit;

import java.util.ArrayList;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Header implements IPaymentSection {
	private Type recordType;
    private Type tapeId;
    private Type branch;
    private Type companyCIF;
    private Type companyName;
    private Type companyAC ;
    private Type instruction;
	private Type reversalIndicator;
	private Type creditingDebitingDate;
	private Type filler1 ;
	private Type customerRef ;
	private Type filler2;
	private Type valueDate;
	private Type filler3 ;
	    
	public static final int HEADER_OUTPUT_FIELD_COUNT=5;

	public Header() {
	}

	public Type getRecordType() {
		return recordType;
	}



	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}



	public Type getTapeId() {
		return tapeId;
	}



	public void setTapeId(Type tapeId) {
		this.tapeId = tapeId;
	}



	public Type getBranch() {
		return branch;
	}



	public void setBranch(Type branch) {
		this.branch = branch;
	}



	public Type getCompanyCIF() {
		return companyCIF;
	}



	public void setCompanyCIF(Type companyCIF) {
		this.companyCIF = companyCIF;
	}



	public Type getCompanyName() {
		return companyName;
	}



	public void setCompanyName(Type companyName) {
		this.companyName = companyName;
	}



	public Type getCompanyAC() {
		return companyAC;
	}



	public void setCompanyAC(Type companyAC) {
		this.companyAC = companyAC;
	}



	public Type getInstruction() {
		return instruction;
	}



	public void setInstruction(Type instruction) {
		this.instruction = instruction;
	}



	public Type getReversalIndicator() {
		return reversalIndicator;
	}



	public void setReversalIndicator(Type reversalIndicator) {
		this.reversalIndicator = reversalIndicator;
	}



	public Type getCreditingDebitingDate() {
		return creditingDebitingDate;
	}



	public void setCreditingDebitingDate(Type creditingDebitingDate) {
		this.creditingDebitingDate = creditingDebitingDate;
	}



	public Type getFiller1() {
		return filler1;
	}



	public void setFiller1(Type filler1) {
		this.filler1 = filler1;
	}



	public Type getCustomerRef() {
		return customerRef;
	}



	public void setCustomerRef(Type customerRef) {
		this.customerRef = customerRef;
	}



	public Type getFiller2() {
		return filler2;
	}



	public void setFiller2(Type filler2) {
		this.filler2 = filler2;
	}



	public Type getValueDate() {
		return valueDate;
	}



	public void setValueDate(Type valueDate) {
		this.valueDate = valueDate;
	}



	public Type getFiller3() {
		return filler3;
	}



	public void setFiller3(Type filler3) {
		this.filler3 = filler3;
	}



	public int[] getAttributesSize() {
		
		return new int[] { recordType.getSize(),tapeId.getSize(),branch.getSize(), companyCIF.getSize(),companyName.getSize(),
				companyAC.getSize(), instruction.getSize(), reversalIndicator.getSize(), 
				creditingDebitingDate.getSize(), filler1.getSize(), customerRef.getSize(), filler2.getSize()};
	}

	public void setParamaters(ArrayList<String> buffer) {
		
		recordType.setValue(buffer.get(0));
		tapeId.setValue(buffer.get(1));
		branch.setValue(buffer.get(2));
		companyCIF.setValue(buffer.get(3));
		companyName.setValue(buffer.get(4));
		companyAC.setValue(buffer.get(5));
		instruction.setValue(buffer.get(6));
		reversalIndicator.setValue(buffer.get(7));
		creditingDebitingDate.setValue(buffer.get(8));
		filler1.setValue(buffer.get(9));
		customerRef.setValue(buffer.get(10));
		filler2.setValue(buffer.get(11));
	}

	public String getName() {
		return "01";
	}

	public String toString() {
		String headerText =  new StringBuffer().append(recordType.toString())
				.append(companyAC.toString()).append(valueDate.toString()).append(customerRef.toString()).append(filler3.toString()).toString();
		return headerText;
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}
}
