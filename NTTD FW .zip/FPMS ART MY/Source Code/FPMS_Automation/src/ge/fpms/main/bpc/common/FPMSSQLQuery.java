package ge.fpms.main.bpc.common;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;

import java.util.Hashtable;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFCreationHelper;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFCellUtil;

import com.nttdata.common.util.ColumnHeader;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.framework.exceptions.BPCException;
import com.sun.jmx.snmp.Timestamp;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.FPMSProperties;

public class FPMSSQLQuery {

	private ResultSet resultSet;
	private Statement stmt;
	private HSSFWorkbook workbook;
	private HSSFFont boldFont;
	private HSSFFont normalFont;
	private HSSFSheet sheet;
	private static java.sql.Connection dbConnection;
	private static DashboardHandler dashboardHandler;

	public FPMSSQLQuery() {
		dashboardHandler = DashboardHandler.getInstance();
		dbConnection = null;
	}

	public ArrayList<String> getPolicNumbers(Hashtable<String, String> hParams) {
		try {
			PolicyHandler policyHandler = FPMSManager.getInstance().getPolicyHandler();		
			ArrayList<String> policyNumbers = new ArrayList<String>();
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				if(!hParams.get("PolicyNumber").isEmpty())
				{					
					Collections.addAll(policyNumbers, hParams.get("PolicyNumber").split(","));	
					policyHandler.getPolicy().setPolicyNo(policyNumbers.get(0));
				}
			} else {

				policyNumbers.add(policyHandler.getPolicy().getPolicyNo());
			}
			return policyNumbers;
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void executeQuery(Hashtable<String, String> hParams) throws Exception {
		try {
			ArrayList<String> policNumbers = getPolicNumbers(hParams);			
			hParams = getSQLQueries();
			for(String policNumber :policNumbers ) {
				
				workbook = new HSSFWorkbook();
				boldFont = workbook.createFont();
				normalFont = workbook.createFont();
				HSSFCellStyle style = workbook.createCellStyle();
				Timestamp time = new Timestamp(System.currentTimeMillis());
				for (int i = 1; i <= Integer.parseInt(hParams.get("NoOfQueries")); i++) {
					String queryToBeExecuted = hParams.get("SQL" + i + "");

					Class.forName("oracle.jdbc.driver.OracleDriver");

					// if(dbConnection == null) {
					dbConnection = DriverManager.getConnection(System.getProperty("Settings.DBConnectionString"),
							System.getProperty("Settings.DBUsername"), System.getProperty("Settings.DBPassword"));
					// }

					String[] queryParams = new String[] { policNumber };
					queryToBeExecuted = constructQuery(queryToBeExecuted, queryParams);

					stmt = dbConnection.createStatement();
					resultSet = stmt.executeQuery(queryToBeExecuted);

					boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
					sheet = workbook.createSheet("SQL" + i + "");
					HSSFRow titleRow = sheet.createRow(0);
					ResultSetMetaData metaData = resultSet.getMetaData();
					int columnCount = metaData.getColumnCount();
					for (int colIndex = 0; colIndex < columnCount; colIndex++) {
						String title = metaData.getColumnLabel(colIndex + 1);
						HSSFCell cell = HSSFCellUtil.createCell(titleRow, colIndex, title);
						style.setFont(boldFont);
						cell.setCellStyle(style);
					}

					int currentRow = 1;
					while (resultSet.next()) {
						HSSFRow row = sheet.createRow(currentRow++);
						for (int colIndex = 0; colIndex < columnCount; colIndex++) {
							Object value = resultSet.getObject(colIndex + 1);
							final HSSFCell cell = row.createCell(colIndex);
							if (value == null) {
								cell.setCellValue("");
							} else {
								if (value instanceof Calendar) {
									cell.setCellValue((Calendar) value);
								} else if (value instanceof Date) {
									HSSFCreationHelper cr = workbook.getCreationHelper();
									style.setDataFormat(cr.createDataFormat().getFormat("m/d/yy"));
									normalFont.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
									cell.setCellStyle(style);
									style.setFont(normalFont);
									cell.setCellValue((Date) value);
								} else if (value instanceof String) {
									cell.setCellValue((String) value);
								} else if (value instanceof Boolean) {
									cell.setCellValue((Boolean) value);
								} else if (value instanceof Double) {
									cell.setCellValue((Double) value);
								} else if (value instanceof BigDecimal) {
									cell.setCellValue(((BigDecimal) value).doubleValue());
								}
							}
						}
					}
					for (int j = 0; j < columnCount; j++) {
						sheet.autoSizeColumn(1);
					}
					String ouputFileFolderPath = dashboardHandler.getAssetPath();
					String destinationFilePath = ouputFileFolderPath + File.separator
							+ FPMSConstants.SQLQuery_FILE_BASENAME + "_" + policNumber + "_"
							+ time.getDateTime() + FPMSConstants.EXCELFILE_XLS_FORMAT;
					FileOutputStream fileOut = new FileOutputStream(destinationFilePath);
					workbook.write(fileOut);
					fileOut.close();
					
				}
				workbook.close();
				
			}
			dashboardHandler.setStepDetails("Write SQL Result to excel file", dashboardHandler.getAssetPath(), "");
			dashboardHandler.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		} finally {
			if (resultSet != null)
				resultSet.close();
		}

		if (stmt != null) {
			stmt.close();
			;
		}
		if (!dbConnection.isClosed())
			dbConnection.close();
	}

	public Hashtable<String, String> getSQLQueries()
	{
		DataHandler dataHandler = new DataHandler();

		Hashtable<String, String> sqlQueries = dataHandler.getTestData("SQLQuery",
				FPMSProperties.getInstance().getTestDataFilePath(System.getProperty("Settings.Module")),
				ColumnHeader.getColumnHeader("SQLQuery"), "1", "QID");
		return sqlQueries;
	}
	
	public String constructQuery(String query, String[] queryParams) {
		String newQuery = StringUtils.EMPTY;
		newQuery = Utils.editString(query, queryParams);
		return newQuery;
	}

	public void executeQueryAndMatchData() throws Exception {
		try {

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
