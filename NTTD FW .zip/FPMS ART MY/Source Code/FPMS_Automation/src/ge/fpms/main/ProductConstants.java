package ge.fpms.main;

public interface ProductConstants {

	public static String ENDOWMENT = "Endowment";

	public static String ILP = "ILP";

	public static String ANNUITY = "Annuity";

	public static String WHOLE_LIFE = "Whole Life";
	public static String A_H = "A&H";
	public static String TH = "TH";
	public static String UL = "UL";
	public static String TERM = "Term";
	public static String SHP = "SHP";
	public static String MORTGAGE = "Mortgage";
	public static String PAYCARE_EDOWMENT_LT_D = "PayCare & Pure Endowment w/o profit& Long Term Disability";
	public static String LA = "Living Assurance";
	public static String CASH_BENEFITS = "Cash benefit(no.of days)";
	public static String ACCIDENT = "Accident";
	public static String SMART_SAVER = "Smart Saver";
	public static String OTHER_PRODUCTS = "Others";
	public static String UNIVERSAL_LIFE = "Universal Life";
}
