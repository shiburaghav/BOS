package ge.fpms.main;

import com.nttdata.app.ARTDriver;
import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.WindowsUtility;
import com.nttdata.core.TestCase;

import ge.fpms.data.FPMSARTDao;
import ge.fpms.data.PolicyHandler;
import ge.fpms.main.bpc.common.FPMSFileProcessor;

public class FPMSARTDriver extends ARTDriver implements Runnable {
	private Thread thread;

	public FPMSARTDriver() {
		thread = new Thread(this);
	}

	public static void main(String[] args) {
		/*
		 * System.out.println("FPMSARTDriver.main() - start : " +
		 * System.currentTimeMillis());
		 */
		FPMSProperties properties = FPMSProperties.getInstance();
		FPMSARTDriver driver = new FPMSARTDriver();
		driver.preExecution();
		driver.execute(properties);
		driver.postExecution();
		/*
		 * System.out.println("FPMSARTDriver.main() - end : " +
		 * System.currentTimeMillis());
		 */}

	@Override
	public void preExecution() {
		setExecutionStatus(FPMSConstants.EXECUTION_STATUS_NOT_STARTED);
		try {
			// Utils.killProcess("KIEDriverServer.exe");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void execute(ARTProperties prop) {
		setExecutionStatus(FPMSConstants.EXECUTION_STATUS_INPROGRESS);
		thread.start();
		super.execute(prop);
		thread.interrupt();
	}

	@Override
	public void postExecution() {
		setExecutionStatus(FPMSConstants.EXECUTION_STATUS_COMPLETE);
		FPMSFileProcessor fpmsFileProcessor = new FPMSFileProcessor();
		try {
			fpmsFileProcessor.persistInfo();			
			
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	@Override
//	public void endTestCase(TestCase testCase) throws Exception {
//
//		PolicyHandler policyHandler = FPMSManager.getInstance().getPolicyHandler();
//		try {
//			FPMSARTDao artDao = new FPMSARTDao(testCase, policyHandler.getPolicy());
//			policyHandler.addPolicytoList(artDao);
//
//		} catch (Exception e) {
//
//			throw new Exception(e);
//		}
//
//	}

	public void run() {
		while (getExecutionStatus().equalsIgnoreCase(FPMSConstants.EXECUTION_STATUS_INPROGRESS)) {
			try {
				// Thread.sleep(120000);
				Thread.sleep(60000);
				WindowsUtility.keepSystemActive();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
