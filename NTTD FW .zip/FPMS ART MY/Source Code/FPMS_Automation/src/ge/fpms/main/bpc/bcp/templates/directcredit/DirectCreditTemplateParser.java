package ge.fpms.main.bpc.bcp.templates.directcredit;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.bpc.bcp.templates.IPaymentType;
import ge.fpms.main.bpc.bcp.templates.PaymentTemplatesParse;
import ge.fpms.main.bpc.bcp.templates.Type;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.nttdata.common.util.ColumnHeader;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.framework.exceptions.BPCException;

public class DirectCreditTemplateParser extends PaymentTemplatesParse{

	
	private static final String SHEET_NAME = "DIRECTCREDIT";
	private DirectCredit directCredit;
	private ArrayList<Details> detailList;
	private Details initalDR;
	private String inputFilePath;
	private String outputFilePath;
	
	public DirectCreditTemplateParser() {
		super();
		detailList = new ArrayList<Details>();
	}
	/**
	 * parseGiro - for parsing giro files
	 * @param params - parameters from testdata
	 * @throws Exception 
	 */
	public void processDirectCreditTemplate(Hashtable<String, String> params) throws Exception {
		inputFilePath = params.get("InputFile");
		String jsonTemplate = FPMSProperties.getInstance().getJsonPath("directcredit.json");
		loadObject(jsonTemplate);		
		processTemplateFile(params);
	}
	@Override
	public void beginParse(String line)  throws Exception{
		parseHeader(line);
		initalDR = directCredit.getDetails()[0];
	}	
	
	@Override
	public void parse(String line) throws Exception {
		try {

			if (line.startsWith(initalDR.getName())) {
				int startIndex = 0, endIndex = 0;

				int[] attributeSpace = initalDR.getAttributesSize();
				Type[] attributes = initalDR.getAllAttributes();
				Type[] newAttributes = new Type[Details.DETAILS_OUTPUT_FIELD_COUNT];
				String[] attributeNames = initalDR.getAllAttributeNames();
				 ArrayList<String> returnFileAttributeName = initalDR.getOutputFieldName();
				 int counter = 0;
				for (int i = 0; i < Details.DETAILS_OUTPUT_FIELD_COUNT; i++) {
					String value = "";
					endIndex += attributeSpace[i];
					if (endIndex <= line.length()) {
						value = new String(line.substring(startIndex, endIndex));
						startIndex = endIndex;
					} else {
						value = "";
					}
					if(returnFileAttributeName.contains(attributeNames[i])){
						newAttributes[counter] = new Type(attributeSpace[i],
							attributes[i].getDataType(), value,
							attributes[i].getAlignment(),
							attributes[i].getPaddingChar());
						counter++;
					}
				}
				
				newAttributes[counter] = new Type(initalDR.getReturnCode().getSize(),
						initalDR.getReturnCode().getDataType(), initalDR.getReturnCode().getValue(),
						initalDR.getReturnCode().getAlignment(),
						initalDR.getReturnCode().getPaddingChar());
				newAttributes[counter + 1] = new Type(initalDR.getRejectCode().getSize(),
						initalDR.getRejectCode().getDataType(), initalDR.getRejectCode().getValue(),
						initalDR.getRejectCode().getAlignment(),
						initalDR.getRejectCode().getPaddingChar());
				newAttributes[counter + 2] = new Type(initalDR.getSuccessIndicator().getSize(),
						initalDR.getSuccessIndicator().getDataType(), initalDR.getSuccessIndicator().getValue(),
						initalDR.getSuccessIndicator().getAlignment(),
						initalDR.getSuccessIndicator().getPaddingChar());
				newAttributes[counter + 3] = new Type(initalDR.getdFiller3().getSize(),
						initalDR.getdFiller3().getDataType(), initalDR.getdFiller3().getValue(),
						initalDR.getdFiller3().getAlignment(),
						initalDR.getdFiller3().getPaddingChar());
				
				detailList.add(getRecordCount(), new Details(newAttributes));
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	@Override
	public void endParse(String line) throws Exception {
		directCredit.setDetails( detailList.toArray(new Details[0]));
		parseFooter(line);
		
	}


	@Override
	public void createNewFile(String outputFile) throws Exception {
		try {
			outputFilePath = getGiroReturnFilePath();
			
			BufferedWriter out = new BufferedWriter(new FileWriter(outputFilePath));
			out.write(directCredit.getHeader().toString()); out.newLine();
			for(Details det : directCredit.getDetails()){
				out.write(det.toString()); out.newLine();
			}
			
			out.write(directCredit.getSummary().toString());
			out.close();
			
		} catch (Exception e) {
			throw new BPCException(e);
		}

				
	}

	@Override
	public void updateAttributes(Hashtable<String, String> params)
			throws Exception {
		try {
			// Updating Details Section
			String policyNumber = params.get("PolicyNumber");
			if(!StringUtils.isEmpty(policyNumber))
			{
				String[] tdPolicies = policyNumber.split(",");
				
				Details dt[] = directCredit.getDetails();
				for (int i = 0; i < tdPolicies.length; i++) {
	
					for (Details d : dt) {
						Hashtable<String, String> dcData = getDirectCredit(tdPolicies[i]);
						String dPolicy = d.getReferenceNumber().getValue(); 
						int dAmount = Integer.parseInt(d
								.getAmount().getValue()); // Settlement Amount inCents
						int tdAmt = Integer.parseInt(dcData.get("Amount").replace(".", ""));
					
						if (tdPolicies[i].contains(dPolicy) && dAmount == tdAmt) {
							
							d.getdInstruction().setValue(dcData.get("Instruction"));
							d.getReturnCode().setValue(dcData.get("ReturnCode"));
							d.getRejectCode().setValue(dcData.get("RejectCode"));
							if(dcData.get("ReturnCode").equalsIgnoreCase("00") && dcData.get("RejectCode").equalsIgnoreCase("00"))
							{
								d.getSuccessIndicator().setValue(IPaymentType.SUCCESS_INDICATOR_Y);
							}else{
								d.getSuccessIndicator().setValue(IPaymentType.SUCCESS_INDICATOR_N);
							}
							
							break;
						}
					}
				}
			}
			String valueDate = new SimpleDateFormat("ddMMyyyy_HHmmss").format(Calendar.getInstance().getTime());
			valueDate = valueDate.substring(0,valueDate.indexOf("_"));
			directCredit.getHeader().getValueDate().setValue(valueDate);
			// Updating Summary - with accepted/rejected count & amount and
			// transaction count & amount
			int totalAcceptedCount = 0, totalRejectedCount = 0, totalAcceptedAmount = 0, 
					totalRejectedAmount = 0, totalTransactionCount = 0, totalTransactionAmount = 0;

			for (Details d : directCredit.getDetails()) {
				int dAmount = Integer.parseInt(d.getAmount().getValue());
				if (!d.getRejectCode().getValue().trim()
						.equals(IPaymentType.DEFAULT_DC_SUCCESS_CODE)) {
					totalRejectedCount++;
					totalRejectedAmount = totalRejectedAmount + dAmount;
				} else {
					totalAcceptedCount++;
					totalAcceptedAmount = totalAcceptedAmount + dAmount;
				}
				totalTransactionCount = totalAcceptedCount + totalRejectedCount;
				totalTransactionAmount = totalAcceptedAmount
						+ totalRejectedAmount;
			}

			directCredit.getSummary().getAcceptedCount().setValue(String.valueOf(totalAcceptedCount));
			directCredit.getSummary().getRejectedCount().setValue(String.valueOf(totalRejectedCount));
			directCredit.getSummary().getAcceptedAmount().setValue(String.valueOf(totalAcceptedAmount));
			directCredit.getSummary().getRejectedAmount().setValue(String.valueOf(totalRejectedAmount));
			directCredit.getSummary().getTotalCount().setValue(String.valueOf(totalTransactionCount));
			directCredit.getSummary().getTotalAmount().setValue(String.valueOf(totalTransactionAmount));
			

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	/**
	 * load the GIRO Structure using the JSON template
	 * @param jsonTemplate
	 */
	private void loadObject(String jsonTemplate) throws Exception {
		try {

			Gson gson = new Gson();
			directCredit = gson.fromJson(new FileReader(jsonTemplate), DirectCredit.class);			
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}
	
	private void parseHeader(String line) throws Exception {
		try {
			if (line.startsWith(directCredit.getHeader().getName())) {
				int startIndex = 0, endIndex = 0;
				ArrayList<String> buffer = new ArrayList<String>();
				int[] attributeSpace = directCredit.getHeader().getAttributesSize();
				for (int i = 0; i < attributeSpace.length; i++) {
					endIndex += attributeSpace[i];
					buffer.add(line.substring(startIndex, endIndex));
					startIndex = endIndex;
				}

				directCredit.getHeader().setParamaters(buffer);

			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	private void parseFooter(String line) throws Exception {
		if(line.startsWith(directCredit.getSummary().getName()))
		{
			int startIndex = 0,  endIndex=0;
			int[] attributeSpace = directCredit.getSummary().getAttributesSize();
			String []attributesValues = new String[attributeSpace.length];
			
			for(int i = 0; i<attributeSpace.length;i++)
			{
				endIndex+=attributeSpace[i];
				
				if(endIndex<=line.length()){
					attributesValues[i] = new String(line.substring(startIndex,endIndex));
					startIndex = endIndex;
				}else{
					break;
				}
			}
			
			directCredit.getSummary().setParamaters(attributesValues);
		}		
	}

	public String getInputFilePath() {
		return inputFilePath;
	}
	public String getGiroReturnFilePath() {
		return System.getProperty("Settings.ART Downloads") + File.separator + getDirectCreditOutputFileName();
	}
	
	public Hashtable<String, String> getDirectCredit(String pNumber) {
		DataHandler dataHandler = new DataHandler();
		Hashtable<String, String> giroData = dataHandler.getTestData(SHEET_NAME,
				FPMSProperties.getInstance().getTestDataFilePath(FPMSConstants.MODULE_BCPBATCH),
				ColumnHeader.getColumnHeader(SHEET_NAME), pNumber, "PolicyNumber");
		return giroData;
	}
/*	public static void main(String[] args)  {
		String dwlLoad ="C:\\Users\\suchitraravindran\\Documents\\FPMS\\MY\\H2HDDS10005228082018001.dat";
		String output = "D:\\FPMS_ART\\";
		Hashtable<String, String> params = new Hashtable<String, String>();
		params.put("InputFile", dwlLoad);
		params.put("OutputFile", output);
		params.put("PolicyNumber", "0073120962");
		params.put("Amount", "5700");
		params.put("ReturnCode", "05");
		
		try {
			new DirectCreditTemplateParser().processDirectCreditTemplate(params);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/

	public String getDirectCreditOutputFileName() {
		
		
		String d1 = new SimpleDateFormat("ddMMyyyy_HHmmss").format(Calendar.getInstance().getTime());

		d1 = d1.substring(0,d1.indexOf("_"));
		String d2 = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
		d2 = d2.substring(0,d2.indexOf("_"));
		String d3 = getRandomNumberInRange(1, 999999);
		String d4 = d3.substring(d3.length() - 2, d3.length());
		
		String fileName = IPaymentType.DC_OUTPUT_FILE_NAME.replace("%%%", d1);
		fileName = fileName.replace("###", d3);
		fileName = fileName.replace("%%", d2);
		fileName = fileName.replace("##", d4);
		System.out
				.println("DirectCreditTemplateParser.getDirectCreditInputFileName() fileNmame : " + fileName);
		return fileName;
	}
	
	private String getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		int rnumber =  r.nextInt((max - min) + 1) + min;
		String srandomNo = String.valueOf(rnumber);
		srandomNo = srandomNo.length() < 6 ? Utils.rightPad(srandomNo, 6, '0') : srandomNo;
		return srandomNo;
	}
	
	public String getDCInputFileName(String bpdate) {
		
		String fileName = IPaymentType.DC_INPUT_FILENAME;

		return fileName;
	}

}