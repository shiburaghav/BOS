package ge.fpms.main.bpc.csd;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.LL_Actions;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

/*
 * Name: Reinstatement 
 * Purpose: Navigate to CS module from the Main Page and Reinstatement a policy
 * Parameters:Parameter Hash table 
 * Return Value: NA 
 * Exception: BPCException
 * @author: Sridhar 0n 18/01/2018
 */
public class ReinstatementComponent {

	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;

	public ReinstatementComponent() {
		dashboard = DashboardHandler.getInstance();
	}

	public void reinstatement(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		try {
			clickEnterInformation(hParams);
			CSDHelper.getInstance().captureChange("CaptureBefore", "BeforeChange");

			if(llAction.isDisplayed("web_btn_reinstatethepolicywithfullamount",2)) // check if Full amount text exist then ILP else Traditional
			{
				ilpreinstatement(hParams);
				submit(hParams);
			}
			else {

				tradReinstatement(hParams);
				submit(hParams);
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validatingAtEnterinformationClick(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			llAction.waitUntilLoadingCompletes();
			String getWarningMsg = llAction.getText("web_txt_ErrorWarningCancellation").trim();
			errorValidateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage-EnterInformation"));
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void reinstatementValidateErrorMessage(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		try {
			clickEnterInformation(hParams);
			CSDHelper.getInstance().captureChange("CaptureBefore", "BeforeChange");
			ilpreinstatement(hParams);
			String getWarningMsg = llAction.getText("web_txt_ErrorWarning").trim();
			errorValidateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage-Submit"));

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void normalRevivalvalidationAtSubmit(Hashtable<String, String> hParams) throws Exception {
		clickEnterInformation(hParams);
		CSDHelper.getInstance().captureChange("CaptureBefore", "BeforeChange");
		tradReinstatement(hParams);
		CSDHelper.getInstance().validateWarningMessages("web_tbl_WarningTable_ilpIncreaseSA", hParams.get("WarningErrorMessage-Submit"));
//		String getWarningMsg = llAction.getText("web_txt_ErrorWarning").trim();
//		errorValidateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage-Submit"));

	}

	private void clickEnterInformation(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();

		if (llAction.isDisplayed("web_btn_continue", 5)) {
			String war = hParams.get("WarningErrorMessage-EnterInformation");
			if ((war != null) && (war != "")) {
				String warningMsg = llAction.getText("web_txt_warningmsg");
				errorValidatemultipleWarningMessages(warningMsg, war);
			}
			llAction.clickElement("web_btn_continue");
		}
	}

	private void tradReinstatement(Hashtable<String, String> hParams) throws Exception {

		int colPos;
		int rowPos;
		try {
			llAction = new FPMS_Actions();
			llAction.enterValue("web_txt_Reinstatement_ValidityDate_normal", hParams.get("Validitydate"));
			if (hParams.get("HealthWarrantyDate") != null && hParams.get("HealthWarrantyDate") != "") {
				llAction.enterValue("web_txt_HealthWarrantyDate", hParams.get("HealthWarrantyDate"));
				llAction.sendkeyStroke("web_txt_HealthWarrantyDate", Keys.ENTER);
				llAction.acceptAlert();
			}
			//added one condition to APL Reinstatement 
			//added on 27/03/2019
			if (!(llAction.isDisplayed("web_btn_aplreinstatement", 5))) {
			if ((hParams.get("BenefitCode") != null && hParams.get("BenefitCode") != "")) {
				colPos = llAction.GetColumnPositionInTable("web_tbl_Benefit_Infor_beforechange", "Benefit Name");
				rowPos = llAction.GetRowPositionInTable("web_tbl_Benefit_Infor_beforechange",
						hParams.get("BenefitCode"), colPos);
				llAction.SelectRowInTable("web_tbl_Benefit_Infor_beforechange", rowPos, colPos - 2, "input");
				dashboard.setStepDetails("Select Benefit option tickbox. ",
						"System should accept the selected details ", "N/A");
				dashboard.writeResults();
			} else {
				llAction.clickElement("web_btn_NormalRevival_All");
				dashboard.setStepDetails("Select Benefit option tickbox. ",
						"System should accept the selected details ", "N/A");
				dashboard.writeResults();
			}
			}
			String buttonName;
			String button;
			button = hParams.get("ReinstatePolicyAction").toLowerCase().replaceAll("\\s", "");
			buttonName = "web_btn_" + button;
			llAction.clickElement(buttonName);
			if (llAction.isDisplayed("web_btn_continue", 6)) {
				if (hParams.get("WarningErrorMessage-ResinatlamnatwithfullNormalRevival") != null && hParams.get("WarningErrorMessage-ResinatlamnatwithfullNormalRevival") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg",
							hParams.get("WarningErrorMessage-ResinatlamnatwithfullNormalRevival"));
					llAction.clickElement("web_btn_continue");
					llAction.waitUntilLoadingCompletes();
				} else {
					llAction.clickElement("web_btn_continue");
					llAction.waitUntilLoadingCompletes();
				}

			}
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("Validitydateanother") != null && hParams.get("Validitydateanother") != "") {
				llAction.enterValue("web_txt_Reinstatement_ValidityDate_normal", hParams.get("Validitydateanother"));
				llAction.sendkeyStroke("web_txt_Reinstatement_ValidityDate_normal", Keys.ENTER);
				llAction.waitUntilAlertisShown();
				dashboard.setStepDetails("Enter validity date with another date",
						"System should display error message \"All alteration details will be cleared, continue with the change?\"",
						"N/A");
				dashboard.writeResults();
				llAction.dismissAlert();
				llAction.waitUntilLoadingCompletes();
			}

			CSDHelper.getInstance().captureChange("CaptureAfterChange", "AfterChange");
			llAction.move_to_element("web_btn_NormalRevival_submit");
			llAction.clickElement("web_btn_NormalRevival_submit");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 6)) {
				if (hParams.get("WarningErrorMessage-Submit") != null && hParams.get("WarningErrorMessage-Submit") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg",
							hParams.get("WarningErrorMessage-Submit"));
					llAction.clickElement("web_btn_continue");
					llAction.waitUntilLoadingCompletes();
				} else {
					llAction.clickElement("web_btn_continue");
					llAction.waitUntilLoadingCompletes();
				}

			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void ilpreinstatement(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			llAction.enterValue("web_txt_Reinstatement_ValidityDate_fullamount", hParams.get("Validitydate"));
			if (hParams.get("HealthWarrantyDate") != null && hParams.get("HealthWarrantyDate") != "") {
				llAction.enterValue("web_txt_HealthWarrantyDate", hParams.get("HealthWarrantyDate"));
				llAction.sendkeyStroke("web_txt_HealthWarrantyDate", Keys.ENTER);
				llAction.acceptAlert();
			}
			String buttonName;
			String button;
			button = hParams.get("ReinstatePolicyAction").toLowerCase().replaceAll("\\s", "");
			buttonName = "web_btn_" + button;
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement(buttonName);
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails(
					"Click Reinstate the policy with" + hParams.get("ReinstatePolicyAction") + "button",
					"ystem should display ILP Reinstatement \r\n"
							+ " screen with Benefit information after reinstatement showing.",
					"N/A");
			dashboard.writeResults();
			llAction.scrolldown();
			CSDHelper.getInstance().captureChange("CaptureAfterChange", "AfterChange");
			llAction.clickElement("web_btnt_ILPReinstatement_submit");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void submit(Hashtable<String, String> hParams) throws Exception {
		if (llAction.isDisplayed("web_btn_continue", 6)) {
			String war = hParams.get("WarningErrorMessage-Submit");
			if ((war != null) && (war != "")) {
				CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg",
						hParams.get("WarningErrorMessage-Submit"));
				llAction.clickElement("web_btn_continue");
			} else {
				llAction.clickElement("web_btn_continue");
			}
		}
		llAction.waitUntilLoadingCompletes();		
		CSDHelper.getInstance().endOfTransaction();
	}

	public void validatingAtReinstatethePolicyClick(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
			}
			if (llAction.isDisplayed("web_btn_reinstatethepolicywithfullamount", 5)) {
				llAction.enterValue("web_txt_Reinstatement_ValidityDate_fullamount", hParams.get("Validitydate"));
				String buttonName;
				String button;
				button = hParams.get("ReinstatePolicyAction").toLowerCase().replaceAll("\\s", "");
				buttonName = "web_btn_" + button;
				llAction.clickElement(buttonName);
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_btn_continue", 5)) {
					llAction.clickElement("web_btn_continue");
					llAction.waitUntilLoadingCompletes();
				}
				String getWarningMsg = llAction.getText("web_txt_ErrorWarningCancellation").trim();
				errorValidateWarningMessages(getWarningMsg,
						hParams.get("WarningErrorMessage-ResinatlamnatwithfullNormalRevival"));
			} else if (llAction.isDisplayed("web_btn_APLReinstatement", 5)) {
				llAction.enterValue("web_txt_Reinstatement_ValidityDate_fullamount", hParams.get("Validitydate"));
				llAction.enterValue("web_txt_HealthWarrantyDate", hParams.get("HealthWarrantyDate"));
				llAction.sendkeyStroke("web_txt_HealthWarrantyDate", Keys.ENTER);
				llAction.acceptAlert();
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Enter validatyDate and HealthWarrantyDate. ",
						"System should accept input details ", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_APLReinstatement");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().validateWarningMessages("web_txt_ErrorWarningApl",
						hParams.get("WarningErrorMessage-ResinatlamnatwithfullNormalRevival"));
			} else {
				llAction.clickElement("web_btn_NormalRevival_submit");
				llAction.waitUntilLoadingCompletes();
				String getWarningMsg = llAction.getText("web_txt_ErrorWarningCancellation").trim();
				errorValidateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage-Submit"));
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void changeRPApportCaptureBeforeOrAfterChange(String ActionType) throws Exception {
		try {
			switch (ActionType.toUpperCase()) {
			case "BEFORECHANGE":
				dashboard.setStepDetails("Before Policy alterationitem top up", "Status should Pending Data Entry",
						"N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":
				dashboard.setStepDetails("After Policy alterationitem top up added", "Status should completed", "N/A");
				dashboard.writeResults();
				break;
			}
		} catch (Exception ex) {
			DashboardProperties.gBPCStatus = 1; // set the business component status to fail
			dashboard.writeResults();

			throw new BPCException(ex);
		}
	}

	public void errorValidateWarningMessages(String warningMsg, String message) throws Exception {
		if (warningMsg.contains(message)) { // compare warning messages
			// System.out.println(message +"" + warningMsg);
			dashboard.setStepDetails(message + "Warning message should be displayed",
					"Warning message should is displayed ", "N/A");
			dashboard.writeResults();
		} else {
			// DashboardHandler("Warning message "+warningMsg+" from application is not
			// matching with test data");
			dashboard.writeResults();
			throw new Exception("ex");
		}
	}

	public void errorValidatemultipleWarningMessages(String warningMsg, String message) throws Exception {
		List<String> allWarningMsgs = new ArrayList<String>();
		List<WebElement> allErrors = null;
		LL_Actions llAction = new LL_Actions();
		Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get("web_tbl_warning_msg");
		String temp = hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]) + "/tbody/tr/td";
		hTableGUIMap.put("xpath", temp);
		ARTProperties.guiMap.put("web_tbl_warning_msg1", hTableGUIMap);
		allErrors = llAction.findElements("web_tbl_warning_msg1");
		Utils.sleep(2);
		for (WebElement Element : allErrors) {
			String Text = Element.getText();
			allWarningMsgs.add(Text);
		}
		String messageslist[] = message.split(",");
		int size = allWarningMsgs.size();
		boolean messageFound = false;
		for (int i = 0; i < size; i++) {
			messageFound = false;
			for (int j = 0; j < messageslist.length; j++) {

				if (allWarningMsgs.get(i).contains(messageslist[j])) {
					messageFound = true;
					break;

				}
			}
			if (messageFound) {
				continue;
			} else {
				break;
			}
		}

		if ((messageFound) == true) {
			dashboard.setStepDetails(message + " Warning message should be displayed",
					"\"Warning message should be displayed ", "N/A");
			dashboard.writeResults();
		} else {
			dashboard.setWarningStatus(
					"Warning message " + message + " from application is not matching with test data");
			dashboard.writeResults();

		}
	}

}
