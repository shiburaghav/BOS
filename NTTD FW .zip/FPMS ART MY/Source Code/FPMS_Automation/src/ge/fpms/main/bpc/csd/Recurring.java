package ge.fpms.main.bpc.csd;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Hashtable;
import org.openqa.selenium.Keys;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class Recurring {
	
	private FPMS_Actions llAction ;
	boolean warning = false;
	private DashboardHandler dashboard;
	
	public Recurring() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void recurringTopUP(Hashtable<String, String> hParams) throws Exception {
		try {
			String validityDate = hParams.get("Validitydate");			
			llAction.enterValue("web_txt_recurring_validity_date", validityDate);
			dashboard.setStepDetails("Enter validity date", "Validity Date should be accepted", "NA");
			dashboard.writeResults();			
			if (hParams.get("RecurringTopUpAction").equalsIgnoreCase("set or change recurring top up")) {
				//get row count, some times selection of benefit(radio button) is not displayed, so select if column exist or else click on button in next step	
				//prashantha Jan 23
				int OptioncolPos = llAction.GetColumnPositionInTable("web_tbl_recurring_benefitlist","Option");				
				if (OptioncolPos > 0) {
					int colPos = llAction.GetColumnPositionInTable("web_tbl_recurring_benefitlist","Benefit Name");
					int rowPos = llAction.GetRowPositionInTable("web_tbl_recurring_benefitlist",hParams.get("BenefitCode"), colPos);
					llAction.SelectRowInTable("web_tbl_recurring_benefitlist", rowPos, colPos-2, "input");
				}
				llAction.clickElement("web_btn_recurring_setorchange_topup");
				llAction.waitUntilLoadingCompletes();
				// if condition add by sridhar
				if(hParams.get("WarningErrorMessage") != null && (hParams.get("WarningErrorMessage") != "")) 
				{
				WarningMessage(hParams.get("WarningErrorMessage"));
				llAction.move_to_element("web_btn_recurring_common_submit_button");	
				}
												
				changeFundPercentageApportionment(hParams);		
				
			} else {
				llAction.waitUntilLoadingCompletes();
				int colPos = llAction.GetColumnPositionInTable("web_tbl_recurring_benefitlist","Benefit Name");
				int rowPos = llAction.GetRowPositionInTable("web_tbl_recurring_benefitlist",hParams.get("BenefitCode"), colPos);
				llAction.SelectRowInTable("web_tbl_recurring_benefitlist", rowPos, colPos-2, "input");				
				llAction.clickElement("web_btn_recurring_Suspend_UnSuspend");
				llAction.waitUntilLoadingCompletes();
				
				dashboard.setStepDetails("Click on Suspendor or UnSuspend Recurring top up button",
						"System should display update of Benefit Information After Change", "NA");
				dashboard.writeResults();
				Submit("System should display ILP Set or change Recurring Top Up screen", "ILP Set or Change Recurring Top Up screen",false);
				WarningMessage(hParams.get("WarningErrorMessage"));
			}			
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void WarningMessage(String warningMessage) throws Exception {
				
			if (llAction.isDisplayed("web_btn_recurring_continue",10))
				{
				if (warningMessage != null && warningMessage != "") {
					if (llAction.getText("web_txt_recurring_warning_msg").toLowerCase().contains(warningMessage.toLowerCase())) {
						dashboard.setStepDetails(warningMessage + " Should be displayed",
								"Warning Message is displayed", "N/A");
							dashboard.writeResults();
						llAction.clickElement("web_btn_recurring_continue");
						llAction.waitUntilLoadingCompletes();
						
					}else {
						dashboard.setFailStatus(new BPCException(warningMessage + "message is invalid or not matching the expected message"));
					}
				}else {
					
					llAction.clickElement("web_btn_recurring_continue");
					llAction.waitUntilLoadingCompletes();
					}		
						
				}		
		
	}

	public void Submit(String expectedResult, String screenName,boolean writeResult) throws Exception {
		try {
			if (llAction.isDisplayed("web_btn_recurring_continue",10))
			{
				llAction.clickElement("web_btn_recurring_continue");
			}
			llAction.clickElement("web_btn_recurring_common_submit_button");
			llAction.waitUntilLoadingCompletes();
			if (!writeResult) {
				dashboard.setStepDetails("Click on Submit button " + screenName, expectedResult, "N/A");
				dashboard.writeResults();
			}

		} catch (Exception ex) {
			throw new BPCException("Submit button was not found in "+screenName +" Or Screen was not populated");
		}
	}

	public void ValidateApplicationStatus(String warningMessage, String applicationStatus) throws Exception {
		try {
			if (warningMessage.toLowerCase().replace("'", "").replace(" ", "")
					.contains(applicationStatus.toLowerCase().replace("'", "").replace(" ", ""))) {
				
				dashboard.setStepDetails(applicationStatus + " should be validated", "ApplicationStatus Message is validated",
						"N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(applicationStatus + "message is invalid/Submit was not successful");
				dashboard.writeResults();
			}
		} catch (Exception ex) {			
			throw new BPCException("Exception occured while fetching Application status in Operation Result screen");
		}
	}
	
	public int getNoOfApportionmentEntriesInFund(Hashtable<String, String> hParams) throws Exception {
		try {			
			int count = llAction.getRowCountInTable("web_tbl_recurring_fundtopuplist");
			return count;
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void changeFundPercentageApportionment(Hashtable<String, String> hParams) throws Exception {
		try {
			Utils.sleep(2);
			int existingCount = getNoOfApportionmentEntriesInFund(hParams) - 1;
			int totalNoOfFunds;
			int newFundToadd;
			//String[] tempArrayOfFunds = new String[1];
			ArrayList<String> tempArrayOfFunds = new ArrayList<String>();
			
			//String[] tempArrayOfFunds = new String[100];
			String addFunds = hParams.get("AddFunds");
			if (addFunds.contains(",")) {  				
				 String[] tempArrayOfFundsList = addFunds.split(",");
				 for (int i = 0; i < tempArrayOfFundsList.length; i++)
				 {
					 tempArrayOfFunds.add(tempArrayOfFundsList[i]);
				 }
				 totalNoOfFunds = existingCount+tempArrayOfFundsList.length;
				 newFundToadd = tempArrayOfFundsList.length;
				 
			} else {
				tempArrayOfFunds.add(addFunds);				
				totalNoOfFunds = existingCount+ 1;
				newFundToadd = 1;
			}
					 
			int[] newEntries = splitIntoParts(100, totalNoOfFunds);
			llAction.enterValue("web_txt_recurring_topup_PremAmount", hParams.get("PremiumAmount"));
			llAction.selectByVisibleText("web_txt_recurring_start_date", hParams.get("StartDate"));
			
			for (int i = 0; i < newFundToadd; i++)
			{
				llAction.enterValue("web_txt_recurring_fundcode", tempArrayOfFunds.get(i));
				llAction.sendkeyStroke("web_txt_recurring_fundcode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_btn_recurring_add");
				Utils.sleep(2);
				dashboard.setStepDetails("Add Premium amount Fund Code select start date and click on Add button", "Row should be added in Fund Top Up List", "NA");
				dashboard.writeResults();		
				llAction.acceptAlert();
				llAction.waitUntilLoadingCompletes();					
			}
			
			for (int i = 1; i <= totalNoOfFunds; i++) {
				int colPos = llAction.GetColumnPositionInTable("web_tbl_recurring_fundtopuplist",
						"Percentage Apportionment");
				BigDecimal bd = new BigDecimal(newEntries[i-1]);
				bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
				llAction.enterTextInTable("web_tbl_recurring_fundtopuplist", i+1, colPos, bd.toString(),"/input[2]");
				llAction.sendkeyStroke("web_tbl_recurring_fundtopuplist", Keys.ENTER);												
				dashboard.setStepDetails("Add Percentage Apportionment to the added fund code", "System should accept the Percentage Apportionment", "NA");
				dashboard.writeResults();	
				
			}	
			Submit("System should display ILP Set or Change Rcurring Top Up Info screen","ILP Set or Change Rcurring Top Up Info screen",false);			
			Submit("System should display ILP Set or Change Recurring Top Up screen with main benefit information after change updated.", "ILP Set or Change Recurring top up information",false);
			WarningMessage(hParams.get("WarningErrorMessage"));
					
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	private static int[] splitIntoParts(int whole, int parts) {
	    int[] arr = new int[parts];
	    for (int i = 0; i < arr.length; i++)
	        whole -= arr[i] = (whole + parts - i - 1) / (parts - i);
	    return arr;
	}

}
