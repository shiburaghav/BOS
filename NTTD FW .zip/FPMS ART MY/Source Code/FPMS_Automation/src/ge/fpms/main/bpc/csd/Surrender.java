package ge.fpms.main.bpc.csd;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import org.openqa.selenium.Keys;
import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;
public class Surrender {

	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;

	public Surrender() {
		dashboard = DashboardHandler.getInstance();
	}	
	public void PerformPartialSurrender(Hashtable<String, String> hParams) throws Exception 
	{

		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {
			CSDHelper.getInstance().handleContinueButton();
			llAction = new FPMS_Actions();
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			dashboard.setStepDetails("Enter validity date.","Valid Validity date is entered.","N/A");
			dashboard.writeResults();
			int colPos = llAction.GetColumnPositionInTable("web_tbl_BenefitInformation", "Benefit Name");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_BenefitInformation", hParams.get("BenefitCode"),
					colPos);
//			if (llAction.getRowCountInTable("web_tbl_BenefitInformation") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitInformation", rowPos, colPos - 2, "input");
//			}
			CSDHelper.getInstance().captureChange("Partial Surrender", "BeforeChange");
			llAction.clickElement("web_btn_PartialSurrender");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();
			llAction.enterValue("web_txt_InitialSumAssured",hParams.get("Initialsumassured"));
			dashboard.setStepDetails("Enter new value of Initial Sum Assured",
					"System shopuld accept input value", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_cb_benefit_into_save_button");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();
			CSDHelper.getInstance().captureChange("Partial Surrender", "AfterChange");
			llAction.clickElement("web_btn_displayNetSV");
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(FPMSConstants.DISPLAY_NET_SV_INFO_TITLE);
			dashboard.setStepDetails("Click Display net SV info button",
					"Display net SV Information window is displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_close");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoDefaultWindow();
			llAction.clickElement("web_btn_cb_app_entry_submit");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();

		}catch (Exception ex)
		{
			throw new BPCException(ex);
		}

	}
	public void ILPFullSurrender(Hashtable<String, String> hParams) throws Exception {
		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {

			CSDHelper.getInstance().handleContinueButton();
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			dashboard.setStepDetails("Enter validity date.","Valid Validity date is entered.","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_displayFundInformation");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click Display Fund Information button",
					"Fund Information screen is displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_ApplicationEntry_btn_Back");
			llAction.waitUntilLoadingCompletes();
			llAction.selectByVisibleText("web_list_Surrender_selectoptions", hParams.get("Reason"));
			if(llAction.isDisplayed("web_lst_WaiverOnFullSurrender", 2))
				llAction.selectByVisibleText("web_lst_WaiverOnFullSurrender", hParams.get("WaiverOnFullSurrender"));
			FullSurrenderCaptureBeforeOrAfterChange("BeforeChange");
			llAction.clickElement("web_btn_fullsurrender");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().handleContinueButton();
			dashboard.setStepDetails("Click on Full Surrender Button",
					"System should display ILP Full Surrender screen ",
					"N/A");
			dashboard.writeResults();
			llAction.move_to_element("web_btn_fullsurrender_submit");
			FullSurrenderCaptureBeforeOrAfterChange("AfterChange");
			llAction.clickElement("web_btn_fullsurrender_submit");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();


		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}


	/*
	 * Name: ILPFullSurrenderWarning 
	 * Purpose: Validate Warning Message during full surrender of a ploicy Parameters: FullSurrender Test Data
	 * sheet Return Value: N/A Exception: BPC Exception on component execution fail
	 * Author : Shree Ganesh
	 */
	public void ILPFullSurrenderWarning(Hashtable<String, String> hParams) throws Exception {
		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {
			String message = hParams.get("WarningErrorMessage"); /* Get expected warning message from Test Data */
			// Validate Warning Message and Click on Continue
			CSDHelper.getInstance().validateWarningMessages("web_tbl_fullsurrender_warning_msg", message);
			llAction.clickElement("web_btn_fullsurrender_warning_continue");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Navigate to ILP Full Surrender Screen on continue button",
					"ILP full surrender screen is displayed", "N/A");
			dashboard.writeResults();

			llAction.move_to_element("web_btn_fullsurrender");
			FullSurrenderCaptureBeforeOrAfterChange("BeforeChange");
			llAction.clickElement("web_btn_fullsurrender");
			llAction.waitUntilLoadingCompletes();

			if (llAction.isDisplayed("web_btn_fullsurrender_warning_continue", 10)) {
				llAction.clickElement("web_btn_fullsurrender_warning_continue");
				llAction.waitUntilLoadingCompletes();
			}

			dashboard.setStepDetails("Click on Full Surrender Button",
					"System should display ILP Full Surrender screen and show Main Benefit Information after change",
					"N/A");
			dashboard.writeResults();

			llAction.move_to_element("web_btn_fullsurrender_submit");
			FullSurrenderCaptureBeforeOrAfterChange("AfterChange");
			llAction.clickElement("web_btn_fullsurrender_submit");
			llAction.waitUntilLoadingCompletes();

			if (llAction.isDisplayed("web_btn_fullsurrender_warning_continue", 10)) {

				llAction.clickElement("web_btn_fullsurrender_warning_continue");
				llAction.waitUntilLoadingCompletes();
			}			
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: ILPFullSurrenderCKAWarning 
	 * Purpose: Validate CKA Warning Message during full surrender of a ploicy Parameters: FullSurrender
	 * Test Data sheet Return Value: N/A Exception: BPC Exception on component
	 * execution fail Author : Shree Ganesh
	 */
	public void ILPFullSurrenderCKAWarning(Hashtable<String, String> hParams) throws Exception {
		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {
			String message = hParams.get("WarningErrorMessage"); /* Get expected warning message from Test Data */
			dashboard.setStepDetails("Navigate to ILP Full Surrender Screen",
					"ILP full surrender screen is displayed", "N/A");
			dashboard.writeResults();
			llAction.move_to_element("web_btn_fullsurrender");
			FullSurrenderCaptureBeforeOrAfterChange("BeforeChange");
			llAction.clickElement("web_btn_fullsurrender");
			llAction.waitUntilLoadingCompletes();



			CSDHelper.getInstance().validateWarningMessages("web_tbl_fullsurrender_warning_msg", message);
			llAction.clickElement("web_btn_fullsurrender_warning_continue");
			llAction.waitUntilLoadingCompletes();

			llAction.move_to_element("web_btn_fullsurrender");
			FullSurrenderCaptureBeforeOrAfterChange("AfterChange");
			llAction.clickElement("web_btn_fullsurrender_submit");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_tbl_fullsurrender_warning_msg", 5)) {
				if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_tbl_fullsurrender_warning_msg",
							hParams.get("WarningErrorMessage1"));
					llAction.clickElement("web_btn_fullsurrender_warning_continue");
				} else {
					llAction.clickElement("web_btn_fullsurrender_warning_continue");
				}
			}
			llAction.waitUntilLoadingCompletes();

			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: FullSurrenderCaptureBeforeOrAfterChange
	 * Purpose: Capture screenshot of policy before full surrender and after full surrender
	 * Test Data sheet Return Value: N/A Exception: BPC Exception on component
	 * execution fail Author : Shree Ganesh
	 */
	public void FullSurrenderCaptureBeforeOrAfterChange(String ActionType) throws Exception {
		try {
			switch (ActionType.toUpperCase()) {
			case "BEFORECHANGE":
				dashboard.setStepDetails("Capture changes before full surrender",
						"Captured full surrender before changes successfully", "N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":
				dashboard.setStepDetails("Capture changes after full surrender",
						"Captured full surrender after changes successfull", "N/A");
				dashboard.writeResults();
				break;
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	public void surrenderforTraditonalPlans(Hashtable<String, String> hParams) throws Exception {
		try {
			surrenderTrad(hParams);
			submit(hParams,"web_btn_Submit");
		}
		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void surrenderTrad(Hashtable<String, String> hParams) throws Exception {
		int colPos;
		int rowPos;
		llAction = new FPMS_Actions();
		try {
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("SurrenderforTraditonalPlans", "BeforeChange");
			llAction.enterValue("web_txt_ILPTopUp_ValidityDate",hParams.get("Validitydate"));
			llAction.sendkeyStroke("web_txt_ILPTopUp_ValidityDate", Keys.ENTER);
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Enter validity date.","Valid Validity date is entered.","N/A");
			dashboard.writeResults();
			colPos = llAction.GetColumnPositionInTable("web_Table_Surrender", "Benefit Name");
			rowPos = llAction.GetRowPositionInTable("web_Table_Surrender", hParams.get("BenefitCode"), colPos);
			llAction.SelectRowInTable("web_Table_Surrender", rowPos, colPos-2,"input");
			dashboard.setStepDetails("Select Benefit option tickbox. ","System should accept the selected details ","N/A");
			dashboard.writeResults();
			llAction.selectByVisibleText("web_list_Surrender_selectoptions",hParams.get("Reason"));
			dashboard.setStepDetails("click on surrender ","System should accept the selected details ","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Surrender");	
			llAction.waitUntilLoadingCompletes();
		}
		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}



	private void submit(Hashtable<String, String> hParams,String key) throws Exception {
		llAction.clickElement(key);
		if (llAction.getText("web_txt_ErrorMessagenote")!=null) 
		{
			String war = hParams.get("WarningErrorMessage");
			if ((war!= null)) {
				String warningMsg = llAction.getText("web_txt_ErrorMessagenote");
				warningMsg.replaceAll("[^A-Z0-9]", warningMsg.toLowerCase());
				FullSurrenderValidateWarningMessages(warningMsg,war);
				int colPost = llAction.GetColumnPositionInTable("web_Table_Surrender", "Benefit Name");
				int rowPost = llAction.GetRowPositionInTable("web_Table_Surrender", hParams.get("BenefitCode"), colPost);
				String text = llAction.GetTextFromTable("web_Table_Surrender", rowPost, colPost+5, null);
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				Date date;			date = formatter.parse(text);
				Calendar calender = Calendar.getInstance();
				calender.setTime(date);
				calender.add(Calendar.DATE, 30);
				String Validate  = formatter.format(calender.getTime());
				llAction.enterValue("web_txt_ILPTopUp_ValidityDate",Validate);
				llAction.sendkeyStroke("web_txt_ILPTopUp_ValidityDate", Keys.ENTER);
				llAction.waitUntilAlertisShown();
				llAction.acceptAlert();
				Utils.sleep(3);
				System.out.println(text);
				dashboard.setStepDetails("Enter validity date.","Valid Validity date is entered.","N/A");
				dashboard.writeResults();
				int colPo = llAction.GetColumnPositionInTable("web_Table_Surrender", "Benefit Name");
				int rowPo = llAction.GetRowPositionInTable("web_Table_Surrender", hParams.get("BenefitCode"), colPo);
				llAction.SelectRowInTable("web_Table_Surrender", rowPo, colPo-2,"input");
				dashboard.setStepDetails("Select Benefit option tickbox. ","System should accept the selected details ","N/A");
				dashboard.writeResults();
				llAction.waitUntilElementPresent("web_list_Surrender_selectoptions");
				llAction.selectByVisibleText("web_list_Surrender_selectoptions",hParams.get("Reason"));
				dashboard.setStepDetails("click on surrender ","System should accept the selected details ","N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_Surrender");
				dashboard.setStepDetails("click on surrender ","System should accept the selected details ","N/A");
				dashboard.writeResults();
			}
			if (llAction.isDisplayed("web_btn_continue",8))
			{
				llAction.clickElement("web_btn_continue");
			}
			llAction.scrolldown();
			CSDHelper.getInstance().captureChange("SurrenderforTraditonalPlans", "AfterChange");
			llAction.clickElement("web_btn_Submit");
			if (llAction.isDisplayed("web_btn_continue",8)) 
			{
				llAction.clickElement("web_btn_continue");
				dashboard.setStepDetails("If show warning message \"Review benefit relationship matrix\", click continue button.","System should display the \"Modify collection/refund \" UI","N/A");
				dashboard.writeResults();
			}
			llAction.clickElement("web_btn_Submit");
			CSDHelper.getInstance().endOfTransaction();
		}

	}

	public void tradFullSurrender(Hashtable<String, String> hParams) throws Exception {
		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {

			CSDHelper.getInstance().handleContinueButton();
			surrenderTrad(hParams);
			CSDHelper.getInstance().handleContinueButton();
			CSDHelper.getInstance().captureChange("Full Surrender", "AfterChange");
			llAction.clickElement("web_btn_displayNetSV");
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(FPMSConstants.DISPLAY_NET_SV_INFO_TITLE);
			dashboard.setStepDetails("Click Display net SV info button",
					"Display net SV Information window is displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_close");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoDefaultWindow();
			llAction.clickElement("web_btn_cb_app_entry_submit");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void FullSurrenderValidateWarningMessages(String warningMsg, String message) throws Exception
	{

		if (warningMsg.contains(message)) { // compare warning messages

			System.out.println(message +"" + warningMsg);

			dashboard.setStepDetails(message + "Warning message should be displayed","Warning message should is displayed ", "N/A");
			dashboard.writeResults();
		} else {
			//DashboardHandler.setWarningStatus("Warning message "+warningMsg+" from application is not matching with test data");
			dashboard.writeResults();
			throw new Exception(""+warningMsg+"is not maching with"+warningMsg+"");
			//exception thrown

		}
	}

	public void validateSurrenderPolicyEntryError(Hashtable<String, String> hParams) throws Exception {
		try {

			String message = hParams.get("WarningErrorMessage"); /* Get expected warning message from Test Data */			
			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {				
				CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg", message);
			}

		} catch (Exception ex) {
			dashboard.writeResults();
			ex.printStackTrace();
			throw new BPCException(
					"Exception occured while calling validateSurrenderPolicyEntryError method \n Exception is "
							+ ex.getMessage());
		}
	}
	public void validateSurrenderPolicyError(Hashtable<String, String> hParams) throws Exception {
		try  {
			if (hParams.get("WarningErrorMessage1") != null && hParams.get("WarningErrorMessage1") != "") {
				if (llAction.isDisplayed("web_btn_fullsurrender_warning_continue", 5)) {
					llAction.clickElement("web_btn_fullsurrender_warning_continue");
					llAction.waitUntilLoadingCompletes();
				}
				llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
				dashboard.setStepDetails("Enter Validity Date greater than PLD", "Validity Date should be entered", "N/A");
				llAction.clickElement("web_btn_fullsurrender");
				CSDHelper.getInstance().validateWarningMessages("web_txt_warrningErrmsg", hParams.get("WarningErrorMessage1"));
			}
			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
				String message = hParams.get("WarningErrorMessage"); /* Get expected warning message from Test Data */
				llAction.move_to_element("web_btn_fullsurrender");
				llAction.clickElement("web_btn_fullsurrender");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg", message);
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

}

