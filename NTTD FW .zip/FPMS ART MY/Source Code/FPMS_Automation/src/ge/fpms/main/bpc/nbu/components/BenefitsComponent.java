package ge.fpms.main.bpc.nbu.components;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.ProductConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;
import ge.fpms.main.bpc.nbu.DetailRegistrationComponent;

public class BenefitsComponent extends BusinessComponent {

	private FPMS_Actions llAction;

	public BenefitsComponent() {
		llAction = new FPMS_Actions();
	}

	public void addBenefits(Hashtable<String, String> hParams) throws Exception {
		addBenefits(StringUtils.EMPTY, hParams, 0);
		Utils.sleep(1);
	}

	public void addBenefits(String type, Hashtable<String, String> hParams, int noOfBenefits) throws Exception {
		List<WebElement> benefitsFields = new ArrayList<WebElement>();
		try {
			List<WebElement> benefitsLabels = llAction.findElements("web_benefits_LableNames");
			for (int i = 0; i < benefitsLabels.size(); i++) {
				if (hParams.containsKey(type + benefitsLabels.get(i).getText().trim())
						&& !StringUtils.isEmpty(benefitsLabels.get(i).getText().trim())) {
					benefitsFields = llAction.findElementsByXpath("web_benefits_FieldsDummy",
							new String[] { benefitsLabels.get(i).getText().trim() });
					if (benefitsFields.size() > 0) {
						System.out.println("BenefitsComponent.addBenefits() benefitsLabels.get(i).getText() : "
								+ benefitsLabels.get(i).getText());
						String fieldValue = hParams.get(type + benefitsLabels.get(i).getText().trim());
						if (!StringUtils.isEmpty(fieldValue)) {
							String[] value = fieldValue.split(FPMSConstants.COMMA_SEPERATOR);

							if (!StringUtils.isEmpty(value[noOfBenefits]) && noOfBenefits < value.length) {
								switch (benefitsFields.get(0).getTagName()) {
								case "select":
									Select ele = new Select(benefitsFields.get(0));
									ele.selectByVisibleText(value[noOfBenefits]);// ????
									break;
								default:
									benefitsFields.get(0).clear();
									llAction.handleMultipleAlerts((long)2);
									benefitsFields.get(0).sendKeys(value[noOfBenefits]);
									benefitsFields.get(0).sendKeys(Keys.ENTER);
									llAction.waitUntilLoadingCompletes();
									break;
								}
							}
						}
					}
					llAction.waitUntilLoadingCompletes();
				} else {
					if (!StringUtils.isEmpty(benefitsLabels.get(i).getText().trim())) {
						DashboardHandler.getInstance()
								.setFailStatus(new BPCException("Field " + benefitsLabels.get(i).getText().trim()
										+ " not found in Benefits Screen or Test Data"));
						Utils.sleep(2);
					}
				}
			}if(llAction.isDisplayed("web_txt_SurvivalOption", 5)) {
				llAction.enterValue("web_txt_SurvivalOption", hParams.get("SB/GCP Option"));
				
			}
			DetailRegistrationComponent detailReg = new DetailRegistrationComponent();
			if (Integer.parseInt(hParams.get("MBNoOfFunds"))> 0) {
				addregularPremiumFunds(hParams);
			}
			if (Integer.parseInt(hParams.get("SingleNoOfFunds"))> 0) {
				addsinglePremiumFunds(hParams);
			}
			if (Integer.parseInt(hParams.get("RecurNoOfFunds"))> 0) {
				addrecurringPremiumFunds(hParams);
			}
			if (hParams.get("AddInvestmentStrategy").equalsIgnoreCase("Y")) {
				detailReg.investmentStrategy(hParams);
			}
			llAction.clickElement("web_benefits_Savebutton");
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void addRiderBenefits(String type, Hashtable<String, String> hParams, int noOfBenefits) throws Exception {
		List<WebElement> benefitsFields = new ArrayList<WebElement>();
		try {
			Utils.sleep(10);
			List<WebElement> benefitsLabels = llAction.findElements("web_benefits_LableNames");
			for (int i = 0; i < benefitsLabels.size(); i++) {
				if (hParams.containsKey(type + benefitsLabels.get(i).getText().trim())
						&& !StringUtils.isEmpty(benefitsLabels.get(i).getText().trim())) {
					benefitsFields = llAction.findElementsByXpath("web_benefits_FieldsDummy",
							new String[] { benefitsLabels.get(i).getText().trim() });
					if (benefitsFields.size() > 0) {
						System.out.println("BenefitsComponent.addBenefits() benefitsLabels.get(i).getText() : "
								+ benefitsLabels.get(i).getText());
						String fieldValue = hParams.get(type + benefitsLabels.get(i).getText().trim());
						if (!StringUtils.isEmpty(fieldValue)) {
							String[] value = fieldValue.split(FPMSConstants.COMMA_SEPERATOR);

							if (!StringUtils.isEmpty(value[noOfBenefits]) && noOfBenefits < value.length) {
								switch (benefitsFields.get(0).getTagName()) {
								case "select":
									Select ele = new Select(benefitsFields.get(0));
									ele.selectByVisibleText(value[noOfBenefits]);// ????
									break;
								default:
									benefitsFields.get(0).clear();
									llAction.handleMultipleAlerts((long)2);
									benefitsFields.get(0).sendKeys(value[noOfBenefits]);
									benefitsFields.get(0).sendKeys(Keys.ENTER);
									llAction.waitUntilLoadingCompletes();
									break;
								}
							}
						}
					}
					llAction.waitUntilLoadingCompletes();
				} else {
					if (!StringUtils.isEmpty(benefitsLabels.get(i).getText().trim())) {
						DashboardHandler.getInstance()
								.setFailStatus(new BPCException("Field " + benefitsLabels.get(i).getText().trim()
										+ " not found in Benefits Screen or Test Data"));
						Utils.sleep(2);
					}
				}
			}if(llAction.isDisplayed("web_txt_SurvivalOption", 5)) {
				llAction.enterValue("web_txt_SurvivalOption", hParams.get("SB/GCP Option"));
			}
			DetailRegistrationComponent detailReg = new DetailRegistrationComponent();
			
			if (Integer.parseInt(hParams.get("SingleNoOfFunds"))> 0) {
				addsinglePremiumFunds(hParams);
			}
			if (Integer.parseInt(hParams.get("RecurNoOfFunds"))> 0) {
				addrecurringPremiumFunds(hParams);
			}
			
			llAction.clickElement("web_benefits_Savebutton");
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void addRiderDetails(Hashtable<String, String> hParams) throws Exception {
		String[] benefitTypes = hParams.get("RiderBenefitType").split(FPMSConstants.COMMA_SEPERATOR);
		if (benefitTypes != null) {
			for (int i = 0; i < benefitTypes.length; i++) {
				llAction.clickElement("web_btn_BenefitAdd");// adding rider details
				llAction.handleCertificateErrors();
				llAction.switchtoSecondWindow();
				llAction.maximizeWindow();
				llAction.enterValue("web_txt_BenefitType", benefitTypes[i]);
				llAction.sendkeyStroke("web_txt_BenefitType", Keys.ENTER);
				addRiderBenefits("Rider_", hParams, i);
			}
		}
	}

	public void addWaiverDetails(Hashtable<String, String> hParams) throws Exception {
		try {
			String[] waiverBenefitTypes = hParams.get("WaiverBenefitType").split(FPMSConstants.COMMA_SEPERATOR);
			if (waiverBenefitTypes != null) {
				for (int i = 0; i < waiverBenefitTypes.length; i++) {
					llAction.enterValue("web_txt_WaiverBenefitType", waiverBenefitTypes[i]);
					llAction.sendkeyStroke("web_txt_WaiverBenefitType", Keys.ENTER);
					llAction.waitUntilLoadingCompletes();
					llAction.clickElement("web_btn_AddWaiver");// adding waiver rider details
					//llAction.waitUntilLoadingCompletes();
					Utils.sleep(10);
					llAction.handleCertificateErrors();
					llAction.switchtoSecondWindow();
					//llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY);
					llAction.maximizeWindow();
					if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
						llAction.clickElement("web_btn_ContinueRP");
					}
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_WAIVER_INFO);
					llAction.maximizeWindow();
					addWaiverBenefits("Waiver_", hParams, i);
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
					llAction.switchtoFrame(1);
				}
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void addWaiverBenefits(String type, Hashtable<String, String> hParams, int noOfBenefits) throws Exception {

		List<WebElement> benefitsFields = new ArrayList<WebElement>();
		try {
			Utils.sleep(10);
			List<WebElement> benefitsLabels = llAction.findElements("web_waiverBenefits_LableNames");
			for (int i = 0; i < benefitsLabels.size(); i++) {
				if (hParams.containsKey(type + benefitsLabels.get(i).getText().trim())
						&& !StringUtils.isEmpty(benefitsLabels.get(i).getText().trim())) {
					benefitsFields = llAction.findElementsByXpath("web_benefits_FieldsDummy",
							new String[] { benefitsLabels.get(i).getText().trim() });
					if (benefitsFields.size() > 0) {
						System.out.println("BenefitsComponent.addBenefits() benefitsLabels.get(i).getText() : "
								+ benefitsLabels.get(i).getText());
						String fieldValue = hParams.get(type + benefitsLabels.get(i).getText().trim());
						if (!StringUtils.isEmpty(fieldValue)) {
							String[] value = fieldValue.split(FPMSConstants.COMMA_SEPERATOR);

							if (!StringUtils.isEmpty(value[noOfBenefits]) && noOfBenefits < value.length) {
								switch (benefitsFields.get(0).getTagName()) {
								case "select":
									Select ele = new Select(benefitsFields.get(0));
									ele.selectByVisibleText(value[noOfBenefits]);// ????
									break;
								default:
									benefitsFields.get(0).clear();
									llAction.handleMultipleAlerts((long)2);
									benefitsFields.get(0).sendKeys(value[noOfBenefits]);
									benefitsFields.get(0).sendKeys(Keys.ENTER);
									llAction.waitUntilLoadingCompletes();
									break;
								}
							}
						}
					}
					llAction.waitUntilLoadingCompletes();
				} else {
					if (!StringUtils.isEmpty(benefitsLabels.get(i).getText().trim())) {
						DashboardHandler.getInstance()
								.setFailStatus(new BPCException("Field " + benefitsLabels.get(i).getText().trim()
										+ " not found in Benefits Screen or Test Data"));
						Utils.sleep(2);
					}

				}
			}

			llAction.clickElement("web_btn_waiverSave");

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void addregularPremiumFunds(Hashtable<String, String> hParams) {
		try {
			Hashtable<String, String> fundElementTag = ARTProperties.guiMap.get("web_benefits_regularPremiumApportionment");
			String fundTablePath = fundElementTag.get(fundElementTag.keySet().toArray()[0]);
			String[] fundCodes = hParams.get("MBFundCodes").split(",");
			String[] apportionments = hParams.get("MBApportionments").split(",");

			// Deleting the existing fund, if exist
			int size = llAction.getSize(fundTablePath);
			if (size > 1) {
				for (int i = 2; i <= size; i++) {
					String temploc = fundTablePath + "/tbody/tr[" + i + "]/td[1]/input";
					WebElement checkBox = llAction.findElementByXpath(temploc);
					checkBox.click();
				}
				llAction.clickElement("web_btn_fund_delete");
			}

			int noOfFunds = Integer.parseInt(hParams.get("MBNoOfFunds"));

			for (int i = 1; i <= noOfFunds; i++) {

				llAction.clickElement("web_btn_FundAdd");
				Utils.sleep(2);

				int rowId = i + 1;
				String temploc1 = fundTablePath + "/tbody/tr[" + rowId + "]/td[2]/input[1]";
				WebElement Code = llAction.findElementByXpath(temploc1);
				Code.sendKeys(fundCodes[i-1]);
				llAction.sendkeyStroke("web_txt_FundCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();

				String temploc2 = fundTablePath + "/tbody/tr[" + rowId + "]/td[3]/input[2]";
				WebElement apportionmentPer = llAction.findElementByXpath(temploc2);
				apportionmentPer.sendKeys(apportionments[i-1]);
				apportionmentPer.sendKeys(Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void addsinglePremiumFunds(Hashtable<String, String> hParams) {
		try {
			Hashtable<String, String> fundElementTag = ARTProperties.guiMap.get("web_benefits_singlePremiumApportionment");
			String fundTablePath = fundElementTag.get(fundElementTag.keySet().toArray()[0]);
			String[] fundCodes = hParams.get("RiderFundCodes").split(",");
			String[] apportionments = hParams.get("RiderApportionments").split(",");
			
			llAction.enterValue("web_txt_SingleTopup", hParams.get("RiderSingleTopupAmount"));
			
			// Deleting the existing fund, if exist
			int size = llAction.getSize(fundTablePath);
			if (size > 1) {
				for (int i = 2; i <= size; i++) {
					String temploc = fundTablePath + "/tbody/tr[" + i + "]/td[1]/input";
					WebElement checkBox = llAction.findElementByXpath(temploc);
					checkBox.click();
				}
				llAction.clickElement("web_btn_fund_delete");
			}

			int noOfFunds = Integer.parseInt(hParams.get("SingleNoOfFunds"));

			for (int i = 1; i <= noOfFunds; i++) {

				llAction.clickElement("web_btn_singleAdd");
				Utils.sleep(2);

				int rowId = i + 1;
				String temploc1 = fundTablePath + "/tbody/tr[" + rowId + "]/td[2]/input[1]";
				WebElement Code = llAction.findElementByXpath(temploc1);
				Code.sendKeys(fundCodes[i]);
				llAction.sendkeyStroke("web_txt_FundCode", Keys.ENTER);

				String temploc2 = fundTablePath + "/tbody/tr[" + rowId + "]/td[3]/input[2]";
				WebElement apportionmentPer = llAction.findElementByXpath(temploc2);
				apportionmentPer.sendKeys(apportionments[i]);
				apportionmentPer.sendKeys(Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void addrecurringPremiumFunds(Hashtable<String, String> hParams) {
		try {
			Hashtable<String, String> fundElementTag = ARTProperties.guiMap.get("web_benefits_recurringPremiumApportionment");
			String fundTablePath = fundElementTag.get(fundElementTag.keySet().toArray()[0]);
			String[] fundCodes = hParams.get("FundCodes").split(",");
			String[] apportionments = hParams.get("Apportionments").split(",");
			
			llAction.enterValue("web_txt_RecurringTopup", hParams.get("Apportionments"));

			// Deleting the existing fund, if exist
			int size = llAction.getSize(fundTablePath);
			if (size > 1) {
				for (int i = 2; i <= size; i++) {
					String temploc = fundTablePath + "/tbody/tr[" + i + "]/td[1]/input";
					WebElement checkBox = llAction.findElementByXpath(temploc);
					checkBox.click();
				}
				llAction.clickElement("web_btn_fund_delete");
			}

			int noOfFunds = Integer.parseInt(hParams.get("RecurNoOfFunds"));

			for (int i = 1; i <= noOfFunds; i++) {

				llAction.clickElement("web_btn_recurAdd");
				Utils.sleep(2);

				int rowId = i + 1;
				String temploc1 = fundTablePath + "/tbody/tr[" + rowId + "]/td[2]/input[1]";
				WebElement Code = llAction.findElementByXpath(temploc1);
				Code.sendKeys(fundCodes[i]);
				llAction.sendkeyStroke("web_txt_FundCode", Keys.ENTER);

				String temploc2 = fundTablePath + "/tbody/tr[" + rowId + "]/td[3]/input[2]";
				WebElement apportionmentPer = llAction.findElementByXpath(temploc2);
				apportionmentPer.sendKeys(apportionments[i]);
				apportionmentPer.sendKeys(Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void amendMainBenefits(Hashtable<String, String> hParams) throws Exception {
		String[] benefitTypes = hParams.get("AmendProp_BenefitType").split(FPMSConstants.COMMA_SEPERATOR);
		if (benefitTypes != null) {
			for (int i = 0; i < benefitTypes.length; i++) {
				llAction.clickElement("web_btn_BenefitAdd");// adding rider details
				llAction.handleCertificateErrors();
				llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_PRODUCT_INFO);
				llAction.maximizeWindow();
				llAction.enterValue("web_txt_BenefitType", benefitTypes[i]);
				llAction.sendkeyStroke("web_txt_BenefitType", Keys.ENTER);
				addBenefits("AmendProp_", hParams, i);
			}
		}
	}
}


