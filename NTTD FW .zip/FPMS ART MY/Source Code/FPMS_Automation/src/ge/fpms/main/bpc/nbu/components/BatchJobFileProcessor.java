package ge.fpms.main.bpc.nbu.components;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.text.PDFTextStripper;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.SCPClient;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;

import com.nttdata.common.util.PIPSGenerics;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class BatchJobFileProcessor {

	private String remoteSiteHostName;
	
	private String remoteSiteUserName;
	private String remoteSitePassword;
	private String remoteSiteInputFolderPath;
	private String inputFolderPath;
	private String outputFolderPath;
	private String inputFolderPathForAH;

	private DashboardHandler dashboard;

	private String downloadPath;
		
	public BatchJobFileProcessor(){
		remoteSiteHostName = System.getProperty("Settings.BatchJobRemoteSiteHostName");
		remoteSiteUserName = System.getProperty("Settings.BatchJobRemoteSiteUsername");	
		remoteSitePassword = System.getProperty("Settings.BatchJobRemoteSitePassword");		
		remoteSiteInputFolderPath = System.getProperty("Settings.BatchJobRemoteSiteInputFolderPath");	
		inputFolderPath = System.getProperty("Settings.BatchJobInputFolderPath");
		outputFolderPath = System.getProperty("Settings.BatchJobInputFolderPathForA_H");
		inputFolderPathForAH = System.getProperty("Settings.BatchJobOutputFolderPath");
		
		dashboard = DashboardHandler.getInstance();
		downloadPath= System.getProperty("Settings.ART Downloads");
	}
	
	public void copyFileFromRemoteSite(String month, String date, String currentTime, boolean isAH, String policyNo) throws Exception{
		Connection connection=null;
		Session session = null;
		try{
		    
			File file = new File(inputFolderPath);
			
			if (!file.exists()) {
				dashboard.setFailStatus(new BPCException("Batch Job File Processing - InputFolderPath - "
								+ inputFolderPath + " does not exist"));
			}

			connection = new Connection(remoteSiteHostName);
			connection.connect();
			boolean isAuthenticated = connection.authenticateWithPassword(
					remoteSiteUserName, remoteSitePassword);
			if (isAuthenticated == false) {
				dashboard.setFailStatus(new IOException("Connecting to remote server " + remoteSiteHostName	+ " failed Authentication failed."));
			} else {
				session = connection.openSession();
				// execute commnad to cd to remoteSite input folder and list all
				// files sorting based on time and print date,month,time and
				// filename
				session.execCommand("cd " + remoteSiteInputFolderPath
						+ " ;  ls -lt | awk '{print $6,$7,$8,$9}'");
				Utils.sleep(5);

				InputStream stdout = new StreamGobbler(session.getStdout());
				BufferedReader reader = new BufferedReader(new InputStreamReader(stdout));

				SCPClient client = new SCPClient(connection);
				ArrayList<String> copyFileList = parseLine(remoteSiteInputFolderPath, reader, month, date,currentTime);
				
				if (copyFileList!=null && copyFileList.size() > 0) {
					String inputFolderLocation = isAH ? inputFolderPathForAH : inputFolderPath;
					client.get(copyFileList.toArray(new String[0]), inputFolderLocation);

					if (isPDFCreated(policyNo)) {
						dashboard.setStepDetails("Batch Job File Processing",
								"PDF for policy" + policyNo + " generated successfully", "N/A");
						dashboard.writeResults();
					} else {
						dashboard.setFailStatus(new BPCException(
								"Batch Job File Processing " + "Failed to create PDF for policy " + policyNo));
					}
				}else {
					dashboard.setFailStatus(new BPCException(
							"Batch Job File Processing " + "Failed : No new file generated upon running batch job " + policyNo));
				}
			}
		
		}catch(Exception ex){
			throw new BPCException(ex);
		}
		finally {
			if (session != null) {
				session.close();
			}
			if (connection != null) {
				connection.close();
			}
		}
	}
	
	private ArrayList<String> parseLine(String folderPath, BufferedReader reader, String month, String date, String currentTime) {
		
		ArrayList<String> copyFileList = new ArrayList<String>();
		int bjHours = Integer.parseInt(currentTime.substring(0, currentTime.indexOf(":")));
		int bjMins = Integer.parseInt(currentTime.substring(currentTime.indexOf(":")+1, currentTime.length()));

		String line;
		try {
				line = reader.readLine(); // total count line -ignoring this
			
				while (true) {
					line = reader.readLine();
					if (line == null)
						break;
					else {
							if (line.contains(month)) {
								String[] temp = line.split(" ");
								if (temp!=null && temp.length==4 && temp[1].equals(date) && temp[2].indexOf(":")!=-1) {
									int fcHours = Integer.parseInt(temp[2].substring(0, temp[2].indexOf(":")));
									int fcMins = Integer.parseInt(temp[2].substring(temp[2].indexOf(":")+1, temp[2].length()));
									int totalFCMins = 60 * fcHours + fcMins;
							    	int totalbjMins = 60 * bjHours + bjMins;
							    	
							    	
							    	if (totalFCMins >= totalbjMins)	{
											copyFileList.add(folderPath + "/" + temp[3]);
											//System.out.println("Logs :: " + remoteSiteInputFolderPath + "/" + temp[3]);
									}
								}
			
							}
		
					}

			}
		
			
		} catch (Exception e) {
			throw new BPCException(e);
		} 
		return copyFileList;
	}
	
	private boolean isPDFCreated(String policyNo){
		boolean status = true;
		int batchQueryTimeout =  Integer.parseInt(System.getProperty("Settings.BatchQueryTimeOut"));
		long currentTime = System.currentTimeMillis();
		long maxBatchProcessingTime = currentTime + TimeUnit.SECONDS.toMillis(batchQueryTimeout);
		
		while (currentTime <= maxBatchProcessingTime)
		{
			
			File folder = new File(outputFolderPath);
			if(folder.exists()) {
				File[] listOfFiles = folder.listFiles();
	
				for (File file : listOfFiles) {
				    if (file.isFile() && file.getName().contains(policyNo)) {
						status = true;
						break;
				    }
				}
			}

		}
		return status;
	}
	
	/**
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	
	
	public void copyFilesFromServer(String folderPath, String month, String date, String currentTime) throws Exception{
	
			Connection connection=null;
			Session session = null;
			boolean status = true;
			
			try{
								    				
				connection = new Connection(remoteSiteHostName);
				connection.connect();
				boolean isAuthenticated = connection.authenticateWithPassword(
						remoteSiteUserName, remoteSitePassword);
				if (isAuthenticated == false) {
					dashboard.setFailStatus(new IOException("Connecting to remote server " + remoteSiteHostName	+ " failed Authentication failed."));
				} else {
					session = connection.openSession();
					// execute commnad to cd to remoteSite input folder and list all
					// files sorting based on time and print date,month,time and
					// filename
					session.execCommand("cd " + folderPath
							+ " ;  ls -lt | awk '{print $6,$7,$8,$9}'");
					Utils.sleep(5);

					InputStream stdout = new StreamGobbler(session.getStdout());
					BufferedReader reader = new BufferedReader(new InputStreamReader(stdout));
					

					SCPClient client = new SCPClient(connection);
					ArrayList<String> copyFileList = parseLine(folderPath,reader, month, date,currentTime);
								
					
					
					if (copyFileList!=null && copyFileList.size() > 0) {
						client.get(copyFileList.toArray(new String[0]), downloadPath);
						
						Utils.sleep(8);
					}else {
						dashboard.setFailStatus(new BPCException(
								"Batch Job File Processing " + "Failed : No new file generated upon running batch job " ));
					}
				}
			
			}catch(Exception ex){
				throw new BPCException(ex);
			}
			finally {
				if (session != null) {
					session.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
	}
	
	
	public boolean isPDFCreatedForBatch(String folderPath, String jobId) throws IOException {
		boolean status = false;
		DateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date dt = new Date();	
		
		String dtFormat = sdf.format(dt).toString();
		
		try {			
			File folder = new File(folderPath);
			if (folder.exists()) {				
				File[] listOfFiles = folder.listFiles();
				for (File file : listOfFiles) {
					if (file.getName().startsWith("RPTFIN______" ) && file.getName().endsWith(".pdf")) {
							PIPSGenerics pipsObj = new PIPSGenerics();
							PDDocument pdfDoc = null;
							String pdfAllTexts = null;
							ArrayList<String> allOccurance = null;
							String pdfFilePath = folderPath + "\\" + file.getName();
							File file1 = new File(pdfFilePath);
							PDFTextStripper pdfStripper = new PDFTextStripper();
							pdfStripper.setSortByPosition(true);
							PDFont titl = PDType1Font.TIMES_BOLD;
							pdfDoc = PDDocument.load(file1);
							pdfAllTexts = pdfStripper.getText(pdfDoc);
							String lines[] = pdfAllTexts.split("\\r?\\n");
							allOccurance = pipsObj.getAllValuesBetweenStrings(lines, "Job ID", "");
							for (int j = 0; j < allOccurance.size(); j++) {
								if (allOccurance.get(j).contains(jobId)) {
									dashboard.setStepDetails("Verify PDF created",
										"The PDF is successfully verified"  + " The file name is:"
												+ file.getName() + "  ",
										"N/A");
									dashboard.writeResults();
									status = true;
									pdfDoc.close();
								break;
							}							
						}
						if (pdfDoc != null) {
							pdfDoc.close();
						}
						
					}
					if (status) {
						break;
					}
				}
					
			}
		}

		catch (Exception ex) {
			throw new BPCException(ex);
		}
		return status;

	}
			
	
	
	public boolean verifyCSVFilesAfterBatchRun(String folderPath, String month, String date, String currentTime, String expCSVFileName) throws Exception{
		
		Connection connection=null;
		Session session = null;
		boolean status = false;
		
		try{
							    				
			connection = new Connection(remoteSiteHostName);
			connection.connect();
			boolean isAuthenticated = connection.authenticateWithPassword(
					remoteSiteUserName, remoteSitePassword);
			if (isAuthenticated == false) {
				dashboard.setFailStatus(new IOException("Connecting to remote server " + remoteSiteHostName	+ " failed Authentication failed."));
			} else {
				session = connection.openSession();
				// execute commnad to cd to remoteSite input folder and list all
				// files sorting based on time and print date,month,time and
				// filename
			
					session.execCommand("cd " + folderPath
							+ " ;  ls -lt | awk '{print substr($0,41)}'");
					Utils.sleep(5);
		
					InputStream stdout = new StreamGobbler(session.getStdout());
					BufferedReader reader = new BufferedReader(new InputStreamReader(stdout));
					
		
					SCPClient client = new SCPClient(connection);			
					int bjHours = Integer.parseInt(currentTime.substring(0, currentTime.indexOf(":")));
					int bjMins = Integer.parseInt(currentTime.substring(currentTime.indexOf(":")+1, currentTime.length()));
		
					String line;
				
							line = reader.readLine(); // total count line -ignoring this
						
						
							while (true) {
								line = reader.readLine();
								if (line == null)
									break;
								else {
										if (line.contains(month)) {
											String[] temp = line.split(" ");
										    if (temp!=null && temp.length>=4 && temp[2].equals(date) && temp[3].indexOf(":")!=-1) {
										    	int fcHours = Integer.parseInt(temp[3].substring(0, temp[3].indexOf(":")));
										    	int fcMins = Integer.parseInt(temp[3].substring(temp[3].indexOf(":")+1, temp[3].length()));
										    	int totalFCMins = 60 * fcHours + fcMins;
										    	int totalbjMins = 60 * bjHours + bjMins;
										    	
										    	//if(fcHours >= bjHours && fcMins >= bjMins)
										    		if (totalFCMins >= totalbjMins)
										    	{
										    		if(line.contains(expCSVFileName)) {
										    				dashboard.setStepDetails("Verify CSV created",
										    				"The CSV file " + expCSVFileName + " is successfully verified.","N/A");
										    				dashboard.writeResults();	
										    				status = true;
										    			break;		
										    		}	
										    	}
										   }				
									   }
								    }				
								}
			
			
			
		}
			return status;
		}
		catch(Exception ex){
			throw new BPCException(ex);
		}
		finally {
			if (session != null) {
				session.close();
			}
			if (connection != null) {
				connection.close();
			}
		
		}
	}
	}
		

