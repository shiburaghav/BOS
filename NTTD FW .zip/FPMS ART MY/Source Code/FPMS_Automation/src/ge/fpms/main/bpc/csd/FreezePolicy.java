package ge.fpms.main.bpc.csd;
import java.util.Hashtable;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;

public class FreezePolicy {

	private FPMS_Actions llAction;

	private DashboardHandler dashboard;

	public FreezePolicy() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void freezePolicy(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.clickElement("web_btn_backButton");
			dashboard.setStepDetails("Click on back button",
					"System prompts an alert message ", "N/A");
			dashboard.writeResults();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Accept the alert",
					" Policy alteration item status changed to Pending Data Entry ", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_ApplicationEntry_btn_Back");
			dashboard.setStepDetails("Click on back button",
					"System prompts an alert message ", "N/A");
			dashboard.writeResults();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Accept the alert",
					" Application sharing pool UI will appear", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_ChangeTerm_btn_Exit");
			dashboard.setStepDetails("Click on Exit button",
					"Main menu screen is displayed", "N/A");
			dashboard.writeResults();
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}
}

