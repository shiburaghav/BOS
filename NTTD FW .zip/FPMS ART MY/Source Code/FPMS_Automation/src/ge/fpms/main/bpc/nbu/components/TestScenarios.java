package ge.fpms.main.bpc.nbu.components;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.components.Contact;

import java.util.Hashtable;

import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;

public class TestScenarios {
	FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	
	
	public TestScenarios() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}

	private void searchPolicy(String policyNo) {

		
		try {
			llAction.selectMenuItem("NBD", "Detail Registration");

			llAction.enterValue("web_txt_DetailReg_PolicyNumber", policyNo); 
			
			llAction.clickElement("web_txt_DetailReg_Search");
			dashboard
					.setStepDetails(
							"In Data Entry Sharing pool search for policy   "
									+ policyHandler.getPolicy()
											.getPolicyNo(),
							"The policy should be avaialble in Search Results. ",
							"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_lnk_PolicyNumber");
			Utils.sleep(5);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void testAddress(Hashtable<String, String> hParams) throws Exception {
		searchPolicy("020862632-1");
		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to
		// the calling function

		llAction.switchtoFrame(1);
		llAction.scrollToElement(llAction.getElement("web_addr_table_proposer"));
		Utils.sleep(3);
		llAction.clickElementJs("web_addr_lnk_proposer");
		
		Contact ov = new Contact( );
		ov.addAddress(hParams);

	}

}
