package ge.fpms.main.bpc.bcp.templates.giro;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Summary implements IPaymentSection {
	
	private Type ctrRecType;
	private Type ctrBatchNo;
	private Type ctrBtCount;
	private Type ctrBtAmt;
	private Type ctrDebitAcceptedCnt;
	private Type ctrDebitAcceptedAmt;
	
	private Type ctrDebitRejectedCnt;
	private Type ctrDebitRejectedAmt;	
	private Type ctrBtHash;
	private Type ctrFiller;



	public Type getCtrRecType() {
		return ctrRecType;
	}

	public void setCtrRecType(Type ctrRecType) {
		this.ctrRecType = ctrRecType;
	}

	public Type getCtrBatchNo() {
		return ctrBatchNo;
	}

	public void setCtrBatchNo(Type ctrBatchNo) {
		this.ctrBatchNo = ctrBatchNo;
	}

	public Type getCtrBtCount() {
		return ctrBtCount;
	}

	public void setCtrBtCount(Type ctrBtCount) {
		this.ctrBtCount = ctrBtCount;
	}

	public Type getCtrBtAmt() {
		return ctrBtAmt;
	}

	public void setCtrBtAmt(Type ctrBtAmt) {
		this.ctrBtAmt = ctrBtAmt;
	}

	public Type getCtrDebitAcceptedCnt() {
		return ctrDebitAcceptedCnt;
	}

	public void setCtrDebitAcceptedCnt(Type ctrDebitAcceptedCnt) {
		this.ctrDebitAcceptedCnt = ctrDebitAcceptedCnt;
	}

	public Type getCtrDebitAcceptedAmt() {
		return ctrDebitAcceptedAmt;
	}

	public void setCtrDebitAcceptedAmt(Type ctrDebitAcceptedAmt) {
		this.ctrDebitAcceptedAmt = ctrDebitAcceptedAmt;
	}

	public Type getCtrDebitRejectedCnt() {
		return ctrDebitRejectedCnt;
	}

	public void setCtrDebitRejectedCnt(Type ctrDebitRejectedCnt) {
		this.ctrDebitRejectedCnt = ctrDebitRejectedCnt;
	}

	public Type getCtrDebitRejectedAmt() {
		return ctrDebitRejectedAmt;
	}

	public void setCtrDebitRejectedAmt(Type ctrDebitRejectedAmt) {
		this.ctrDebitRejectedAmt = ctrDebitRejectedAmt;
	}

	public Type getCtrBtHash() {
		return ctrBtHash;
	}

	public void setCtrBtHash(Type ctrBtHash) {
		this.ctrBtHash = ctrBtHash;
	}

	public Type getCtrFiller() {
		return ctrFiller;
	}

	public void setCtrFiller(Type ctrFiller) {
		this.ctrFiller = ctrFiller;
	}

	public int[] getAttributesSize() {
		return new int[] { ctrRecType.getSize(), 
				ctrBatchNo.getSize(),
				ctrBtCount.getSize(),
				ctrBtAmt.getSize(),
				ctrDebitAcceptedCnt.getSize(),
				ctrDebitAcceptedAmt.getSize(),
				ctrDebitRejectedCnt.getSize(),
				ctrDebitRejectedAmt.getSize(),
				ctrBtHash.getSize(),
				ctrFiller.getSize() };
	}

	public void setParamaters(String[] buffer) {
		ctrRecType.setValue(buffer[0]);
		ctrBatchNo.setValue(buffer[1]);
		ctrBtCount.setValue(buffer[2]);
		ctrBtAmt.setValue(buffer[3]);
		ctrDebitAcceptedCnt.setValue(buffer[4]);
		ctrDebitAcceptedAmt.setValue(buffer[5]);
		ctrDebitRejectedCnt.setValue(buffer[6]);
		ctrDebitRejectedAmt.setValue(buffer[7]);
		ctrBtHash.setValue(buffer[8]);
		ctrFiller.setValue(buffer[9]);
	}

	public String getName() {
		return "03";
	}

	public String toString() {

		return new StringBuffer().append(getCtrRecType().toString())
				.append(getCtrBatchNo().toString())
				.append(getCtrBtCount().toString())
				.append(getCtrBtAmt().toString())
				.append(getCtrDebitAcceptedCnt().toString())
				.append(getCtrDebitAcceptedAmt().toString())
				.append(getCtrDebitRejectedCnt().toString())
				.append(getCtrDebitRejectedAmt().toString())
				.append(getCtrBtHash().toString())
				.append(getCtrFiller().toString()).toString();
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}

}
