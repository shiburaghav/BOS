package ge.fpms.main.bpc.bcp;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.bcp.templates.IPaymentType;
import ge.fpms.main.bpc.bcp.templates.directcredit.DirectCreditTemplateParser;
import ge.fpms.main.bpc.bcp.templates.giro.GiroTemplateParser;
import ge.fpms.main.bpc.bcp.templates.lockbox.LockboxTemplateParser;
import ge.fpms.main.bpc.nbu.BatchConstants;
import ge.fpms.main.bpc.nbu.BatchJobs;

import com.nttdata.common.util.ArtRobot;
import com.nttdata.common.util.FTPClientUtils;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class BCPComponent {

	 private FPMS_Actions llAction;
	 private DashboardHandler dashboard;
	 //  GIRO Bank Transfer /Download GIRO Bank File
	
	public BCPComponent() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	
	public void downloadGIROBankFile(Hashtable<String, String> hParams) throws Exception{
		try {
			llAction.selectMenuItem("System Administration", "BCP","GIRO Bank Transfer","Download GIRO Bank File");
						
			llAction.enterValue("web_batchJob_upload_bank_code",hParams.get("BankCode"));
			llAction.enterValue("web_bcp_dwl_giro_generateDate",hParams.get("GenerationDate"));
			llAction.selectByVisibleText("web_bcp_dwl_giro_deductionDate",hParams.get("GIRODeductionDate"));
			
			dashboard.setStepDetails("GIRO Bank Transfer" ,"About to download file" ,"N/A");
			dashboard.writeResults();
			
			llAction.clickElement("web_batchJob_dwl_cpf_download_datafile");
			llAction.clickElementJs("web_batchJob_dwl_cc_link");
			Utils.sleep(2);		
			ArtRobot.saveFile();
			Utils.sleep(2);	
			dashboard.setStepDetails("GIRO Bank Transfer" ,"File has been downloaded to Download Folder" ,"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_billing_exit_btn");
			llAction.waitUntilLoadingCompletes();
			
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	public void UploadGIROBankFile(Hashtable<String, String> hParams) throws Exception {
		try {

			GiroTemplateParser giroParser = new GiroTemplateParser();
			giroParser.processGiroTemplate(hParams);
			String outputpath = giroParser.getGiroReturnFilePath();

			llAction.selectMenuItem("System Administration", "BCP", "GIRO Bank Transfer", "Upload GIRO Bank File");
			llAction.waitUntilLoadingCompletes();

			llAction.enterValue("web_batchJob_upload_cc_batchno", hParams.get("BatchNo"));
			llAction.selectByVisibleText("web_batchJob_upload_bank_code", hParams.get("BankName"));
			llAction.enterValue("web_batchJob_upload_cc_browseBtn", outputpath);
			llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
			llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);

			dashboard.setStepDetails("GIRO Bank Transfer Upload", "File is uploaded. About to validate", "N/A");
			dashboard.writeResults();

			if (llAction.isEnabled("web_batchJob_upload_cc_validateBtn")) {
				llAction.clickElement("web_batchJob_upload_cc_validateBtn");
				dashboard.setStepDetails("GIRO Bank Transfer - Upload", "File is valid. About to submit", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_billing_giro_submit_btn");
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_billing_exit_btn");
				llAction.waitUntilLoadingCompletes();
			} else {
				dashboard.setFailStatus(
						new BPCException("GIRO Bank Transfer Upload - Validate Failed!! - File is invalid!!"));
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	public void processFileForCC(String action, Hashtable<String, String> hParams) throws Exception {
		if (action.equalsIgnoreCase(BatchConstants.FILE_DOWNLOAD)) {
			creditCardDownloadFile(hParams);
		} else {
			creditCardUploadFile(hParams);
		}

	}
	public void creditCardDownloadFile(Hashtable<String, String> hParams) throws Exception{
		llAction.selectMenuItem("System Administration","BCP","Credit Card Transfer","Credit Card Bank Download File");
		llAction.waitUntilLoadingCompletes();
		llAction.enterValue("web_batchjobs_cc_generate_date",hParams.get("GenerationDate"));
		dashboard.setStepDetails("Credit Card Bank Download File", "About to click on download button" ,"N/A");
		dashboard.writeResults();
		llAction.clickElement("web_batchjobs_cc_download_btn");
		dashboard.setStepDetails("Credit Card Bank Download File", "About to download credit card download file" ,"N/A");
		dashboard.writeResults();
		llAction.clickElementJs("web_batchJob_dwl_cc_link");
		Utils.sleep(2);		
		ArtRobot.saveFile();
		Utils.sleep(3);
		llAction.clickElement("web_billing_exit_btn");
		llAction.waitUntilLoadingCompletes();
	}
	public void creditCardUploadFile(Hashtable<String, String> hParams){		
		try {
			llAction.selectMenuItem("System Administration","BCP","Credit Card Transfer","Credit Card BankTransfer Upload File");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_batchJob_upload_cc_batchno",hParams.get("BatchNo"));
			llAction.enterValue("web_batchJob_upload_cc_browseBtn",hParams.get("UploadFilePath"));
			llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
			llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
			dashboard.setStepDetails("Credit Card BankTransfer Upload File", "About to click on validate button" ,"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_batchJob_upload_cc_validateBtn");
			llAction.waitUntilLoadingCompletes();
			if(llAction.isEnabled("web_batchJob_upload_cc_submitBtn")){
				dashboard.setStepDetails("Credit Card BankTransfer Upload File", "File validated. About to submit" ,"N/A");
				dashboard.writeResults();
				llAction.clickElement("web_batchJob_upload_cc_submitBtn");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Credit Card BankTransfer Upload File", "About to exit" ,"N/A");
				dashboard.writeResults();
				llAction.clickElement("web_billing_exit_btn");
				llAction.waitUntilLoadingCompletes();
			}else{
				dashboard.setFailStatus(new BPCException("File is invalid. Credit card upload failed!!"));
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	/**
	 * downloads the giro input file to local machine, parses and creates a new return file.
	 * Return file is copied to windows shared location 
	 * @param hParams
	 * @throws Exception
	 */
	public void ProcessGiroReturnFile(Hashtable<String, String> hParams)
			throws Exception {
		
		GiroTemplateParser parser = new GiroTemplateParser();
		hParams.put("FileName",parser.getGiroInputFileName(hParams.get("BatchProcessingDate")));
		ArrayList<String> fileList = getFilesFromSecuredFTP(hParams);	
		
		if (fileList != null && fileList.size() > 0) {
			for (String file : fileList) {

				hParams.put("InputFile", file);				
				parser.processGiroTemplate(hParams);
				uploadFile(parser.getGiroReturnFilePath(),hParams);
			}
		}
	}

	/**
	 * 
	 * Method - getFilesFromSecuredFTP - It could be SFTP
	 * folder location
	 * 
	 * @param hParams
	 * @return - gets list of the files copied from remote location
	 * @throws Exception
	 */
	private ArrayList<String> getFilesFromSecuredFTP(Hashtable<String, String> hParams) throws Exception {
		String fesIpAddress = hParams.get("FesIPAddress");
		BatchJobs bj = new BatchJobs();
		ArrayList<String> list = new ArrayList<String>();
		try {
				if (StringUtils.isEmpty(fesIpAddress)||StringUtils.isEmpty(hParams.get("UserName"))
							|| StringUtils.isEmpty(hParams.get("Password"))|| StringUtils.isEmpty(hParams.get("FolderLocation")))
				{
						dashboard.setFailStatus(new BPCException("Getting files from windows shared location"
								+ "Failed as one or more input parameter (FES shared ipaddress, UserName, Password, FolderLocation)is empty"));
	
				}
				else {
	
					list = bj.copyFileFromSFTP(hParams);
				}
		}

		catch (Exception e) {
			throw new BPCException(e);
		}
		return list;
	}
	/**
	 * Upload file to windows shared location
	 * @param sourceFilePath : refers to a file in local machine
	 * @param hParams : parameters for constructing destination url
	 * @throws Exception : if file copy fails
	 */
	private void uploadFile(String sourceFilePath,Hashtable<String, String> hParams) throws Exception{
		//String returnFileDestinationPath = hParams.get("OutputFile");		
		FTPClientUtils util = new FTPClientUtils();
		util.uploadFile(hParams.get("FesIPAddress"),  hParams.get("UserName"),
				hParams.get("Password"), hParams.get("OutputFile"),sourceFilePath);
	
	}
	
	
	public void CreateAndUploadLockboxReturnFile(Hashtable<String, String> hParams){
		
		LockboxTemplateParser parser = new LockboxTemplateParser();
		try {
			parser.processLockBoxTemplate(hParams);
			
			uploadFile(parser.getLockboxReturnFilePath(),hParams);
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	public void ProcessDirectCreditReturnFile(Hashtable<String, String> hParams)
			throws Exception {
		
		DirectCreditTemplateParser parser = new DirectCreditTemplateParser();
		hParams.put("FileName", IPaymentType.DC_INPUT_FILENAME);
		ArrayList<String> fileList = getFilesFromSecuredFTP(hParams);	
		
		if (fileList != null && fileList.size() > 0) {
			for (String file : fileList) {

				hParams.put("InputFile", file);				
				parser.processDirectCreditTemplate(hParams);
				uploadFile(parser.getDirectCreditOutputFileName(),hParams);
			}
		}
				
				/*hParams.put("InputFile", file "D:\\FPMS_ART\\IBGFPMSPAY2018082001.txt");				
				parser.processDirectCreditTemplate(hParams);
				uploadFile(parser.getDirectCreditOutputFileName(),hParams);*/
	}

}
