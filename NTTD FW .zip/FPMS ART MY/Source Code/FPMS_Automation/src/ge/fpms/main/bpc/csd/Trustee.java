package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;
import ge.fpms.main.bpc.nbu.ApplicationAccess;

public class Trustee {

	/*
	 * Name: Trustee Purpose: Navigate to CS module from the Main Page and change
	 * the trustee beneficiary info, Change Trustee Parameters:Parameter Hash table
	 * Return Value: NA Exception: BPCException
	 * 
	 * @author: Prashantha 0n 02/01/2019
	 */

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public Trustee() {
		dashboard = DashboardHandler.getInstance();
	}

	// This method is to add a trustee to the policy
	public void addTrustee(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();

		try {

			CSDHelper.getInstance().captureChange("Change Trustee", "BeforeChange");
			llAction.clickElement("web_btn_addTrustee");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoFrame("", "iframe0");
			llAction.enterValue("web_txt_partyName", hParams.get("Name"));
			dashboard.setStepDetails("Enter Party Name in Party Information page",
					"Valid Party name is entered in Party Information page", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_next");
			llAction.waitUntilLoadingCompletes();

			int partyIdNumberCol = llAction.GetColumnPositionInTable("web_tbl_partyList", "Name");
			int partyRecordNumberRow = llAction.GetRowPositionInTable("web_tbl_partyList", hParams.get("Name"),
					partyIdNumberCol);
			llAction.SelectRowInTable("web_tbl_partyList", partyRecordNumberRow, partyIdNumberCol - 2, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on PartyRecordNo link",
					"Create and Maintain Party-Step 2 page is displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_trusteeInfo_Submit");
			llAction.waitUntilLoadingCompletes();

			int addressRecordNoCol = llAction.GetColumnPositionInTable("web_tbl_address_ChangeTrustee",
					"Address Rec No.");
			int addressRow = llAction.GetRowPositionInTable("web_tbl_address_ChangeTrustee",
					hParams.get("AddressRecno"), addressRecordNoCol);
			llAction.SelectRowInTable("web_tbl_address_ChangeTrustee", addressRow, addressRecordNoCol - 1, "input");
			dashboard.setStepDetails("Select address", "address is selected", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_trusteeInfo_Submit");
			llAction.waitUntilLoadingCompletes();

			llAction.clickElement("web_btn_submit_ChangeTrustee");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("click Submit in change trustee screen", "Selected Address and clicked Submit",
					"N/A");

			llAction.clickElement("web_btn_submitforApproval_AppEntry");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("click Submit for Approval in Application Entry Screen",
					"clicked Submit for Approval", "N/A");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_Exit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	// This method is to delete a trustee to the policy
	public void deleteTrustee(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();

		try {

			CSDHelper.getInstance().captureChange("Delete Trustee", "BeforeChange");
			int partyIdNumberCol = llAction.GetColumnPositionInTable("web_tbl_trusteeList", "ID number");
			int partyRecordNumberRow = llAction.GetRowPositionInTable("web_tbl_trusteeList", hParams.get("IDNumber"),
					partyIdNumberCol);
			llAction.SelectRowInTable("web_tbl_trusteeList", partyRecordNumberRow, partyIdNumberCol - 3, "input");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_deleteTrustee");
			Utils.sleep(2);
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("click Delete trustee ", "Clicked Delete trustee", "N/A");
			if (llAction.isDisplayed("web_btn_recurring_continue")) {
				if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_tbl_WarningTable",
							hParams.get("WarningErrorMessage"));

					llAction.clickElement("web_btn_recurring_continue");
				} else {
					llAction.clickElement("web_btn_recurring_continue");
				}
			}
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_txt_NoRecordsFound")) {
				dashboard.setStepDetails("Record Not Found is displayed", "Deleted Trustee Successfully", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setStepDetails("Record Not Found is not displayed", "Delete Trustee was Unsuccessfull",
						"N/A");
				dashboard.writeResults();
			}

			llAction.clickElement("web_btn_submit_ChangeTrustee");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_submitforApproval_AppEntry");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("click Submit for Approval", "Selected Address and clicked Submit", "N/A");
			llAction.clickElement("web_btn_Exit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	// This method is to change the trustee info to the policy
	public void changeTrusteeInformation(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();

		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {
			llAction = new FPMS_Actions(); /* Get expected warning message from Test Data */
			CSDHelper.getInstance().captureChange("Change Beneficiary", "BeforeChange");

			// Click on the radio button under Trustee information and click on "Change
			// trustee information"
			// System should display the "Trustee Information" page UI
			int partyIdNumberCol = llAction.GetColumnPositionInTable("web_tbl_trusteeList", "ID number");
			int partyRecordNumberRow = llAction.GetRowPositionInTable("web_tbl_trusteeList", hParams.get("IDNumber"),
					partyIdNumberCol);
			llAction.SelectRowInTable("web_tbl_trusteeList", partyRecordNumberRow, partyIdNumberCol - 3, "input");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_changeTrusteeInformation");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails(
					"Click on the radio button under Trustee information and click on Change trustee information",
					"System should display the Trustee Information page UI", "N/A");
			dashboard.writeResults();
			int addressRecordNoCol = llAction.GetColumnPositionInTable("web_tbl_address_ChangeTrustee",
					"Address Rec No.");
			int addressRow = llAction.GetRowPositionInTable("web_tbl_address_ChangeTrustee",
					hParams.get("AddressRecno"), addressRecordNoCol);
			llAction.SelectRowInTable("web_tbl_address_ChangeTrustee", addressRow, addressRecordNoCol - 1, "input");
			dashboard.setStepDetails("Select address", "address is selected", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_trusteeInfo_Submit");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_recurring_continue")) {
				llAction.clickElement("web_btn_recurring_continue");
			}

			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("Change Trustee Information", "AfterChange");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_submit_ChangeTrustee");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("click Submit in change trustee screen", "Selected Address and clicked Submit",
					"N/A");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_submit_ChangeTrustee");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("click Submit in Application Entry Screen",
					"clicked Submit for Approval", "N/A");
			
//			dashboard.setStepDetails("click Submit for Approval in Application Entry Screen",
//					"clicked Submit for Approval", "N/A");
			llAction.waitUntilLoadingCompletes();
//			llAction.clickElement("web_btn_Exit");
//			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	// This method is to change the trustee info to the policy
	public void changeTrusteeApproval(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();

		try {

			changeTrusteeApprovalType();
			String applicationStatus = hParams.get("ApplicationStatus");
			llAction = new FPMS_Actions();
			llAction.selectMenuItem("Customer Service", "Application Entry Sharing Pool");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_PolicyNumber", hParams.get("PolicyNo"));
			llAction.clickElement("web_btn_Search");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Policy Search", "Policy search should be successfully searched", "N/A");
			dashboard.writeResults();
			CSDHelper.getInstance().captureChange("Change Trustee Approval", "BeforeChange");
			llAction.clickElement("web_btn_trusteeInfo_Submit");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("Change Trustee Approval", "AfterChange");
			if (llAction.getText("web_txt_FinalAppStatus").contains(applicationStatus)) {
				dashboard.setStepDetails(applicationStatus + " Should be populated", "Message is validated", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(applicationStatus + "message is invalid/Submit was not successful");
				dashboard.writeResults();
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_txt_common_back_to_main");

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	/*
	 * Name: changeTrusteeApprovalType Purpose: Use Approver credentials to approve
	 * the incoming Maker requests. * Test Data sheet Return Value: N/A Exception:
	 * BPC Exception on component execution fail Author :Prashantha
	 */
	public void changeTrusteeApprovalType() throws Exception {
		try {

			ApplicationAccess appAccess = new ApplicationAccess();
			Hashtable<String, String> loginParams = appAccess.getAccessParameters();
			appAccess.logout(loginParams);
			appAccess.login(loginParams);

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

}
