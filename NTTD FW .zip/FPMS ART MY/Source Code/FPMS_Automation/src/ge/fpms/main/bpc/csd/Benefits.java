package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import org.openqa.selenium.Keys;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class Benefits {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	
	public Benefits() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	
	public void ChangeBenefits(Hashtable<String, String> hParams) throws Exception {
		try {
		     DashboardHandler.getInstance().setStepDetails("Change Benefits ",
		                  "About to select  change benefit from immediate ", "N/A");
		     DashboardHandler.getInstance().writeResults();
		
//		     llAction.clickElement("web_btn_cb_immediate");
//		     llAction.waitUntilLoadingCompletes();
		
		     // changebenefit.UpgradeDowngradeCoverage=>Amend screen
		     String benefitInfoTbl = "web_tbl_cb_benefits_beforechange";
		     int cPos = llAction.GetColumnPositionInTable(benefitInfoTbl, "Benefit");
		     int rPos = llAction.GetRowPositionInTable(benefitInfoTbl,hParams.get("BenefitCode"), cPos);
		     int optionButtonPos = llAction.GetColumnPositionInTable(benefitInfoTbl,"Option");
		     llAction.SelectRowInTable(benefitInfoTbl, rPos, optionButtonPos,"input");
		
		     DashboardHandler.getInstance().setStepDetails("Change Benefits ","Selected the plan to be amended ", "N/A");
		     DashboardHandler.getInstance().writeResults();
		
		     llAction.clickElement("web_btn_cb_benefit_change_button");
		     llAction.waitUntilLoadingCompletes();
		
		     llAction.enterValue("web_txt_cb_benefit_info_benefit_type",hParams.get("BenefitType"));
		     llAction.sendkeyStroke("web_txt_cb_benefit_info_benefit_type",Keys.ENTER);
		    // llAction.clickElement("web_btn_cb_benefit_into_save_button");
		    // llAction.waitUntilLoadingCompletes();
		     
		     //llAction.enterValue("web_txt_cb_benefit_coverage_year",hParams.get("Yearageofcoverageterm"));
		     llAction.enterValue("web_txt_cb_benefit_details_pcalc_method",hParams.get("Premiumcalculationmethod"));
		     llAction.sendkeyStroke("web_txt_cb_benefit_details_pcalc_method",Keys.ENTER);
		     Utils.sleep(2);
		     llAction.enterValue("web_txt_cb_benefit_details_premium_amt",hParams.get("PremiumAmount"));
		
		     DashboardHandler.getInstance().setStepDetails(" Amend Changes","Amended the changes, about to save.. ", "N/A");
		     DashboardHandler.getInstance().writeResults();
		     llAction.clickElement("web_btn_cb_benefit_into_save_button");
		     llAction.waitUntilLoadingCompletes();
		
		     if (llAction.isDisplayed("web_btn_continue")) {
					if ( hParams.get("WarningErrorMessage")!=null && hParams.get("WarningErrorMessage")!="" )
					{							
						CSDHelper.getInstance().validateWarningMessages("web_txt_cb_benefit_details_warning_tbl",hParams.get("WarningErrorMessage"));
						llAction.waitUntilLoadingCompletes();				
					}		
					llAction.clickElement("web_btn_continue");
					dashboard.setStepDetails("Click on continue button",
							"System should navigate to application entry screen with status as completed.", "N/A");
					dashboard.writeResults();
				}

//		     if (llAction.isDisplayed("web_btn_continue", 5)) {
//		    	 
//		    	 
//		            llAction.clickElement("web_btn_continue");
//		     }
//		     llAction.waitUntilLoadingCompletes();
		
		     // Change Benefit Coverage
		     llAction.clickElement("web_btn_cb_coverage_submit");
		     llAction.waitUntilLoadingCompletes();
		
		     DashboardHandler.getInstance().setStepDetails("Change Benefits "," UI with Benefit information after change info ", "N/A");
		     DashboardHandler.getInstance().writeResults();
		     // System should display "Change benefit" UI with Benefit information
		     // after change info
		     llAction.clickElement("web_btn_cb_coverage_submit");
		     llAction.waitUntilLoadingCompletes();
		     CSDHelper.getInstance().endOfTransaction();
		} catch (Exception ex) {
			dashboard.writeResults();
			ex.printStackTrace();
			throw new BPCException(
					"Exception occured while calling ChangeBenefits method \n Exception is " + ex.getMessage());
		}
	}	
}
