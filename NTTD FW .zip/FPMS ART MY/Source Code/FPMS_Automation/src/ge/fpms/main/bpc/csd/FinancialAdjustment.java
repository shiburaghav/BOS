package ge.fpms.main.bpc.csd;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.common.Query;
import ge.fpms.main.bpc.csd.components.CSDHelper;

import java.util.Hashtable;

import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class FinancialAdjustment {


	private static final String ADJONFROZENSTATUS = "Yes";
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private final String DEFAULT_SELECTION="Please Select";

	public FinancialAdjustment() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void FinancialManualAdjustment(Hashtable<String, String> hParams) throws Exception{
	
		String lapseReason = hParams.get("Lapsereason");
		String terminationReason = hParams.get("Terminationreason");
		
		
		llAction.selectMenuItem("Customer Service", "Financial Manual Adjustment");
		llAction.waitUntilLoadingCompletes();
		llAction.enterValue("web_txt_fma_policy_txt", hParams.get("PolicyNumber"));
		llAction.clickElement("web_btn_fma_policy_search");
		llAction.waitUntilLoadingCompletes();
		
		String newPolicyStatus = hParams.get("Policyriskstatus");
	
		// Updating Policy information Adjustment
		String currentPolicyStatus =llAction.getText("web_txt_fma_policy_current_status");
		String currentLapsedDate =llAction.getElement("web_txt_fma_policy_lapseDate").getAttribute("value");
		String currentTerminationDate =llAction.getElement("web_txt_fma_policy_endDate").getAttribute("value");
		String currentPolicyDate = llAction.getElement("web_txt_fma_policy_inforceDate").getAttribute("value");
		
		llAction.selectByVisibleText("web_list_fma_policy_risk", newPolicyStatus);
		
		if(newPolicyStatus.equalsIgnoreCase(FPMSConstants.POLICY_STATUS_INFORCE)){
			updatePolicyAttributes("web_txt_fma_policy_inforceDate", hParams.get("Inforcedate"),
					"web_txt_fma_policy_lapseDate","web_txt_fma_policy_endDate");
			llAction.selectByVisibleText("web_list_fma_policy_lapse_reason", DEFAULT_SELECTION);
			llAction.selectByVisibleText("web_list_fma_policy_end_reason",  DEFAULT_SELECTION);
		}
		else if(newPolicyStatus.equalsIgnoreCase(FPMSConstants.POLICY_STATUS_LAPSED))
		{
			updatePolicyAttributes("web_txt_fma_policy_lapseDate", hParams.get("Lapsedate"),
					"web_txt_fma_policy_inforceDate","web_txt_fma_policy_endDate");
			llAction.selectByVisibleText("web_list_fma_policy_lapse_reason", lapseReason);
			llAction.selectByVisibleText("web_list_fma_policy_end_reason",  DEFAULT_SELECTION);
		}
		else if(newPolicyStatus.equalsIgnoreCase(FPMSConstants.POLICY_STATUS_TERMINATED))
		{
			updatePolicyAttributes("web_txt_fma_policy_endDate", hParams.get("Terminationdate"),
					"web_txt_fma_policy_lapseDate","web_txt_fma_policy_inforceDate");
			llAction.selectByVisibleText("web_list_fma_policy_lapse_reason", DEFAULT_SELECTION);
			llAction.selectByVisibleText("web_list_fma_policy_end_reason",  terminationReason);
		}
		
		DashboardHandler.getInstance().setStepDetails("Financial Manual Adjustment","updating  policy information adjustment, risk status changed to  " + newPolicyStatus,"N/A");
		DashboardHandler.getInstance().writeResults();
		
		//updating benefits 
		updateBenefits(newPolicyStatus,hParams);
		
		llAction.clickElement("web_list_fma_policy_risk_submit");
		llAction.acceptAlert();
		llAction.waitUntilLoadingCompletes();
		
		queryPolicyStatus(hParams.get("PolicyNumber"), hParams.get("Policyriskstatus"), currentLapsedDate, currentPolicyStatus,currentTerminationDate,currentPolicyDate);
		launchBenefitInfo(newPolicyStatus);
		
	}
	private void updatePolicyAttributes(String newStatusElement, String newStatusDate, String clearField1, String clearField2) throws Exception{
	
		llAction.enterValue(newStatusElement,newStatusDate);
		llAction.clearText(clearField1);
		llAction.clearText(clearField2);

	}
	private void queryPolicyStatus(String policyNumber, String policyStatus, String currentLapsedDate, String currentPolicyStatus, String currentTerminationDate,String currentPolicyDate) throws Exception{
		Hashtable<String, String> policyDetails = new Hashtable<String, String>();
		policyDetails.put("PolicyNo", policyNumber);
		policyDetails.put("PolicyStatus", policyStatus);
		
		Query query = new Query();
		query.queryPolicyInfo(policyDetails);
		String message = "";
		message = validateStatus(currentPolicyStatus, currentLapsedDate, currentPolicyDate, currentTerminationDate);
		String newLapsedDate =llAction.table_GetValueOfSpecificLabel("web_tbl_query_fma_table","Lapse Date");
		String newTerminationDate =llAction.table_GetValueOfSpecificLabel("web_tbl_query_fma_table","Termination Date");
		String newPolicyDate = llAction.getText("web_txt_query_policy_commencementDate");
		DashboardHandler.getInstance().setStepDetails("Verifying policy status","Old policy status = " + currentPolicyStatus + " and " + currentPolicyStatus + 
				" date = " + message,"N/A");
		DashboardHandler.getInstance().writeResults();
		
		message = validateStatus(policyStatus, newLapsedDate, newPolicyDate, newTerminationDate);
		DashboardHandler.getInstance().setStepDetails("Verifying policy status","New policy status = " + policyStatus + " and " + policyStatus + 
				" date = " + message,"N/A");
		DashboardHandler.getInstance().writeResults();
	}
	
	private void updateBenefits(String newPolicyStatus, Hashtable<String, String> hParams) throws Exception{
		String benefitsTable = "web_tbl_lifeassuredinfo";
		int size = llAction.getRowCountInTable(benefitsTable);
		
		int riskStatusCol = llAction.GetColumnPositionInTable(benefitsTable, "Risk Status");
		int inforceDateCol = llAction.GetColumnPositionInTable(benefitsTable, "In Force Date");
		int lapReasonCol = llAction.GetColumnPositionInTable(benefitsTable, "Lapse Reason");
		int terminationReasonCol = llAction.GetColumnPositionInTable(benefitsTable, "Termination Reason");
		int lapDateCol = llAction.GetColumnPositionInTable(benefitsTable, "Lapse Date");
		int terminationDateCol = llAction.GetColumnPositionInTable(benefitsTable, "Termination Date");
		String lapseReason = hParams.get("Lapsereason");
		String terminationReason = hParams.get("Terminationreason");
		
		for(int i=2; i <= size; i++){
			llAction.enterTextInTable(benefitsTable, i, riskStatusCol, newPolicyStatus,"/span/select");
			
			if(newPolicyStatus.equalsIgnoreCase(FPMSConstants.POLICY_STATUS_INFORCE)){
				llAction.enterTextInTable(benefitsTable, i, inforceDateCol,hParams.get("Inforcedate"), "/input");
				llAction.enterTextInTable(benefitsTable, i, lapDateCol,  "","/input");
				llAction.enterTextInTable(benefitsTable, i, terminationDateCol, "","/input");
				llAction.enterTextInTable(benefitsTable, i, lapReasonCol, DEFAULT_SELECTION,"/span/select");
				llAction.enterTextInTable(benefitsTable, i, terminationReasonCol, DEFAULT_SELECTION,"/span/select");
			}
			else if(newPolicyStatus.equalsIgnoreCase(FPMSConstants.POLICY_STATUS_LAPSED))
			{
				llAction.enterTextInTable(benefitsTable, i, inforceDateCol,"", "/input");
				llAction.enterTextInTable(benefitsTable, i, lapDateCol,   hParams.get("Lapsedate"),"/input");
				llAction.enterTextInTable(benefitsTable, i, terminationDateCol, "","/input");
				
				llAction.enterTextInTable(benefitsTable, i, lapReasonCol, lapseReason,"/span/select");
				llAction.enterTextInTable(benefitsTable, i, terminationReasonCol, DEFAULT_SELECTION,"/span/select");
			}
			else if(newPolicyStatus.equalsIgnoreCase(FPMSConstants.POLICY_STATUS_TERMINATED))
			{
				llAction.enterTextInTable(benefitsTable, i, inforceDateCol,"", "/input");
				llAction.enterTextInTable(benefitsTable, i, lapDateCol,"","/input");
				llAction.enterTextInTable(benefitsTable, i, terminationDateCol, hParams.get("Terminationdate"),"/input");
				llAction.enterTextInTable(benefitsTable, i, lapReasonCol, DEFAULT_SELECTION,"/span/select");
				llAction.enterTextInTable(benefitsTable, i, terminationReasonCol, terminationReason,"/span/select");
			}
			
		}
		
		DashboardHandler.getInstance().setStepDetails("Financial Manual Adjustment","Updating Benefit information adjustment]","N/A");
		DashboardHandler.getInstance().writeResults();
		
		

	}
	
	private void launchBenefitInfo(String newPolicyStatus) throws Exception
	{
		llAction.selectTab(FPMSConstants.BENEFIT_INFO);
		llAction.waitUntilLoadingCompletes();
		String benefitsTable = "web_query_benefitInfo_tbl";
		String benefitStatus = "";
		
		int size = llAction.getRowCountInTable(benefitsTable);
		int benefitStatusCol = llAction.GetColumnPositionInTable(benefitsTable, "Benefit Status");
		for(int i=2; i < size; i++){
			benefitStatus = llAction.GetTextFromTable(benefitsTable, i, benefitStatusCol);
			if(!benefitStatus.equalsIgnoreCase(newPolicyStatus)){
				
				DashboardHandler.getInstance().setStepDetails("Common Query - Benefit Info","Benefit status " + benefitStatus + "does not match, Expected is " + newPolicyStatus ,"N/A");
				DashboardHandler.getInstance().writeResults();
				throw new BPCException(new Exception("Benefit status does not match, Expected is " + newPolicyStatus));
			}
		}
		DashboardHandler.getInstance().setStepDetails("Common Query - Benefit Info","Benefit status " + benefitStatus + " is same as expected = " + newPolicyStatus,"N/A");
		DashboardHandler.getInstance().writeResults();
		
		llAction.clickElement("web_btn_benefit_info_query_exit");
		llAction.waitUntilLoadingCompletes();
		
	}
	
	private String validateStatus(String status, String lapsedt, String policyDt, String terminationDt) {
		String message ="";
		switch (status) {

			case FPMSConstants.POLICY_STATUS_INFORCE: {
				message = policyDt;
				break;
			}
			case FPMSConstants.POLICY_STATUS_LAPSED: {
				message = lapsedt;
				break;
			}
			case FPMSConstants.POLICY_STATUS_TERMINATED: {
				message = terminationDt;
				break;
			}
		}
		return message;
	}

	public void adjustFrozenStatus(Hashtable<String, String> hParams) throws Exception {
		
		try {
			llAction.selectMenuItem("Customer Service", "Financial Manual Adjustment");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_fma_policy_txt", hParams.get("PolicyNumber"));
			llAction.selectByVisibleText("web_lst_adjustFrozenStatus", ADJONFROZENSTATUS);
			dashboard.setStepDetails("Enter Policynumber and Adjustment on frozen status",
					"System shopuld accept input value", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_fma_policy_search");
			llAction.waitUntilLoadingCompletes();
			llAction.selectByVisibleText("web_lst_FrozenStatus", hParams.get("FrozenStatus"));
			if(llAction.isEnabled("web_lst_SuspendCause"))
				llAction.selectByVisibleText("web_lst_SuspendCause", hParams.get("SuspendCause"));
			dashboard.setStepDetails("Select the new Frozen Status",
					"Frozen Status is changed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_PartyChanges_btn_Submit");
			llAction.acceptAlert();
			if(llAction.isDisplayed("web_txt_ErrorMessage"))
			{
				dashboard.setFailStatus(new BPCException("Frozen Status is not changed!"));
			}
			else {
				dashboard.setStepDetails("Accept the alert",
						"FPMS home page is displayed", "N/A");
				dashboard.writeResults();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
