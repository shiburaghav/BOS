package ge.fpms.main.bpc.bcp.templates.giro;

import org.apache.commons.lang3.StringUtils;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.IPaymentType;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Details implements IPaymentSection {
	private Type dtlRecType;
	private Type dtlBatchNo;
	private Type dtlRefNo;
	private Type dtlCustId;
	private Type dtlCustName;
	private Type dtlCustAcct;
	private Type dtlDebitAmt;
	private Type dtlFiller1;
	private Type dtlFiller2;
	private Type dtlReferenceNumber2;
	private Type dtlFiller3;
	private Type dtlBankRefNum;
	private Type dtlDebitStatusCode;
	private Type dtlDebitStsDesc;
	public static final int FIELD_COUNT = 14;

	public Details(){
		
	}
	public Type getDtlRecType() {
		return dtlRecType;
	}

	public void setDtlRecType(Type dtlRecType) {
		this.dtlRecType = dtlRecType;
	}

	public Type getDtlBatchNo() {
		return dtlBatchNo;
	}

	public void setDtlBatchNo(Type dtlBatchNo) {
		this.dtlBatchNo = dtlBatchNo;
	}

	public Type getDtlRefNo() {
		return dtlRefNo;
	}

	public void setDtlRefNo(Type dtlRefNo) {
		this.dtlRefNo = dtlRefNo;
	}

	public Type getDtlCustId() {
		return dtlCustId;
	}

	public void setDtlCustId(Type dtlCustId) {
		this.dtlCustId = dtlCustId;
	}

	public Type getDtlCustName() {
		return dtlCustName;
	}

	public void setDtlCustName(Type dtlCustName) {
		this.dtlCustName = dtlCustName;
	}

	public Type getDtlCustAcct() {
		return dtlCustAcct;
	}

	public void setDtlCustAcct(Type dtlCustAcct) {
		this.dtlCustAcct = dtlCustAcct;
	}

	public Type getDtlDebitAmt() {
		return dtlDebitAmt;
	}

	public void setDtlDebitAmt(Type dtlDebitAmt) {
		this.dtlDebitAmt = dtlDebitAmt;
	}

	public Type getDtlFiller1() {
		return dtlFiller1;
	}

	public void setDtlFiller1(Type dtlFiller1) {
		this.dtlFiller1 = dtlFiller1;
	}

	public Type getDtlFiller2() {
		return dtlFiller2;
	}

	public void setDtlFiller2(Type dtlFiller2) {
		this.dtlFiller2 = dtlFiller2;
	}

	public Type getDtlReferenceNumber2() {
		return dtlReferenceNumber2;
	}

	public void setDtlReferenceNumber2(Type dtlReferenceNumber2) {
		this.dtlReferenceNumber2 = dtlReferenceNumber2;
	}

	public Type getDtlFiller3() {
		return dtlFiller3;
	}

	public void setDtlFiller3(Type dtlFiller3) {
		this.dtlFiller3 = dtlFiller3;
	}

	public Type getDtlBankRefNum() {
		return dtlBankRefNum;
	}

	public void setDtlBankRefNum(Type dtlBankRefNum) {
		this.dtlBankRefNum = dtlBankRefNum;
	}
	
	public Type getDtlDebitStatusCode() {
		String val = dtlDebitStatusCode.getValue().trim();
		if(StringUtils.isEmpty(val)){
			val = IPaymentType.DEFAULT_RETURN_CODE;			
			dtlDebitStatusCode.setValue(val);
		}
		return dtlDebitStatusCode;
	}
	
	public void setDtlDebitStatusCode(Type dtlDebitStatusCode) {
		this.dtlDebitStatusCode = dtlDebitStatusCode;
	}
	
	public Type getDtlDebitStsDesc() {
		return dtlDebitStsDesc;
	}

	public void setDtlDebitStsDesc(Type dtlDebitStsDesc) {
		this.dtlDebitStsDesc = dtlDebitStsDesc;
	}
	
	
	public Details(Type[] type) {
		super();
		this.dtlRecType = new Type(type[0].getSize(), type[0].getDataType(),
				type[0].getValue(), type[0].getAlignment(),
				type[0].getPaddingChar());
		
		this.dtlBatchNo = new Type(type[1].getSize(),
				type[1].getDataType(), type[1].getValue(),
				type[1].getAlignment(), type[1].getPaddingChar());
		
		this.dtlRefNo = new Type(type[2].getSize(),
				type[2].getDataType(), type[2].getValue(),
				type[2].getAlignment(), type[2].getPaddingChar());
		
		this.dtlCustId = new Type(type[3].getSize(),
				type[3].getDataType(), type[3].getValue(),
				type[3].getAlignment(), type[3].getPaddingChar());
		
		this.dtlCustName = new Type(type[4].getSize(),
				type[4].getDataType(), type[4].getValue(),
				type[4].getAlignment(), type[4].getPaddingChar());
		
		this.dtlCustAcct = new Type(type[5].getSize(),
				type[5].getDataType(), type[5].getValue(),
				type[5].getAlignment(), type[5].getPaddingChar());
		
		this.dtlDebitAmt = new Type(type[6].getSize(),
				type[6].getDataType(), type[6].getValue(),
				type[6].getAlignment(), type[6].getPaddingChar());
		this.dtlFiller1 = new Type(type[7].getSize(),
				type[7].getDataType(), type[7].getValue(),
				type[7].getAlignment(), type[7].getPaddingChar());
		this.dtlFiller2 = new Type(type[8].getSize(),
				type[8].getDataType(), type[8].getValue(),
				type[8].getAlignment(), type[8].getPaddingChar());
		this.dtlReferenceNumber2 = new Type(type[9].getSize(), type[9].getDataType(),
				type[9].getValue(), type[9].getAlignment(),
				type[9].getPaddingChar());
		
		this.dtlFiller3 = new Type(type[10].getSize(),
				type[10].getDataType(), type[10].getValue(),
				type[10].getAlignment(), type[10].getPaddingChar());
		
		this.dtlBankRefNum = new Type(type[11].getSize(),
				type[11].getDataType(), type[11].getValue(),
				type[11].getAlignment(), type[11].getPaddingChar());
		
		this.dtlDebitStatusCode = new Type(type[12].getSize(), type[12].getDataType(),
				type[12].getValue(), type[12].getAlignment(),
				type[12].getPaddingChar());
		
		this.dtlDebitStsDesc = new Type(type[13].getSize(),
				type[13].getDataType(), type[13].getValue(),
				type[13].getAlignment(), type[13].getPaddingChar());
	}

	public int[] getAttributesSize() {
		return new int[] { dtlRecType.getSize(),
				dtlBatchNo.getSize(),
				dtlRefNo.getSize(),
				dtlCustId.getSize(),
				dtlCustName.getSize(), dtlCustAcct.getSize(),
				dtlDebitAmt.getSize(),dtlFiller1.getSize(),dtlFiller2.getSize(),
				dtlReferenceNumber2.getSize(), dtlFiller3.getSize()
				/*dtlBankRefNum.getSize(), dtlDebitStatusCode.getSize(),
				dtlReferenceNumber2.getSize(), dtlDebitStsDesc.getSize()*/};
	}

	
	public String getName() {
		return "02";
	}

	

	public String toString() {
		String details = new StringBuilder().append(getDtlRecType().toString())
				.append(getDtlBatchNo().toString())
				.append(getDtlRefNo().toString())
				.append(getDtlCustId().toString())
				.append(getDtlCustName().toString())
				.append(getDtlCustAcct().toString())
				.append(getDtlDebitAmt().toString())
				.append(getDtlBankRefNum().toString())
				.append(getDtlDebitStatusCode().toString())
				.append(getDtlReferenceNumber2().toString())
				.append(getDtlDebitStsDesc().toString()).toString();
		
		return details;
	}

	public Type[] getAllAttributes() {
		return new Type[] { dtlRecType, dtlBatchNo,
				dtlRefNo, dtlCustId,
				dtlCustName, dtlCustAcct,
				dtlDebitAmt, dtlFiller1,dtlFiller2,
				dtlReferenceNumber2,
				dtlFiller3};
	}
	public int getFieldCount(){
		return FIELD_COUNT ;
	}
}
