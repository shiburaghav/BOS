package ge.fpms.data;

import java.lang.reflect.Method;
import java.util.ArrayList;

import ge.fpms.data.BenefitData;
import ge.fpms.data.CSDData;
import ge.fpms.data.Policy;
import ge.fpms.main.FPMSManager;

public class PolicyHandler {
	private Policy policy;
	private CSDData csd;
	private BenefitData benefit;
	private ArrayList<FPMSARTDao> policyList;

	public PolicyHandler() {
		policyList = new ArrayList<FPMSARTDao>();	
	}
	public void  initializePolicy()
	{
		createPolicy();

	}

	public void updatePolicy(String propertyName,String value) throws Exception{
		createPolicy();
		//update(policy,popertyName,value);
		//update(csd,popertyName,value);
		update(policy,propertyName,value);
	}
		
	public void addPolicytoList(FPMSARTDao artDao)
	
	{
		policyList.add(artDao);
		policy = null;
	}
	private void update(Object obj,String popertyName,String value)throws Exception {
		String methodName = "set" + popertyName;
		Method method = obj.getClass().getMethod(methodName, String.class) ;
		method.invoke(obj, value);

	}
	private void createPolicy() {
		
		if(policy==null) {
			policy  = new Policy();
			
		}
	//	csd  = new CSDData();
	//	benefit  = new BenefitData();
		

	}
	public Boolean isPolicyEmpty() {
	
		String policyNo = "";
		if (policy != null) {
			policyNo = policy.getPolicyNo();
		}
		return policyNo == null ? true : policyNo.isEmpty();
	}

	public ArrayList<FPMSARTDao> getPolicyList() {
		// TODO Auto-generated method stub
		return policyList;
	}
	public Policy getPolicy() {
	
		return policy;
	}
}
