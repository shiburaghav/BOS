package ge.fpms.data;

import com.nttdata.core.TestCase;

public class FPMSARTDao {

	private TestCase testCase;
	private Policy policy;
	public FPMSARTDao(TestCase testCase, Policy policy) {
		super();
		this.testCase = testCase;
		this.policy = policy;
	}
public Policy getPolicy() {
		
		return policy;
	}
public TestCase getTestCase() {
	
	return testCase;
}

	
}
