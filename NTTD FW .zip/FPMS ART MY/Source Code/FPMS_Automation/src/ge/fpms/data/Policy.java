package ge.fpms.data;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;

public class Policy {

	private String proposerName;
	private String proposerId;

	private HashMap<String, String> lifeAssured;
	private HashMap<String, String> nominee;
	private HashMap<String, String> trustee;
	private HashMap<String, String> beneficialOwner;
	private HashMap<String, String> connectedParty;

	private String policyNo;
	private String PartyName;
	private String PartyId;
	private String agentCode;

	private String actualBenefitName;
	private String actualInstallementPremium;
	private String actualSumAssured;
	private String actualPaymentFrequency;
	private String actualLoadingOption;
	private String actualLoadingRate;

	private String actualLifeAssuredName;

	private String paymentMethod;
	private String policyStatus;
	private String policyHolder;
	private String paymentFrequency;
	private String coverageYear;
	private String chargeYear;
	private String premium;
	private String commencementDate;

	private BenefitData benefit;
	
	private ArrayList<BenefitData> benefitsList = new ArrayList<BenefitData>();

	public String getActualLifeAssuredName() {

		return actualLifeAssuredName;
	}

	public void setActual_LifeAssuredName(String actual_LifeAssuredName) {
		this.actualLifeAssuredName = actual_LifeAssuredName;
	}

	public String getActualBenefitName() {
		return actualBenefitName;
	}

	public void setActualBenefitName(String actual_BenefitName) {
		this.actualBenefitName = actual_BenefitName;
	}

	public String getActual_InstallementPremium() {
		return actualInstallementPremium;
	}

	public void setActualInstallementPremium(String actual_InstallementPremium) {
		this.actualInstallementPremium = actual_InstallementPremium;
	}

	public String getActualSumAssured() {
		return actualSumAssured;
	}

	public void setActualSumAssured(String actual_SumAssured) {
		this.actualSumAssured = actual_SumAssured;
	}

	public String getActualPaymentFrequency() {
		return actualPaymentFrequency;
	}

	public void setActualPaymentFrequency(String actual_PaymentFrequency) {
		this.actualPaymentFrequency = actual_PaymentFrequency;
	}

	public String getActualLoadingOption() {
		return actualLoadingOption;
	}

	public void setActualLoadingOption(String actual_LoadingOption) {
		this.actualLoadingOption = actual_LoadingOption;
	}

	public String getActualLoadingRate() {
		return actualLoadingRate;
	}

	public void setActualLoadingRate(String actual_LoadingRate) {
		this.actualLoadingRate = actual_LoadingRate;
	}

	// Policy data
	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNumber) {
		System.out.println("Policy.setPolicyNo() policyNo ... " + policyNumber);
		policyNumber = policyNumber.trim().replaceAll("-", "");
		this.policyNo = policyNumber;
	}

	public String getPartyName() {
		return PartyName;
	}

	public void setPartyName(String partyName) {
		PartyName = partyName;
	}

	public String getPartyId() {
		return PartyId;
	}

	public void setPartyId(String partyId) {
		PartyId = partyId;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	public String getPolicyHolder() {
		return policyHolder;
	}

	public void setPaymentFrequency(String paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}

	public String getPaymentFrequency() {
		return paymentFrequency;
	}

	public void setCoverageYear(String coverageYear) {
		this.coverageYear = coverageYear;
	}

	public String getCoverageYear() {
		return coverageYear;
	}

	public void setChargeYear(String chargeYear) {
		this.chargeYear = chargeYear;
	}

	public String getChargeYear() {
		return chargeYear;
	}

	public void setPremium(String premium) {
		this.premium = premium;
	}

	public String getPremium() {
		return premium;
	}

	public void setCommencementDate(String commencementDate) {
		this.commencementDate = commencementDate;
	}

	public String getCommencementDate() {
		return commencementDate;
	}

	public void addBenefittoList(BenefitData benefit)

	{
		benefitsList.add(benefit);
		benefit = null;
	}

	public ArrayList<BenefitData> getBenefitList() {

		return benefitsList;
	}

	private void update(Object obj, String propertyName, String value) throws Exception {
		String methodName = "set" + propertyName;
		Method method = obj.getClass().getMethod(methodName, String.class);
		method.invoke(obj, value);

	}

	public void updateBenefit(String propertyName, String value) throws Exception {
		createBenefit();
		update(benefit, propertyName, value);
	}

	private void createBenefit() {

		if (benefit == null) {
			benefit = new BenefitData();

		}
	}

	public Policy() {
		lifeAssured = new HashMap<String, String>();
		nominee = new HashMap<String, String>();
		beneficialOwner = new HashMap<String, String>();
		trustee = new HashMap<String, String>();
		connectedParty = new HashMap<String, String>();
	}

	public String getLifeAssuredName(String id) {
		return lifeAssured.get(id);
	}

	public HashMap<String, String> getAllLifeAssured() {
		return lifeAssured;
	}

	public String getNomineeName(String id) {
		return nominee.get(id);
	}

	public HashMap<String, String> getAllNominee() {
		return nominee;
	}

	public String getTrusteeName(String id) {
		return trustee.get(id);
	}

	public HashMap<String, String> getAllTrustee() {
		return trustee;
	}

	public String getBeneficialOwnerName(String id) {
		return beneficialOwner.get(id);
	}

	public HashMap<String, String> getAllBeneficialOwner() {
		return beneficialOwner;
	}

	public void setLifeAssured(String lifeAssuredId, String lifeAssuredName) {
		lifeAssured.put(lifeAssuredId, lifeAssuredName);
	}

	public String getLifeAssuredId(int index) {
		String id = "";

		if (lifeAssured.size() > 0) {
			id = lifeAssured.keySet().toArray()[index].toString();
		}
		return id;
	}

	public void setNominee(String nomineeId, String nomineeName) {
		nominee.put(nomineeId, nomineeName);
	}

	public String getNomineeId(int index) {
		String id = "";

		if (nominee.size() > 0) {
			id = nominee.keySet().toArray()[index].toString();
		}
		return id;
	}

	public void setTrustee(String trusteeId, String trusteeName) {
		trustee.put(trusteeId, trusteeName);
	}

	public String getTrusteeId(int index) {
		String id = "";

		if (trustee.size() > 0) {
			id = trustee.keySet().toArray()[index].toString();
		}
		return id;
	}

	public void setBeneficialOwner(String beneficialOwnerId, String beneficialOwnerName) {
		beneficialOwner.put(beneficialOwnerId, beneficialOwnerName);
	}
	
	public String getBeneficialOwnerId(int index) {
		String id = "";

		if (beneficialOwner.size() > 0) {
			id = beneficialOwner.keySet().toArray()[index].toString();
		}
		return id;
	}

	public void setConnectedParty(String beneficialOwnerId, String beneficialOwnerName) {
		connectedParty.put(beneficialOwnerId, beneficialOwnerName);
	}
	
	public String getConnectedPartyId(int index) {
		String id = "";

		if (connectedParty.size() > 0) {
			id = connectedParty.keySet().toArray()[index].toString();
		}
		return id;
	}
	
	public String getProposerName() {
		return proposerName;
	}

	public void setProposerName(String name) {
		proposerName = name;
	}

	public String getProposerId() {
		return proposerId;
	}

	public void setProposerId(String id) {
		proposerId = id;
	}

	public String getConnectedPartyName(String id) {
		return connectedParty.get(id);
	}
}
