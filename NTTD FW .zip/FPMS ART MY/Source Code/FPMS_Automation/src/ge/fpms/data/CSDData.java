package ge.fpms.data;

public class CSDData {

	private String commencementDate;
	public void setcommencementDate(String commencementDate) {
		this.commencementDate = commencementDate;
	}
	public String getcommencementDate() {
		return commencementDate;
	}
}
