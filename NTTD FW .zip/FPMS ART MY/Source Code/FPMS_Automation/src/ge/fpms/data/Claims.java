package ge.fpms.data;

public class Claims {
	private String caseNumber;
	private String sysDate;
	private static Claims claims;

	private Claims() {

	}

	public static Claims getInstance() {
		if (claims == null) {
			claims = new Claims();
		}
		return claims;
	}

	public void setCaseNumber(String caseNumber) {
		caseNumber = caseNumber.trim().replaceAll(";", "");
		this.caseNumber = caseNumber;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public Boolean isCaseNumberEmpty() {
		String caseNumber = "";
		if (this != null) {
			caseNumber = this.getCaseNumber();
		}
		return caseNumber == null ? true : caseNumber.isEmpty();
	}

	public void setSysDate(String systemDate) {
		this.sysDate = systemDate;
	}

	public String getSysDate() {
		return this.sysDate;
	}

	public Boolean isSysDateEmpty() {
		String systemDate = "";
		if (this != null) {
			systemDate = this.getSysDate();
		}
		return systemDate == null ? true : systemDate.isEmpty();
	}
}
