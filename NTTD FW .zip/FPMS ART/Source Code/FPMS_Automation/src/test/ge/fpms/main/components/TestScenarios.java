package test.ge.fpms.main.components;

import ge.fpms.main.FPMSManager;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.components.Contact;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.SCPClient;
import ch.ethz.ssh2.StreamGobbler;

import com.codoid.products.fillo.Recordset;

import com.nttdata.common.util.ColumnHeader;
import com.nttdata.common.util.ExcelUtility;

import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.core.handler.DataHandler;

public class TestScenarios {
	FPMS_Actions llAction;
	private DashboardHandler dashboard;
	
	public TestScenarios() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	private void searchPolicy(String policyNo) {

		
		try {
			llAction.selectMenuItem("NBD", "Detail Registration");

			llAction.enterValue("web_txt_DetailReg_PolicyNumber", policyNo); 
			
			llAction.clickElement("web_txt_DetailReg_Search");
			/*dashboard
					.setStepDetails(
							"In Data Entry Sharing pool search for policy   "
									+ FPMSManager.getInstance().getPolicyHandler().getPolicy().getPolicyNo(),
							"The policy should be avaialble in Search Results. ",
							"N/A");
			dashboard.writeResults();*/
			llAction.clickElement("web_lnk_PolicyNumber");
			Utils.sleep(5);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void testAddress(Hashtable<String, String> hParams) throws Exception {
		searchPolicy("020862632-1");
		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to
		// the calling function

		llAction.switchtoFrame(1);
		llAction.scrollToElement(llAction.getElement("web_addr_table_proposer"));
		Utils.sleep(3);
		llAction.clickElementJs("web_addr_lnk_proposer");
		
		Contact ov = new Contact();
		ov.addAddress(hParams);

	}

	public void testRead(){
	
		FPMSProperties properties = FPMSProperties.getInstance();
		new DataHandler().qaLoadToHashTable(properties.getTestPlanLocation(),
				"Settings", "Setting", "Value", true);
		String loginQuery = "select TCID,TestScenarioName,TestCaseName from Login where  ExecuteTC='Yes'";
		String querySheetRange = String.valueOf(ColumnHeader.Login.getColumnHeader());
		Recordset testCaseRecordSet;
		try {
			testCaseRecordSet = ExcelUtility.queryExcel(properties.getTestDataFilePath( System.getProperty("Settings.Module")), loginQuery,
					querySheetRange);

			while (testCaseRecordSet.next()) {
				String testScenarioName = testCaseRecordSet.getField("TestScenarioName").trim();
				String testCaseId = testCaseRecordSet.getField("TCID").trim();
				String testCasename =  Utils.formatString(testCaseRecordSet.getField("TestCaseName"));

				
					
//					String testPlanQuery = "select TestScenario,TestDataSheetName,TCInstance from TestPlan where Run='Yes' and TestScenario='" + testScenarioName + 
//							"'";
					String testPlanQuery = "select TestScenario,TestDataSheetName,TCInstance from TestPlan where Run='Yes' and TestScenario='" + testScenarioName + 
							"'";
					Recordset testPlanRecordSet = ExcelUtility.queryExcel(properties.getTestPlanLocation(), testPlanQuery);
					testPlanRecordSet.next();
					String currentTCInstance = testPlanRecordSet.getField("TCInstance");
			System.out.println("TestScenarios.testRead()" + currentTCInstance);
				
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	/*public void testSCP(){
		RemoteConnection con = new RemoteConnection();
		con.openConnection("test", "test", "10.163.32.219");
		try {
			con.changeDirectory("/app/China/DEV/FPMS/General/OPUSPolicy/Input");
			con.getFile("NDOPUSEXT2AM0113.txt", "D:/Suchi");
			con.closeConnection();
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	public static void main(String[] args) {
		try {
			new TestScenarios().SSHClient( "10.163.32.219","","test","test");
		
			//System.out.println("TestScenarios.main()" + Utils.generateNRIC("01/03/1970", false));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void SSHClient(String serverIp,String command, String usernameString,String password) throws IOException{
        System.out.println("inside the ssh function");
       
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        
        String currentTime = sdf.format(cal.getTime());
        currentTime = currentTime.substring(0, currentTime.lastIndexOf(":"));
      
        String month = new SimpleDateFormat("MMM").format(cal.getTime());
        String date = new SimpleDateFormat("d").format(cal.getTime());
        String sshDirectoryName = "/app/China/DEV/FPMS/General/OPUSPolicy/Input/test077";
        try
        {
        	File file =new File("D:\\Suchi\\temp");
        
        	file.mkdir();
        	
            Connection conn = new Connection(serverIp);
            conn.connect();
            boolean isAuthenticated = conn.authenticateWithPassword(usernameString, password);
            if (isAuthenticated == false)
                throw new IOException("Authentication failed.");        
            ch.ethz.ssh2.Session sess = conn.openSession();
            //sess.execCommand("cd /app/China/DEV/FPMS/General/OPUSPolicy/Input/test077 | find . '*.txt' -cmin -4 |  ls -lt | awk '{print $8,$9}'"); //cmin for minutes
            sess.execCommand("cd " + sshDirectoryName + " ;  ls -lt | awk '{print $6,$7,$8,$9}'"); //cmin for minutes
            Utils.sleep(5);
            InputStream stdout = new StreamGobbler(sess.getStdout());
            BufferedReader br = new BufferedReader(new InputStreamReader(stdout));
            System.out.println("the output of the command is");
        	ArrayList<String> list = new ArrayList<String>();
        	String line = br.readLine();
        	
            
            while (true)
            {
            	line = br.readLine();
             
                if (line == null)
                    break;
                else{
                	
                	if(line.contains(month)){
                		String[] temp = line.split(" ");
                		if(temp[1].equals(date)){
                			if(temp[2].compareTo(currentTime)>=0){
                				list.add(sshDirectoryName + "/" + temp[3]);
                				 System.out.println(sshDirectoryName + "/" + temp[3]);
                			}
                		}
                    	
                	}
                	
                }
               
            }
            System.out.println("ExitCode: " + sess.getExitStatus());
       
            SCPClient client = new SCPClient(conn);
            
           client.get( list.toArray(new String[0]), "D:\\Suchi\\temp");
           list = replaceAll("/app/China/DEV/FPMS/General/OPUSPolicy/Input/test","D:\\Suchi\\temp",list);
          //  client.put( list.toArray(new String[0]), "/app/China/DEV/FPMS/General/OPUSPolicy/Output/test");
            sess.close();
            conn.close();
        	//Utils.deleteFiles(new File("D:\\Suchi\\temp"));
        }
        catch (IOException e)
        {
            e.printStackTrace(System.err);

        }
    }
	
	private ArrayList<String> replaceAll ( String inputFolderPath, String tempFolderLocation, ArrayList<String> al){
		ArrayList<String> newList = new ArrayList<String>();
		for(int i=0; i<al.size();i++){
			String temp = al.get(i);
			temp = temp.substring(inputFolderPath.length(),temp.length());
			String s= "D:\\Suchi\\temp" + temp;
			newList.add(s);
		}
		return newList;
	}

}
