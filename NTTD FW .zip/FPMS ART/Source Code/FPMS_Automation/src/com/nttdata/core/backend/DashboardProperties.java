/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nttdata.core.backend;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;

import com.nttdata.common.util.RunStatus;

public class DashboardProperties {
	private final static Logger LOGGER = Logger.getLogger(DashboardProperties.class
			.getName());

	public static int gRunID;

	public static String gsErrorMsg = "";

	public static WebDriver _driverWeb;

	public static RunStatus giLLStatus = RunStatus.INPROGRESS;
		
	//TODO: gProjectName used in writeResults, which is not used	
	public static String gProjectName; 								// dashboardHandler
	public static String gRunName;
	public static String gComponentName;
	public static int gTestSuiteID;
	public static int gTestCasesInstanceID;
	public static int gComponentID;
	public static int gStatusID;
	public static int gBPCStatus;

	public static int gUploadImageFlag = 2;

	// TODO: moveFile method not invoked
	public static String gAssetPath;

	//public static String gTCID;
	public static String gsWarningMsg;

	public static String riskAmount;
}
