package com.nttdata.core;

import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.framework.exceptions.LowLevelException;


import ge.fpms.main.actions.FPMS_Actions;

/************************************************************************************
 * #Description: FindWebElement object by Reflection * #Author: 'Mahammad
 * Rasheed' * #version:'1.0' * #Date of Creation: 02/05/2016
 ************************************************************************************/

public class ObjectIdentifier
{
	WebDriver driver;
	Method findElement=null;
	private LL_Actions ll;
	public ObjectIdentifier(WebDriver driver)
	{

		this.driver = driver;
		ll=new LL_Actions();
	
	}

	private final static Logger LOGGER = Logger.getLogger(ObjectIdentifier.class.getName());

	public WebElement FindObject(String IdentifyBy, String value) throws Exception
	{
		WebElement element = null;
		
		
		try
		{
			Class<?> byClass = Class.forName(By.class.getName());
			Method getMethodby = byClass.getMethod(IdentifyBy, String.class);
			By newId = (By) getMethodby.invoke(IdentifyBy, value);
			Class<?> webDriverClass = Class.forName(this.driver
					.getClass().getName());
			Method findElement = webDriverClass.getMethod("findElement",
					new Class[] { By.class });

			//this.waitUntilElementVisible(newId);

			//below line has been commented to handle the wait for WebElement
			//element = (WebElement) findElement.invoke(this.driver, newId);

			
			
			//ll.waitforPageLoad();
			
			//ll.switchtoDefaultWindow();
			//ll.switchtoFrame(1);
			//ll.executeMethod();
			
			
			//ll.waitUntilLoadingCompletes();
			waitForElementToAppear(newId);
			element=(WebElement) findElement.invoke(driver, newId);
		}
		catch (Exception ex)
		{

			LOGGER.log(Level.SEVERE,"-- Unhandled exception occurred  while identifying element "+ value + "\n" + ex.toString());
		}
		return element;
	}


	protected WebElement waitForElementToAppear(final By newId)
	{
		//to get the time out from test plan settings
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Long.parseLong(System.getProperty("Settings.ImplicitWait")), TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		WebElement element = null;
		try
		{

			element = wait.until(ExpectedConditions.presenceOfElementLocated(newId));
		}
		catch (Exception e)
		{
			throw new LowLevelException(e);
		}

		return element;
	}


	@SuppressWarnings("unchecked")
	public List<WebElement> FindObjects(String IdentifyBy, String value) {
		List<WebElement> element = null;
		try {
			Class<?> byClass = Class.forName(By.class.getName());
			Method getMethodby = byClass.getMethod(IdentifyBy, String.class);
			By newId = (By) getMethodby.invoke(IdentifyBy, value);
			Class<?> webDriverClass = Class.forName(this.driver
					.getClass().getName());
			Method findElement = webDriverClass.getMethod("findElements",
					new Class[] { By.class });
			element = (List<WebElement>) findElement.invoke(this.driver, newId);
		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE,"--Unhandled exception  occured  while identifying element"+ value + "\n" + ex.toString());
		}
		return element;
	}

	@SuppressWarnings("unchecked")
	public List<WebElement> FindObjects(WebElement parent, String IdentifyBy,
			String value) {
		List<WebElement> element = null;
		try {
			Class<?> byClass = Class.forName(By.class.getName());
			Method getMethodby = byClass.getMethod(IdentifyBy, String.class);
			By newId = (By) getMethodby.invoke(IdentifyBy, value);
			Method findElement = parent.getClass().getMethod("findElements",
					new Class[] { By.class });
			element = (List<WebElement>) findElement.invoke(
					this.driver, newId);
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE,"--Unhandled exception  occured  while identifying element"
					+ value + "\n" + ex.toString());
		}
		return element;
	}

	public WebElement FindObject(WebElement parent, String IdentifyBy,
			String value) {
		WebElement element = null;
		try {
			Class<?> byClass = Class.forName(By.class.getName());
			Method getMethodby = byClass.getMethod(IdentifyBy, String.class);
			By newId = (By) getMethodby.invoke(IdentifyBy, value);
			Class<? extends WebElement> parentClass = parent.getClass();
			Method method = parentClass.getMethod("findElement",
					new Class[] { By.class });
			element = (WebElement) method.invoke(parent, newId);
		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE,"--Unhandled exception  occured  while identifying element"
					+ value + "\n" + ex.toString());
		}
		return element;
	}
	// added by shibu need to be reomved once Rasheed fix the findobjects issue
	public List<WebElement> FindWeblements (String xpathString)
	{
		return driver.findElements(By.xpath(xpathString));
	}

	// added by shibu need to be reomved once Rasheed fix the findobjects issue
	

	public WebElement FindObject(String IdentifyBy, String value,String suppressException)
	{
		WebElement element = null;
		try
		{
			Class<?> byClass = Class.forName(By.class.getName());
			Method getMethodby = byClass.getMethod(IdentifyBy, String.class);
			By newId = (By) getMethodby.invoke(IdentifyBy, value);
			Class<?> webDriverClass = Class.forName(this.driver
					.getClass().getName());
			Method findElement = webDriverClass.getMethod("findElement",
					new Class[] { By.class });
		
			LL_Actions ll=new LL_Actions();
		
			element=(WebElement) findElement.invoke(driver, newId);


		}
		catch (Exception ex)
		{

			
		}
		return element;
	}

}
