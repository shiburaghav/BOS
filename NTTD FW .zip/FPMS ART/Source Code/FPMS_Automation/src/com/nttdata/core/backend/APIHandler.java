package com.nttdata.core.backend;

import ge.fpms.main.FPMSProperties;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DataHandler;

/* NAME			: DBMethods
DESCRIPTION		: This class is used to do database operations using Web APIs
METHODS 		: 1. checkIfRunExists
				  2. InsertIntoTestSuite - Send POST request
PROPERTIES 		: None */

public class APIHandler
{

	private final static Logger LOGGER = Logger.getLogger(APIHandler.class.getName());
	public static URL endPoint = null;
	protected static String param = null;
	protected static String reqType = null;
	protected static String wAPIMethodName = null;
	/*
	 * NAME 		: CheckIfRunExists
	 * PURPOSE 		: Checks If the runName is available in the DB. If not, inserts the same
	 * PARAMETERS 	: projectName, runName
	 * RETURN VALUE : sResp (Response from Server)
	 */

	public static int checkIfRunExists() {
		int sResp = 0;
		String runName = System.getProperty("Settings.Run Name");
		try {

			int projectID = getProjectID(System.getProperty("Settings.ProjectName"));
			sResp = getRunID(projectID, runName);

			// Checks for response code . If response code is zero creating new run in
			// database
			if (sResp == 0) {
				sResp = insertIntoRun(projectID, runName);
			}
		}

		catch (Exception ex) {
			LOGGER.log(Level.SEVERE, "Exception occured in CheckIfRunExists \n " + ex.getMessage());
		}
		return sResp;
	}

	/*
	 * NAME : InsertIntoRun PURPOSE : Insert a record for run. PARAMETERS :
	 * projectID, runName RETURN VALUE : sResp (Response from Server)
	 */

	public static int insertIntoRun(int projectID, String runName) throws Exception {
		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		htParam = getAPIParam("InsertIntoRun");

		
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			Timestamp executionDateTime = Utils.getCurrentTimeStamp();
			String[] paramArr = { String.valueOf(projectID), runName, String.valueOf(executionDateTime) };

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
		}
		DashboardProperties.gRunID = Integer.parseInt(sResp);
		DashboardProperties.gRunName = runName;
		return Integer.parseInt(sResp);
	}

	/*
	 * NAME : InsertIntoTestSuite PURPOSE : Insert a record for test suite.
	 * PARAMETERS : runID, testSuiteName, statusID RETURN VALUE : sResp (Response
	 * from Server)
	 */

	public static int insertIntoTestSuite(int runID, String testSuiteName, int statusID) {
		String sResp = null;

		try {
			Hashtable<String, String> htParam = new Hashtable<String, String>();
			sResp = String.valueOf(APIHandler.getTestSuiteID(runID, testSuiteName));

			if (sResp.equals("0")) {

				htParam = getAPIParam("InsertIntoTestSuite");

				
				String reqType = (String) htParam.get("HTTP_Method_Type");
				String param = (String) htParam.get("Parameter");
				String url = (String) htParam.get("Endpoint");
				URL url1 = new URL(url);

				if (reqType.equals("GET")) {

					sResp = SendRequest.sendGetRequest(url1);

				} else {
					// int statusID = 4; //statusID is set to in progress
					Timestamp executionDateTime = Utils.getCurrentTimeStamp();
					String[] paramArr = { String.valueOf(runID), testSuiteName, String.valueOf(statusID),
							String.valueOf(executionDateTime) }; // Set it to in progress
					String parStr =getParamStr(param, paramArr).trim();

					sResp = SendRequest.sendPostRequest(url1, parStr);

				}

			}
			DashboardProperties.gTestSuiteID = Integer.parseInt(sResp);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Failed while executing InsertIntoTestSuite\n error details:\n " + e.getMessage());
		}
		return Integer.parseInt(sResp);
	}

	/*
	 * NAME : InsertIntoTestCase PURPOSE : Insert a record for test case. PARAMETERS
	 * : testSuiteID, testCaseName, statusID RETURN VALUE : sResp (Response from
	 * Server)
	 */

	public static int insertIntoTestCase(String testCaseID,int testSuiteID, String testCaseName, int statusID) throws Exception {
		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		htParam = getAPIParam("InsertIntoTestCase");

		String userName = System.getenv("USERNAME");
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			String[] paramArr = { String.valueOf(testSuiteID), testCaseID,testCaseName, String.valueOf(statusID),userName };

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
		}
		DashboardProperties.gTestCasesInstanceID = Integer.parseInt(sResp);
		return Integer.parseInt(sResp);
	}

	/*
	 * NAME : InsertIntoTestComponents PURPOSE : Insert a record for test
	 * components. PARAMETERS : testCasesInstanceID, testComponentName, statusID
	 * RETURN VALUE : sResp (Response from Server)
	 */

	public static int insertIntoTestComponents(int testCasesInstanceID, String testComponentName, int statusID)
	{
		String sResp = null;
		try
		{
			Hashtable<String, String> htParam = new Hashtable<String, String>();

			htParam = getAPIParam("InsertIntoTestComponents");

			String wAPIMethod = htParam.get("Web_API_Method");
			String reqType = htParam.get("HTTP_Method_Type");
			String param = htParam.get("Parameter");
			String url = htParam.get("Endpoint");
			URL url1 = new URL(url);

			if (reqType.equals("GET")) {

				sResp = SendRequest.sendGetRequest(url1);

			} else {

				String[] paramArr = { String.valueOf(testCasesInstanceID), testComponentName, String.valueOf(statusID) };

				String parStr =getParamStr(param, paramArr).trim();

				sResp = SendRequest.sendPostRequest(url1, parStr);
			}
			DashboardProperties.gComponentID = Integer.parseInt(sResp);
			DashboardProperties.gComponentName = testComponentName;
		}
		catch(Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Exception occcured in insertIntoTestComponents\n Message is :"+ex.getMessage());
		}
		return Integer.parseInt(sResp);
	}

	/*
	 * NAME : InsertIntoTestComponentSteps PURPOSE : Insert a record for test
	 * component steps. PARAMETERS : componentID, stepNo, stepDesc, expectedRes,
	 * actualRes, screenShotPath, statusID RETURN VALUE : sResp (Response from
	 * Server)
	 */

	public static int insertIntoTestComponentSteps(int componentID, int stepNo, String stepDesc, String expectedRes, String actualRes, String screenShotPath, int statusID) throws Exception {

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		htParam = getAPIParam("InsertIntoTestComponentSteps");

		
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			Timestamp executionDateTime = Utils.getCurrentTimeStamp();
			String[] paramArr = { String.valueOf(componentID), String.valueOf(stepNo), stepDesc, expectedRes, actualRes, screenShotPath, String.valueOf(statusID), String.valueOf(executionDateTime) }; // testSuiteID is a
			// global variable
			// set by Selenium
			// script

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
		}
		return Integer.parseInt(sResp);
	}

	/*
	 * NAME : UpdateTestComponent PURPOSE : Update a record for test component.
	 * PARAMETERS : componentID, testComponentName, statusID RETURN VALUE : sResp
	 * (Response from Server)
	 */

	public static String updateTestComponent(int componentID, String testComponentName, int statusID) throws Exception {

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		int countFail = 0;
		int countPass = 0;
		int countWarning = 0;
		int countUndefined = 0;
		// int statusID = 0;

		sResp = String.valueOf(getstatusIDFromCSD(componentID));
		if (sResp.contains(",")) {
			String[] sRespArr = sResp.split(",");
			int arrLen = sRespArr.length;

			for (int i = 0; i < arrLen; i++) {
				switch (Integer.parseInt(sRespArr[i])) {

				case 1:
					countFail = countFail + 1;
					break;
				case 0:
					countPass = countPass + 1;
					break;
				case 3:
					countWarning = countWarning + 1;
					break;

				default:
					countUndefined = countUndefined + 1; // change the status to 6 and exit the Loop

				}
				if (countFail > 0) {
					statusID = 1; // Return Fail
				}
				if ((countFail == 0) && (countWarning > 0)) {
					statusID = 3; // Set Business Component as Warning in case there is no failure and warning
					// exist
				}
				if ((countFail == 0) && (countWarning == 0) && (countUndefined == 0)) {
					statusID = 0; // Set Business Component as PASS in case there is no failure, warning and
					// undefined step exist
				}
				if ((countFail == 0) && (countUndefined > 0)) {
					statusID = 6; // Return undefined
				}
			}
		}

		htParam = getAPIParam("UpdateTestComponent");

		
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			String[] paramArr = { String.valueOf(componentID), testComponentName, String.valueOf(statusID) };

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
		}
		return sResp;
	}

	/*
	 * NAME : UpdateTestCase PURPOSE : Update a record for test case. PARAMETERS :
	 * testCasesInstanceID, testCaseName, statusID RETURN VALUE : sResp (Response
	 * from Server)
	 */

	public static String updateTestCase(int testCasesInstanceID, String testCaseName, int statusID,String duration) throws Exception
	{
		if(DashboardProperties.gTestCasesInstanceID==0)
		{
			return "";
		}

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		int countFail = 0;
		int countPass = 0;
		int countWarning = 0;
		int countUndefined = 0;
		// int statusID = 0;

		sResp = String.valueOf(getstatusIDFromTCD(testCasesInstanceID));
		if (sResp.contains(",")) {
			String[] sRespArr = sResp.split(",");
			int arrLen = sRespArr.length;

			for (int i = 0; i < arrLen; i++) {
				switch (Integer.parseInt(sRespArr[i])) {

				case 1:
					countFail = countFail + 1;
					break;
				case 0:
					countPass = countPass + 1;
					break;
				case 3:
					countWarning = countWarning + 1;
					break;

				default:
					countUndefined = countUndefined + 1; // change the status to 6 and exit the Loop

				}
				if (countFail > 0) {
					statusID = 1; // Return Fail
				}
				if ((countFail == 0) && (countWarning > 0)) {
					statusID = 3; // Set Business Component as Warning in case there is no failure and warning
					// exist
				}
				if ((countFail == 0) && (countWarning == 0) && (countUndefined == 0)) {
					statusID = 0; // Set Business Component as PASS in case there is no failure, warning and
					// undefined step exist
				}
				if ((countFail == 0) && (countUndefined > 0)) {
					statusID = 6; // Return undefined
				}
			}
		}

		htParam = getAPIParam("UpdateTestCase");

		
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			String[] paramArr = { String.valueOf(testCasesInstanceID), testCaseName, String.valueOf(statusID),duration };

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
		}
		DashboardProperties.gTestCasesInstanceID=0;
		return sResp;
	}

	/*
	 * NAME : UpdateTestSuite PURPOSE : Update a record for test suite. PARAMETERS :
	 * testSuiteID, testSuiteName, statusID RETURN VALUE : sResp (Response from
	 * Server)
	 */

	public static String updateTestSuite(int testSuiteID, String testSuiteName, int statusID) throws Exception {

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		int countFail = 0;
		int countPass = 0;
		int countWarning = 0;
		int countUndefined = 0;
		// int statusID = 0;

		sResp = String.valueOf(getstatusIDFromTC(testSuiteID));
		if (sResp.contains(",")) {
			String[] sRespArr = sResp.split(",");
			int arrLen = sRespArr.length;

			for (int i = 0; i < arrLen; i++) {
				switch (Integer.parseInt(sRespArr[i])) {

				case 1:
					countFail = countFail + 1;
					break;
				case 0:
					countPass = countPass + 1;
					break;
				case 3:
					countWarning = countWarning + 1;
					break;

				default:
					countUndefined = countUndefined + 1; // change the status to 6 and exit the Loop

				}
				if (countFail > 0) {
					statusID = 1; // Return Fail
				}
				if ((countFail == 0) && (countWarning > 0)) {
					statusID = 3; // Set Business Component as Warning in case there is no failure and warning
					// exist
				}
				if ((countFail == 0) && (countWarning == 0) && (countUndefined == 0)) {
					statusID = 0; // Set Business Component as PASS in case there is no failure, warning and
					// undefined step exist
				}
				if ((countFail == 0) && (countUndefined > 0)) {
					statusID = 6; // Return undefined
				}
			}
		}

		htParam = getAPIParam("UpdateTestSuite");

		
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			Timestamp executionDateTime = Utils.getCurrentTimeStamp();
			String[] paramArr = { String.valueOf(testSuiteID), testSuiteName, String.valueOf(statusID),
					String.valueOf(executionDateTime) };

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
		}
		return sResp;
	}




	/*
	 * NAME : GetMaxRunID
	 * PURPOSE : Gets runID on passing runName from run table
	 * PARAMETERS: runName
	 * RETURN VALUE : sResp (Response from Server)
	 */

	public static int getRunID(int projectID, String runName) {

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();
		try{

			htParam = getAPIParam("GetRunID");

			
			String reqType = (String) htParam.get("HTTP_Method_Type");
			String param = (String) htParam.get("Parameter");
			String url = (String) htParam.get("Endpoint");
			URL url1 = new URL(url);

			if (reqType.equals("GET")) {

				sResp = SendRequest.sendGetRequest(url1);

			}
			else
			{

				String[] paramArr = {String.valueOf(projectID), runName};

				String parStr =getParamStr(param, paramArr).trim();

				sResp = SendRequest.sendPostRequest(url1, parStr);
			}
			if (sResp.equals("") || sResp.equals(" ") || sResp.equals(null))
			{
				sResp = "0";
			}
		}
		catch(Exception ex)
		{
			//return 0;

		}
		return Integer.parseInt(sResp);
	}

	/*
	 * NAME : GetstatusIDFromCSD PURPOSE : Gets statusID on passing componentID from
	 * componentstepsdetails table PARAMETERS : componentID RETURN VALUE : sResp
	 * (Response from Server)
	 */

	public static String getstatusIDFromCSD(int componentID) throws Exception {

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		htParam = getAPIParam("GetstatusIDFromCSD");

		
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			String[] paramArr = { String.valueOf(componentID) };

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
			sResp = sResp.replace("[", "");
			sResp = sResp.replace("]", "").trim();
		}
		if (sResp.equals("") || sResp.equals(" ") || sResp.equals(null)) {
			sResp = "0";
		}
		return sResp;
	}

	/*
	 * NAME : GetstatusIDFromTCD PURPOSE : Gets statusID on passing testCaseID from
	 * testcomponentsdetails table PARAMETERS : testCaseID RETURN VALUE : sResp
	 * (Response from Server)
	 */

	public static String getstatusIDFromTCD(int testCaseID) throws Exception {

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		htParam = getAPIParam("GetstatusIDFromTCD");

		
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			String[] paramArr = { String.valueOf(testCaseID) };

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
			sResp = sResp.replace("[", "");
			sResp = sResp.replace("]", "").trim();
		}
		if (sResp.equals("") || sResp.equals(" ") || sResp.equals(null)) {
			sResp = "0";
		}
		return sResp;
	}



	/*
	 * NAME : GetstatusIDFromTC
	 * PURPOSE : Gets statusID on passing testSuiteID from testcase table
	 * PARAMETERS : testSuiteID
	 * RETURN VALUE : sResp (Response from Server)
	 */

	public static int getstatusIDFromTC(int testSuiteID) throws Exception {

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		htParam = getAPIParam("GetstatusIDFromTC");

		
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			String[] paramArr = { String.valueOf(testSuiteID) };

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
			sResp = sResp.replace("[", "");
			sResp = sResp.replace("]", "").trim();
		}
		if (sResp.equals("") || sResp.equals(" ") || sResp.equals(null)) {
			sResp = "0";
		}
		return Integer.parseInt(sResp);
	}



	/*
	 * NAME : GetstatusIDFromTC
	 * PURPOSE : Gets statusID on passing testSuiteID from testcase table
	 * PARAMETERS : runID, testSuiteName
	 * RETURN VALUE : sResp(Response from Server)
	 */

	public static int getTestSuiteID(int runID, String testSuiteName) throws Exception {

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();

		htParam = getAPIParam("GetTestSuiteID");

		
		String reqType = (String) htParam.get("HTTP_Method_Type");
		String param = (String) htParam.get("Parameter");
		String url = (String) htParam.get("Endpoint");
		URL url1 = new URL(url);

		if (reqType.equals("GET")) {

			sResp = SendRequest.sendGetRequest(url1);

		} else {

			String[] paramArr = { String.valueOf(runID), testSuiteName };

			String parStr =getParamStr(param, paramArr).trim();

			sResp = SendRequest.sendPostRequest(url1, parStr);
			sResp = sResp.replace("[", "");
			sResp = sResp.replace("]", "").trim();
		}
		if (sResp.equals("") || sResp.equals(" ") || sResp.equals(null)) {
			sResp = "0";
		}
		return Integer.parseInt(sResp);
	}



	/*
	 * NAME : GetProjectID
	 * PURPOSE : Gets Project ID on passing Project Name from projects table
	 * PARAMETERS : projectName
	 * RETURN VALUE : sResp(Response from Server)
	 */

	public static int getProjectID(String projectName) {

		String sResp = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();
		try{

			htParam = getAPIParam("GetProjectID"); // get Project id is returning null due to that Number format exception is throwing.

			
			String reqType = (String) htParam.get("HTTP_Method_Type");
			String param = (String) htParam.get("Parameter");
			String url = (String) htParam.get("Endpoint");
			URL url1 = new URL(url);

			if (reqType.equals("GET")) {

				sResp = SendRequest.sendGetRequest(url1);

			} else {

				String[] paramArr = {projectName};

				String parStr =getParamStr(param, paramArr).trim();

				sResp = SendRequest.sendPostRequest(url1, parStr);
				sResp = sResp.replace("[", "");
				sResp = sResp.replace("]", "").trim();
			}
			if (sResp.equals("") || sResp.equals(" ") || sResp.equals(null)) {
				sResp = "0";
			}
		}
		catch(Exception ex){

		}
		return Integer.parseInt(sResp);
	}




	public static int postFile(int fileType, String filePath)
	{

		String sResp = null;
		String url = null;
		Hashtable<String, String> htParam = new Hashtable<String, String>();
		try{

			htParam = getAPIParam("PostFile");
			if(fileType == 1)											//file type 1 is for PDF and 2 is for Image
			{
				url = (String) htParam.get("Endpoint")+"1";
			}

			if(fileType == 2)
			{
				url = (String) htParam.get("Endpoint")+"2";
			}
			String reqType = (String) htParam.get("HTTP_Method_Type");

			sResp = SendRequest.uploadFile(url, fileType, filePath);

			if (sResp.equals("") || sResp.equals(" ") || sResp.equals(null)) {
				sResp = "0";
			}
		}
		catch(Exception ex)
		{

		}
		return Integer.parseInt(sResp);
	}

	public static boolean checkUrlUp(String url)
	{

		try
		{
			URL pURL1 = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) pURL1.openConnection();
			if(conn.getResponseCode() == HttpURLConnection.HTTP_OK)
			{
				return true;
			}
		}
		catch (Exception e)
		{

		}
		return false;

	}

	/**
	 * getAPIParam - To get Web API method details from API_Mapping.xlsx
	 * @param methodName - (Web API method name)
	 * @return hTableMap
	 * @throws FilloException
	 */
	public static Hashtable<String, String> getAPIParam(String methodName) throws FilloException {

		Hashtable<String, String> hTableMap = new Hashtable<String, String>();
		try {
			DataHandler dataHandler = new DataHandler();
			Recordset recordset = dataHandler.queryExcel(FPMSProperties.getInstance().getAPIMapLocation(), methodName);
			while (recordset.next()) {
				wAPIMethodName = recordset.getField("Web_API_Method");
				reqType = recordset.getField("HTTP_Method_Type");
				try {
					endPoint = new URL(recordset.getField("Endpoint"));
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				param = recordset.getField("Parameter");

				hTableMap.put("Web_API_Method", wAPIMethodName);
				hTableMap.put("HTTP_Method_Type", reqType);
				hTableMap.put("Endpoint", endPoint.toString());
				hTableMap.put("Parameter", param);
			}
		}

		catch (Exception ex) {
			LOGGER.log(Level.SEVERE, "Exception occured in getAPIParam \n " + ex.getMessage());
		}
		return hTableMap;
	}

	public static String getParamStr(String lParam, String [] strArr){

		int parmCount;
		String paramStr = null;

		if(lParam == null || lParam.isEmpty() || lParam.equalsIgnoreCase("N/A") || lParam.equalsIgnoreCase("NA"))
		{
			parmCount = 0;
			paramStr = null;

		}else
		{

			String [] paramArr = lParam.split(",");
			parmCount = paramArr.length;
			//System.out.println(parmCount);
			StringBuilder sbObj = new StringBuilder();

			for(int i=0; i<parmCount; i++){
				//System.out.println("Inside for");
				sbObj.append(paramArr[i]).append("=").append(strArr[i]).append("&");
				paramStr = sbObj.toString();
				//System.out.println(paramStr);
			}
			paramStr = sbObj.deleteCharAt(sbObj.length()-1).toString();
		}
		//System.out.println(paramStr);
		return paramStr;
	}

}

