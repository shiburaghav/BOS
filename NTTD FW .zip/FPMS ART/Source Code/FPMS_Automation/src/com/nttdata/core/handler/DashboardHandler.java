package com.nttdata.core.handler;

import ge.fpms.main.FPMSConstants;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Logger;

import com.nttdata.common.util.AWTScreenshot;
import com.nttdata.common.util.FileUtil;
import com.nttdata.common.util.Utils;
import com.nttdata.core.TestCase;
import com.nttdata.core.backend.APIHandler;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.framework.exceptions.LowLevelException;

public class DashboardHandler{

	private final static  Logger LOGGER = Logger.getLogger(DashboardHandler.class.getName());
	private  TestCase testCase;
	private int stepNo;
	private String assetPath;
	private String gStepDesc;
	private static DashboardHandler handler;
	private  String gsErrorMsg;
	private  final String ASSETS = "Assets" ;
	private  final String SCREENSHOTS = "Screenshots" ;
	private String gExpectedResult;
	private String gTestData;
	private String strScreenShotPath;
	private String  gsWarningMsg;

	private DashboardHandler(){
		
	}
	public static DashboardHandler getInstance(){
		if(handler == null ) {
			handler= new DashboardHandler();	
		}
		return handler;
	}
	

	/*
	 * NAME : createDirStruct PURPOSE : Creates directory structure recursively
	 * PARAMETERS : folderPath RETURN VALUE : None
	 */

	public void createDirStruct(String folderPath) throws Exception {

		try {
			File file = new File(folderPath);
			file.mkdirs();
			if (FileUtil.isFileExists(folderPath)) {
				System.out.println("Folder directory " + folderPath + " is created");
			}
		} catch (Exception ex) {
			throw new Exception("Exception occured while creating folder structure: " + folderPath);
		}
	}


	public  int writeResults() { // Implement Test Data in write results later


		String strScreenShotName = null;
		String strScreenShotPathForDB = null;
		String tcLocalPath = null;
		final int conErrOK = 0;
		final int conErrFail = 1;
		final int conErrWarning = 3;
		int res = 0;
		StringBuilder sb = new StringBuilder();
		
		String gCaptureScrnSht = System.getProperty("Settings.Capture Screen Shot");
		try{

			if(stepNo == 0)
			{
				sb.append(System.getProperty("Settings.ART Downloads"));sb.append(File.separator); sb.append(System.getProperty("Settings.Run Name").trim());sb.append(File.separator);
				sb.append(testCase.getSuiteName());sb.append(File.separator);
				sb.append(testCase.getId());sb.append(FPMSConstants.NAME_SEPERATOR);sb.append(testCase.getName());sb.append(FPMSConstants.NAME_SEPERATOR);sb.append(System.currentTimeMillis());
				tcLocalPath = sb.toString();
				sb.setLength(0);
				strScreenShotPath = tcLocalPath+ File.separator + SCREENSHOTS;
				assetPath = tcLocalPath+ File.separator+ ASSETS;
				createDirStruct(strScreenShotPath);											//This method creates folder structure for screenshots
				createDirStruct(assetPath);
			}
			stepNo = stepNo + 1;  //Added to set the Step no in a sequential order for reporting

			String dashBoardImageName = gStepDesc.replaceAll("[^a-zA-Z0-9_]", "_");
			gStepDesc = gStepDesc.replaceAll("[^a-zA-Z0-9_\\s-.]", "_");

			strScreenShotName = sb.append(DashboardProperties.gComponentID).append("_").append("StepNo_").append(stepNo).append("_").append(dashBoardImageName).append(".jpeg").toString();
			sb.setLength(0);
			strScreenShotPathForDB = sb.append(strScreenShotPath).append(File.separator).append(strScreenShotName).toString();
			String strScreenShotPathForDB1 = null;
			switch (DashboardProperties.gStatusID) {

			case conErrOK:

				try{
					res = APIHandler.insertIntoTestComponentSteps(DashboardProperties.gComponentID, stepNo, gStepDesc, gExpectedResult, "As Expected", strScreenShotPathForDB1, conErrOK);

					if(gCaptureScrnSht.equalsIgnoreCase("always"))
					{
						AWTScreenshot.captureScreenshot(strScreenShotPathForDB);
						APIHandler.postFile(DashboardProperties.gUploadImageFlag, strScreenShotPathForDB);
					}
				}
				catch(Exception Ex){
					System.out.println(res);
				}
			//	DashboardProperties.gBPCStatus = DashboardProperties.gStatusID;
				break;

			case conErrFail:

				try{
					res = APIHandler.insertIntoTestComponentSteps(DashboardProperties.gComponentID, stepNo, gStepDesc, gExpectedResult, "Error: "+gsErrorMsg, strScreenShotPathForDB1, conErrFail);

					if(gCaptureScrnSht.equalsIgnoreCase("on errors") || gCaptureScrnSht.equalsIgnoreCase("always") || gCaptureScrnSht.equalsIgnoreCase("on errors & warnings"))
					{
						AWTScreenshot.captureScreenshot(strScreenShotPathForDB);
						APIHandler.postFile(DashboardProperties.gUploadImageFlag, strScreenShotPathForDB);
					}

				}
				catch(Exception Ex){
					System.out.println(res);
				}
				//DashboardProperties.gBPCStatus = DashboardProperties.gStatusID;
				break;

			case conErrWarning:


				try{
					res = APIHandler.insertIntoTestComponentSteps(DashboardProperties.gComponentID, stepNo, gStepDesc, gExpectedResult, "Warning: "+ gsWarningMsg, strScreenShotPathForDB1, conErrWarning);
					if(gCaptureScrnSht.equalsIgnoreCase("always") || gCaptureScrnSht.equalsIgnoreCase("on errors & warnings"))
					{
						AWTScreenshot.captureScreenshot(strScreenShotPathForDB);
						APIHandler.postFile(DashboardProperties.gUploadImageFlag, strScreenShotPathForDB);
					}
				}
				catch(Exception Ex){
					System.out.println(res);
				}
				//DashboardProperties.gBPCStatus = DashboardProperties.gStatusID;
				break;

			default :


				try{
					res = APIHandler.insertIntoTestComponentSteps(DashboardProperties.gComponentID, stepNo, gStepDesc, gExpectedResult, "Error Message: "+DashboardProperties.gsErrorMsg, strScreenShotPathForDB1, conErrWarning);
					if(gCaptureScrnSht.equalsIgnoreCase("always") || gCaptureScrnSht.equalsIgnoreCase("on errors & warnings"))
					{
						AWTScreenshot.captureScreenshot(strScreenShotPathForDB);
						APIHandler.postFile(DashboardProperties.gUploadImageFlag, strScreenShotPathForDB);
					}
				}
				catch(Exception Ex){
					System.out.println(res);
				}
				DashboardProperties.gBPCStatus = DashboardProperties.gStatusID;
				break;
			}

			DashboardProperties.gStatusID = conErrOK;
		}
		catch(Exception Ex){
		}
		return res;

	}

	public  void setStepDetails(String stepDesc, String expectedResult, String testData) {
		// if(stepDesc.length()>28)
		// stepDesc=stepDesc.substring(0,28);

		gStepDesc = stepDesc;
		gExpectedResult = expectedResult;
		gTestData = testData;
	}

	public void setFailStatus(Exception ex) throws Exception {
		writeErrorMessage(ex.getMessage());//calling the write results here before throw otherwise the actual failure reason is written to dashbaord
		throw ex;
	}
	public void writeErrorMessage(String message) {
		DashboardProperties.gStatusID = 1;
		gsErrorMsg = message;
		writeResults();
	}

	public void setWarningStatus(String warMessage) {
		gStepDesc = warMessage;
		DashboardProperties.gStatusID = 3;
	}

	private  void moveFile(String sourceFileName, String destinationFileName) throws Exception

	{

		InputStream inStream = null;
		OutputStream outStream = null;
		OutputStream outStream1 = null;

		try {
			String originalPath = System.getProperty("user.home");
			originalPath = originalPath + "\\Downloads";
			String alternativePath = System.getProperty("user.home") + "\\Documents\\Downloads";

			File source = new File(originalPath + "\\" + sourceFileName);
			if (!source.exists()) {
				source = new File(alternativePath + "\\" + sourceFileName);
			}
			File destination = new File(DashboardProperties.gAssetPath + "\\" + destinationFileName);
			createDirStruct("C:\\PDFs");
			File destinationForPdfCompare = new File("C:\\PDFs\\" + destinationFileName);
			inStream = new FileInputStream(source);

			outStream = new FileOutputStream(destination);

			byte[] buffer = new byte[5000];

			int length;

			while ((length = inStream.read(buffer)) > 0) {
				outStream.write(buffer, 0, length);
			}

			inStream.close();
			outStream.close();
			Thread.sleep(2000);

			inStream = new FileInputStream(source);
			outStream1 = new FileOutputStream(destinationForPdfCompare);

			byte[] buffer1 = new byte[5000];

			int length1;

			while ((length1 = inStream.read(buffer1)) > 0) {
				outStream1.write(buffer1, 0, length1);
			}

			inStream.close();
			outStream1.close();
			source.delete();
			Thread.sleep(2000);
		}

		catch (Exception e) {
			throw new LowLevelException(
					sourceFileName + "file either does not exist in downloads folder or unable to move pdf file");

		}

	}

	/**
	 * writes the steps to dashboard
	 * 
	 * @param sleepFor
	 *            - sleep for defined seconds before write to dashboard
	 * @param stepDesc
	 *            - step description
	 * @param expectedResult
	 *            - expected result
	 * @param testData
	 *            - test data
	 */
	public void writeToDashboard(int sleepFor, String stepDesc, String expectedResult, String testData) {
		Utils.sleep(sleepFor);
		setStepDetails("Enter first party correspondence details.",
				"The correspondence details are entered.", "N/A");
		writeResults();

	}

	public void initSteps(TestCase tc){
		testCase = tc;
		stepNo = 0;
		gsErrorMsg = "";
		gsWarningMsg ="";
		gStepDesc="";
	}
	
	public void reset(){
		testCase = null;
		stepNo = 0;
		gsErrorMsg = "";
		gsWarningMsg ="";
		gStepDesc="";
	}
	
}
