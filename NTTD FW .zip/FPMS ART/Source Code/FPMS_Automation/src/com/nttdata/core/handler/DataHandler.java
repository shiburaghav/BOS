package com.nttdata.core.handler;

import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.ExcelUtility;

public class DataHandler {
	
	private final static  Logger LOGGER = Logger.getLogger(DataHandler.class.getName());

	public DataHandler(){
		
	}

	public  Hashtable<String, String> qaLoadToHashTable(String  strExcelFilePath,String strExcelSheetName,String strColumn1,String strColumn2, boolean saveToProp)
	{
		Hashtable<String, String> hTable=new Hashtable<String, String>();
		Recordset recordset=null;
		Connection connection=null;
		try
		{
			Fillo fillo=new Fillo();
			connection=fillo.getConnection(strExcelFilePath);
			String strQuery="Select * from " +strExcelSheetName+"";
			recordset=connection.executeQuery(strQuery);

			while(recordset.next())
			{

				String key=recordset.getField(strColumn1);
				String value=recordset.getField(strColumn2);
				hTable.put(key,value);
				// key.replaceAll("\\s+","") //to remove whitespace
				if(saveToProp){
					System.setProperty(strExcelSheetName + "." + key, value);
				}
			}

		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE,String.format("Failed to load file %s to hashTable " ,strExcelFilePath));
			LOGGER.log(Level.SEVERE,"Exception is "+ex.getMessage());
		}
		finally
		{
			recordset.close();
			connection.close();
		}		
		return hTable;

	}

	

	public void qaLoadGUIMap(String  strExcelFilePath,String strExcelSheetName)
	{
		//Hashtable<String, Hashtable<String, String>> hTable=new Hashtable<String, Hashtable<String,String>>();
		
		Recordset recordset=null;
		Connection connection=null;
		try
		{
			Fillo fillo=new Fillo();
			connection=fillo.getConnection(strExcelFilePath);
			String strQuery="Select * from " +strExcelSheetName+"";
			recordset=connection.executeQuery(strQuery);

			while(recordset.next())
			{

				String key=recordset.getField("Object_ID");
				String identfiedBy=recordset.getField("Identfied_By");
				String value=recordset.getField("Value");

				Hashtable<String, String> IdentifyDetails=new Hashtable<String,String>();
				IdentifyDetails.put(identfiedBy,value);
				ARTProperties.guiMap.put(key, IdentifyDetails);
			}

		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE,String.format("Failed to load file %s to hashTable " ,strExcelFilePath));
			LOGGER.log(Level.SEVERE,"Exception is "+ex.getMessage());
		}
		finally
		{
			recordset.close();
			connection.close();
		}
	}
	
	

	public void loadComponentMap(String strExcelFilePath, String strExcelSheetName) {
		// Hashtable<String, Hashtable<String, String>> hTable=new Hashtable<String,
		// Hashtable<String,String>>();

		Recordset recordset = null;
		Connection connection = null;
		try {
			Fillo fillo = new Fillo();
			connection = fillo.getConnection(strExcelFilePath);
			String strQuery = "Select * from " + strExcelSheetName + "";
			recordset = connection.executeQuery(strQuery);

			while (recordset.next()) {
				if(!recordset.getField("LogicalName").equals(""))
				{
					String key = recordset.getField("Object_ID");
					String value = recordset.getField("LogicalName");
					ARTProperties.componentMap.put(key, value);
				}
			}

		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE, String.format("Failed to load file %s to hashTable and create ComponentMap ", strExcelFilePath));
			LOGGER.log(Level.SEVERE, "Exception is " + ex.getMessage());
		} finally {
			recordset.close();
			connection.close();
		}

	}






	/*  Name: getTestData

	Purpose: This function returns the tested from TestData file using Sheet name and Reference ID and Range will set based on the value passed.

	Parameters:   testDataRef,testDataSheetRef,tdfilepath,excelTDRange

	Return Value: returns hashtable<String,string>

	Exception:File not found Exception

	EXAMPLE CALL:   getTestdata("TD_0001","Login","C:\testdat.xlsm",0);

	 */
	public  Hashtable<String, String> getTestData(String testDataSheetRef, String tdfilepath,int excelTDRange, String testCaseId)
	{
		Hashtable<String, String> hTableTD = getTestData(testDataSheetRef,tdfilepath,excelTDRange, testCaseId, "TCID");
		
		return hTableTD;

	}
	public  Hashtable<String, String> getTestData(String sheetName, String dataFilePath,int excelTDRange, String id, String keyAttributeName)
	{
		Hashtable<String, String> hTableTD = new Hashtable<String, String>();
		try {

			String testDataQuery = "Select * from  " + sheetName;// this query is to get the used row and column
			Recordset allrecords = ExcelUtility.queryExcel(dataFilePath, testDataQuery,String.valueOf(excelTDRange));

			testDataQuery = "Select * from  " + sheetName + " where " + keyAttributeName+ "='" + id + "'";

			Recordset testDatarows = ExcelUtility.queryExcel(dataFilePath, testDataQuery,String.valueOf(excelTDRange));
			int size = allrecords.getFieldNames().size();
			for (int i = 0; i < size; i++) {
				testDatarows.next();

				String key = allrecords.getFieldNames().get(i);
				String value = testDatarows.getField(key);
				hTableTD.put(key, value.trim()); //updated on Feb 15 , to handle trailing white spaces 
			}

		} catch (Exception ex) {
			LOGGER.log(Level.SEVERE,"Error occured while reading the test data \n Eror is as follows:\n " + ex.getMessage());
			ex.printStackTrace();
		}

		return hTableTD;
	}
	public  Recordset queryExcel(String filePath, String matchdata)
	{
		String excelQuery = "SELECT * FROM Mapping WHERE DB_Function_Name='"+matchdata+"'";
		//System.out.println(excelQuery);
		Recordset recordset = null;
		Connection connection = null;
		try
		{
			Fillo fillo=new Fillo();
			connection=fillo.getConnection(filePath);
			recordset=connection.executeQuery(excelQuery);

			if(recordset.equals(null))
			{
				LOGGER.log(Level.SEVERE,String.format("Query %s is returned invalid data for excel file location %s",excelQuery,filePath));
			}

			return recordset;

		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE,String.format(" Exception occured while querying the excel using "
					+ "Query {0} is returned invalid data for excel file location {1}",excelQuery,filePath));

		}
		return recordset;
	}
}
