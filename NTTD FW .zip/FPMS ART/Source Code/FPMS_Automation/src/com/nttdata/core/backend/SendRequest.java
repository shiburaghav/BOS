package com.nttdata.core.backend;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Logger;

/* NAME			: SendRequest
   DESCRIPTION	: This class is used to send request to Web APIs
   METHODS 		: 1. sendGetRequest - Send GET request
   				  2. sendPostRequest - Send POST request
   PROPERTIES 	: None */



public class SendRequest {

	/* NAME  		: sendGetRequest
    PURPOSE		: This is used to send request to GET methods of the Web API.
    PARAMETERS	: It takes URL of the Web API as a parameter
    RETURN VALUE: Server Response */
	private final static Logger LOGGER = Logger.getLogger(SendRequest.class.getName());
	public static String sendGetRequest(URL gURL) {

		int respCode = 0;
		String serverResponse = null;

		try {

			HttpURLConnection conn = (HttpURLConnection) gURL.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			respCode = conn.getResponseCode();

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ respCode);
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			System.out.println("Output from Server .... \n");
			while ((serverResponse = br.readLine()) != null) {
				//System.out.println(serverResponse);
				return serverResponse;
			}

			//conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		return serverResponse;
		//return "Failed : HTTP error code : "+ respCode;

	}

	/* NAME  		: sendPostRequest
   PURPOSE		: This is used to send request to POST methods of the Web API.
   PARAMETERS	: It takes URL of the Web API and parameters consumed by the Web API POST method as a parameter
   RETURN VALUE	: None */

	public static String sendPostRequest(URL pURL, String reqPStr)
	{
		int respCode = 0;
		String output = null;

		try {
			reqPStr = reqPStr.trim();
			//URL pURL1 = new URL(pURL + "?" + reqPStr);
			HttpURLConnection conn = (HttpURLConnection) pURL.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			OutputStream os = conn.getOutputStream();
			os.write(reqPStr.getBytes());
			os.flush();
			respCode = conn.getResponseCode();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK)
			{
				throw new RuntimeException("Failed : HTTP error code : "+ respCode);
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			while ((output = br.readLine()) != null)
			{
				return output;
			}

			conn.disconnect();

		}
		catch (Exception e)
		{
			System.out.println("The dashbaord service stopped. The execution results will not be available in Dashbord.Check with technical team to resolve this issue.\n" + 
		    " Additional information :Response Code: "+respCode+"from WebAPI: "+pURL);
			
		}
		return output;
	}



	public static String uploadFile(String url, int fileType, String filePath) {
		int responseCode = 0;
		try
		{

			String charset = "UTF-8";
			//String charset = "ISO-8859-1";
			String param = "value";
			File uploadFile = new File(filePath);
			//File binaryFile = new File("D:\\Abhay\\104_StepNo_0_FLP PDF.bin");
			String boundary = Long.toHexString(System.currentTimeMillis()); // Just generate some unique random value.
			String CRLF = "\r\n"; // Line separator required by multipart/form-data.

			URLConnection connection = new URL(url).openConnection();
			connection.setDoOutput(true);
			connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

			OutputStream output = connection.getOutputStream();
			PrintWriter writer = new PrintWriter(new OutputStreamWriter(output, charset), true);

			// Send normal param.
			writer.append("--" + boundary).append(CRLF);
			writer.append("Content-Disposition: form-data; name=\"param\"").append(CRLF);
			writer.append("Content-Type: text/plain; charset=" + charset).append(CRLF);
			writer.append(CRLF).append(param).append(CRLF).flush();

			// Send  file.
			writer.append("--" + boundary).append(CRLF);
			writer.append("Content-Disposition: form-data; name=\"textFile\"; filename=\"" + uploadFile.getName() + "\"").append(CRLF);

			if(fileType == 1){														//Flag 1 for PDF and 2 for Image file
				writer.append("Content-Type: application/pdf").append(CRLF);
			}
			else{
				writer.append("Content-Type: text/plain; charset=" + charset).append(CRLF);
			}

			writer.append(CRLF).flush();
			Files.copy(uploadFile.toPath(), output);
			output.flush(); // Important before continuing with writer!
			writer.append(CRLF).flush(); // CRLF is important! It indicates end of boundary.

			/*     // Send binary file.
            writer.append("--" + boundary).append(CRLF);
            writer.append("Content-Disposition: form-data; name=\"binaryFile\"; filename=\"" + binaryFile.getName() + "\"").append(CRLF);
            writer.append("Content-Type: " + URLConnection.guessContentTypeFromName(binaryFile.getName())).append(CRLF);
            writer.append("Content-Transfer-Encoding: binary").append(CRLF);
            writer.append(CRLF).flush();
            Files.copy(binaryFile.toPath(), output);
            output.flush(); // Important before continuing with writer!
            writer.append(CRLF).flush(); // CRLF is important! It indicates end of boundary.
			 */

			// End of multipart/form-data.
			writer.append("--" + boundary + "--").append(CRLF).flush();

			// Request is lazily fired whenever you need to obtain information about response.
			responseCode = ((HttpURLConnection) connection).getResponseCode();
			//System.out.println(responseCode);
		}
		catch(Exception ex)
		{
			System.out.print("Exception:"+responseCode);
		}
		return String.valueOf(responseCode);
	}


	public static void createBinaryFile()
	{
		SendRequest binary = new SendRequest();
		byte[] bytes = null;
		try {
			bytes = binary.readSmallBinaryFile(FILE_NAME);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		log("Small - size of file read in:" + bytes.length);
		try {
			binary.writeSmallBinaryFile(bytes, OUTPUT_FILE_NAME);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	final static String FILE_NAME = "D:\\Abhay\\104_StepNo_0_FLP PDF.pdf";
	final static String OUTPUT_FILE_NAME = "D:\\Abhay\\104_StepNo_0_FLP PDF.bin";

	byte[] readSmallBinaryFile(String aFileName) throws IOException {
		Path path = Paths.get(aFileName);
		return Files.readAllBytes(path);
	}

	void writeSmallBinaryFile(byte[] aBytes, String aFileName) throws IOException {
		Path path = Paths.get(aFileName);
		Files.write(path, aBytes); //creates, overwrites
	}

	private static void log(Object aMsg){
		System.out.println(String.valueOf(aMsg));
	}
}


