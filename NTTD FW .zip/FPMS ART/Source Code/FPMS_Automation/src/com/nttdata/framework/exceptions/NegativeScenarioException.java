package com.nttdata.framework.exceptions;

import ge.fpms.main.actions.FPMS_Actions;

public class NegativeScenarioException extends BPCException {


	public NegativeScenarioException(Exception e) 
	{
		
		super(e);
	}
	
}