package com.nttdata.common.util;

import java.security.SecureRandom;

public class RandomString
{

	
   static final String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	static final String numeric = "0123456789";
	static SecureRandom rnd = new SecureRandom();
	
	
	public static void main(String[] args)
	{
		System.out.println(randomNumeric(2));
	}

	public static String  randomString( int len ){
	   StringBuilder sb = new StringBuilder( len );
	   for( int i = 0; i < len; i++ ) 
	      sb.append( AB.charAt( rnd.nextInt(AB.length()) ) );
	   return sb.toString();
	}
	
	public static String randomNumeric( int len ){
		   StringBuilder sb = new StringBuilder( len );
		   for( int i = 0; i < len; i++ ) 
		      sb.append( numeric.charAt( rnd.nextInt(numeric.length()) ) );
		   return sb.toString();
		}
}
