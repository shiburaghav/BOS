package com.nttdata.common.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;



public class UtilsForTesting
{

	public static ArrayList<String> testGetVariableOccurence(String pdfPath, String startText, String endText) throws IOException
	{
		PIPSGenerics pipsObj = new PIPSGenerics();	
		PDDocument pdfDoc = null; 
	    String pdfAllTexts = null; 
	    ArrayList<String> allOccurance = null;
		String pdfFilePath = pdfPath;
		File file = new File(pdfFilePath);      
	    PDFTextStripper pdfStripper = new PDFTextStripper();
	   // pdfStripper.setStartPage(17);
	   // pdfStripper.setEndPage(17);
	    pdfStripper.setSortByPosition(true);
	    pdfDoc = PDDocument.load(file);
	    pdfAllTexts = pdfStripper.getText(pdfDoc); 
	    String lines[] = pdfAllTexts.split("\\r?\\n");
		allOccurance = pipsObj.getAllValuesBetweenStrings(lines, startText, endText);
		return allOccurance;
	}

	

}
