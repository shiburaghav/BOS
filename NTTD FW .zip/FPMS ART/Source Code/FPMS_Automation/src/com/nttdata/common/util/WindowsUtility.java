package com.nttdata.common.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.LowLevelException;

public class WindowsUtility
{

	public static boolean processFound(String processName) throws IOException
	{
		String findProcess = processName;
		String filenameFilter = "/nh /fi \"Imagename eq "+findProcess+"\"";
		String tasksCmd = System.getenv("windir") +"/system32/tasklist.exe "+filenameFilter;

		Process p = Runtime.getRuntime().exec(tasksCmd);
		BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));

		ArrayList<String> procs = new ArrayList<String>();
		String line = null;
		while ((line = input.readLine()) != null)
			procs.add(line);

		input.close();

		//Boolean processFound = procs.stream().filter(row -> row.indexOf(findProcess) > -1).count() > 0;
		//return processFound;
		return false;
	}
	
	public static boolean waitUntillProcessFound(String processName,int maxWait) throws IOException
	{
		for(int i=0;i<=maxWait;i++)
		{
			Utils.sleep(2);
			if(processFound(processName))
			{
				
				return killProcess(processName);
			}
		}
		return false;
	}
	
	public static boolean  killProcess(String processName)
	{
		try {
			Runtime.getRuntime().exec("taskkill /F /IM "+processName+"");
			if(processFound(processName))
			{
			return false;
			}
			else
			{
				return true;
			}
		}
		catch (IOException e)
		{
			
		}
		return false;
	}

	public static void runJarExecutable(String executablePath) throws Exception
	{
		DashboardHandler.getInstance().setStepDetails("Launch SynerGE Application Splash JAR", "SynerGE application should be launched successfully", "N/A");
		try
		{
		if(new File(executablePath).exists())
		{
		Runtime rt = Runtime.getRuntime();
		Process pr = rt.exec("java -jar "+executablePath+"");

		// Wait untill synfirefox.exe
		
		if(!WindowsUtility.waitUntillProcessFound("synfirefox.exe",500))
		{
		 throw new LowLevelException("SynerGE Application Splash JAR failed to launch the application");	
		}
		
		}
		else
		{	
			throw new LowLevelException("SynerGE application executable Splash JAR file not found at location : "+executablePath+"..please check the path in settings in GE_Test_Plan.xls in your SynerGE Temp folder");
		}
		}
		
		catch(Exception ex)
		{
			throw new LowLevelException("Exception occured while running the SynerGE executable");
		}
	}

	

	

	

	public static void sendWindowsKeyStrokeEnter() throws AWTException
	{
		Robot robot=new Robot();
		robot.keyPress(java.awt.event.KeyEvent.VK_ENTER);
	}


	public static void sendWindowsKeyStrokeCtrlS() throws AWTException
	{
		Robot robot=new Robot();
		robot.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
		robot.keyPress(java.awt.event.KeyEvent.VK_S);
		robot.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
		robot.keyRelease(java.awt.event.KeyEvent.VK_S);
		// press Enter

		robot.keyPress(java.awt.event.KeyEvent.VK_ENTER);
		robot.keyRelease(java.awt.event.KeyEvent.VK_ENTER);

	}

	// This will move mouse randomly. to keep machine active.
	public static void keepSystemActive() throws Exception {
		Robot hal = new Robot();
		Random random = new Random();
		int x = random.nextInt() % 640;
		int y = random.nextInt() % 480;
		hal.mouseMove(x, y);

	}

}
