/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nttdata.common.util;

/**
 * 
 * @author Mahammad Rasheed Mundole
 */
public enum RunStatus {
	INPROGRESS(4), WARNING(3), FAIL(1), PASS(0);
	public int value;

	private RunStatus(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
}
