package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class Contact extends BusinessComponent {
	private FPMS_Actions llAction;

	public Contact() {
		llAction = new FPMS_Actions();
	}
	public void addContactInformation(Hashtable<String, String> hParams) throws Exception{
		try {
			llAction.selectTab("Other Contact");
			/*if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				llAction.selectTab("contact");
			}*/
			llAction.waitUntilLoadingCompletes();
			
			if(llAction.isDisplayed("web_lst_HomeCountry", 3)){
				llAction.selectByVisibleText("web_lst_HomeCountry", hParams.get("HomeNoCode"));
	
				llAction.enterValue("web_txt_HomeTelephone", hParams.get("HomeNo"));
			}
			llAction.selectByVisibleText("web_lst_la_TelCode", hParams.get("HandphoneCode"));
			llAction.sendkeyStroke("web_lst_la_TelCode", Keys.ENTER);
			llAction.enterValue("web_txt_la_handNo", hParams.get("HandPhoneNo"));
			llAction.sendkeyStroke("web_txt_la_handNo", Keys.ENTER);
			llAction.clickElement("web_addr_btn_apply");
			llAction.waitUntilLoadingCompletes();
			DashboardHandler.getInstance().writeToDashboard(4, "Enter Other Contact Details.","Mobile and residence numbers are entered.",
					"N/A");

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	public void addAddress(Hashtable<String, String> hParams) throws Exception {
		try {

			// llAction.handleCertificateErrors();
			// llAction.switchtoChildWindow(
			// FPMSConstants.WINDOW_TITLE_CORRESPONDENCE_ADDRESS, "");
			// llAction.maximizeWindow();
		//	llAction.waitUntilElementPresent("web_addr_lst_CountryofAddress");
			llAction.selectByVisibleText("web_addr_lst_CountryofAddress", hParams.get("CountryCode"));
			String contactType = hParams.get("AddrressContactType");
			String addressIndicator = hParams.get("AddressIndicator");
			String addressType = hParams.get("AddressType");
			String contactTypeWidget = "web_addr_lst_contactType";

			if (llAction.isDisplayed(contactTypeWidget, 5)) {
				llAction.selectByVisibleText(contactTypeWidget, contactType);
			}

			llAction.selectByVisibleText("web_addr_lst_addressIndicator", addressIndicator);

			if (addressIndicator.equalsIgnoreCase(FPMSConstants.ADDRESS_INDICATOR_LOCAL)) {

				llAction.selectByVisibleText("web_addr_lst_addressType", addressType);
			}

			if (addressType.equalsIgnoreCase(FPMSConstants.ADDRESS_TYPE_FORMATTED)) {
				llAction.enterValue("web_addr_txt_postalCode", hParams.get("PostalCode"));
				llAction.enterValue("web_addr_lnk_block", hParams.get("AddressBlock"));

			} else {
				llAction.enterValue("web_addr_txt_postalCode2", hParams.get("PostalCode"));
				llAction.enterValue("web_addr_txt_line1", hParams.get("UnformattedAddrLine1"));

			}
			/*
			 * if (contactType .equalsIgnoreCase(FPMSConstants.ADDRESS_TYPE_CORRESPONDENCE)
			 * && hParams.get("SameAddrIndCheckBox").equalsIgnoreCase("Y")) {
			 * 
			 * llAction.checkBox_Check("web_checkBox_SameforResidentialAddress"); }
			 */

			if (hParams.get("SameAddrIndCheckBox").equalsIgnoreCase("Y")) {
				llAction.checkBox_Check("web_addr_checkBox_SameforResidential");
			}

			llAction.clickElement("web_addr_btn_apply");
			llAction.waitUntilLoadingCompletes();
			DashboardHandler.getInstance().writeToDashboard(4, "Enter Contact Details.", addressType + " details are entered.",
					"N/A");

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

}
