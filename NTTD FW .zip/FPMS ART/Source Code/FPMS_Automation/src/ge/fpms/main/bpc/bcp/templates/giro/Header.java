package ge.fpms.main.bpc.bcp.templates.giro;

import java.util.ArrayList;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Header implements IPaymentSection {

	private Type recordType;
	private Type messageType;
	private Type submissionDate;
	private Type batchNumber;
	private Type valueDate;
	private Type originatingBankBICCode;
	private Type originatingAccountNumber;
	private Type originatingAccountCurrency;
	private Type originatingAccountName;

	private Type customerInstructionReference;
	private Type productCode;
	private Type filler1;
	private Type changeBearer;
	private Type sendersID;
	private Type filler2;

	public Header() {
	}

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getMessageType() {
		return messageType;
	}

	public void setMessageType(Type messageType) {
		this.messageType = messageType;
	}

	public Type getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(Type submissionDate) {
		this.submissionDate = submissionDate;
	}

	public Type getBatchNumber() {
		return batchNumber;
	}

	public void setBatchNumber(Type batchNumber) {
		this.batchNumber = batchNumber;
	}

	public Type getValueDate() {
		return valueDate;
	}

	public void setValueDate(Type valueDate) {
		this.valueDate = valueDate;
	}

	public Type getOriginatingBankBICCode() {
		return originatingBankBICCode;
	}

	public void setOriginatingBankBICCode(Type originatingBankBICCode) {
		this.originatingBankBICCode = originatingBankBICCode;
	}

	public Type getOriginatingAccountNumber() {
		return originatingAccountNumber;
	}

	public void setOriginatingAccountNumber(Type originatingAccountNumber) {
		this.originatingAccountNumber = originatingAccountNumber;
	}

	public Type getOriginatingAccountCurrency() {
		return originatingAccountCurrency;
	}

	public void setOriginatingAccountCurrency(Type originatingAccountCurrency) {
		this.originatingAccountCurrency = originatingAccountCurrency;
	}

	public Type getOriginatingAccountName() {
		return originatingAccountName;
	}

	public void setOriginatingAccountName(Type originatingAccountName) {
		this.originatingAccountName = originatingAccountName;
	}

	public Type getCustomerInstructionReference() {
		return customerInstructionReference;
	}

	public void setCustomerInstructionReference(Type customerInstructionReference) {
		this.customerInstructionReference = customerInstructionReference;
	}

	public Type getProductCode() {
		return productCode;
	}

	public void setProductCode(Type productCode) {
		this.productCode = productCode;
	}

	public Type getFiller1() {
		return filler1;
	}

	public void setFiller1(Type filler1) {
		this.filler1 = filler1;
	}

	public Type getChangeBearer() {
		return changeBearer;
	}

	public void setChangeBearer(Type changeBearer) {
		this.changeBearer = changeBearer;
	}

	public Type getSendersID() {
		return sendersID;
	}

	public void setSendersID(Type sendersID) {
		this.sendersID = sendersID;
	}

	public Type getFiller2() {
		return filler2;
	}

	public void setFiller2(Type filler2) {
		this.filler2 = filler2;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(), messageType.getSize(), submissionDate.getSize(), batchNumber.getSize(),
				valueDate.getSize(), originatingBankBICCode.getSize(), originatingAccountNumber.getSize(),
				originatingAccountCurrency.getSize(), originatingAccountName.getSize(),
				customerInstructionReference.getSize(), productCode.getSize(), filler1.getSize(),
				changeBearer.getSize(), sendersID.getSize(), filler2.getSize() };
	}

	public void setParamaters(ArrayList<String> buffer) {

		recordType.setValue(buffer.get(0));
		messageType.setValue(buffer.get(1));
		submissionDate.setValue(buffer.get(2));
		batchNumber.setValue(buffer.get(3));
		valueDate.setValue(buffer.get(4));
		originatingBankBICCode.setValue(buffer.get(5));
		originatingAccountNumber.setValue(buffer.get(6));
		originatingAccountCurrency.setValue(buffer.get(7));
		originatingAccountName.setValue(buffer.get(8));
		customerInstructionReference.setValue(buffer.get(9));
		productCode.setValue(buffer.get(10));
		filler1.setValue(buffer.get(11));
		changeBearer.setValue(buffer.get(12));
		sendersID.setValue(buffer.get(13));
		filler2.setValue(buffer.get(14));
	}

	public String getName() {
		return "0";
	}

	public String toString() {
		String headerText =  new StringBuffer().append(getRecordType().toString()).append(getMessageType().toString())
				.append(getSubmissionDate().toString()).append(getBatchNumber().toString())
				.append(getValueDate().toString()).append(getOriginatingBankBICCode().toString())
				.append(getOriginatingAccountNumber().toString()).append(getOriginatingAccountCurrency().toString())
				.append(getOriginatingAccountName().toString()).append(getCustomerInstructionReference().toString())
				.append(getProductCode().toString()).append(getFiller1().toString())
				.append(getChangeBearer().toString()).append(getSendersID().toString()).append(getFiller2().toString()).toString();
		return headerText;
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}
}
