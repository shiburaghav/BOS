package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.Hashtable;

import ge.fpms.main.IRider;

public class RiderBenefits extends MainBenefits implements IRider{

	public RiderBenefits()  {
		
	}

	@Override
	public void addRider(Hashtable<String, String> hParams, int riderId) throws Exception {
		ILPRider ilpRider=new ILPRider();
		ilpRider.addBenefitsDetails(hParams);
		save();
	}
}
