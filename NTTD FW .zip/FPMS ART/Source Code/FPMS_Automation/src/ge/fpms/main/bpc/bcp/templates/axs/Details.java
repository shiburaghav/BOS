package ge.fpms.main.bpc.bcp.templates.axs;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Details implements IPaymentSection {

	private Type recordType;
	private Type transactionDate;
	private Type transactionReferenceNumber;
	private Type billType;
	private Type policyNumber;
	private Type paidAmount;
	private Type payerName;
	private Type contactNumber;
	private Type filler;
	
	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Type transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Type getTransactionReferenceNumber() {
		return transactionReferenceNumber;
	}

	public void setTransactionReferenceNumber(Type transactionReferenceNumber) {
		this.transactionReferenceNumber = transactionReferenceNumber;
	}

	public Type getBillType() {
		return billType;
	}

	public void setBillType(Type billType) {
		this.billType = billType;
	}

	public Type getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(Type policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Type getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(Type paidAmount) {
		this.paidAmount = paidAmount;
	}

	public Type getPayerName() {
		return payerName;
	}

	public void setPayerName(Type payerName) {
		this.payerName = payerName;
	}

	public Type getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Type contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Type getFiller() {
		return filler;
	}

	public void setFiller(Type filler) {
		this.filler = filler;
	}

	public Details(Type[] type) {
		super();
		this.recordType= new Type(type[0].getSize(), type[0].getDataType(),type[0].getValue(), type[0].getAlignment(),type[0].getPaddingChar());
		this.transactionDate= new Type(type[1].getSize(), type[1].getDataType(),type[1].getValue(), type[1].getAlignment(),type[1].getPaddingChar());
		this.transactionReferenceNumber= new Type(type[2].getSize(), type[2].getDataType(),type[2].getValue(), type[2].getAlignment(),type[2].getPaddingChar());
		this.billType= new Type(type[3].getSize(), type[3].getDataType(),type[3].getValue(), type[3].getAlignment(),type[3].getPaddingChar());
		this.policyNumber= new Type(type[4].getSize(), type[4].getDataType(),type[4].getValue(), type[4].getAlignment(),type[4].getPaddingChar());
		this.paidAmount= new Type(type[5].getSize(), type[5].getDataType(),type[5].getValue(), type[5].getAlignment(),type[5].getPaddingChar());
		this.payerName= new Type(type[6].getSize(), type[6].getDataType(),type[6].getValue(), type[6].getAlignment(),type[6].getPaddingChar());
		this.contactNumber= new Type(type[7].getSize(), type[7].getDataType(),type[7].getValue(), type[7].getAlignment(),type[7].getPaddingChar());
		this.filler= new Type(type[8].getSize(), type[8].getDataType(),type[8].getValue(), type[8].getAlignment(),type[8].getPaddingChar());
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(),
				transactionDate.getSize(),
				transactionReferenceNumber.getSize(),
				billType.getSize(),
				policyNumber.getSize(),
				paidAmount.getSize(),
				payerName.getSize(),
				contactNumber.getSize(),
				filler.getSize()};
	}

	public String getName() {
		return "1";
	}

	public String toString() {
		String details = new StringBuilder().append(getRecordType().toString())
				.append(getTransactionDate().toString())
				.append(getTransactionReferenceNumber().toString())
				.append(getBillType().toString())
				.append(getPolicyNumber().toString())
				.append(getPaidAmount().toString())
				.append(getPayerName().toString())
				.append(getContactNumber().toString())
				.append(getFiller().toString()).toString();
		
		return details;
	}

	public Type[] getAllAttributes() {
		return new Type[] { recordType,
				transactionDate,
				transactionReferenceNumber,
				billType,
				policyNumber,
				paidAmount,
				payerName,
				contactNumber,
				filler	 };
	}
}
