package ge.fpms.main.bpc.bcp;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;

public class FPMSBill {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;

	public FPMSBill() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	public void extractionAmountToBill(Hashtable<String, String> hParams) throws Exception {
		try {
			String policyNumber = StringUtils.EMPTY;
			String extractionDate = hParams.get("Extractiondate");
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			llAction.selectMenuItem("Billing", "extraction amount to bill");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_EB_txt_PolicyNumber");
			llAction.enterValue("web_EB_txt_PolicyNumber", policyNumber);

			llAction.clickElement("web_EB_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Validate if the policy is displayed in Search Results",
					"Policy should be displayed in search results", "");
			dashboard.writeResults();

			int colPos = llAction.GetColumnPositionInTable("web_EB_tbl_SearchResults", "Policy number");
			int rowPos = llAction.GetRowPositionInTable("web_EB_tbl_SearchResults", policyNumber, colPos);
			llAction.SelectRowInTable("web_EB_tbl_SearchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();

			if (StringUtils.isEmpty(extractionDate)) {
				String dueDate = llAction.getAttribute("web_EB_txt_DueDate", "value");
				String[] Date = dueDate.substring(3).split("/");
				extractionDate = Date[0] + Date[1];
			}
			
			llAction.clickElement("web_EB_txt_ExtractionDueDate");
			llAction.enterValue("web_EB_txt_ExtractionDueDate", extractionDate);
			
			dashboard.setStepDetails("Validate if the due date is entered successfully",
					"Due date should be entered successfully", "");
			dashboard.writeResults();
			
			llAction.clickElement("web_EB_btn_SubmitExtraction");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Validate if the extraction method is a success",
					"Extracted method status should be a success", "");

			if (llAction.getText("web_EB_lbl_ExtractionStatusMessage").equalsIgnoreCase("Extraction succeeded!")) {
				dashboard.writeResults();
				llAction.clickElement("web_EB_btn_ExtractionBack");
				llAction.clickElement("web_EB_btn_ExtractionExit");
			} else {
				dashboard.writeResults();
				dashboard.setFailStatus(new BPCException("extraction method is not a success"));
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void performManualExtraction(Hashtable<String, String> hParams) throws Exception {
		try {
			String policyNumber = StringUtils.EMPTY;
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			llAction.selectMenuItem("Billing", "perform manual extraction");
			llAction.waitUntilLoadingCompletes();

			llAction.selectByVisibleText("web_PME_lst_PaymentMethod", hParams.get("PaymentMethod"));
			llAction.clickElement("web_PME_txt_PolicyNumber");
			llAction.enterValue("web_PME_txt_PolicyNumber", policyNumber);
			llAction.clickElement("web_PME_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Validate if the policy is displayed in Search Results",
					"Policy should be displayed in search results", "");
			dashboard.writeResults();
			
			int colPos = llAction.GetColumnPositionInTable("web_PME_tbl_SearchResults", "Proposal/Policy Number");
			int rowPos = llAction.GetRowPositionInTable("web_PME_tbl_SearchResults", policyNumber, colPos);
			llAction.SelectRowInTable("web_PME_tbl_SearchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();

			llAction.clickElement("web_PME_txt_amountForceBilling");
			llAction.enterValue("web_PME_txt_amountForceBilling", hParams.get("ForceBillingAmount"));
			llAction.clickElement("web_PME_txt_addAmountForceBilling");
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Validate if the mentioned amount is added in force billing",
					"Amount is added must be added in force billing", "");
			dashboard.writeResults();
			
			llAction.clickElement("web_PME_btn_SubmitManualExtraction");
			llAction.waitUntilAlertisShown();
			String alertText = llAction.getAlertText();
			if (alertText.equalsIgnoreCase("Successfully!")) {
				llAction.acceptAlert();
			} else {
				dashboard.setFailStatus(new BPCException("Extraction amount not added successfully"));
			}

			colPos = llAction.GetColumnPositionInTable("web_PME_tbl_DeductionRecords", "Amount");
			List<String> alldeductableAmounts = llAction.GetAllTextUnderColumnInTable("web_PME_tbl_DeductionRecords",
					colPos);
			dashboard.setStepDetails("Validate if newly added amount is found in deductable tables",
					"Newly added amount should be displayed", "");
			if (alldeductableAmounts.contains(hParams.get("ForceBillingAmount"))) {
				dashboard.writeResults();
				llAction.clickElement("web_PME_btn_ExitExtraction");
			} else {
				dashboard.writeResults();
				dashboard.setFailStatus(new BPCException("Extraction amount not added successfully"));
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void manuallySuspendOrUnsuspendExtraction(Hashtable<String, String> hParams) throws Exception {
		try {
			String policyNumber = StringUtils.EMPTY;
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			llAction.selectMenuItem("Billing", "manually suspend and unsuspend extraction");
			llAction.waitUntilLoadingCompletes();

			llAction.selectByVisibleText("web_MS_lst_PaymentMethod", hParams.get("Suspend_PaymentMethod"));
			llAction.clickElement("web_MS_txt_PolicyNumber");
			llAction.enterValue("web_MS_txt_PolicyNumber", policyNumber);
			llAction.clickElement("web_MS_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Validate if the policy is displayed in Search Results",
					"Policy should be displayed in search results", "");
			dashboard.writeResults();

			int colPos = llAction.GetColumnPositionInTable("web_MS_tbl_SearchResults", "Policy Number");
			int rowPos = llAction.GetRowPositionInTable("web_MS_tbl_SearchResults", policyNumber, colPos);
			llAction.SelectRowInTable("web_MS_tbl_SearchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();

			int colEffectiveFromDate = llAction.GetColumnPositionInTable("web_MS_tbl_SuspendDetails",
					"Effective from date");
			int colEffectiveToDate = llAction.GetColumnPositionInTable("web_MS_tbl_SuspendDetails",
					"Effective to date");
			int colCollectionType = llAction.GetColumnPositionInTable("web_MS_tbl_SuspendDetails", "Collection type");
			int colRemarks = llAction.GetColumnPositionInTable("web_MS_tbl_SuspendDetails", "Remarks");
			List<String> collectionTypes = Arrays.asList(hParams.get("CollectionType").split("\\s*,\\s*"));
			
			for (String collectionType : collectionTypes) {
				rowPos = llAction.GetRowPositionInTable("web_MS_tbl_SuspendDetails", collectionType, colCollectionType);
				
				if(hParams.get("Action").trim().toUpperCase().equals("SUSPEND")) {
					llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colEffectiveFromDate,
							hParams.get("EffectiveFromDate"), "/input");
					llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colEffectiveToDate,
							hParams.get("EffectiveToDate"), "/input");
					llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colRemarks, hParams.get("Remarks"),
							"/textarea");
				}else if(hParams.get("Action").trim().toUpperCase().equals("UNSUSPEND")){
					llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colEffectiveFromDate,
							"", "/input");
					llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colEffectiveToDate,
							"", "/input");
					llAction.enterTextInTable("web_MS_tbl_SuspendDetails", rowPos, colRemarks, hParams.get("Remarks"),
							"/textarea");
				}
			}
			
			llAction.clickElement("web_MS_btn_SubmitManuallySuspendExtraction");
			dashboard.setStepDetails("Validate if the payment method is suspended or unsuspended successfully",
					"payment method should be suspended or unsuspended successfully", "");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_EB_btn_ExtractionExit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
