package ge.fpms.main.bpc.bcp.templates.creditcard;

import java.util.ArrayList;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class FileHeader implements IPaymentSection {

	private Type recordType;
	private Type companyCode;
	private Type headerDate;
	private Type sequenceNumber;

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(Type companyCode) {
		this.companyCode = companyCode;
	}

	public Type getHeaderDate() {
		return headerDate;
	}

	public void setHeaderDate(Type headerDate) {
		this.headerDate = headerDate;
	}

	public Type getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Type sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(), companyCode.getSize(), headerDate.getSize(),
				sequenceNumber.getSize() };
	}

	public void setParamaters(ArrayList<String> buffer) {
		recordType.setValue(buffer.get(0));
		companyCode.setValue(buffer.get(1));
		headerDate.setValue(buffer.get(2));
		sequenceNumber.setValue(buffer.get(3));
	}

	public String getName() {
		return "FH";
	}

	public String toString() {
		String headerText = new StringBuffer().append(recordType.toString())
				.append(companyCode.toString())
				.append(headerDate.toString())
				.append(sequenceNumber.toString()).toString();
		System.out.println("Header.toString() header: " + headerText);
		return headerText;
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}
}
