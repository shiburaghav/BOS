package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;
import java.util.Set;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.Keys;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;

public class PolicyManagement {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	public PolicyManagement() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void reverseInforce(Hashtable<String, String> hParams) throws Exception {		
		try {
			String policyNumber = hParams.get("PolicyNo");
			String policyStatus="\"Waiting For Data Entry\"";					
			llAction = new FPMS_Actions();
			llAction.selectMenuItem("NBD", "Reverse Inforce");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_PolicyNo", hParams.get("PolicyNo"));
			dashboard.setStepDetails("Enter Policy number","Policy Number '" + policyNumber +"' is entered","N/A");
			dashboard.writeResults();									
			llAction.clickElement("web_Btn_Submit_Party");
			llAction.waitUntilLoadingCompletes();			
		    if (llAction.isDisplayed("web_btn_continue",5)) {
				/*if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
					String getWarningMsg = llAction.getText("web_txt_ErrorWarning").trim();*/						
					llAction.clickElement("web_btn_continue");
					llAction.waitUntilLoadingCompletes();
				/*}
				else
				{
					llAction.clickElement("web_btn_ContinueRP");
				}*/
			}
			llAction.clickElement("web_Btn_Submit_Party");
			llAction.waitUntilLoadingCompletes();
			String expectedPolicyStatus = llAction.getText("web_txt_reversePolicyStatus");
			if(llAction.getText("web_txt_reversePolicyStatus").contains(policyStatus)){
				dashboard.setStepDetails("Verify the Reverse Inforce Status of policy in Change Policy Status screen","The ReverseInforce Status of policy should be '" +policyStatus +"'","N/A");
				dashboard.writeResults();
			}else{	
			dashboard.setFailStatus(new BPCException("The ReverseInforce Status of policy has failed"));
			dashboard.setStepDetails("Verify the Reverse Inforce Status of policy in Change Policy Status screen","The ReverseInforce Status of policy has failed. Expected '" +policyStatus +"' and actual:'" + expectedPolicyStatus + "'","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_return");
			llAction.waitUntilLoadingCompletes();
		}
			
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	public void despatchAndAcknowledgement(Hashtable<String, String> hParams) throws Exception {
		
		try {
			String policyNumber = hParams.get("PolicyNo");
			String serviceBranchRecievedDate = hParams.get("ServiceBranchReceivedDate");
			String dcRepCollectionDate = hParams.get("DCRepCollectionDate");
			String acknowledgementDate = hParams.get("AcknowledgementDate");
			String despatchAndAcknowledgementType = hParams.get("DespatchAndAcknowledgementType");					
			
			llAction.selectMenuItem("NBD", "Despatch Policy Acknowledgement", "Individual");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_dm_txt_DMSPolicyNo", hParams.get("PolicyNo"));//Enter Policy number
			dashboard.setStepDetails("Enter Policy number","Policy Number '" + policyNumber +"' is entered","N/A");
			dashboard.writeResults();									
			llAction.clickElement("web_Btn_Submit_Party");
			llAction.waitUntilLoadingCompletes();				
			llAction.enterValue("web_txt_UpdtPolicyAcknwldgmnt_Svc_brnch_rcvd_dt", serviceBranchRecievedDate);
			dashboard.setStepDetails("Fill in Service Branch Receive Date",serviceBranchRecievedDate +"' is entered","N/A");
			dashboard.writeResults();	
			llAction.enterValue("web_txt_UpdtPolicyAcknwldgmnt_dc_rep_coll_dt", dcRepCollectionDate);
			dashboard.setStepDetails("Fill in DC Rep Collection Date",dcRepCollectionDate +"' is entered","N/A");
			dashboard.writeResults();	
			llAction.enterValue("web_txt_UpdtPolicyAcknwldgmnt_ack_dt", acknowledgementDate);	
			dashboard.setStepDetails("Fill in Acknowledgement Date", acknowledgementDate +"' is entered","N/A");
			dashboard.writeResults();	
			llAction.clickElement("web_txt_UpdtPolicyAcknwldgmnt_ack_dt");	
			if (llAction.isDisplayed("web_btn_continue",5)) {
				if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
					String getWarningMsg = llAction.getText("web_txt_ErrorWarning").trim();						
					llAction.clickElement("web_btn_continue");
				}
				else
				{
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_Btn_Submit_Party");
			dashboard.setStepDetails("Click on Submit button", "System should back to Select Proposal screen.","N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
						
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}
	

	public void reprintPolicy(Hashtable<String, String> hParams){
		
		try {
			  
			llAction.selectMenuItem("NBD", "Policy Document", "Re-generate");
			llAction.waitUntilLoadingCompletes();
			llAction.addToCookies("current_module_id", "300964");
			llAction.enterValue("web_txt_reprint_policyNo2", hParams.get("PolicyNo"));
			llAction.sendkeyStroke("web_txt_reprint_policyNo2", Keys.ENTER);
			llAction.clickElement("web_btn_reprint_search");
			llAction.waitUntilLoadingCompletes();
			if(llAction.isDisplayed("web_coln_no_rec_found")){
				dashboard.setFailStatus(new BPCException("Reprint policy failed! No record found with the policy no provided."));
			}else{
				dashboard.setStepDetails("Click on Search button", "Policy information table is updated.","N/A");
				dashboard.writeResults();
				
				llAction.clickElement("web_btn_reprint_submit");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Click on Submit button", "Policy is reprint submitted successfully.","N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_reprint_return");
				llAction.waitUntilLoadingCompletes();
				llAction.deleteFromCookies(new Cookie("current_module_id","300964"));
			}
			
		} catch (Exception e) {
			throw new BPCException(e);
		}
		
	}
}
