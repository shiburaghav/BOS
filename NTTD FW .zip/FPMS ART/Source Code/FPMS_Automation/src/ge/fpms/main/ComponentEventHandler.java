package ge.fpms.main;

import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class ComponentEventHandler implements WebDriverEventListener {

	private String errorMessage;

	private String fieldName;
	FPMS_Actions llAction;
	private DashboardHandler dashboard;

	private String currentContext;
	//private boolean validateWarningMessage;

	public ComponentEventHandler() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public void setCurrentContext(String cxt) {
		currentContext = cxt;
	}
	/*	while (isAlertPresent(wait)) {
		System.out.println("LL_Actions.handleMultipleAlerts()");
		dashboard.setStepDetails("Alert message is found", "Alert message is captured", "N/A");
		dashboard.writeResults();
		driver.switchTo().alert().accept();*/

	private void validateClickEvent() throws Exception {
		boolean isValid = false;
		if (!errorMessage.equals("")) {
			if(currentContext!=null && currentContext.equalsIgnoreCase(fieldName)) {
				while (llAction.isAlertDisplayed((long)2)) {
					isValid=validateDialogue();
					if(isValid)
						break;
				}
				System.out.println("ComponentEventHandler.validateClickEvent()");
				if(!isValid) {
					llAction.waitUntilLoadingCompletes();
					isValid = CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", errorMessage);
				}
				//}
				System.out.println("ComponentEventHandler.validateClickEvent() isValid : " + isValid);
				if (isValid) {
					//Utils.sleep(10);
					throw new BPCException(BPCException.NEGATIVE_SCENARIO_MESSAGE);

				}else {
					dashboard.setFailStatus(new BPCException("No errormessage "+errorMessage+" is found"));
				}
			}
		}

	}
	private void validateAlerts() throws Exception {
		boolean isValid = false;

		if (!errorMessage.equals("")) {
			if(currentContext!=null && currentContext.equalsIgnoreCase(fieldName)) {
				if (llAction.isAlertDisplayed((long)5)) {
					isValid=validateDialogue();
				}

			}
			System.out.println("ComponentEventHandler.validateAlerts() isValid : " + isValid);
			if (isValid) {

				//llAction.handleMultipleAlerts((long)2);
				throw new BPCException(BPCException.NEGATIVE_SCENARIO_MESSAGE);

			}
		}
	}

	private boolean validateDialogue() throws Exception {
		boolean isValid = false;
		String alertText = llAction.getDialogueText();
		if (alertText.contains(errorMessage)) {
			dashboard.setStepDetails("Alert Text:"+alertText+" contains required Error message"+errorMessage,
					"Expected error message"+errorMessage+" is displayed", "N/A");
			dashboard.writeResults();

			isValid = true;
		}else {
			llAction.acceptAlertDialogs();
		}
		return isValid;
	}

	@Override
	public void afterAlertAccept(WebDriver arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterAlertDismiss(WebDriver arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterChangeValueOf(WebElement arg0, WebDriver arg1, CharSequence[] arg2) {
		// TODO Auto-generated method stub
	
		try {
			validateAlerts();
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	@Override
	public void afterClickOn(WebElement arg0, WebDriver arg1) {
		// TODO Auto-generated method stub
	
		try {
			validateClickEvent();
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	@Override
	public void afterFindBy(By arg0, WebElement arg1, WebDriver arg2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterNavigateBack(WebDriver arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterNavigateForward(WebDriver arg0) {
		// TODO Auto-generated method stub
	
	}

	@Override
	public void afterNavigateRefresh(WebDriver arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterNavigateTo(String arg0, WebDriver arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterScript(String arg0, WebDriver arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void beforeAlertAccept(WebDriver arg0) {
		// TODO Auto-generated method stub

	
	}

	@Override
	public void beforeAlertDismiss(WebDriver arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void beforeChangeValueOf(WebElement arg0, WebDriver arg1, CharSequence[] arg2) {
		// TODO Auto-generated method stub
	
		try {
			validateAlerts();
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	@Override
	public void beforeClickOn(WebElement arg0, WebDriver arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void beforeFindBy(By arg0, WebElement arg1, WebDriver arg2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void beforeNavigateBack(WebDriver arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void beforeNavigateForward(WebDriver arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void beforeNavigateRefresh(WebDriver arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void beforeNavigateTo(String arg0, WebDriver arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void beforeScript(String arg0, WebDriver arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onException(Throwable arg0, WebDriver arg1) {
		// TODO Auto-generated method stub
	

		if(arg0 instanceof UnhandledAlertException) {
			
			try {
				validateAlerts();
			} catch (Exception e) {
				throw new BPCException(e);
			}
		}
	}
}
