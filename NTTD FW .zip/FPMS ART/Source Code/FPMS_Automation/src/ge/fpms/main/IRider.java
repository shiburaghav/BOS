package ge.fpms.main;

import java.util.Hashtable;

public interface IRider {

	public void addRider(Hashtable<String, String> hParams, int riderId) throws Exception;
}
