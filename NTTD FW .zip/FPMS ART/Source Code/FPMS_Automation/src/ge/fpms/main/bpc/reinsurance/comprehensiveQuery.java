package ge.fpms.main.bpc.reinsurance;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.Iterator;

import org.apache.commons.lang3.StringUtils;
import org.omg.CORBA.PolicyHolder;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.data.*;

public class comprehensiveQuery {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;

	public comprehensiveQuery() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	public void getPolicyDetails(Hashtable<String, String> hParams) {
		try {
			navigateToQueryByPolicy(hParams);
			String policyNo = StringUtils.EMPTY;
			policyNo = llAction.getAttribute("web_CS_txt_PD_policyNumber", "value");

			int rowCount = llAction.getRowCountInTable("web_cs_table_RiPolicyProduct");
			int colRIStatusPos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "RI Status");
			int colRiskTypePos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "Risk Type");
			int colRIDuedatePos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "RI Due Date");
			int colProductCodePos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "Product Code");
			int colSumAssuredPos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "Sum Assured");

			for (int i = 2; i <= rowCount; i++) {
				String riStatus = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colRIStatusPos);
				String productCode = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colProductCodePos);
				String riskType = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colRiskTypePos);
				String riDueDate = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colRIDuedatePos);
				String riSumAssured = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colSumAssuredPos);
				policyHandler.setQueryRIByPolicyData(riStatus, productCode, riskType, riDueDate, policyNo,
						riSumAssured);
			}

			llAction.clickElement("web_btn_attributeValueExit");

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void getContractDetails(Hashtable<String, String> hParams) {
		try {
			navigateToQueryByContract(hParams);
			String policyNo = llAction.getAttribute("web_CS_txt_policyNumber", "value");
			int colProductCodePos = llAction.GetColumnPositionInTable("web_cr_table_RiContractSearch", "Product Code");

			List<String> allProductCodes = llAction.GetAllTextUnderColumnInTable("web_cr_table_RiContractSearch",
					colProductCodePos);
			List<String> distinctProductCodes = new ArrayList<String>();
			List<Integer> contractIDAll = new ArrayList<Integer>();
			Hashtable<String, String> contractID = new Hashtable<String, String>();

			for (String str : allProductCodes) {
				if (!distinctProductCodes.contains(str)) {
					distinctProductCodes.add(str);
				}
			}

			for (String str : distinctProductCodes) {
				Utils.editXpath("web_cr_table_RiContractPolicy", "web_cr_table_" + str + "", new String[] { str });
				for (WebElement ele : llAction.findElements("web_cr_table_" + str + "")) {
					contractIDAll.add(Integer.parseInt(ele.getText()));
				}
				contractIDAll.sort(Collections.reverseOrder());
				contractID.put(str, contractIDAll.get(0).toString());
			}

			Set<String> keys = contractID.keySet();
			Iterator<String> itr = keys.iterator();
			while (itr.hasNext()) {
				String thisKey = itr.next();
				Utils.editXpath("web_cr_table_RiContactIDRowData", "web_cr_table_RiContactIDRowData" + thisKey + "",
						new String[] { thisKey, contractID.get(thisKey) });
				List<WebElement> elements = llAction.findElements("web_cr_table_RiContactIDRowData" + thisKey + "");
				policyHandler.setrIQueriByContractData(elements.get(0).getText(), elements.get(3).getText(),
						elements.get(4).getText(), elements.get(6).getText(), policyNo);
				dashboard.writeResults();
			}
			llAction.clickElement("web_btn_attributeValueExit");
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void navigateToQueryByPolicy(Hashtable<String, String> hParams) {
		try {
			String policyNumber = StringUtils.EMPTY;
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNumber");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			
			policyHandler.getPolicy().setPolicyNo(hParams.get("PolicyNumber"));

			llAction.selectMenuItem("Query", "by policy");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_CS_txt_policyNumber");
			llAction.enterValue("web_CS_txt_policyNumber", policyNumber);
			llAction.clickElement("web_btn_attributeValueSearch");
			llAction.waitUntilLoadingCompletes();

			String policyNo = llAction.getAttribute("web_CS_txt_policyNumber", "value");
			Utils.editXpath("web_link_policyID", "web_link_" + policyNumber + "", new String[] { policyNo });
			llAction.clickElementJs("web_link_" + policyNumber + "");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void navigateToQueryByContract(Hashtable<String, String> hParams) {
		try {
			String policyNumber = StringUtils.EMPTY;
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNumber");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			llAction.selectMenuItem("Query", "by contract");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_CS_txt_policyNumber");
			llAction.enterValue("web_CS_txt_policyNumber", policyNumber);
			llAction.clickElement("web_btn_attributeValueSearch");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validatePolicyDetails(Hashtable<String, String> hParams) {
		try {
			navigateToQueryByPolicy(hParams);
			String policyNo = StringUtils.EMPTY;
			policyNo = llAction.getAttribute("web_CS_txt_PD_policyNumber", "value");
			List<RIQueriByPolicyData> beforeBatchData = policyHandler.getListRIQueriByPolicyData();
			String[] expectedRIStatus = hParams.get("RIStatus").split(",");
			String[] expectedSumAssured = hParams.get("ExpectedSumAssured").split(";");

			int rowCount = llAction.getRowCountInTable("web_cs_table_RiPolicyProduct");
			int colRIStatusPos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "RI Status");
			int colRiskTypePos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "Risk Type");
			int colRIDuedatePos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "RI Due Date");
			int colProductCodePos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "Product Code");
			int colSumAssuredPos = llAction.GetColumnPositionInTable("web_cs_table_RiPolicyProduct", "Sum Assured");

			for (int i = 2; i <= rowCount; i++) {
				if (!beforeBatchData.get(i - 2).getRIPolicyNumber().equalsIgnoreCase(policyNo)) {
					dashboard.setFailStatus(new BPCException(
							"Policy Number before batch: " + beforeBatchData.get(i - 2).getRIPolicyNumber()
									+ "Policy Number after batch: " + policyNo));
				} 
				
				String actuaRIStatus = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colRIStatusPos);
				if (!actuaRIStatus.trim().equalsIgnoreCase(expectedRIStatus[i - 2])) {
					dashboard.setFailStatus(new BPCException("Expected RI Status after batch  "
							+ expectedRIStatus[i - 2] + "RI Status after batch  " + actuaRIStatus));
				} 
				
				String productCode = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colProductCodePos);
				if (!beforeBatchData.get(i - 2).getProductCode().equalsIgnoreCase(productCode)) {
					dashboard.setFailStatus(
							new BPCException("Product Code before batch  " + beforeBatchData.get(i - 2).getProductCode()
									+ "Product Code after batch  " + productCode));
				} 
				
				String riskType = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colRiskTypePos);
				if (!beforeBatchData.get(i - 2).getRiskType().equalsIgnoreCase(riskType)) {
					dashboard.setFailStatus(new BPCException("Risk Type before batch  "
							+ beforeBatchData.get(i - 2).getRiskType() + "Risk Type after batch  " + riskType));
				} 
				
				String riDueDate = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colRIDuedatePos);
				Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(beforeBatchData.get(i - 2).getRIDueDate());
				Date date2 = new SimpleDateFormat("dd/MM/yyyy").parse(riDueDate);

				if (date2.compareTo(date1) > 0) {
					if(StringUtils.isEmpty(hParams.get("ExpectedSumAssured"))){
						dashboard.setStepDetails("Validate Policy Number, RI Status, Product Code, Risk Type and Due Date",
								"Success", "");
						dashboard.writeResults();
					}
				} else if (date2.compareTo(date1) < 0 && expectedRIStatus[i - 2].equalsIgnoreCase("valid")){
					dashboard.setFailStatus(new BPCException("RI Due Date before batch is less than RI DUe Date after Batch"));
				}else if (date2.compareTo(date1) == 0 && expectedRIStatus[i - 2].equalsIgnoreCase("valid")){
					dashboard.setFailStatus(new BPCException("RI Due Date before batch is same as RI DUe Date after Batch"));
				}
				
				
				
				if(!StringUtils.isEmpty(hParams.get("ExpectedSumAssured"))) {
					String riSumAssured = llAction.GetTextFromTable("web_cs_table_RiPolicyProduct", i, colSumAssuredPos);
					if (!riSumAssured.trim().equals(expectedSumAssured[i-2].trim())) {
						dashboard.setFailStatus(
								new BPCException("Expected Sum Assured " + expectedSumAssured[i-2].trim()
										+ "Sum Assured after batch   " + riSumAssured));
					} else {
						dashboard.setStepDetails("Validate Policy Number, RI Status, Product Code, Risk Type, Sum Assured and Due Date",
								"Success", "");
						dashboard.writeResults();
					}
				}
			}
			llAction.clickElement("web_btn_attributeValueExit");
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateContractDetails(Hashtable<String, String> hParams) {
		try {
			List<RIQueriByContractData> beforeBatchData = policyHandler.getListRIQueriByContractData();
			navigateToQueryByContract(hParams);
			String policyNo = llAction.getAttribute("web_CS_txt_policyNumber", "value");
			String[] expectedContractStatus = hParams.get("ContractStatus").split(",");
			int colProductCodePos = llAction.GetColumnPositionInTable("web_cr_table_RiContractSearch", "Product Code");

			List<String> allProductCodes = llAction.GetAllTextUnderColumnInTable("web_cr_table_RiContractSearch",
					colProductCodePos);
			List<String> distinctProductCodes = new ArrayList<String>();
			List<Integer> contractIDAll = new ArrayList<Integer>();
			Hashtable<String, String> contractID = new Hashtable<String, String>();

			for (String str : allProductCodes) {
				if (!distinctProductCodes.contains(str)) {
					distinctProductCodes.add(str);
				}
			}

			for (String str : distinctProductCodes) {
				Utils.editXpath("web_cr_table_RiContractPolicy", "web_cr_table_" + str + "", new String[] { str });
				for (WebElement ele : llAction.findElements("web_cr_table_" + str + "")) {
					contractIDAll.add(Integer.parseInt(ele.getText()));
				}
				contractIDAll.sort(Collections.reverseOrder());
				contractID.put(str, contractIDAll.get(0).toString());
			}

			Set<String> keys = contractID.keySet();
			Iterator<String> itr = keys.iterator();
			int i = 0;
			while (itr.hasNext()) {
				String thisKey = itr.next();
				Utils.editXpath("web_cr_table_RiContactIDRowData", "web_cr_table_RiContactIDRowData" + thisKey + "",
						new String[] { thisKey, contractID.get(thisKey) });
				List<WebElement> elements = llAction.findElements("web_cr_table_RiContactIDRowData" + thisKey + "");

				if (!beforeBatchData.get(i).getRiContractPolicyNumber().equalsIgnoreCase(policyNo)) {
					dashboard.setFailStatus(new BPCException(
							"Policy Number before batch: " + beforeBatchData.get(i).getRiContractPolicyNumber()
									+ "Policy Number after batch: " + policyNo));
				}

				if (!beforeBatchData.get(i).getRiContractID().equalsIgnoreCase(elements.get(0).getText())) {
					dashboard.setFailStatus(
							new BPCException("Contract ID before batch: " + beforeBatchData.get(i).getRiContractID()
									+ "Contract ID after batch: " + elements.get(0).getText()));
				}

				if (!beforeBatchData.get(i).getRiContractProductCode().trim()
						.equalsIgnoreCase(elements.get(3).getText().trim())) {
					dashboard.setFailStatus(new BPCException(
							"Product Code before batch: " + beforeBatchData.get(i).getRiContractProductCode()
									+ "Product Code after batch: " + elements.get(3).getText()));
				}

				if (!beforeBatchData.get(i).getRiContractRiskType().equalsIgnoreCase(elements.get(4).getText())) {
					dashboard.setFailStatus(
							new BPCException("Risk Type before batch: " + beforeBatchData.get(i).getRiContractRiskType()
									+ "Risk Type after batch: " + elements.get(4).getText()));
				} else {
					if(StringUtils.isEmpty(hParams.get("expectedContractStatus"))) {
						dashboard.setStepDetails("Validate Policy Number, RI Status, Product Code, Risk Type and Contract ID",
								"Success", "");
						dashboard.writeResults();
					}
				}
				
				if(!StringUtils.isEmpty(hParams.get("expectedContractStatus"))) {
					if (!expectedContractStatus[i].trim().equalsIgnoreCase(elements.get(6).getText().trim())) {
						dashboard.setFailStatus(new BPCException(
								"Expected Contract Status: " + expectedContractStatus[i]
										+ " Actual Contract Status: " + elements.get(6).getText()));
					} else {
						dashboard.setStepDetails("Validate Policy Number, RI Status, Product Code, Risk Type, Contract Status and Contract ID",
								"Success", "");
						dashboard.writeResults();
					}
				}
				i++;
			}
			llAction.clickElement("web_btn_attributeValueExit");
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
