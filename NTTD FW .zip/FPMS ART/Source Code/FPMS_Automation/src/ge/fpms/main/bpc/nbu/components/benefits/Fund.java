package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.logging.Logger;

import org.openqa.selenium.WebElement;

import ge.fpms.main.actions.FPMS_Actions;

public class Fund {
	private final static Logger LOGGER = Logger.getLogger(MainBenefits.class.getName());
	private FPMS_Actions llAction;
	private String fundCode;
	private String apportionment;

	public Fund() {
	}

	public void setFundCode(WebElement element, String fundCode) {
		try {
			
			element.sendKeys(fundCode);
			this.fundCode=fundCode;
			
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void setFundApportionmentPercentage(WebElement element, String apportionment) {
		try {
			element.sendKeys(apportionment);
			this.apportionment=apportionment;
			
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
}
