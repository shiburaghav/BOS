package ge.fpms.main.bpc.csd;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class Beneficiary {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	
	public Beneficiary()  {
		dashboard = DashboardHandler.getInstance();
	}
	public void manageBeneficiary(Hashtable<String, String> hParams) throws Exception {

		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {
			llAction = new FPMS_Actions();
			String applicationStatus = hParams
					.get("ApplicationStatus"); /* Get expected warning message from Test Data */
			CSDHelper.getInstance().captureChange("Change Beneficiary", "BeforeChange");
			if (hParams.get("Nominationtype") != null && hParams.get("Nominationtype") != "") {
				llAction.selectByVisibleText("web_lst_nominationType", hParams.get("Nominationtype"));
			}			
			llAction.clickElement("web_btn_addBeneficiary");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoFrame("", "iframe0");
			llAction.enterValue("web_txt_partyName", hParams.get("Name"));
			dashboard.setStepDetails("Enter Party Name in Party Information page",
					"Valid Party name is entered in Party Information page", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_next");
			llAction.waitUntilLoadingCompletes();
			int partyNameCol = llAction.GetColumnPositionInTable("web_tbl_partyList", "Name");
			int partyRow = llAction.GetRowPositionInTable("web_tbl_partyList", hParams.get("Name"), partyNameCol);
			int partyRecordNoCol = llAction.GetColumnPositionInTable("web_tbl_partyList", "Party Record No.");
			llAction.SelectRowInTable("web_tbl_partyList", partyRow, partyRecordNoCol, "a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on PartyRecordNo link",
					"Create and Maintain Party-Step 2 page is displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_changeBeneficiary_Submit");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_relationship", hParams.get("RelationshipwithPolicyholder"));
			llAction.enterValue("web_txt_sharePercentage", hParams.get("Percentageofshare%"));
			int addressRecordNoCol = llAction.GetColumnPositionInTable("web_tbl_address", "Address Rec No.");
			int addressRow = llAction.GetRowPositionInTable("web_tbl_address", hParams.get("AddressRecno"),
					addressRecordNoCol);
			llAction.SelectRowInTable("web_tbl_address", addressRow, addressRecordNoCol - 1, "input");
			dashboard.setStepDetails("Enter Beneficiary Information", "Beneficiary Information is added", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_beneficiaryInfo_Submit");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("Change Beneficiary", "AfterChange");
			llAction.clickElement("web_btn_changeBeneficiary_Submit");
			dashboard.setStepDetails("Click on Submit in Change beneficiary page",
					"Please check all indicators again popup should be displayed", "N/A");
			dashboard.writeResults();
			Utils.sleep(2);
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Accept the alert", "Policy alteration status should be completed", "N/A");
			dashboard.writeResults();
			if(llAction.isDisplayed("web_btn_continue"))
			{	
				CSDHelper.getInstance().validateWarningMessages("web_tbl_ca_warning_msg", hParams.get("WarningErrorMessage"));
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_btn_submitforApproval_AppEntry");
				llAction.waitUntilLoadingCompletes();
			}
			else
			{
			llAction.clickElement("web_btn_Submit_ApplicationEntry");
			llAction.waitUntilLoadingCompletes();
			if (llAction.getText("web_txt_policyStatus_message").contains(applicationStatus)) {
				dashboard.setStepDetails(applicationStatus + " Should be populated", "Message is validated",
						"N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(applicationStatus + "message is invalid/Submit was not successful");
				dashboard.writeResults();
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_txt_common_back_to_main");
		}
		}

		catch (Exception ex) {

			throw new BPCException("Exception occured during Change beneficiary \n Exception is " + ex.getMessage());

		}
	}

	public void searchbypolicy(Hashtable<String, String> hParams) throws Exception {
		int colPos = 0;
		int rowPos = 0;

		try {
			llAction = new FPMS_Actions();

			llAction.selectMenuItem("Party", "Search Party");
			llAction.clickElementJs("web_radio_radioName2");
			llAction.enterValue("web_text_PolicyNo", hParams.get("PolicyNumber"));
			llAction.sendkeyStroke("web_text_PolicyNo", Keys.ENTER);
			dashboard.setStepDetails("Search for policy " + hParams.get("PolicyNo"),
					"System should show relevant search results", "");
			dashboard.writeResults();
			llAction.clickElement("web_Btn_Search&Edit");
			dashboard.setStepDetails("Click Search and Edit button",
					"System should show relevant search results.", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();

			colPos = llAction.GetColumnPositionInTable("web_tbl_party_Table", "Insurance Role");
			rowPos = llAction.GetRowPositionInTable("web_tbl_party_Table", "Life Assured", colPos);
			llAction.SelectRowInTable("web_tbl_party_Table", rowPos, colPos + 1, "a");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Click on life assured hyperlink ",
					"System should display the \"Create and Maintain Party - Step 2\"", "N/A");
			dashboard.writeResults();

			if (hParams.get("Gender") != null) {
				llAction.selectByVisibleText("web_list_Beneficery_gender", hParams.get("Gender"));
				dashboard.setStepDetails(" Change the gender ", "System should accept the given values", "N/A");
				dashboard.writeResults();

				dashboard.writeResults();
			} else {
				llAction.enterValue("web_list_Beneficery_DOB", hParams.get("DOB"));
				dashboard.setStepDetails(" Change the DOB ", "System should accept the given values", "N/A");
				dashboard.writeResults();

			}
			llAction.clickElement("web_Btn_Submit");

			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 8)) {

				CSDHelper.getInstance().validateWarningMessages("web_txt_cb_benefit_details_warning_tbl", hParams.get("WarningErrorMessage"));
				llAction.clickElement("web_btn_continue");
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_Exit");
		}

		catch (Exception ex) {
			throw new BPCException("Exception occured while calling searchbypolicy method Exception is " + ex.getMessage());
		}
	}

	public void ChangeBirthDateorGender(Hashtable<String, String> hParams) throws Exception {
		int colPos = 0;
		int rowPos = 0;
		llAction = new FPMS_Actions();
		llAction.waitUntilLoadingCompletes();
		CSDHelper.getInstance().captureChange("Benefit information Before change", "BeforeChange");
		// ChangeRPApportCaptureBeforeOrAfterChange("Before");
		if ((hParams.get("Gender") != null)) {
			colPos = llAction.GetColumnPositionInTable("web_table_Lifeassuredinformation", "Gender");
			rowPos = llAction.GetRowPositionInTable("web_table_Lifeassuredinformation", hParams.get("Gender"), colPos);
			llAction.SelectRowInTable("web_table_Lifeassuredinformation", rowPos, colPos - 6, "input");

		} else {
			colPos = llAction.GetColumnPositionInTable("web_table_Lifeassuredinformation", "Birth date");
			rowPos = llAction.GetRowPositionInTable("web_table_Lifeassuredinformation", hParams.get("DOB"), colPos);
			llAction.SelectRowInTable("web_table_Lifeassuredinformation", rowPos, colPos - 5, "input");

		}
		llAction.waitUntilLoadingCompletes();
		llAction.clickElement("web_Btn_Beneficery_changebo");
		llAction.waitUntilLoadingCompletes();
		// ChangeRPApportCaptureBeforeOrAfterChange("After");
		CSDHelper.getInstance().captureChange("Benefit information After change", "Afterchange");
		llAction.clickElement("web_Btn_Submit"); // click on submit button
		llAction.waitUntilLoadingCompletes();
		if (llAction.isDisplayed("web_btn_continue", 8)) {

			llAction.clickElement("web_btn_continue");
			llAction.waitUntilLoadingCompletes();
		}
		dashboard.setStepDetails("click on submit",
				"System should display the Application entry UI with status as completed", "N/A");
		dashboard.writeResults();
		String pageDisplay = llAction.getText("web_tbl_CancellationPageHeader");
		if (pageDisplay.contains("collection/refund")) {
			dashboard.setStepDetails("Collection and refund information after change",
					"Collection and refund information after change should appear", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
		}
		dashboard.setStepDetails("Click on submit",
				"System should display the Application entry UI with status as completed", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_Btn_Submit"); // click on submit button
		llAction.waitUntilLoadingCompletes();
		String pageDisplay2 = llAction.getText("web_tbl_CancellationPageHeader");
		if (pageDisplay2.contains("offset fee")) {
			dashboard.setStepDetails("Display offset fee result", "Display offset fee result should appear", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Exit");
			llAction.waitUntilLoadingCompletes();
		}
		String applicationStatus = hParams.get("ApplicationStatus"); /* Get expected warning message from Test Data */
		if (llAction.getText("web_txt_policyStatus_message").contains(applicationStatus)) {
			dashboard.setStepDetails(applicationStatus + " Should be populated", "Message is validated", "N/A");
			dashboard.writeResults();
		} else {
			dashboard.setWarningStatus(applicationStatus + "message is invalid/Submit was not successful");
			dashboard.writeResults();
		}
		llAction.waitUntilLoadingCompletes();
		llAction.clickElement("web_txt_common_back_to_main");
	}

	public void changepolicybasicinformation(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();

			llAction.enterValue("web_txt_Bfy_Employercontribution", hParams.get("EmployerContribution"));
			llAction.sendkeyStroke("web_txt_Bfy_Employercontribution", Keys.ENTER);
			llAction.enterValue("web_txt_Bfy_Carregistrationnumber", hParams.get("Carregistrationnumber"));
			llAction.selectByVisibleText("web_list_Bfy_PolicyunderTrustIndicator",
					hParams.get("PolicyunderTrustindicator"));
			llAction.selectByVisibleText("web_list_Bfy_Foreignpolicyindicator", hParams.get("Foreignpolicyindicator"));
			llAction.enterValue("web_list_Bfy_Startdate", hParams.get("Startdate"));
			llAction.enterValue("web_list_Bfy_Campaigncode", hParams.get("Campaigncode"));
			llAction.sendkeyStroke("web_txt_Bfy_Employercontribution", Keys.ENTER);
			dashboard.setStepDetails("Enter the Policy Basic information",
					"System should accept the given values", "N/A");
			dashboard.writeResults();
			llAction.scrolldown();
			llAction.clickElement("web_btn_Bfy_submit");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException("Exception occured while calling changepolicybasicinformation method Exception is" + ex.getMessage());
		}

	}

}
