package ge.fpms.main.bpc.finance;

import ge.fpms.data.Login;
import ge.fpms.main.AdhocBatchJob;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.BatchJob.*;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.claims.ClaimRegistration;
import ge.fpms.main.bpc.nbu.BatchConstants;
import ge.fpms.main.bpc.nbu.BatchJobs;
import ge.fpms.main.bpc.nbu.components.BatchJobFileProcessor;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.codoid.products.fillo.Recordset;
import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.ArtRobot;
import com.nttdata.common.util.ExcelUtility;
import com.nttdata.common.util.PIPSGenerics;
import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class DividendAndCoupon {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private String home = System.getProperty("user.home");

	public DividendAndCoupon() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	/**
	 * addDividendAndCoupon
 	- add a dividend and coupon from Initiate/Maintain Dividend and Coupon screen. 
	 * @param hParams
	 * @throws Exception
	 */
	public void addDividendAndCoupon(Hashtable<String, String> hParams) throws Exception {
		try {			
			/* DEbug area String saveType = "Save Online";

			String batchNumber= "7212";
			Hashtable<String, String> hParams1 = new Hashtable<String, String>();
			
			String  dt = hParams.get("BatchProcessingDate");

			hParams1.put("BatchDueDate", "01/01/2000");
			hParams1.put("BatchProcessingDate", dt);


			if (saveType.equalsIgnoreCase("Save Online"))
			{	hParams1.put("ScheduleId", "Coupon Dividend Payment- Trial Report");
				hParams1.put("Parameters", batchNumber);	
				hParams1.put("JobName", "CSV");
				hParams1.put("JobId", "CSV");
			}else if (saveType.equalsIgnoreCase("Save Offline"))
			{
				hParams1.put("JobId", "5175");
			}

			BatchJobs j=new BatchJobs();

			j.ExecuteAndMonitorJobs(hParams1);
			}
		Debug area*/
            llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
            //llAction.goMenuItem("Coupon  & Dividend Payout","web_batchjobs_menuitem_cd_payout");
            //llAction.goMenuItem("Coupon & Dividend Processing","web_batchjobs_menuitem_cd_payout_processing");
            llAction.selectMenuItem("COUPON_AND_DIVIDEND_INTIIATE_MAINTAIN");


            llAction.selectByVisibleText("web_finance_cdinfo_fundCode",hParams.get("FundCodeFrom"));       

            llAction.clickElement("web_finance_cd_add_button");
            llAction.waitUntilLoadingCompletes();  

            //Select Company Code (GELS) Company code & payout type will auto populate by sys
            //System should accept selected details

            String strPayoutType  = llAction.getAttribute("web_finance_cdinfo_payoutTypeName", "value");                  

            //String strPayoutType = llAction.getText("web_finance_cdinfo_payoutTypeName");                   
            String strCompanyName = llAction.getSelectedOption("web_finance_cd_info_companyCode_list");

            if(StringUtils.isEmpty(strPayoutType)){
                  dashboard.setFailStatus(new BPCException(
                                "Failed to find the value for Payout type,Payout type must be aut-populated by the system "));
                  dashboard.writeResults();
            }else {
                  dashboard.setStepDetails("Note Payout type'", "Payout type is " +  strPayoutType, "N/A");
                  dashboard.writeResults();
            }

            if(StringUtils.isEmpty(strCompanyName)){
                  dashboard.setFailStatus(new BPCException(
                                "Failed to find the value for Company name,Company name must be aut-populated by the system "));
                  dashboard.writeResults();
            }else {
                  dashboard.setStepDetails("Note Company Name'", "Company name is  " +  strCompanyName, "N/A");
                  dashboard.writeResults();
            }


            //Fill in Bid Price Bid price will autopopulated by sys after declaration date entered.
            // If the fund price status is not �Approved� or �Confirmed�, error msg - The declared fund price status must be Approved or Confirmed is raised.
        llAction.enterValue("web_finance_cd_info_declarationDate_txt",hParams.get("DeclarationDate"));
            llAction.sendkeyStroke("web_finance_cd_info_declarationDate_txt", Keys.ENTER);
            long timeOut = (long) 3;
            if (llAction.isAlertDisplayed(timeOut)) {
                  String strAlertText = llAction.getAlertText();
                  dashboard.setFailStatus(new BPCException(strAlertText));
                  dashboard.writeResults();                      
            }

            //Fill in Bid Price Bid price will autopopulated by sys after declaration date entered.
            // If the fund price status is not �Approved� or �Confirmed�, error msg - The declared fund price status must be Approved or Confirmed is raised.
            llAction.waitUntilElementPresent("web_finance_cd_info_BidPrice_txt");
            String strbidPrice=llAction.getAttribute("web_finance_cd_info_BidPrice_txt", "value");
            if(StringUtils.isEmpty(strbidPrice)){
                  dashboard.setFailStatus(new BPCException(
                                "Failed to find the value for Bid Price,Bid Price  must be aut-populated by the system "));
                  dashboard.writeResults();
            }else {
                  dashboard.setStepDetails("Note Bid Price'", "Bid Price is  " +  strbidPrice, "N/A");
                  dashboard.writeResults();
            }

            if (strPayoutType.equalsIgnoreCase("UT Dividend")
                         || strPayoutType.equalsIgnoreCase("Dividend")) {
                   llAction.enterValue("web_finance_cdinfo_payoutRate_txt",hParams.get("PayOutRate"));               
            }

            if (strPayoutType.equalsIgnoreCase("Coupon")){
                   llAction.enterValue("web_finance_cdinfo_parValue_txt",hParams.get("ParValue"));      
                  if(llAction.isEnabled("web_finance_cdinfo_priceDate_txt")){
                  llAction.enterValue("web_finance_cdinfo_priceDate_txt",hParams.get("PriceEffectiveDateforReinvestment"));
                         dashboard.setStepDetails("Fill in Price Effective Date (Reinvestment)", hParams.get("PriceEffectiveDateforReinvestment") + " System should accept input details", "N/A");
                         dashboard.writeResults();
                  }
            }

            if(llAction.isEnabled("web_finance_cdinfo_paymentdt_txt")){
               llAction.enterValue("web_finance_cdinfo_paymentdt_txt",hParams.get("PaymentDateforReinvest"));
                  if (llAction.isAlertDisplayed(timeOut)) {
                         String strAlertText = llAction.getAlertText();
                         System.out.println(strAlertText);
                         dashboard.setFailStatus(new BPCException(strAlertText));
                         dashboard.writeResults();                      
                  }
                  dashboard.setStepDetails("Fill in Payment date for (Reinvestment)", hParams.get("PaymentDateforReinvest") + " System should accept input details", "N/A");
                  dashboard.writeResults();
                  
            }
     
            String saveType = hParams.get("SaveType");
            
            String e = "web_finance_cd_info_" + saveType.replaceAll(" ", "_") + "_btn".toLowerCase();
            e=e.toLowerCase();
            llAction.clickElement(e);
            
            
            if(llAction.isDisplayed("web_coupon_dividend_unit_info_save_notes",3)){
                  String notes = llAction.getText("web_coupon_dividend_unit_info_save_notes");
                  dashboard.setFailStatus(new BPCException("Dividend and Coupon Save Online Info : Could not save because of " + notes + " !!!"));
            }
            
            
                  
            
            if (llAction.isDisplayed("web_finance_cd_info_message",2))
            {
                  String Message = llAction.getText("web_finance_cd_info_message");
                  String batchNumber = Message.replaceAll("[^0-9+]","");
                  dashboard.setStepDetails("Capture Batch no '", "Batch no " + batchNumber + " captured", "N/A");
                  dashboard.writeResults();
                  llAction.clickElement("web_unitadjustment_exit_btn");      

                  llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
                  llAction.goMenuItem("Coupon  & Dividend Payout","web_batchjobs_menuitem_cd_payout");
                  llAction.goMenuItem("Coupon & Dividend Processing","web_batchjobs_menuitem_cd_payout_processing");
                  llAction.selectMenuItem("COUPON_AND_DIVIDEND_INTIIATE_MAINTAIN");



                  llAction.enterValue("web_finance_cd_batchNumber_txt",batchNumber);
                  dashboard.setStepDetails("Enter Batch Number", batchNumber +" Batch Number is entered", "N/A");
                  dashboard.writeResults();
                  llAction.clickElement("web_unitadjustment_search_btn");
                  llAction.waitUntilLoadingCompletes();  

                  Hashtable<String, String> batchListTable = ARTProperties.guiMap.get("web_finance_cd_BatchList");
                  String batchListTablePath = batchListTable.get(batchListTable.keySet().toArray()[0]);


                  if(llAction.getSize(batchListTablePath) < 1){
                         dashboard.setFailStatus(new BPCException("Search Batch Number: No Batch Number found when searched!!!"));
                  }
                  else {
                         dashboard.setStepDetails("Search Batch Number", batchNumber +" Batch Number is found", "N/A");
                         dashboard.writeResults();
                  }
                  llAction.clickElement("web_unitadjustment_exit_btn");      
                  llAction.waitUntilLoadingCompletes();  

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                  //BatchJob job = new BatchJob(jobId, hParams.get(BatchConstants.BATCH_JOBNAME + counter), hParams.get(BatchConstants.BATCH_DUE_DATE),
                  //hParams.get(BatchConstants.BATCH_PROCESSING_DATE), hParams.get(BatchConstants.BATCH_MULTISTREAM_JOB + counter));

                  //String batchNumber= "7210";
                  Hashtable<String, String> hParams1 = new Hashtable<String, String>();
                  //ClaimRegistration cl = new ClaimRegistration();
                  //String dt = cl.getSystemDate();
                  String  dt = hParams.get("BatchProcessingDate");

                  //hParams1.put("NoOfJobs", "1");

                  hParams1.put("BatchDueDate", "01/01/2000");
                  hParams1.put("BatchProcessingDate", dt);


                  if (saveType.equalsIgnoreCase("Save Online"))
                  {      hParams1.put("ScheduleId", "Coupon Dividend Payment- Trial Report");
                  hParams1.put("Parameters", batchNumber);      
                  hParams1.put("JobName", "CSV");
                  hParams1.put("JobId", "CSV");
                  }else if (saveType.equalsIgnoreCase("Save Offline"))
                  {
                         hParams1.put("JobId", "5175");
                  }

                  BatchJobs j=new BatchJobs();

                  j.ExecuteAndMonitorJobs(hParams1);
            
            }
            else {
                  dashboard.setFailStatus(new BPCException("Capture Batch Number: No Batch Numbers when doing '" + saveType + "' !!!"));
            }   }             

	catch (Exception e) {
			throw new BPCException(e);
		}

	}

	/**
	 * runTrailReportAndUpdateBatchAllocationStatus
 	- updates the batch allocation stauts for a Initiate/Maintain - ed  Dividend and Coupon screen. 
	 * @param hParams
	 * @throws Exception
	 */
	public void runTrailReportAndUpdateBatchAllocationStatus(Hashtable<String, String> hParams) throws Exception {
		try {			
			int timeOut= 3;
			deleteExistingPDFFiles();
			String notesDisplayed = "";
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Coupon  & Dividend Payout","web_batchjobs_menuitem_cd_payout");
			llAction.goMenuItem("Coupon & Dividend Processing","web_batchjobs_menuitem_cd_payout_processing");
			llAction.selectMenuItem("COUPON_AND_RUN_REPORT_CHANGE_ALLOC_STATUS");

			llAction.enterValue("web_finance_ca_batchnumber_txt", hParams.get("AdjustUnitsBatchNumber"));
			llAction.clickElement("web_finance_ca_Search_btn");
			llAction.waitUntilLoadingCompletes();
			if ((llAction.isDisplayed("web_finance_ca_runtrailrpt_csv_btn", 2)) && 
					(llAction.isDisplayed("web_finance_ca_runtrailreport_btn", 2)) && 
					(llAction.isDisplayed("web_finance_ca_SummaryReport_btn", 2))  &&
					(llAction.isDisplayed("web_finance_ca_Save_btn", 2))) {
				dashboard.setStepDetails("Click Search button.", "System should display Allocation Status dropdownlist, Run Trial Report -CSV button, Run Trial Report button, Summary Report button and save button.", "N/A");
				dashboard.writeResults();
			}
			else {
				dashboard.setFailStatus(new BPCException("System has not displayed Allocation Status dropdownlist, Run Trial Report -CSV button, Run Trial Report button, Summary Report button and save button. searched!!!"));
			}			
			llAction.clickElementJs("web_finance_ca_runtrailrpt_csv_btn");	

			if (llAction.isDisplayed("web_finance_runtrailreport_alloc_notes_error", timeOut)){
				notesDisplayed = llAction.getText("web_finance_runtrailreport_alloc_notes_error");
				dashboard.setStepDetails("Click on Run Trail Reports'","Errors appeared.", "N/A");
				dashboard.writeResults();
				dashboard.setFailStatus(new BPCException("Run Trail Reports thro"+notesDisplayed));			
			}

			Utils.sleep(2);		
			dashboard.setStepDetails("Click Run Trial Report - csv button.","System should display a pop up message asking if wanted to open or save the report.pdf.", "N/A");
			dashboard.writeResults();
			ArtRobot.saveFile();
			Utils.sleep(2);					
			llAction.clickElementJs("web_finance_ca_runtrailreport_btn");		
			Utils.sleep(2);	
			dashboard.setStepDetails("Click Run Trial Report button. ","System should display a pop up message asking if wanted to open or save the report.pdf.", "N/A");
			dashboard.writeResults();
			ArtRobot.saveFile();			
			llAction.clickElementJs("web_finance_ca_SummaryReport_btn");	
			dashboard.setStepDetails("Click on Summary Reports","System has saved the files in the Downloads folder.Please check.", "N/A");
			dashboard.writeResults();			
			Utils.sleep(2);		
			ArtRobot.saveFile();	
			dashboard.setStepDetails("Save Reports","System should display a pop up message asking if wanted to open or save the report.pdf.", "N/A");
			dashboard.writeResults();

			llAction.selectByVisibleText("web_finance_runtrailreport_alloc_list",hParams.get("AllocationStatus"));						
			llAction.clickElement("web_finance_ca_Save_btn");
			llAction.waitUntilLoadingCompletes();	

			if (llAction.isDisplayed("web_finance_runtrailreport_alloc_notes_error", timeOut)){
				notesDisplayed = llAction.getText("web_finance_runtrailreport_alloc_notes_error");
				dashboard.setStepDetails("Change the allocation status to 'Allocated'","Allocation status change failed. Pls refer the screenshot.", "N/A");
				dashboard.writeResults();
				dashboard.setFailStatus(new BPCException("The status could not be changed to 'Allocated' due to " +notesDisplayed));				
			}			

			//validate the success message 
			WebElement allocStatus  = llAction.findElementByXpath("//td[contains(text(),\"Batch no " + hParams.get("AdjustUnitsBatchNumber") +" is set to Allocated successfully\")]");
			if (!allocStatus.equals(null))
			{	
				String allocStatusValue = allocStatus.getText();
				dashboard.setStepDetails("Change the allocation status to 'Allocated'","Batch no "+ hParams.get("AdjustUnitsBatchNumber") +" is set to Allocated successfully! ", "N/A");
				dashboard.writeResults();
			}else {
				dashboard.setStepDetails("Change the allocation status to 'Allocated'","Batch no "+ hParams.get("AdjustUnitsBatchNumber") +" is set to Allocated successfully! didnt appear. ", "N/A");
				dashboard.writeResults();
				dashboard.setFailStatus(new BPCException("The status message is not " + "Batch no "+ hParams.get("AdjustUnitsBatchNumber") +" is set to Allocated successfully!" ));	
			}

			llAction.clickElement("web_unitadjustment_exit_btn");
			llAction.waitUntilLoadingCompletes();	
			dashboard.setStepDetails("Click Exit button.","System will display main screen.", "N/A");
			dashboard.writeResults();

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	/**
	 * adjustCouponAndDividendUnits
	 	- It will adjust units for Coupon and dividends. 
	 * @param hParams
	 * @throws Exception
	 */
	public void adjustCouponAndDividendUnits(Hashtable<String, String> hParams) throws Exception {
		try {
			boolean isAdjusted = false;
			long timeout = (long) 0;
			
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			//llAction.goMenuItem("Coupon & Dividend Payout","web_batchjobs_menuitem_cd_payout");
			llAction.selectMenuItem("COUPON_AND_DIVIDEND_UNIT_ADJUSTMENT");
							
			/*
			 Random get 1 pol no. from the report generated in Step 6 - Run Trial Report button			
			 */
			String policyNumber = getPolicyNumberFromRunTrailReport();			
			llAction.enterValue("web_coupon_dividend_unit_adjustment_policyNo", policyNumber);			
			dashboard.setStepDetails("Enter the policy number'",policyNumber + " is entered.", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_coupon_dividend_unit_adjustment_batchNumber", hParams.get("AdjustUnitsBatchNumber"));
			dashboard.setStepDetails("Enter the batch number'",hParams.get("AdjustUnitsBatchNumber") + " is entered.", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_unitadjustment_search_btn");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click button'","Search button is clicked.", "N/A");
			dashboard.writeResults();
			
			String couponDividendRateBefore  = llAction.getAttribute("web_cd_Allocation_rate", "value");
				
			if (couponDividendRateBefore.equalsIgnoreCase("0.000000")) {				
				
				dashboard.setStepDetails("Check Allocation Status","Units are already allocated", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_cd_Allocation_cancel");
				llAction.waitUntilLoadingCompletes();
				
			}else {
			
			llAction.enterValue("web_cd_Allocation_txt_unitsAdjusted", hParams.get("CouponAndDividendsUnitsToAdjust"));
			dashboard.setStepDetails("Enter units to be allocated'", hParams.get("CouponAndDividendsUnitsToAdjust") +  " units entered.", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_cd_Allocation_submit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click button","Submit button is clicked.", "N/A");
			dashboard.writeResults();
			
			llAction.enterValue("web_coupon_dividend_unit_adjustment_policyNo", policyNumber);			
			dashboard.setStepDetails("Enter the policy number'",policyNumber + " is entered.", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_coupon_dividend_unit_adjustment_batchNumber", hParams.get("AdjustUnitsBatchNumber"));
			dashboard.setStepDetails("Enter the batch number'",hParams.get("AdjustUnitsBatchNumber") + " is entered.", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_unitadjustment_search_btn");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click button'","Search button is clicked.", "N/A");
			dashboard.writeResults();
			
			llAction.clickElementJs("web_cd_Allocation_printPolicieswithAdjustedQualUnit");
			llAction.waitUntilLoadingCompletes();	
			dashboard.setStepDetails("Click Print List of Policies with Adjusted Qualifying Unit","A report will be generated online to display all the records where adjustment have been make for the batch allocation number.", "N/A");
			dashboard.writeResults();
			
			llAction.clickElement("web_cd_Allocation_updateBatchStatus");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click button","Update Batch Status button is clicked.", "N/A");
			dashboard.writeResults();
			
			String  couponDividendRate = llAction.getAttribute("web_cd_Allocation_rate", "value");
			if(couponDividendRate.equalsIgnoreCase("0.000000")) {
				dashboard.setStepDetails("Verify Coupon or Dividend rate","System will clear all the details showed previously left coupon/divide rat to be 0.000000.", "N/A");
				dashboard.writeResults();
			}else {
				dashboard.setFailStatus(new BPCException("Coupon/Dividend rate: System did not clear off rate to 0.000000!!!"));
				}
			llAction.clickElement("web_cd_Allocation_cancel");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click button","cancel button is clicked.", "N/A");			
			
			isAdjusted = IsBatchStausUnitAdjusted(hParams);
			if(isAdjusted) {
				dashboard.setStepDetails("The Batch Number " + hParams.get("AdjustUnitsBatchNumber")  + " with the fund code will have Adjusted Batch Status."," The Batch Number " + hParams.get("BatchNumber") + " with the fund code will have  Adjusted Batch Status.", "N/A");
				dashboard.writeResults();
			}
			llAction.clickElement("web_unitadjustment_exit_btn");
			llAction.waitUntilLoadingCompletes();
			}	
			
		}
		
		catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void authorizeDividendAndCoupon(Hashtable<String, String> hParams) throws Exception {
		try {			
			String [] allocationStatus = hParams.get("Auth_AllocationStatus").split(FPMSConstants.COMMA_SEPERATOR); 
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Coupon  & Dividend Payout","web_batchjobs_menuitem_cd_payout");
			llAction.goMenuItem("Coupon & Dividend Processing","web_batchjobs_menuitem_cd_payout_processing");
			llAction.selectMenuItem("COUPON_AND_DIVIDEND_AUTHORIZATION");

			llAction.enterValue("web_coupon_dividend_unit_adjustment_batchNumber", hParams.get("Auth_BatchNumber"));
			llAction.clickElement("web_finance_ca_Search_btn");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Search the batch number'","System should display relevant result in search result section.", "N/A");
			dashboard.writeResults();
			llAction.selectByVisibleText("web_finance_runtrailreport_alloc_list", allocationStatus[0]);
			dashboard.setStepDetails("Change the allocation status to Verified","Allocation status is changed to Verified", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_save");
			dashboard.setStepDetails("Click on Save button'","System should update and save the changes.", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_coupon_dividend_unit_adjustment_batchNumber", hParams.get("Auth_BatchNumber"));
			llAction.clickElement("web_finance_ca_Search_btn");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Search the batch number'","System should display relevant result in search result section.", "N/A");
			dashboard.writeResults();
			llAction.selectByVisibleText("web_finance_runtrailreport_alloc_list", allocationStatus[1]);
			dashboard.setStepDetails("Change the allocation status to Verified","Allocation status is changed to Verified", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_save");
			llAction.waitUntilLoadingCompletes();	
			dashboard.setStepDetails("Click on Save button'","System should update and save the changes.", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_unitadjustment_exit_btn");
			llAction.waitUntilLoadingCompletes();	
			dashboard.setStepDetails("Click Exit button.","System will display main screen.", "N/A");
			dashboard.writeResults();

		}catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void generateAndSaveReport(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Coupon  & Dividend Payout","web_batchjobs_menuitem_cd_payout");
			llAction.goMenuItem("Coupon & Dividend Processing","web_batchjobs_menuitem_cd_payout_processing");
			llAction.selectMenuItem("COUPON_AND_DIVIDEND_AUTHORIZATION");

			llAction.enterValue("web_coupon_dividend_unit_adjustment_batchNumber", hParams.get("Auth_BatchNumber"));
			llAction.clickElement("web_finance_ca_Search_btn");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Search the batch number'","System should display relevant result in search result section.", "N/A");
			dashboard.writeResults();
			llAction.clickElementJs("web_btn_generateReport");
			dashboard.setStepDetails("Click on Generate Report'","System should display a pop up message asking if wanted to open or save the report.", "N/A");
			dashboard.writeResults();
			Utils.sleep(2);
			ArtRobot.saveFile();
			llAction.clickElement("web_unitadjustment_exit_btn");
			llAction.waitUntilLoadingCompletes();	
			dashboard.setStepDetails("Click Exit button.","System will display main screen.", "N/A");
			dashboard.writeResults();

		}catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	public String getPolicyNumberFromRunTrailReport() throws Exception {
		try {
			//Delete all pdf files.	
			
			String runTrailReportFilepath= home+"/Downloads/" ;
					
				String policyNumber = "";			
					File runTrailReport = new File(runTrailReportFilepath);
					if (runTrailReport.exists()) {				
						File[] listOfFiles = runTrailReport.listFiles();
						for (File file : listOfFiles) {
							if ( file.getName().equalsIgnoreCase("report.pdf")) {
									PIPSGenerics pipsObj = new PIPSGenerics();
									PDDocument pdfDoc = null;
									String pdfAllTexts = null;
									ArrayList<String> allOccurance = null;
									String pdfFilePath = runTrailReport + "\\" + file.getName();
									File file1 = new File(pdfFilePath);
									PDFTextStripper pdfStripper = new PDFTextStripper();
									pdfStripper.setSortByPosition(true);
									PDFont titl = PDType1Font.TIMES_BOLD;
									pdfDoc = PDDocument.load(file1);
									pdfStripper.setStartPage(1);						
									pdfAllTexts = pdfStripper.getText(pdfDoc);
									String lines[] = pdfAllTexts.split("\\r?\\n");
									if(lines[0].equalsIgnoreCase("List of Policies For Coupon & Dividend Allocation")) {
										allOccurance = pipsObj.getAllValuesBetweenStrings(lines, "", "DP" );
									if (allOccurance.size() >0) {
										policyNumber = allOccurance.get(0);
										break;
									}else {
										allOccurance = pipsObj.getAllValuesBetweenStrings(lines, "", "SP" );
										if (allOccurance.size() >0) {
											policyNumber = allOccurance.get(0);
										break;
								}
									}
			
						}	
										
									if(pdfDoc!=null) {
										pdfDoc.close();	
									}				
				}
							
						}
					}
					
					if(policyNumber.equalsIgnoreCase("")) {
						
						dashboard.setFailStatus(new BPCException("Find list of policies from Run Trail REport:: No policies found"));
					}
					return policyNumber;
		
			
		}
			catch (Exception e) {
			throw new BPCException(e);
		
	}
		}
	
	
	public void deleteExistingPDFFiles() throws Exception {
		try {
			//Delete all pdf files.		
			String runTrailReportFilepath= home+"/Downloads/" ;
			File runTrailReport = new File(runTrailReportFilepath);
			if (runTrailReport.exists()) {				
				File[] listOfFiles = runTrailReport.listFiles();
				for (File file : listOfFiles) {
					if (file.getName().endsWith(".pdf"))
						{
						file.delete();
						}
				}			

			}

		}
			catch (Exception e) {
			throw new BPCException(e);
		}
	}

	
	private boolean IsBatchStausUnitAdjusted(Hashtable<String, String> hParams) throws Exception {
		try {
					
			boolean isBatchStatusAjusted = false;
			
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
            llAction.goMenuItem("Coupon  & Dividend Payout","web_batchjobs_menuitem_cd_payout");        
            llAction.selectMenuItem("COUPON_AND_DIVIDEND_INTIIATE_MAINTAIN");
           
            //Enter batch number
            llAction.enterValue("web_finance_ca_batchnumber_txt", hParams.get("AdjustUnitsBatchNumber"));
            //Enter declaration date
            llAction.enterValue("web_finance_cd_info_declarationDate_txt", hParams.get("DeclarationDate"));
			llAction.clickElement("web_fund_search_btn");
			llAction.waitUntilLoadingCompletes();
			
			String xPath = "//a[normalize-space(text()) = '" + hParams.get("AdjustUnitsBatchNumber") + "']/ancestor::table[1]//tr/td[normalize-space(text()) = 'Adjusted']";
			if(llAction.findElementByXpath(xPath)!=null) {				
				isBatchStatusAjusted = true;
			}else {
				dashboard.setFailStatus(new BPCException("Batch status as Adjusted: The batch status didnt turn to 'Adjusted'."));
			}
		
			return isBatchStatusAjusted;
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	
}









