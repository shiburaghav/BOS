package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class FreelookComponent {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public FreelookComponent() {
		dashboard = DashboardHandler.getInstance();
		llAction = new FPMS_Actions();
	}

	public void Freelook(Hashtable<String, String> hParams) throws Exception {

		int colPos;
		int rowPos;
		try {
			clickEnterInformation(hParams);
			ChangeRPApportCaptureBeforeOrAfterChange("BeforeChange");
			llAction.waitUntilElementPresent("web_txt_ILPTopUp_ValidityDate");
			llAction.enterValue("web_txt_ILPTopUp_ValidityDate", hParams.get("Validitydate"));
			dashboard.setStepDetails("Enter validity date.", "Valid Validity date is entered.", "N/A");
			dashboard.writeResults();
			if ((hParams.get("BenefitCode") != null && hParams.get("BenefitCode") != "")) {
				colPos = llAction.GetColumnPositionInTable("web_tbl_Benefit_Infor_beforechange", "Benefit Name");
				rowPos = llAction.GetRowPositionInTable("web_tbl_Benefit_Infor_beforechange",
						hParams.get("BenefitCode"), colPos);
				llAction.SelectRowInTable("web_tbl_Benefit_Infor_beforechange", rowPos, colPos - 2, "input");
				dashboard.setStepDetails("Select Benefit option tickbox. ",
						"System should accept the selected details ", "N/A");
				dashboard.writeResults();
			} else {
				llAction.clickElement("web_Radio_Freelook_All");
				dashboard.setStepDetails("Select Benefit option tickbox. ",
						"System should accept the selected details ", "N/A");
				dashboard.writeResults();
			}
			llAction.selectByVisibleText("web_list_Freelookup_selectoptions", hParams.get("Freelookreason"));
			llAction.clickElement("web_btn_Freelookup_Freelook");
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_warning_msg",
							hParams.get("WarningErrorMessage"));
					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_Submit");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
			}
			CSDHelper.getInstance().endOfTransaction();
		} catch (Exception ex) {
			throw new BPCException("Exception occured while calling Freelook method. Exception is " + ex.getMessage());
		}
	}

	private void clickEnterInformation(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		if (llAction.isDisplayed("web_btn_continue", 8)) {
			String war = hParams.get("Warning/Error Message");
			if ((war != null)) {
				String warningMsg = llAction.getText("web_txt_warrningErrmsg");
				ErrorValidateWarningMessages(warningMsg, war);
			}
		}

	}

	public void ChangeRPApportCaptureBeforeOrAfterChange(String ActionType) throws Exception {

		try {
			switch (ActionType.toUpperCase()) {
			case "BEFORECHANGE":
				dashboard.setStepDetails("Before Policy alterationitem top up", "Status should Pending Data Entry",
						"N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":
				dashboard.setStepDetails("After Policy alterationitem top up added", "Status should completed", "N/A");
				dashboard.writeResults();
				break;
			}
		} catch (Exception ex) {
			throw new BPCException(
					"Exception occured while calling ChangeRPApportCaptureBeforeOrAfterChange method Exception is "
							+ ex.getMessage());
		}
	}

	public void ErrorValidateWarningMessages(String warningMsg, String message) throws Exception {

		if (warningMsg.contains(message)) {
			System.out.println(message + "" + warningMsg);
			dashboard.writeResults();

		} else {
			dashboard.setFailStatus(new BPCException(
					"Warning message " + warningMsg + " from application is not matching with test data"));
		}
	}
}