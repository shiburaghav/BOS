package ge.fpms.main.bpc.bcp.templates.axs;

import java.util.ArrayList;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Header implements IPaymentSection {

	private Type recordType;
	private Type corporationCode;
	private Type transactionDate;
	private Type corporationName;
	private Type totalNumberOfRecords;
	private Type procService;
	private Type gelApplication;
	private Type filler;

	public Header() {
	}

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getCorporationCode() {
		return corporationCode;
	}

	public void setCorporationCode(Type corporationCode) {
		this.corporationCode = corporationCode;
	}

	public Type getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Type transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Type getCorporationName() {
		return corporationName;
	}

	public void setCorporationName(Type corporationName) {
		this.corporationName = corporationName;
	}

	public Type getTotalNumberOfRecords() {
		return totalNumberOfRecords;
	}

	public void setTotalNumberOfRecords(Type totalNumberOfRecords) {
		this.totalNumberOfRecords = totalNumberOfRecords;
	}

	public Type getProcService() {
		return procService;
	}

	public void setProcService(Type procService) {
		this.procService = procService;
	}

	public Type getGelApplication() {
		return gelApplication;
	}

	public void setGelApplication(Type gelApplication) {
		this.gelApplication = gelApplication;
	}

	public Type getFiller() {
		return filler;
	}

	public void setFiller(Type filler) {
		this.filler = filler;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(), corporationCode.getSize(), transactionDate.getSize(),
				corporationName.getSize(), totalNumberOfRecords.getSize(), procService.getSize(),
				gelApplication.getSize(), filler.getSize() };
	}

	public void setParamaters(ArrayList<String> buffer) {
		recordType.setValue(buffer.get(0));
		corporationCode.setValue(buffer.get(1));
		transactionDate.setValue(buffer.get(2));
		corporationName.setValue(buffer.get(3));
		totalNumberOfRecords.setValue(buffer.get(4));
		procService.setValue(buffer.get(5));
		gelApplication.setValue(buffer.get(6));
		filler.setValue(buffer.get(7));
	}

	public String getName() {
		return "0";
	}

	public String toString() {
		String headerText = new StringBuffer().append(getRecordType().toString())
				.append(getCorporationCode().toString()).append(getTransactionDate().toString())
				.append(getCorporationName().toString()).append(getTotalNumberOfRecords().toString())
				.append(getProcService().toString()).append(getGelApplication().toString())
				.append(getFiller().toString()).toString();
		System.out.println("Header.toString() header: " + headerText);
		return headerText;
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}
}
