package ge.fpms.main.actions;


import ge.fpms.main.FPMSConstants;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.LL_Actions;
import com.nttdata.core.ObjectIdentifier;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.LowLevelException;

public class FPMS_Actions extends LL_Actions {
	private static HashMap<String, String> map;
	static {
		map = new HashMap<String, String>();
		map.put("FUND_NEW_REVISE", "/ls/fnd/toEnterFundPrice.do");
		map.put("FUND_PRICE_APPROVAL", "/ls/fnd/toApprovalFundPrice.do");
		map.put("QUERY_INFORCE", "/ls/qry/commonquery.CommonQuery.do");
		map.put("RUN_JOB_TASK", "/ls/sys/scd/toTest.do");
		map.put("QUERY_FUND_PRICE", "/ls/fnd/toQueryFundPrice.do");
		map.put("MAIN_PAGE", "/ls/mainMenu.do");
		map.put("RUN_ADHOC_JOB_TASK", "/ls/sys/scd/toTestAdhoc.do");
		map.put("RUN_CC_BANK_DWL_FILE", "/ls/arap/cash/banktransfer/downloadcreditextract.do");
		map.put("FUND_PRICE_UPLOAD", "/ls/fnd/toFundPriceBatchUpload.do");
		map.put("REGENERATE_POLICY", "/ls/prt/regenSearch.do");
		map.put("COUPON_AND_DIVIDEND_INTIIATE_MAINTAIN",
				"/ls/cs/policyalteration.ilp.coupondividend.CouponDividendDisplay.do");
		map.put("COUPON_AND_RUN_REPORT_CHANGE_ALLOC_STATUS",
				"/ls/cs/policyalteration.ilp.coupondividend.CouponDividendTrialRunSearch.do");
		map.put("COUPON_AND_DIVIDEND_AUTHORIZATION",
				"/ls/arap/dividendCoupon/authorization/search.do");
		map.put("UNIT_ADJUSTMENT", "/ls/fnd/toFundAdjustment.do");
		map.put("COUPON_AND_DIVIDEND_UNIT_ADJUSTMENT", "/ls/arap/dividendCoupon/adjust/search.do");
		map.put("BATCH_PRICE_CORRECTION", "/ls/fnd/toBatchFundAdjustment.do");
		map.put("UVL_CASH_FLOW_QUERY", "/ls/fnd/toUVLCashFlowSummary.do");

	}

	public void selectMenuItem(String mainMenu, String subMenu) throws Exception {
		// GenericFunctions.setStepDetails("Retrieve Text","Should be able to get the
		// text from component : "+webElementKey+"","N/A");
		// Hashtable<String, String> hTableGUIMap=
		// GlobalVariables.guiMap.get("MainMenuLocator");
		try {
			List<WebElement> menuItems = returnWebElements("web_lst_MainMenu");

			for (WebElement menu : menuItems) {
				if (menu.getText().equalsIgnoreCase(mainMenu)) {
					org.openqa.selenium.interactions.Actions act = new org.openqa.selenium.interactions.Actions(driver);
					act.moveToElement(menu).perform();
					;
					break;
				}
			}

			String currentUrl = driver.getCurrentUrl();
			String toReplace = "";
			switch (subMenu.toLowerCase()) {

			case "Maintain First Party":
			case "maintain first party":
				toReplace = "/ls/pty/toIdentifyParty.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;

			case "verification":
				toReplace = "/ls/pm/queryProofingPool.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;

			case "detail registration":
				toReplace = "/ls/pm/queryDetailPool.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;

			case "underwriting":
				toReplace = "/ls/uw/uwPool.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;

			case "receive counter collection":
				toReplace = "/ls/arap/cash/recv/counter/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "Scehduled Batch Task":
			case "scehduled batch task":
				toReplace = "/ls/sys/scd/toTest.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "Common Query":
			case "common query":
				toReplace = "/ls/qry/commonquery.CommonQuery.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "Search Party":
			case "search party":
				toReplace = "/ls/pty/toSearchParty.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "document_with_reply":
				toReplace = "/ls/cmu/replyDocument.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "publish_issue_document":
				toReplace = "/ls/cmu/issueDocument.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "authorisation_hrc_bypass":
				toReplace = "/ls/pty/byPassAMLScreening.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "batch query":
				toReplace = "/ls/sys/scd/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
				// Sahil:16/01/2019
			case "Health Warranty & Consent":
			case "health warranty & consent":
				toReplace = "/ls/pm/searchPolicyForConsent.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
				// Divya:Below submenu items are added for CSD 12/12/18
			case "new application registration":
				toReplace = "/ls/cs/commonflow.registration.EnterRegister.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "unlock frozen policy":
				toReplace = "/ls/cs/unfreezePolicy.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "application entry sharing pool":
				toReplace = "/ls/cs/commonflow.appentry.ApplicationEntryPool.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "financial manual adjustment":
				toReplace = "/ls/cs/policyalteration.trad.financmanualadjust.FmaDisplay.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;

			case "apply policy loan":
				toReplace = "/ls/cs/policyalteration.trad.applypolicyloan.ApplyPolicyLoanDisplay.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "reverse inforce":
				toReplace = "/ls/crt/toSelectProposalAction.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
				// claim processing pool Prashantha Feb 7
			case "claims processing pool":
				toReplace = "/ls/clm/processingpool/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "individual":
				toReplace = "/ls/prt/acknow.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;

			case "amend_proposal":
				toReplace = "/ls/pm/displayDetailRegAmend.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;

			case "withdrawal":
				toReplace = "/ls/pm/queryWithdrawProposal.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;

			case "case registration":
				toReplace = "/ls/clm/RegisterCase.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "extraction amount to bill":
				toReplace = "/ls/arap/subprem/extraction/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "perform manual extraction":
				toReplace = "/ls/arap/cash/banktransfer/manual/SearchAction.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "manually suspend and unsuspend extraction":
				toReplace = "/ls/arap/cash/banktransfer/suspend/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "payment requisition":
				toReplace = "/ls/arap/cash/pay/alloc/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "payment authorization":
				toReplace = "/ls/arap/cash/pay/auth/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "upload cpf file":
				toReplace = "/ls/arap/cash/banktransfer/upload.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "query cpf records pending extraction":
				toReplace = "/ls/arap/cash/banktransfer/query.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "giro upload approval":
				toReplace = "/ls/arap/cash/banktransfer/approveGiroUpload.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "cpf sa static/reconciliation upload":
				toReplace = "/ls/arap/cash/banktransfer/uploadCPFSAReturnFiles.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "upload & cancel rewards file":
				toReplace = "/ls/arap/cash/pay/rewards/uploadCancelRewardsFile.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;

			case "payment cancellation&expiry":
				toReplace = "/ls/arap/cash/pay/cancellation/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "batch cheque printing":
				toReplace = "/ls/arap/cash/pay/cancellation/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "cheque printing":
				toReplace = "/ls/arap/cash/pay/chkprt/online/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "change payment details":
				toReplace = "/ls/arap/cash/pay/change/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "cancel payment":
				toReplace = "/ls/arap/cash/pay/undo/search.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "cancel collection":
				toReplace = "/ls/crt/toCancleColSelAction.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "by policy":
				toReplace = "/ls/ri/queryByPolicy.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "by contract":
				toReplace = "/ls/ri/queryByContract.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			case "by treaty":
				toReplace = "/ls/ri/queryByTreaty.do";
				driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
				break;
			
			default:
				System.out.println("Wrong navigation");
				break;

			}

			DashboardHandler.getInstance().setStepDetails("Select Menu Item",
					"Main Menu " + mainMenu + " and SubMenu " + subMenu + " Should selected Successfully", "N/A");
			DashboardHandler.getInstance().writeResults();

		} catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while getting the text \n Please refer the Exception details %s",
					ex.getMessage()));
		}

	}

	public void selectTab(String tabName) throws Exception {
		try {
			List<WebElement> elements = driver.findElements(By.cssSelector(".link1"));

			for (WebElement element : elements) {
				if (element.getText().equalsIgnoreCase(tabName)) {
					WebDriverWait wait = new WebDriverWait(driver,
							Integer.parseInt(System.getProperty("Settings.ImplicitWait")));
					wait.pollingEvery(5, TimeUnit.SECONDS);
					wait.ignoring(Exception.class);
					wait.until(ExpectedConditions.visibilityOf(element));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", element);
					break;
				}
			}

		} catch (Exception e) {
			throw new LowLevelException("Failed to choose tab:" + tabName);
		}
		/*
		 * String currentUrl=driver.getCurrentUrl(); String toReplace=""; switch
		 * (tabName.toLowerCase()) {
		 * 
		 * case "Contact": case "contact": toReplace="/ls/pty/toContact.do"; driver
		 * .navigate().to(currentUrl.substring(0,currentUrl.indexOf("/ls")) +toReplace);
		 * break;
		 * 
		 * default: System.out.println("Wrong navigation"); break;
		 */

	}

	public void selectMenuItem(String mainMenu, String subMenu, String subOfSub) throws Exception {
		// Ugly way of doing
		try {
			List<WebElement> menuItems = returnWebElements("web_lst_MainMenu");
			for (WebElement menu : menuItems) {
				if (menu.getText().equalsIgnoreCase(mainMenu)) {
					org.openqa.selenium.interactions.Actions act = new org.openqa.selenium.interactions.Actions(driver);
					act.moveToElement(menu).perform();

					break;
				}
			}

			String currentUrl = driver.getCurrentUrl();
			String toReplace = "";
			switch (subMenu.toLowerCase()) {
			case "initial registration":
				switch (subOfSub.toLowerCase().trim()) {
				case "initial reg":
					toReplace = "/ls/pm/displayInitReg.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
				break;
			case "medical billing":
				switch (subOfSub.toLowerCase().trim()) {
				case "update billing":
					toReplace = "/ls/pm/toEnterMed.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
				break;
			case "despatch policy acknowledgement":
				switch (subOfSub.toLowerCase().trim()) {
				case "individual":
					toReplace = "/ls/prt/acknow.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
				break;
			case "perform cpf extraction":
				switch (subOfSub.toLowerCase().trim()) {
				case "perform cpf extraction - generate file":
					toReplace = "/ls/arap/cash/banktransfer/generateextract.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;

				case "perform cpf extraction - download file":
					toReplace = "/ls/arap/cash/banktransfer/downloadextract.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}

			case "policy document":
				switch (subOfSub.toLowerCase().trim()) {
				case "re-generate":

					driver.navigate()
					.to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + map.get("REGENERATE_POLICY"));
					break;
				}
			case "query payments":
				switch (subOfSub.toLowerCase().trim()) {
				case "paymentquery":
					toReplace = "/ls/gl/query/paymentQuery.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
			case "query accounting":
				switch (subOfSub.toLowerCase().trim()) {
				case "transaction query":
					toReplace = "/ls/gl/query/transactionQuery.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
			case "query fund pricing & cashflow":
				switch (subOfSub.toLowerCase().trim()) {
				case "ut cashflow query":
					toReplace = "/ls/fnd/toUTCashFlowSummary.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				case "ilp cashflow query":
					toReplace = "/ls/fnd/toCashFlowSummary.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				case "uvl cashflow query":
					toReplace = "/ls/fnd/toUVLCashFlowSummary.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
			case "perform cpf reconciliation": {
				switch (subOfSub.toLowerCase().trim()) {
				case "perform cpf reconciliation - generate file":
					toReplace = "/ls/arap/cash/banktransfer/generatereconciliate.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				case "perform cpf reconciliation - download file":
					toReplace = "/ls/arap/cash/banktransfer/downloadreconciliate.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
				break;
			}
			case "bcp": {
				switch (subOfSub.toLowerCase().trim()) {
				case "upload lockbox&ebank file":
					toReplace = "/ls/arap/cash/recv/efile/uploadFile.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;				
				}
				break;
			}

			default:
				System.out.println("Wrong navigation");
				break;
			}
			DashboardHandler.getInstance().setStepDetails("Select Menu Item",
					"Main Menu " + mainMenu + " and SubMenu " + subOfSub + " Should selected Successfully", "N/A");
			DashboardHandler.getInstance().writeResults();

		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while getting the text \n Please refer the Exception details %s",
					ex.getMessage()));
		}
	}

	public void selectMenuItem(String mainMenu, String MenuLevel1, String MenuLevel2, String MenuLevel3)
			throws Exception {
		// Ugly way of doing
		try {
			List<WebElement> menuItems = returnWebElements("web_lst_MainMenu");
			for (WebElement menu : menuItems) {
				if (menu.getText().equalsIgnoreCase(mainMenu)) {
					org.openqa.selenium.interactions.Actions act = new org.openqa.selenium.interactions.Actions(driver);
					act.moveToElement(menu).perform();

					break;
				}
			}

			String currentUrl = driver.getCurrentUrl();
			String toReplace = "";
			switch (MenuLevel2.toLowerCase()) {

			case "system config":

				switch (MenuLevel3.toLowerCase().trim()) {
				case "setting system date":
					toReplace = "/ls/tool/setSysdateAction.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
				break;
			case "credit card transfer": {
				switch (MenuLevel3.toLowerCase().trim()) {
				case "credit card bank download file":
					toReplace = "/ls/arap/cash/banktransfer/downloadcreditextract.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;

				case "credit card banktransfer upload file":
					toReplace = "/ls/arap/cash/banktransfer/uploadcreditcard.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
				break;
			}
			case "giro bank transfer": {
				switch (MenuLevel3.toLowerCase().trim()) {
				case "download giro bank file":
					toReplace = "/ls/arap/cash/banktransfer/downloadgiro.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;

				case "upload giro bank file":
					toReplace = "/ls/arap/cash/banktransfer/uploadgiro.do";
					driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
					break;
				}
				break;
			}

			default:
				System.out.println("Wrong navigation");
				break;

			}

			DashboardHandler.getInstance().setStepDetails("Select Menu Item",
					"Main Menu " + mainMenu + " and SubMenu " + MenuLevel3 + " Should selected Successfully", "N/A");
			DashboardHandler.getInstance().writeResults();
		}

		catch (Exception ex) {

			throw new LowLevelException(String.format(
					"General Exception has been occured while getting the text \n Please refer the Exception details %s",
					ex.getMessage()));
		}
	}

	public void AcceptCertificateError() {

		try {

			driver.get("javascript:document.getElementById('overridelink').click();");
			// driver.get("javascript:document.getElementById('overridelink').click();");
		} catch (Exception e) {
			System.out.println("Excpetion");
		}

	}

	public boolean switchtoChildWindow(String title, String index) {
		try {
			for (int i = 0; i < 15; i++) {

				Set<String> allWindows = driver.getWindowHandles();

				for (String currentWindow : allWindows) {
					driver.switchTo().window(currentWindow);
					if (driver.getTitle().equalsIgnoreCase(title)) {
						return true;
					}
				}

				Utils.sleep(5);
			}
		} catch (Exception e) {
			System.out.println("");
		}

		return false;

	}

	public void goMenuItem(String item, String mainMenu) throws Exception {

		List<WebElement> menuItems = returnWebElements(mainMenu);

		for (WebElement menu : menuItems) {
			if (menu.getText().equalsIgnoreCase(item)) {
				org.openqa.selenium.interactions.Actions act = new org.openqa.selenium.interactions.Actions(driver);
				act.moveToElement(menu).perform();
				;
				break;
			}
		}

	}

	public void selectMenuItem(String item) throws Exception {

		String currentUrl = driver.getCurrentUrl();
		String toReplace = map.get(item);
		driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + toReplace);
	}

	public void handleCertificateErrors() {
		Set<String> allWindows = driver.getWindowHandles();
		for (String currentWindow : allWindows) {

			if (driver.switchTo().window(currentWindow).getTitle()
					.equalsIgnoreCase(FPMSConstants.CERTIFICATE_ERR_NAVIGATION_BLOCKED))
				AcceptCertificateError();
		}

	}

	public HashMap<String, Integer> getFPMSScreenDimensions() throws Exception {
		try {
			HashMap<String, Integer> hMap = new HashMap<String, Integer>();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			int totalHeight = Math.toIntExact((Long) js.executeScript("return document.body.scrollHeight"));
			int windowHeight = Math.toIntExact((Long) js.executeScript("return document.body.clientHeight"));
			int windowWidth = Math.toIntExact((Long) js.executeScript("return document.body.clientWidth"));
			hMap.put("totalHeight", totalHeight);
			hMap.put("windowHeight", windowHeight);
			hMap.put("windowWidth", windowWidth);
			return hMap;
		} catch (Exception ex) {
			throw new LowLevelException(ex);
		}
	}

	public void scrollTo(int width, int height) throws Exception {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(" + width + ", " + height + ")");
		} catch (Exception ex) {
			throw new LowLevelException(ex);
		}
	}

	/**
	 * This method is NOT WORKING and should be investigated and use in future. This
	 * method shall take an array of menu items and iterate through each and select.
	 * 
	 * @param mi
	 *            - array of menu items to browse
	 * @param url
	 *            - final url to be selected
	 */
	public void selectMenuItems(String[] mi, String url) {
		org.openqa.selenium.interactions.Actions act = new org.openqa.selenium.interactions.Actions(driver);
		for (int i = 0; i < mi.length; i++) {

			Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(mi[i]);
			try {
				WebElement e = new ObjectIdentifier(driver).FindObject(hTableGUIMap.keySet().toArray()[0].toString(),
						hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
				e.click();
				// act.clickAndHold(e).perform();

				Thread.sleep(100);
			}

			catch (Exception ex) {
				throw new LowLevelException(String.format(
						"General Exception has been occured while Finding list of WebElemnt for Key %s\n Please refer the Exception details %s",
						i, ex.getMessage()));
			}

		}
		String currentUrl = driver.getCurrentUrl();
		driver.navigate().to(currentUrl.substring(0, currentUrl.indexOf("/ls")) + map.get(url));
	}

	public void enterValuewithAlert(String webElementKey, String value) throws Exception {
	
	
		if (value != null && !value.isEmpty()) {
			try {

				/*
				 * dashboard.setStepDetails("Enter Value", "Value: " + value +
				 * " should be Entered to the text field: " + webElementKey, webElementKey);
				 */
				// dashboard.setStepDetails("Enter");
				Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap.get(webElementKey);

				WebElement element = new ObjectIdentifier(driver).FindObject(
						hTableGUIMap.keySet().toArray()[0].toString(),
						hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));

				if (element.isDisplayed() && element.isEnabled()) {
				
						System.out.println("1");
						String readonly = element.getAttribute("readonly");
					if (!"true".equalsIgnoreCase(readonly)) {
						//element.clear();
					//	element.sendKeys(value);
						//handleMultipleAlerts((long)2);
						element.sendKeys(Keys.chord(Keys.CONTROL, "a"), value);
				
						System.out.println("2");
					//	sendkeyStroke(webElementKey,Keys.TAB);

						Utils.sleep(5);
						//notify(webElementKey);
						
					}
					
				}

			} catch (ElementNotVisibleException ex) {

				throw new LowLevelException(
						String.format("Element= %s is not visible to Enter value =%s ", webElementKey, value));
			} catch (StaleElementReferenceException ex) {
				throw new LowLevelException(String.format(
						"Element was not clickable as the page reloaded before the actual the Enter value =%s has been occured ",
						webElementKey, value));
			}

			catch (UnexpectedTagNameException ex) {
				throw new LowLevelException(String.format(
						"Unexpected tag name error has been found before the actual Enter value =%s happend on Element %s",
						webElementKey, value));
			}
			catch (WebDriverException ex) {
				throw new LowLevelException(String.format(
						"Current browser is closed or Terminated before the actual value enter =%s occured for Element =%s",
						webElementKey, value));
			}
			

			catch (Exception ex) {

				throw new LowLevelException(String.format(
						"  General Exception  has been occured while entering the value %s on Element %s \n Please refer the Exception details %s",
						value, webElementKey, ex.getMessage()));
			}

		}
	}
}
