package ge.fpms.main.bpc.nbu.components.benefits;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.IBenefits;
import ge.fpms.main.actions.FPMS_Actions;

import java.util.Hashtable;
import java.util.logging.Logger;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;

public class ILPBenefits extends MainBenefits implements IBenefits {
	private final static Logger LOGGER = Logger.getLogger(ILPBenefits.class.getName());
	private FPMS_Actions llAction;
	
	public ILPBenefits() {

		super();
		llAction = new FPMS_Actions();

	}

	@Override
	public void addBenefitsDetails(Hashtable<String, String> hParams) throws Exception {
		super.addBenefitsDetails(hParams);
		setPremiumAmount(hParams.get("PremiumAmount"));
		setInitialSumAssured(hParams.get("InitialSumAssured"));
		setWrapFeeOption(hParams.get("WrapFeeOption"));
		setAutoReBalancingIND(hParams.get("AutoReBalancingIND"));
		addFunds(hParams);
		save();
	}
	
	public void addFunds(Hashtable<String, String> hParams) {
		try {
			// Read hparams ..fund code 1 & fund 1 % , fund 2 code and fund 2
			// app
			Hashtable<String, String> fundElementTag = ARTProperties.guiMap.get("web_tbl_FundDetails");
			String fundTablePath = fundElementTag.get(fundElementTag.keySet().toArray()[0]);
			
			//Deleting the existing fund, if exist
			int size = llAction.getSize(fundTablePath);
			if (size > 1) {
				for (int i = 2; i <= size; i++) {
					String temploc = fundTablePath + "/tbody/tr[" + i + "]/td[1]/input";
					WebElement checkBox = llAction.findElementByXpath(temploc);
					checkBox.click();
				}
				llAction.clickElement("web_btn_fund_delete");
			}

			int noOfFunds = Integer.parseInt(hParams.get("MBNoOfFunds"));

			for (int i = 1; i <= noOfFunds; i++) {

				llAction.clickElement("web_btn_FundAdd");
				Utils.sleep(2);
				Fund obj = new Fund();

				int rowId = i + 1;
				String temploc1 = fundTablePath + "/tbody/tr[" + rowId
						+ "]/td[2]/input[1]";
				WebElement Code = llAction.findElementByXpath(temploc1);
				obj.setFundCode(Code, hParams.get(FPMSConstants.FUNDCODE + i));

				llAction.sendkeyStroke("web_txt_FundCode", Keys.ENTER);

				
				String temploc2 = fundTablePath + "/tbody/tr[" + rowId
						+ "]/td[3]/input[2]";
				WebElement apportionmentPer = llAction
						.findElementByXpath(temploc2);
				obj.setFundApportionmentPercentage(apportionmentPer,
						hParams.get(FPMSConstants.APPORTIONMENT + i));
				apportionmentPer.sendKeys(Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
	public ILPBenefits createBenefits()
	{
		return new ILPBenefits();
	}

	@Override
	public void getBenefitsType(String type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public IBenefits createRider() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setBenefitsType(String type) {
		try {
			llAction.enterValue("web_benefits_internalIdNew", type);
			llAction.sendkeyStroke("web_benefits_internalIdNew", Keys.ENTER);
			llAction.sleep(5);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	public void setFDCV(String fdcv) {
		try {
			llAction.enterValue("web_benefits_fdcv", fdcv);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	public void setExpenseRate(String rate) {
		try {
			llAction.enterValue("web_benefits_expenseRate", rate);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

}
