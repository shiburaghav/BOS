package ge.fpms.main.bpc.csd;
import java.util.Hashtable;
import org.openqa.selenium.WebElement;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class SumAssured {

	// Name: SumAssured
	// Purpose: Navigate to CS module from the Main Page and increase sum assured
	// for a policy
	// Parameters : Parameter Hash table
	// Return Value: NA
	// Exception: BPCException
	// @author: Prashantha on 21/12/2018
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public SumAssured() {
		dashboard = DashboardHandler.getInstance();
		llAction = new FPMS_Actions();
	}

	// Select Benefits
	public void selectBenefit(String tableElementKey, String benefitCode) throws Exception {
		try {

			// switch (actionType.toUpperCase()) {
			// case "BEFORECHANGE":
			llAction.waitUntilElementPresent(tableElementKey);
			int BenefitalterCol = llAction.GetColumnPositionInTable(tableElementKey, "Benefit");
			int BenefitalterRow = llAction.GetRowPositionInTable(tableElementKey, benefitCode, BenefitalterCol);

			// int SumAssuredBeforeChangeCol =
			// llAction.GetColumnPositionInTable("web_tbl_ILPDecreaseBenefitSABeforeChange",
			// "Sum Assured");
			llAction.SelectRowInTable(tableElementKey, BenefitalterRow, BenefitalterCol - 2, "input");
			dashboard.setStepDetails(
					"Select benefit by select radio button under Benefit information before change section.",
					"Benefit is selected.", "N/A");
			dashboard.writeResults();

		} catch (Exception ex) {
			throw new BPCException(ex);

		}
	}

	// Validate the validity date error
	public void validateValidityDateWarning(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			selectBenefit("web_tbl_ILPBenefitSA", hParams.get("BenefitCode"));
			llAction.clickElement("web_btn_IncreaseSA");
			llAction.waitUntilLoadingCompletes();

			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
				String message = hParams.get("WarningErrorMessage");
				CSDHelper.getInstance().validateWarningMessages("web_tbl_fullsurrender_warning_msg", message);
			}

		} catch (Exception ex) {
			throw new BPCException(ex);

		}
	}

	// Validate the Enter Information Error
	// Validate the validity date error
	public void validateAfterEnterInformationError(Hashtable<String, String> hParams) throws Exception {
		try {

			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
				String message = hParams.get("WarningErrorMessage");
				CSDHelper.getInstance().validateWarningMessages("web_tbl_fullsurrender_warning_msg", message);
			}

		} catch (Exception ex) {
			throw new BPCException(ex);

		}
	}

	public void ilpDecreaseSumAssured(Hashtable<String, String> hParams) throws Exception {
		try {
			String initialSumAssured = hParams.get("InitialSumAssured");
			String BenefitCode = hParams.get("BenefitCode");

			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			String initialSABeforeChange = captureBenefitInfo("web_tbl_ILPDecreaseBenefitSABeforeChange", BenefitCode,
					"Sum Assured");
			selectBenefit("web_tbl_ILPDecreaseBenefitSABeforeChange", hParams.get("BenefitCode"));
			String clickButtonName = hParams.get("DecreaseSAfrom");
			String temp = "web_btn_" + clickButtonName.replace(" ", "_").toLowerCase();
			llAction.clickElement(temp);
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on button", clickButtonName + " is clicked", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_InitialSumAssured", initialSumAssured);
			dashboard.setStepDetails("Decrease Initial Sum Assured amount by:" + initialSumAssured,
					"System should accept input details.", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_save");
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
				String message = hParams.get("WarningErrorMessage");
				CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg", message);
			} else {
				String initialSAAfterChange = captureBenefitInfo("web_tbl_ILPDecreaseBenefitSAAfterChange", BenefitCode,
						"Sum Assured");
				if (initialSABeforeChange.equals(initialSAAfterChange)) {
					dashboard.setStepDetails("Validate ILP Sum Assured is decreased",
							"It is not decreased;Before Change:=" + initialSAAfterChange + "After Change:="
									+ initialSAAfterChange,
							"N/A");
					dashboard.writeResults();
				} else {
					dashboard.setStepDetails("Validate ILP Sum Assured is decreased", "It is decreased;Before Change:="
							+ initialSAAfterChange + "After Change:=" + initialSAAfterChange, "N/A");
					dashboard.writeResults();
				}
				llAction.clickElement("web_btn_recurring_common_submit_button");
				CSDHelper.getInstance().endOfTransaction();
			}
		}

		catch (Exception ex) {
			throw new BPCException(ex);

		}
	}

	public String captureBenefitInfo(String tableElementKey, String benefitCode, String columnName) throws Exception {
		try {

			llAction.waitUntilElementPresent(tableElementKey);
			int BenefitInfoCol = llAction.GetColumnPositionInTable(tableElementKey, "Benefit");
			int sumAssuredCol = llAction.GetColumnPositionInTable(tableElementKey, columnName);
			int BenefitalterRow = llAction.GetRowPositionInTable(tableElementKey, benefitCode, BenefitInfoCol);
			WebElement ILPSumAssuredAfterChange = llAction.getElementAt(tableElementKey, BenefitalterRow, sumAssuredCol,
					"/input");
			String capturedValue = ILPSumAssuredAfterChange.getAttribute("value");
			return capturedValue;
		}

		catch (Exception ex) {
			throw new BPCException(ex);

		}

	}

	public void Submit(String expectedResult, String screenName, boolean writeResult) throws Exception {
		try {

			llAction.clickElement("web_btn_recurring_common_submit_button");
			llAction.waitUntilLoadingCompletes();
			if (!writeResult) {
				dashboard.setStepDetails("Click on Submit button " + screenName, expectedResult, "N/A");
				dashboard.writeResults();
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateDecreaseSumAssuredWarning(Hashtable<String, String> hParams) throws Exception {
		try {

			String message = hParams.get("WarningErrorMessage");
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			selectBenefit("web_tbl_ILPDecreaseBenefitSABeforeChange", hParams.get("BenefitCode"));
			String clickButtonName = hParams.get("DecreaseSAfrom");
			String temp = "web_btn_" + clickButtonName.replace(" ", "_").toLowerCase();
			llAction.clickElement(temp);
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on button", clickButtonName + " is clicked", "N/A");
			dashboard.writeResults();
			CSDHelper.getInstance().validateWarningMessages("web_tbl_WarningTable", message);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void decreaseSumAssured(Hashtable<String, String> hParams) throws Exception {
		try {
			String decreaseSAOption = hParams.get("DecreaseSAfrom");
			llAction.waitUntilElementPresent("web_tbl_ILPDecreaseBenefitSABeforeChange");
			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_ILPDecreaseBenefitSABeforeChange",
					"Benefit");
			int SumAssuredBeforeChangeCol = llAction
					.GetColumnPositionInTable("web_tbl_ILPDecreaseBenefitSABeforeChange", "Sum Assured");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_ILPDecreaseBenefitSABeforeChange",
					hParams.get("BenefitCode"), BenefitalterCol);
			llAction.SelectRowInTable("web_tbl_ILPDecreaseBenefitSABeforeChange", BenefitalterRow, BenefitalterCol - 2,
					"input");
			dashboard.setStepDetails(
					"Select benefit by select radio button under Benefit information before change section.",
					"Benefit is selected.", "N/A");
			dashboard.writeResults();
			WebElement ILPSumAssuredBeforeChange = llAction.getElementAt("web_tbl_ILPDecreaseBenefitSABeforeChange",
					BenefitalterRow, SumAssuredBeforeChangeCol, "/input");
			String ILPSABeforeChange = ILPSumAssuredBeforeChange.getAttribute("value");

			switch (decreaseSAOption.toUpperCase()) {
			case "DECREASE SA IMMEDIATELY":
				llAction.move_to_element("web_btn_ILPDescreaseSAImmediately");
				llAction.clickElement("web_btn_ILPDescreaseSAImmediately");
				break;
			case "DECREASE SA FROM LAST RISK CHARGE DATE":
				llAction.move_to_element("web_btn_ILPDescreaseSALstRskChrgDt");
				llAction.clickElement("web_btn_ILPDescreaseSALstRskChrgDt");
				break;
			case "DECREASE SA FROM NEXT RISK CHARGE DATE":
				llAction.move_to_element("web_btn_ILPDescreaseSANxtRskChrgDt");
				llAction.clickElement("web_btn_ILPDescreaseSANxtRskChrgDt");
				break;
			}
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on '" + decreaseSAOption + "''" + "button.",
					"System should display Benefit Information screen.", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_InitialSumAssured", hParams.get("InitialSumAssured"));
			dashboard.setStepDetails("Decrease Initial Sum Assured amount.", "System should accept input details.",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_save");
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
				String getWarningMsg = llAction.getText("web_txt_ErrorWarning").trim();
				validateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage"));
				llAction.clickElement("web_btn_ContinueRP");
			}
			llAction.waitUntilLoadingCompletes();

			// Validate change of the record.
			llAction.waitUntilElementPresent("web_tbl_ILPDecreaseBenefitSAAfterChange");
			BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_ILPDecreaseBenefitSAAfterChange", "Benefit");
			BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_ILPDecreaseBenefitSAAfterChange",
					hParams.get("BenefitCode"), BenefitalterCol);
			WebElement ILPSumAssuredAfterChange = llAction.getElementAt("web_tbl_ILPDecreaseBenefitSAAfterChange",
					BenefitalterRow, SumAssuredBeforeChangeCol, "/input");
			String ILPSAAfterChange = ILPSumAssuredAfterChange.getAttribute("value");
			if (ILPSABeforeChange.equals(ILPSAAfterChange)) {
				dashboard.setStepDetails("Validate ILP Sum Assured is decreased",
						"It is not decreased;Before Change:=" + ILPSABeforeChange + "After Change:=" + ILPSAAfterChange,
						"N/A");
				dashboard.writeResults();

			} else {
				dashboard.setStepDetails("Validate ILP Sum Assured is decreased",
						"It is decreased;Before Change:=" + ILPSABeforeChange + "After Change:=" + ILPSAAfterChange,
						"N/A");
				dashboard.writeResults();

			}
			llAction.clickElement("web_btn_SubmitChangeRP");
			CSDHelper.getInstance().endOfTransaction();
		}
		catch (Exception ex) {
			throw new BPCException(ex);
		}

	}
	
	public void increaseSumAssured(Hashtable<String, String> hParams) throws Exception {
		try {			
			String clickButtonName = hParams.get("IncreaseSAfrom");
			if (llAction.isDisplayed("web_btn_ContinueRP")) {
					llAction.clickElement("web_btn_ContinueRP");
			}
			llAction.waitUntilLoadingCompletes();
						
			llAction.enterValue("web_txt_IncreaseSAValidateDate", hParams.get("Validitydate"));
			dashboard.setStepDetails("Enter validity date",
					"Valid Validity date is entered.", "N/A");
			dashboard.writeResults();  		
						
			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_IncreaseSABeforeChange", "Benefit Name");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_IncreaseSABeforeChange",
					hParams.get("BenefitCode"), BenefitalterCol);
			llAction.SelectRowInTable("web_tbl_IncreaseSABeforeChange", BenefitalterRow, BenefitalterCol-2, "input");
			dashboard.setStepDetails("Select benefit by select radio button under Benefit information before change section.",
					"Rider benefit is selected.", "N/A");
			dashboard.writeResults();			
			llAction.clickElement("web_btn_" + clickButtonName.replace(" ", "_").toLowerCase());
			dashboard.setStepDetails("Click button",
					clickButtonName + " is clicked", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			if ( hParams.get("WarningErrorMessage")!=null && hParams.get("WarningErrorMessage")!="" )
			{							
				CSDHelper.getInstance().validateWarningMessages("web_tbl_PolicyLoanWarning",hParams.get("WarningErrorMessage"));
				llAction.waitUntilLoadingCompletes();				
				
			}				
			
		} 
				
		catch (Exception ex) {			
			throw new BPCException(ex);
		}
		
	}	
		
	public void validateWarningMessages(String warningMsg, String message) throws Exception {
		try {
			if (warningMsg.contains(message)) { // compare warning messages
				dashboard.setStepDetails(message + "Warning message should be displayed",
						"\"Warning message should is displayed ", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(
						"Warning message " + warningMsg + " from application is not matching with test data");
				dashboard.writeResults();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);

		}

	}
	
	public void ilpIncreaseSumAssured(Hashtable<String, String> hParams) throws Exception {
		try {
			String increaseSA = hParams.get("IncrInitialSumAssured");
			String increaseSAMaxlimit = hParams.get("IncreaseSAMaxLimit");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			llAction.waitUntilElementPresent("web_tbl_ILPBenefitSA");

			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_ILPBenefitSA", "Benefit");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_ILPBenefitSA", hParams.get("BenefitCode"),
					BenefitalterCol);
			llAction.SelectRowInTable("web_tbl_ILPBenefitSA", BenefitalterRow, BenefitalterCol - 2, "input");
			dashboard.setStepDetails(
					"Select benefit by select radio button under Benefit information before change section.",
					"Rider benefit is selected.", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_IncreaseSA");
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
				CSDHelper.getInstance().validateWarningMessages("web_tbl_WarningTable_ilpIncreaseSA",
						hParams.get("WarningErrorMessage"));
			} else {
				if (increaseSAMaxlimit.isEmpty() == false) {

					llAction.enterValue("web_txt_InitialSumAssured", increaseSAMaxlimit);
					dashboard.setStepDetails("Fill in initial sum assure field with." + increaseSAMaxlimit,
							"System should accept input details.", "N/A");
					dashboard.writeResults();
					llAction.clickElement("web_btn_save");
					CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg",
							hParams.get("WarningErrorMessage1"));
				}
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_InitialSumAssuredChange", increaseSA);
				dashboard.setStepDetails("Fill in initial sum assure field with." + increaseSA,
						"System should accept input details.", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_save");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("The ILP Sum Assured is increased with:=" + increaseSA,
						"System should save record and display ILP Increase Sum Assured screen.", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_SubmitChangeRP");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().endOfTransaction();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void validateIncreaseSAPolicyEntryError(Hashtable<String, String> hParams) throws Exception {
		try {

			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
				String message = hParams.get("WarningErrorMessage");
				CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg", message);
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateIncreaseSAOptionSelectionError(Hashtable<String, String> hParams) throws Exception {
		try {

			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
				String message = hParams.get("WarningErrorMessage");
				CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg", message);
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateSumAssuredLimitError(Hashtable<String, String> hParams) throws Exception {
		try {

			String increaseSAMaxlimit = hParams.get("IncreaseSAMaxLimit");

			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			llAction.waitUntilElementPresent("web_tbl_ILPBenefitSA");

			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_ILPBenefitSA", "Benefit");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_ILPBenefitSA", hParams.get("BenefitCode"),
					BenefitalterCol);
			llAction.SelectRowInTable("web_tbl_ILPBenefitSA", BenefitalterRow, BenefitalterCol - 2, "input");
			dashboard.setStepDetails(
					"Select benefit by select radio button under Benefit information before change section.",
					"Rider benefit is selected.", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_IncreaseSA");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_InitialSumAssured", increaseSAMaxlimit);
			dashboard.setStepDetails("Fill in initial sum assure field with." + increaseSAMaxlimit,
					"System should accept input details.", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_save");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().validateWarningMessages("web_tbl_WarningTable_ilpIncreaseSA",
					hParams.get("WarningErrorMessage1"));

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}


}
