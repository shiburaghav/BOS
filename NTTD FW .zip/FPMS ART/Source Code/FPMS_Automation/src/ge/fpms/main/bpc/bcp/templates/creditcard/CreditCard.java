package ge.fpms.main.bpc.bcp.templates.creditcard;

import java.util.ArrayList;

public class CreditCard {
	private FileHeader FileHeader;
	private ArrayList<BatchRecord> BatchRecord;
	private FileFooter FileFooter;

	public FileHeader getFileHeader() {
		return FileHeader;
	}

	public void setFileHeader(FileHeader fileHeader) {
		FileHeader = fileHeader;
	}
	
	public ArrayList<BatchRecord> getBatchRecords() {
		return BatchRecord;
	}

	public void setBatchRecords(ArrayList<BatchRecord> batchRecords) {
		BatchRecord = batchRecords;
	}

	public FileFooter getFileFooter() {
		return FileFooter;
	}

	public void setFileFooter(FileFooter fileFooter) {
		FileFooter = fileFooter;
	}

}
