package ge.fpms.main;

import java.util.Hashtable;

public interface ILoadingType {
	public static String Loading_Type1 = "1";
	public static String Loading_Type2 = "2";
	public static String Loading_Type3 = "3";
	public static String Loading_Type4 = "4";
	public static String Loading_Type5 = "5";
	public static String Loading_Type6 = "6";
	public static String Loading_Type7 = "7";
	public static String Loading_Type8 = "8";
	public void enterSpecificLoadingTypeInfo(Hashtable<String, String> hParams) throws Exception;
}
