package ge.fpms.main.bpc.nbu;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;

public class DocumentManagement {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	
	
	public DocumentManagement() {
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}
	/* Name: SearchLCALetters
	Purpose: Navigate to Search Document Page from the Main Page and Search a Document based on 
	Main Category, Sub Category, Template Name and Policy.
	Parameters:  Parameter Hash table
	Return Value: NA    
	Exception: BPCException 
	Added By: ManjuPrasad 0n 27/11/2018 */
	public void SearchLCALetters(Hashtable<String, String> hParams) throws Exception {
		String policyNumber;
		String mainCategory = hParams.get("MainCategory");
		String subCategory = hParams.get("SubCategory");
		String templateName = hParams.get("TemplateName");
		try 
		{
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			
			String URL = llAction.getCurrentURL();
			if(!URL.contains("/ls/mainMenu.do")) {
				String[] parts = URL.split("/ls");
				String toReplace = "/ls/mainMenu.do";
				URL = parts[0] + toReplace;
				llAction.navigatetoUrl(URL);
			}
			
			llAction.selectMenuItem("Document Management", "Publish_Issue_Document");
			llAction.waitUntilLoadingCompletes();
			if (mainCategory.isEmpty() == false) 
			{
				llAction.selectByVisibleText("web_dm_lst_DMSMainCategory", mainCategory);
			}
			Utils.sleep(3);
			if (subCategory.isEmpty() == false) 
			{
				llAction.selectByVisibleText("web_dm_lst_DMSSubCategory", subCategory);
			}
			Utils.sleep(3);
			if (templateName.isEmpty() == false) 
			{
				llAction.selectByVisibleText("web_dm_lst_DMSTemplateName", templateName);
			}
			Utils.sleep(3);
			if (policyNumber.isEmpty() == false) 
			{
				llAction.clickElement("web_dm_txt_DMSPolicyNo");
				llAction.enterValue("web_dm_txt_DMSPolicyNo", policyNumber);
			}
			Utils.sleep(3);
			dashboard.setStepDetails("Click on Search Button",
					"Page refreshes and Displays all the documents based on the Search Criteria", "N/A");
			llAction.clickElement("web_dm_btn_DMSSearch");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
		}
		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void SelectLCALetter(Hashtable<String, String> hParams) throws Exception {
		try {
			String DocsToBeSelected = hParams.get("DocumentsToBeSelected");
			String TemplateName = hParams.get("TemplateName");
			if (DocsToBeSelected.toUpperCase().equals("ALL")) {
				
				String TableFirstRowData = llAction.getText("web_dm_tbl_DMSDocListRow");
				if(StringUtils.isEmpty(TableFirstRowData))
				{
					llAction.checkBox_Check("web_dm_check_DMSDocListAll");
					llAction.waitUntilLoadingCompletes();
					dashboard.setStepDetails("Select any "+ TemplateName +" Document from the Document List" ,
							"User should be able to Select a Document", "N/A");
					dashboard.writeResults();
					
				}
				else {
					dashboard.setStepDetails("No Documents to select from the Document List" ,
							"No Documents to select from the Document List", "N/A");
					dashboard.writeResults();
				}
			} else {
				int colPos = llAction.GetColumnPositionInTable("web_dm_tbl_DMSDocList", "Template Name");
				int rowPos = llAction.GetRowPositionInTable("web_dm_tbl_DMSDocList", DocsToBeSelected, colPos);
				llAction.SelectRowInTable("web_dm_tbl_DMSDocList", rowPos, 1,"input");
			}
		}
		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void DocumentWithReply(Hashtable<String, String> hParams) throws Exception {
		String policyNumber;
		String mainCategory = hParams.get("MainCategory");
		String subCategory = hParams.get("SubCategory");
		String templateName = hParams.get("TemplateName");
		try {
			
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			
			llAction.selectMenuItem("Document Management", "Document_With_Reply");
			llAction.waitUntilLoadingCompletes();
			if (mainCategory.isEmpty() == false) 
			{
				llAction.selectByVisibleText("web_drp_lst_MainCategory", mainCategory);
			}
			Utils.sleep(3);
			if (subCategory.isEmpty() == false) 
			{
				llAction.selectByVisibleText("web_drp_lst_SubCategory", subCategory);
			}
			Utils.sleep(3);
			if (templateName.isEmpty() == false) 
			{
				llAction.selectByVisibleText("web_drp_lst_TemplateName", templateName);
			}
			Utils.sleep(3);
			if (policyNumber.isEmpty() == false) 
			{
				llAction.clickElement("web_drp_txt_PolicyNo");
				llAction.enterValue("web_dm_txt_DMSPolicyNo", policyNumber);
			}
			Utils.sleep(3);
			llAction.move_to_element("web_drp_btn_Search");
			llAction.clickElement("web_drp_btn_Search");
			dashboard.setStepDetails("Click on Search Button",
					"Page refreshes and Displays all the documents based on the Search Criteria", "N/A");
			dashboard.writeResults();
			llAction.waitUntilLoadingCompletes();
			
			String TableFirstRowData = llAction.getText("web_drp_tbl_DocListRow");
			if(StringUtils.isEmpty(TableFirstRowData))
			{
				llAction.move_to_element("web_drp_check_DocListAll");
				llAction.clickElement("web_drp_check_DocListAll");
				
				llAction.move_to_element("web_drp_btn_CloseCase");
				llAction.clickElement("web_drp_btn_CloseCase");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Click on Close Case Button",
						"Page refreshes and Closes All Documents", "N/A");
				dashboard.writeResults();
			}
			else {
				dashboard.setStepDetails("No Documents to select from the Document List" ,
						"No Documents to select from the Document List", "N/A");
				dashboard.writeResults();
			}
			
			llAction.clickElement("web_drp_btn_Exit");
			llAction.waitUntilLoadingCompletes();
		}
		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void PerformActionOnSelectedLetters(Hashtable<String, String> hParams) throws Exception {
		String ActionOnSelectedLetters = hParams.get("ActionOnSelectedDocuments");
		try {
			String TableFirstRowData = llAction.getText("web_dm_tbl_DMSDocListRow");
			if(StringUtils.isEmpty(TableFirstRowData))
			{
				switch(ActionOnSelectedLetters.toUpperCase())
				{
				case "DEFAULTISSUE":
					dashboard.setStepDetails("Click on DEFAULT ISSUE Button",
							"User Should be able to see the PDF", "N/A");
					llAction.clickElement("web_dm_btn_DMSDefaultIssue");
					llAction.waitUntilLoadingCompletes();
					llAction.switchtoSecondWindow();
					llAction.ClickOnOverideLink();
					Utils.sleep(20);
					dashboard.writeResults();
					llAction.closeCurrentWindow();
					dashboard.setStepDetails("Validate if Document Status is Published/Issued" ,
							"Document Status should be Published/Issued", "N/A");
					dashboard.writeResults();
					break;
				case "PRINTLOCAL": 
					llAction.clickElement("web_dm_btn_DMSPrintLocal");
					llAction.waitUntilLoadingCompletes();
					llAction.switchtoSecondWindow();
					llAction.ClickOnOverideLink();
					Utils.sleep(20);
					llAction.closeCurrentWindow();
					dashboard.setStepDetails("Validate if Document Status is Published/Issued" ,
							"Document Status should be Published/Issued", "N/A");
					dashboard.writeResults();
					break;
				case "PRINTINEDMS": 
					//TODO To be Enhanced if any TC Requires
					break;
				case "EMAIL": 
					//TODO To be Enhanced if any TC Requires
					break;
				case "PUBLISH": 
					llAction.clickElement("web_dm_btn_Publish");
					llAction.waitUntilLoadingCompletes();
					dashboard.setStepDetails("Validate if Document Status is Published/Issued" ,
							"Document Status should be Published/Issued", "N/A");
					dashboard.writeResults();
					break;
				case "PUBLISHALL": 
					llAction.clickElement("web_dm_btn_PublishAll");
					llAction.waitUntilLoadingCompletes();
					dashboard.setStepDetails("Validate if Document Status is Published/Issued" ,
							"Document Status should be Published/Issued", "N/A");
					dashboard.writeResults();
					break;
				}
			}
			llAction.clickElement("web_dm_btn_DMSExit");
			llAction.waitUntilLoadingCompletes();
		}
		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
