package ge.fpms.main.bpc.bcp.templates.creditcard;

import java.util.ArrayList;

public class BatchRecord {

	private Header Header;
	private ArrayList<Details> Details;
	private Summary Summary;
	
	public BatchRecord(Header newHeader,
			ArrayList<Details> detailList,
			Summary newSummary) {
		this.Header = newHeader;
		this.Details = detailList;
		this.Summary = newSummary;
	}

	public Header getHeader() {
		return Header;
	}

	public void setFH(Header headers) {
		Header = headers;
	}

	public ArrayList<Details> getDetails() {
		return Details;
	}

	public void setDetails(ArrayList<Details> details) {
		Details = details;
	}

	public Summary getSummary() {
		return Summary;
	}

	public void setSummary(Summary summary) {
		Summary = summary;
	}
}
