package ge.fpms.main.bpc.nbu;

public interface BatchConstants {
	public static final String BATCH_NO_OF_JOBS = "NoOfJobs";
	public static final String BATCH_DUE_DATE = "BatchDueDate";
	public static final String BATCH_PROCESSING_DATE = "BatchProcessingDate";
	public static final String PARAMETERS = "Parameters";
	public static final String BATCH_JOBID = "JobId";
	public static final String BATCH_MULTISTREAM_JOB = "MultistreamJob";
	public static final String BATCH_JOB_RESULT_FAILED = "Fail";
	public static final String BATCH_JOB_RESULT_SUCCESS = "Success";
	public static final String BATCH_JOB_RESULT_PARTIAL_SUCCESS = "Partial Success";
	public static final String BATCH_JOB_STATUS_COMPLETED = "Completed";
	public static final int BATCH_JOB_STATUS_SUCCESS = 0;
	public static final int BATCH_JOB_STATUS_FAILED = 1;
	public static final int BATCH_JOB_STATUS_NOT_AVAILABLE = -1;
	public static final int BATCH_JOB_STATUS_INPROGRESS = 2;
	public static final String BATCH_JOBNAME = "JobName";
	
	public static final int BATCH_MONITOR_ROWINDEX=2;
	public static final String SCHEDULE_ID = "ScheduleId";
	
	public static final String FILE_DOWNLOAD = "download";
	public static final String FILE_UPLOAD = "upload";
	
	public static final String CANCEL_REWARDS_SUCCESS_TXT="Batch No is cancelled"; 
	public static final int UNDEFINED=-1;
}
