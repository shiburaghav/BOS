package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;



public class Funds 
{

	private final static Logger LOGGER = Logger.getLogger(Funds.class.getName());
	private static final String FUNDCODE = "FundCode";
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	
	public Funds() {
		dashboard = DashboardHandler.getInstance();
	}
	public void launchFundPriceEntry(Hashtable<String, String> hParams) throws Exception 
	{
		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try
		{		
			// Finance-> 
			llAction.goMenuItem("Finance","web_lst_MainMenu");
			llAction.goMenuItem("Fund Administration","web_fund_menu_level1");
			llAction.goMenuItem("Fund Price Entry","web_fund_menu_level2");
			llAction.goMenuItem("New/Revise","web_fund_menu_level3");
			llAction.selectMenuItem("FUND_NEW_REVISE");		
			
			dashboard.setStepDetails("Select Fund New Revise menu","The FPMS batch fund price entry search criteria should be displayed","N/A");
			dashboard.writeResults();
			/* FPMS BATCH FUND PRICE ENTRY */
			llAction.enterValue("web_fund_txt_FundCode_From", hParams.get("FundCodeFrom"));
			llAction.enterValue("web_fund_txt_FundCode_To", hParams.get("FundCodeTo"));
			llAction.enterValue("web_fund_txt_Price_Effective_Dt", hParams.get("PriceEffectiveDate"));
			llAction.clickElement("web_fund_price_entry_batch");
			
			dashboard.setStepDetails("Enter search criteria for fund price and click on search.","The fund price entry screen should be displayed","N/A");
			dashboard.writeResults();
			
			/* FPMS BATCH FUND PRICE ENTRY  - Fund Price Entry*/
			llAction.checkBox_Check("web_fund_price_entry_option");
			updateBidPrice(hParams);
			
			llAction.clickElement("web_fund_price_entry_submit");
			Utils.sleep(2);
			dashboard.setStepDetails("Update the Bid Price for fund names and click on Submit followed Exit button.","The user is taken back to home screen.","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_fund_price_entry_exit");
			
		}
		
			catch (Exception ex)
			{
				DashboardProperties.gBPCStatus = 1; // set the business component status to fail
				LOGGER.log(Level.SEVERE,"Exception occured while calling launchFunds method \n Exception is " + ex.getMessage());
				throw new BPCException("");
			}
		
	}
	public void launchFundPriceApproval(Hashtable<String, String> hParams) throws Exception {
		
		try {
			llAction.goMenuItem("Finance","web_lst_MainMenu");
			llAction.goMenuItem("Fund Administration","web_fund_menu_level1");
			llAction.goMenuItem("Fund Price Approval","web_fund_menu_fundApproval");
			llAction.selectMenuItem("FUND_PRICE_APPROVAL");
			dashboard.setStepDetails("Select Fund Price Approval menu","The FPMS batch fund price approval search criteria should be displayed","N/A");
			dashboard.writeResults();
			//Fund approval part is missing 
			//code for search fund 
			
			
            llAction.enterValue("web_fund_txt_FundCode_From", hParams.get("FundCodeFrom"));
            llAction.enterValue("web_fund_txt_FundCode_To", hParams.get("FundCodeTo"));
            llAction.enterValue("web_btn_fund_approval_price_effective_date", hParams.get("PriceEffectiveDate"));
            llAction.clickElement("web_btn_fund_batch_price_approval_search");
           Utils.sleep(2);
            
            llAction.checkBox_Check("web_fund_batch_price_approval_option");
            llAction.clickElement("web_fund_price_approval_submit");
           

            dashboard.setStepDetails("Enter search criteria for fund price approval and click on search.","The fund price entry screen should be displayed","N/A");
            dashboard.writeResults();
			//
			 llAction.clickElement("web_fund_price_approval_exit");
			//code for Fund price approval Option all check box tick and approve 
			 dashboard.setStepDetails("Select all funds and approve then click on Submit followed Exit button.","The user is taken back to home screen.","N/A");
			 dashboard.writeResults();
			
		} catch (Exception e) {
			DashboardProperties.gBPCStatus = 1; // set the business component status to fail
			LOGGER.log(Level.SEVERE,"Exception occured while calling launchFunds method \n Exception is " + e.getMessage());
			throw new BPCException("");
		}
		
	}
	private void updateBidPrice(Hashtable<String, String> hParams) throws Exception {
		
		List<WebElement> bidList = llAction.returnWebElements("web_fund_price_entry_bid_price");
		int counter = 1;
		for(WebElement bid:bidList)
		{
			String fieldName = FUNDCODE + counter;
			String value = hParams.get(fieldName);
			llAction.enterValues(bid, value); 
			counter++;
		}
		
	}
	
}
