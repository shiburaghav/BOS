package ge.fpms.main.bpc.bcp.templates.creditcard;

import java.util.ArrayList;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Header implements IPaymentSection {

	private Type recordType;
	private Type fileDescriptor;
	private Type fileType;
	private Type version;
	private Type productId;
	private Type batchIndicator;
	private Type paymentGroup;
	private Type productCode;
	private Type merchantNumber;
	private Type terminalId;
	private Type hostNumber;

	public Header(Type[] type) {
		super();
		this.recordType = new Type(type[0].getSize(), type[0].getDataType(), type[0].getValue(), type[0].getAlignment(),
				type[0].getPaddingChar());
		this.fileDescriptor = new Type(type[1].getSize(), type[1].getDataType(), type[1].getValue(),
				type[1].getAlignment(), type[1].getPaddingChar());
		this.fileType = new Type(type[2].getSize(), type[2].getDataType(), type[2].getValue(),
				type[2].getAlignment(), type[2].getPaddingChar());
		this.version = new Type(type[3].getSize(), type[3].getDataType(), type[3].getValue(), type[3].getAlignment(),
				type[3].getPaddingChar());
		this.productId = new Type(type[4].getSize(), type[4].getDataType(), type[4].getValue(), type[4].getAlignment(),
				type[4].getPaddingChar());
		this.batchIndicator = new Type(type[5].getSize(), type[5].getDataType(), type[5].getValue(),
				type[5].getAlignment(), type[5].getPaddingChar());
		this.paymentGroup = new Type(type[6].getSize(), type[6].getDataType(), type[6].getValue(),
				type[6].getAlignment(), type[6].getPaddingChar());
		this.productCode = new Type(type[7].getSize(), type[7].getDataType(), type[7].getValue(),
				type[7].getAlignment(), type[7].getPaddingChar());
		this.merchantNumber = new Type(type[8].getSize(), type[8].getDataType(), type[8].getValue(),
				type[8].getAlignment(), type[8].getPaddingChar());
		this.terminalId = new Type(type[9].getSize(), type[9].getDataType(), type[9].getValue(), type[9].getAlignment(),
				type[9].getPaddingChar());
		this.hostNumber = new Type(type[10].getSize(), type[10].getDataType(), type[10].getValue(), type[10].getAlignment(),
				type[10].getPaddingChar());
	}
	

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getFileDescriptor() {
		return fileDescriptor;
	}

	public void setFileDescriptor(Type fileDescriptor) {
		this.fileDescriptor = fileDescriptor;
	}

	public Type getFileType() {
		return fileType;
	}

	public void setFileType(Type fileType) {
		this.fileType = fileType;
	}

	public Type getVersion() {
		return version;
	}

	public void setVersion(Type version) {
		this.version = version;
	}

	public Type getProductId() {
		return productId;
	}

	public void setProductId(Type productId) {
		this.productId = productId;
	}

	public Type getBatchIndicator() {
		return batchIndicator;
	}

	public void setBatchIndicator(Type batchIndicator) {
		this.batchIndicator = batchIndicator;
	}

	public Type getPaymentGroup() {
		return paymentGroup;
	}

	public void setPaymentGroup(Type paymentGroup) {
		this.paymentGroup = paymentGroup;
	}

	public Type getProductCode() {
		return productCode;
	}

	public void setProductCode(Type productCode) {
		this.productCode = productCode;
	}

	public Type getMerchantNumber() {
		return merchantNumber;
	}

	public void setMerchantNumber(Type merchantNumber) {
		this.merchantNumber = merchantNumber;
	}

	public Type getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(Type terminalId) {
		this.terminalId = terminalId;
	}
	
	public Type getHostNumber() {
		return hostNumber;
	}

	public void setHostNumber(Type hostNumber) {
		this.hostNumber = hostNumber;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(), fileDescriptor.getSize(), fileType.getSize(), version.getSize(),
				productId.getSize(), batchIndicator.getSize(), paymentGroup.getSize(), productCode.getSize(),
				merchantNumber.getSize(), terminalId.getSize(),hostNumber.getSize() };
	}

	public void setParamaters(ArrayList<String> buffer) {
		recordType.setValue(buffer.get(0));
		fileDescriptor.setValue(buffer.get(1));
		fileType.setValue(buffer.get(2));
		version.setValue(buffer.get(3));
		productId.setValue(buffer.get(4));
		batchIndicator.setValue(buffer.get(5));
		paymentGroup.setValue(buffer.get(6));
		productCode.setValue(buffer.get(7));
		merchantNumber.setValue(buffer.get(8));
		terminalId.setValue(buffer.get(9));
		hostNumber.setValue(buffer.get(10));
	}

	public String getName() {
		return "BH";
	}

	public String toString() {
		String headerText = new StringBuffer().append(recordType.toString()).append(fileDescriptor.toString())
				.append(fileType.toString()).append(version.toString()).append(productId.toString())
				.append(batchIndicator.toString()).append(paymentGroup.toString()).append(productCode.toString())
				.append(merchantNumber.toString()).append(terminalId.toString()).append(hostNumber.toString()).toString();
		System.out.println("Header.toString() header: " + headerText);
		return headerText;
	}

	@Override
	public Type[] getAllAttributes() {
		return new Type[] { recordType, fileDescriptor, fileType, version, productId, batchIndicator,
				paymentGroup, productCode, merchantNumber, terminalId,hostNumber };
	}
}
