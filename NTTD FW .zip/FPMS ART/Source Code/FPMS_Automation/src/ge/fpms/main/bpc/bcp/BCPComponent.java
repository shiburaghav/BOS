package ge.fpms.main.bpc.bcp;

import ge.fpms.main.FPMSProperties;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.bcp.templates.creditcard.CreditCardTemplateParser;
import ge.fpms.main.bpc.bcp.templates.giro.GiroTemplateParser;
import ge.fpms.main.bpc.common.Query;
import ge.fpms.main.bpc.nbu.BatchConstants;
import ge.fpms.main.bpc.nbu.BatchJobs;
import ge.fpms.main.bpc.nbu.components.BatchJobFileProcessor;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.ArtRobot;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class BCPComponent {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public BCPComponent() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public ArrayList<String> downloadGIROBankFile(Hashtable<String, String> hParams) throws Exception {
		ArrayList<String> downloadedFileList = new ArrayList<String>();
		try {
			llAction.selectMenuItem("System Administration", "BCP", "GIRO Bank Transfer", "Download GIRO Bank File");

			llAction.enterValue("web_batchJob_upload_bank_code", hParams.get("BankCode"));
			llAction.enterValue("web_bcp_dwl_giro_generateDate", hParams.get("GenerationDate"));
			llAction.selectByVisibleText("web_bcp_dwl_giro_deductionDate", hParams.get("GIRODeductionDate"));

			dashboard.setStepDetails("GIRO Bank Transfer", "About to download file", "N/A");
			dashboard.writeResults();
			int i = 0;
			llAction.clickElement("web_batchJob_dwl_cpf_download_datafile");

			Hashtable<String, String> dwlLinks = ARTProperties.guiMap.get("web_batchJob_dwl_giro_link");
			List<WebElement> elements = llAction
					.findElementsByXpath(dwlLinks.get(dwlLinks.keySet().toArray()[0].toString()));

			if (elements != null && elements.size() > 0) {

				Hashtable<String, String> dwlFileNames = ARTProperties.guiMap.get("web_batchJob_dwl_link_filename");
				List<WebElement> dwlfiles = llAction
						.findElementsByXpath(dwlFileNames.get(dwlFileNames.keySet().toArray()[0].toString()));

				for (WebElement element : elements) {
					llAction.clickElementJs(element);
					downloadedFileList.add(dwlfiles.get(i).getText());
					Utils.sleep(2);
					ArtRobot.saveFile();
					Utils.sleep(2);
					i++;
					dashboard.setStepDetails("GIRO Bank Transfer", "File has been downloaded to Download Folder",
							"N/A");
					dashboard.writeResults();
				}
			} else {
				dashboard.setStepDetails("GIRO Bank Transfer", "No File has been downloaded", "N/A");
				dashboard.writeResults();
			}

			llAction.clickElement("web_billing_exit_btn");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception e) {
			throw new BPCException(e);
		}
		return downloadedFileList;
	}

	public void UploadGIROBankFile(Hashtable<String, String> hParams) throws Exception {
		try {

			GiroTemplateParser giroParser = new GiroTemplateParser();
			giroParser.processGiroTemplate(hParams);
			String outputpath = giroParser.getOutputFilePath();

			llAction.selectMenuItem("System Administration", "BCP", "GIRO Bank Transfer", "Upload GIRO Bank File");
			llAction.waitUntilLoadingCompletes();

			llAction.enterValue("web_batchJob_upload_cc_batchno", hParams.get("BatchNo"));
			llAction.selectByVisibleText("web_batchJob_upload_bank_code", hParams.get("BankName"));
			llAction.enterValue("web_batchJob_upload_cc_browseBtn", outputpath);
			llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
			llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);

			dashboard.setStepDetails("GIRO Bank Transfer Upload", "File is uploaded. About to validate", "N/A");
			dashboard.writeResults();

			if (llAction.isEnabled("web_batchJob_upload_cc_validateBtn")) {
				llAction.clickElement("web_batchJob_upload_cc_validateBtn");
				dashboard.setStepDetails("GIRO Bank Transfer - Upload", "File is valid. About to submit", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_billing_giro_submit_btn");
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_billing_exit_btn");
				llAction.waitUntilLoadingCompletes();
			} else {
				dashboard.setFailStatus(
						new BPCException("GIRO Bank Transfer Upload - Validate Failed!! - File is invalid!!"));
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void processFileForCC(String action, Hashtable<String, String> hParams) throws Exception {
		if (action.equalsIgnoreCase(BatchConstants.FILE_DOWNLOAD)) {
			creditCardDownloadFile(hParams);
		} else {
			creditCardUploadFile(hParams);
		}

	}

	public void creditCardDownloadFile(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("System Administration", "BCP", "Credit Card Transfer",
					"Credit Card Bank Download File");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_batchjobs_cc_generate_date", hParams.get("GenerationDate"));
			dashboard.setStepDetails("Credit Card Bank Download File", "About to click on download button", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_batchjobs_cc_download_btn");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Credit Card Bank Download File", "About to download credit card download file",
					"N/A");
			dashboard.writeResults();
			if (llAction.isDisplayed("web_batchJob_dwl_cc_link", 5)) {
				llAction.clickElementJs("web_batchJob_dwl_cc_link");
				Utils.sleep(2);
				ArtRobot.saveFile();
				Utils.sleep(3);
				dashboard.setStepDetails("Credit Card File should be downloaded",
						"credit card download file is downloaded", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setStepDetails("Credit Card File  is not generated to download",
						"Credit Card File is not available to download", "N/A");
				dashboard.writeResults();
			}
			llAction.clickElement("web_billing_exit_btn");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void creditCardUploadFile(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("System Administration", "BCP", "Credit Card Transfer",
					"Credit Card BankTransfer Upload File");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_batchJob_upload_cc_batchno", hParams.get("BatchNo"));
			llAction.enterValue("web_batchJob_upload_cc_browseBtn", hParams.get("UploadFilePath"));
			// llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
			// llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
			dashboard.setStepDetails("Credit Card BankTransfer Upload File", "About to click on validate button",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_batchJob_upload_cc_validateBtn");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isEnabled("web_batchJob_upload_cc_submitBtn")) {
				dashboard.setStepDetails("Credit Card BankTransfer Upload File", "File validated. About to submit",
						"N/A");
				dashboard.writeResults();
				llAction.clickElement("web_batchJob_upload_cc_submitBtn");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Credit Card BankTransfer Upload File", "About to exit", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_billing_exit_btn");
				llAction.waitUntilLoadingCompletes();
			} else {
				dashboard.setFailStatus(new BPCException("File is invalid. Credit card upload failed!!"));
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void uploadCreditCard(Hashtable<String, String> hParams) throws Exception {
		try {
			String filePath = FPMSProperties.getInstance().getUserDownloadsAbsolutePath()+File.separator+"gesin"+hParams.get("BatchProcessingDate").substring(2);
			File file = new File(filePath);
			if (file.exists()) {
				CreditCardTemplateParser templateParse = new CreditCardTemplateParser();
				templateParse.processCreditCardTemplate(hParams);
				String outputpath = templateParse.getOutputFilePath();
				hParams.put("UploadFilePath", outputpath);
				creditCardUploadFile(hParams);
			}
			else
			{
				dashboard.setStepDetails("Parsing and uploading Credit Card downloaded file", "Credit Card file contains no detail section. Hence Upload will not be done",
						"N/A");
				dashboard.writeResults();
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	/**
	 * 
	 * Method - ConfirmPremiumNoticeGenerated - called to check if premium notice
	 * files are generated
	 * 
	 * @param hParams
	 *            - testdata from batchJobs
	 * @throws Exception
	 */
	public void ConfirmPremiumNoticeGenerated(Hashtable<String, String> hParams) throws Exception {

		String dt = Utils.formatDateTime(hParams.get("BatchProcessingDate"), "dd/MM/yyyy", "yyMMdd");
		String fileName = hParams.get("FileName").replace("%%", dt);

		boolean fileExist = false;

		String fesIpAddress = hParams.get("FesIPAddress");

		try {
			if (StringUtils.isEmpty(fesIpAddress)) {
				BatchJobs bj = new BatchJobs();

				fileExist = bj.isFileGenerated(hParams.get("ServerLocation"), hParams.get("UserName"),
						hParams.get("Password"), hParams.get("FolderLocation"), fileName);
			} else {
				BatchJobFileProcessor bfp = new BatchJobFileProcessor();
				String folderLocation = hParams.get("FolderLocation");
				String fesLocation = "\\\\" + fesIpAddress + folderLocation;
				fileExist = bfp.fesFileExist(fesLocation, fileName);
			}

			if (fileExist) {
				dashboard.setStepDetails("Verify file in FES", "The file " + fileName + "is generated successfully",
						"N/A");
				dashboard.writeResults();
			} else {
				dashboard.setFailStatus(new BPCException("Verify file in FES - " + "Failed to find file " + fileName
						+ " at " + hParams.get("FolderLocation")));
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	/**
	 * 
	 * Method - VerifyGIROStatus
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void DownloadGiroFileAndVerifyStatus(Hashtable<String, String> hParams) throws Exception {

		try {

			hParams.put("FileName", getGiroFileName(hParams.get("BatchProcessingDate")));
			ArrayList<String> fileList = downloadGIROBankFile(hParams);

			if (fileList != null && fileList.size() > 0) {
				for (String file : fileList) {
					String inputFileName = FPMSProperties.getInstance().getUserDownloadsAbsolutePath() + File.separator
							+ file;
					hParams.put("InputFile", inputFileName);

					GiroTemplateParser parser = new GiroTemplateParser();
					parser.parseGiroTemplate(hParams);
					String policies = parser.getAllPolicies(5);
					if (!StringUtils.isEmpty(policies)) {
						Hashtable<String, String> qhParams = new Hashtable<>();
						qhParams.put("Capture", hParams.get("Capture"));
						qhParams.put("PolicyNumber", policies);

						Query query = new Query();
						query.displayCommonQueryInfo(qhParams);
					} else {
						dashboard.setStepDetails("Parsing downloaded GIRO file",
								"Downloaded GIRO file contains no detail section. Hence no policy extracted.", "N/A");
						dashboard.writeResults();
					}
					parser = null;
				}
			} else {
				dashboard.setStepDetails("GIRO Bank Transfer", "No file has been downloaded", "N/A");
				dashboard.writeResults();
			}
		} catch (Exception e) {
			throw (new BPCException(e));
		}

	}

	/**
	 * 
	 * Method - VerifyDirectCreditStatus
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void VerifyDirectCreditStatus(Hashtable<String, String> hParams) throws Exception {

		try {
			String fileName = hParams.get("FileName");
			String batchProcessingDate = hParams.get("BatchProcessingDate");
			batchProcessingDate = Utils.formatDateTime(batchProcessingDate, "dd/MM/yyyy", "yyyyMMdd");
			if (StringUtils.isEmpty(fileName)) {
				fileName = "gein" + batchProcessingDate;
			}
			hParams.put("FileName", fileName);
			ArrayList<String> fileList = getFilesFromRemoteLocation(hParams);

			for (String giroFileName : fileList) {

				hParams.put("InputFile", giroFileName);

				GiroTemplateParser parser = new GiroTemplateParser();
				parser.parseGiroTemplate(hParams);

				String policies = parser.getAllPolicies(5);

				if (!StringUtils.isEmpty(policies)) {
					Hashtable<String, String> qhParams = new Hashtable<>();
					qhParams.put("Capture", hParams.get("Capture"));
					qhParams.put("PolicyNumber", policies);

					Query query = new Query();
					query.captureQuickLinksSubSection(qhParams);
				} else {
					dashboard.setStepDetails("Parsing downloaded directcredit file",
							"Downloaded directcredit file contains no detail section. Hence no policy extracted.",
							"N/A");
					dashboard.writeResults();
				}
			}
			if (fileList.isEmpty() || fileList.size() == 0) {

				dashboard.setStepDetails("Direct Credit ", "No file found", "N/A");
				dashboard.writeResults();
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	/**
	 * 
	 * Method - getFilesFromRemoteLocation - It could be either SSH or FES Shared
	 * folder location
	 * 
	 * @param hParams
	 * @return - gets list of the files copied from remote location
	 * @throws Exception
	 */
	private ArrayList<String> getFilesFromRemoteLocation(Hashtable<String, String> hParams) throws Exception {
		String fesIpAddress = hParams.get("FesIPAddress");
		BatchJobFileProcessor bfp = new BatchJobFileProcessor();
		ArrayList<String> list = new ArrayList<String>();
		try {
			if (StringUtils.isEmpty(fesIpAddress)) {
				BatchJobs bj = new BatchJobs();

				if (StringUtils.isEmpty(hParams.get("ServerLocation")) || StringUtils.isEmpty(hParams.get("UserName"))
						|| StringUtils.isEmpty(hParams.get("Password"))
						|| StringUtils.isEmpty(hParams.get("FolderLocation"))) {
					dashboard.setFailStatus(new BPCException("Getting files from remote server"
							+ "Failed as one or more input parameter (ServerLocation, UserName, Password, FolderLocation)is empty"));

				}
				list = bj.copyFilesFromRemoteServer(hParams.get("ServerLocation"), hParams.get("UserName"),
						hParams.get("Password"), hParams.get("FolderLocation"));

			} else {

				list = bfp.copyFileFromFesSharedLocation(hParams);
			}
		}

		catch (Exception e) {
			throw new BPCException(e);
		}
		return list;
	}

	private String getGiroFileName(String bpdate) {
		String fileName = "gein";
		String batchProcessingDate = Utils.formatDateTime(bpdate, "dd/MM/yyyy", "yyyyMMdd");
		fileName = "gein" + batchProcessingDate;

		return fileName;
	}

	/**
	 * 
	 * Method - VerifyGiroUploadStatus
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	public void VerifyGiroUploadStatus(Hashtable<String, String> hParams) throws Exception {
		GiroTemplateParser parser = new GiroTemplateParser();
		parser.parseGiroTemplate(hParams);
		String policies = parser.getAllPolicies(5);

		if (!StringUtils.isEmpty(policies)) {
			Hashtable<String, String> qhParams = new Hashtable<>();
			qhParams.put("Capture", hParams.get("Capture"));
			qhParams.put("PolicyNumber", policies);

			Query query = new Query();
			query.captureQuickLinksSubSection(qhParams);

		} else {
			dashboard.setStepDetails("Parsing GIRO file",
					"GIRO file contains no detail section. Hence no policy extracted.", "N/A");
			dashboard.writeResults();
		}
		parser = null;
	}

	public void VerifyCreditCardStatus(Hashtable<String, String> hParams) throws Exception {

		try {
			String filePath = FPMSProperties.getInstance().getUserDownloadsAbsolutePath()+File.separator+"gesin"+hParams.get("BatchProcessingDate").substring(2);
			File file = new File(filePath);
			if (file.exists()) {
			CreditCardTemplateParser parser = new CreditCardTemplateParser();
			parser.processCreditCardTemplate(hParams);
			Hashtable<String, String> qhParams = new Hashtable<>();
			qhParams.put("Capture", hParams.get("Capture"));
			qhParams.put("PolicyNumber", parser.getAllPolicies(5));
			Query query = new Query();
			query.captureQuickLinksSubSection(qhParams);
			}
			else
			{
				dashboard.setStepDetails("Parsing Credit Card Input file",
						"Credit Card file contains no detail section. Hence no policy extracted.", "N/A");
				dashboard.writeResults();
			}

		} catch (Exception e) {
			throw (new BPCException(e));
		}

	}
}
