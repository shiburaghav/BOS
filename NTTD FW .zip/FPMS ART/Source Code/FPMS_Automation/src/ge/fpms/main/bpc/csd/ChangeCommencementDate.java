package ge.fpms.main.bpc.csd;
import java.util.Hashtable;
import com.nttdata.common.util.ColumnHeader;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;
import ge.fpms.main.bpc.nbu.ReceiveCounterCollections;
import ge.fpms.main.bpc.common.Query;

public class ChangeCommencementDate {
	
	
	/*
	 * Name: ChangeCommencementDate 
	 * Purpose: Navigate to CS module from the Main Page and ChangeCommencementDate a policy
	 * Parameters:Parameter Hash table 
	 * Return Value: NA 
	 * Exception: BPCException
	 * @author: Sridhar 0n 18/12/2018
	 */	

	
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	private static String  currentCommencementDate;
	private String newCommencementDate;
	private String benifitcode;

	public ChangeCommencementDate() {
		dashboard = DashboardHandler.getInstance();
		
	}

	public void changeCommencementdate(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("Benefit information before change", "BeforeChange");
			llAction.enterValue("web_txt_CCD_Commencementdatefield", hParams.get("NewcommencementDate"));
			llAction.clickElement("web_btn_CCD_Changecommencementdate");
			if (llAction.isDisplayed("web_btn_ContinueRP", 10)) 
			{
				llAction.clickElement("web_btn_ContinueRP");
			}
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("Benefit information After change", "AfterChange");
			llAction.clickElement("web_btn_CCD_Submit");
			llAction.waitUntilLoadingCompletes();
			String pageDisplay = llAction.getText("web_tbl_CancellationPageHeader");
			if (pageDisplay.contains("collection/refund")) {
				dashboard.setStepDetails("Collection and refund information after change",
						"Collection and refund information after change should appear", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_CCD_Submit");
				llAction.waitUntilLoadingCompletes();
			}
			if (llAction.isDisplayed("web_btn_ContinueRP", 10)) {

				llAction.clickElement("web_btn_ContinueRP");
			}
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on the Submit button", "System to route to Application Entry Page", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CCD_Submit");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_Exit")) {
				llAction.clickElement("web_txt_Exit");
				dashboard.setStepDetails("Click on  Exit button",
						"System should display \"Display offset fee result\" screen.", "N/A");
				dashboard.writeResults();
			}
			llAction.waitUntilLoadingCompletes();
			String applicationStatus = hParams
					.get("ApplicationStatus"); /* Get expected warning message from Test Data */
			// FPMSConstants.POLICY_STATUS_INFORCE)
			if (llAction.getText("web_txt_policyStatus_message").contains(hParams.get("ApplicationStatus"))) {
				dashboard.setStepDetails(applicationStatus + " Should be populated", "Message is validated", "N/A");
				dashboard.writeResults();
			} 
			else if (llAction.getText("web_txt_policyStatus_message").contains("Approved")) {
				DataHandler dataHandler = new DataHandler();
				Hashtable<String, String> rccData = dataHandler.getTestData(ColumnHeader.Collection.toString(),
						FPMSProperties.getInstance().getTestDataFilePath( System.getProperty("Settings.Module")), ColumnHeader.Collection.getColumnHeader(),
						hParams.get("TCID"));
				ReceiveCounterCollections rcc = new ReceiveCounterCollections();
				rcc.ReceiveCounterCollection(rccData);
			} else 
			{
				dashboard.setFailStatus(new BPCException("message is invalid/Submit was not successful"));
			}
			llAction.clickElement("web_btn_BacktoMainScrn");
			llAction.waitUntilLoadingCompletes();
			Query query = new Query();
			query.launchQuerySearch(hParams.get("PolicyNumber"));
			// save commencement date
			newCommencementDate = getCommencementDate("web_CCD_txt_CommencementDate");
			if (!newCommencementDate.equalsIgnoreCase(currentCommencementDate)) {
				// TODO: pass set	
				dashboard.setStepDetails(newCommencementDate + currentCommencementDate,
						"CommencementDate succesfully changed", "N/A");
				dashboard.writeResults();
			} else {
				// todo: failure
				dashboard.setFailStatus(new BPCException("Commencement  Date not changed"));			
			}
			llAction.clickElement("web_btn_Exit");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {

			throw new BPCException(ex);
		}
	}

	public void getCommencementdate(Hashtable<String, String> hParams) {
		try {
			llAction = new FPMS_Actions();
			// launching common query
			Query query = new Query();
			query.launchQuerySearch(hParams.get("PolicyNumberRegistration"));
			// save commencement date
			currentCommencementDate = getCommencementDate("web_CCD_txt_CommencementDate");

			dashboard.setStepDetails(currentCommencementDate + " Should be populated", "Message is validated", "N/A");
			dashboard.writeResults();
			setBenefitCode(hParams);
			llAction.clickElement("web_btn_Exit");
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	private void setBenefitCode(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			llAction.selectTab("Benefit Info");
			int colPosition = 1;
			int rowPosition = 2;
			String text = llAction.GetTextFromTable("web_CCD_tbl_Benefit", rowPosition, colPosition,"/a");
			String messageslist[] = text.split(":");
			benifitcode = messageslist[1];
			System.out.println("benifitcode"+benifitcode);

			// TODO: Add exit from query
		} catch (Exception ex) {

			throw new BPCException(ex);
		}

	}

	private String getCommencementDate(String commencementElement) {
		String commencementDatevalue = null;
		try {
			commencementDatevalue = llAction.getText(commencementElement);
		} 
		catch (Exception ex) {
			throw new BPCException(ex);
		}
		return commencementDatevalue;
	}

}
