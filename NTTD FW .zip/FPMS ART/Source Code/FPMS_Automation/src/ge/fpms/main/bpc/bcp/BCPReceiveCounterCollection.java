package ge.fpms.main.bpc.bcp;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.ReceiveCounterCollections;

public class BCPReceiveCounterCollection extends ReceiveCounterCollections {
	
	FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	
	public BCPReceiveCounterCollection() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	
	public void BCPReceiveCounterCollections(java.util.Hashtable<String, String> hParams) {
		try {
			ReceiveCounterCollection(hParams);
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	public void cancelCollection(Hashtable<String, String> hParams) throws Exception{
		try {
			String policyNumber = StringUtils.EMPTY;
			String amount = hParams.get("Amount");
			String collectType = hParams.get("CancelType");
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			
			llAction.selectMenuItem("Collection", "cancel collection");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_CC_txt_policyNumber");
			llAction.enterValue("web_CC_txt_policyNumber", policyNumber);
			
			llAction.clickElement("web_CC_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Validate if the policy displayed in the search results",
					"Policy should be displayed in search results", "");
			dashboard.writeResults();
			
			Utils.editXpath("web_CC_Link_selectPolicy", "web_CC_Link_selectPolicy"+policyNumber+"", new String[] { policyNumber} );
			llAction.clickElement("web_CC_Link_selectPolicy"+policyNumber+"");
			llAction.waitUntilLoadingCompletes();
			
			Utils.editXpath("web_CC_check_CancelCollectionPolicy", "web_CC_check_Policy"+policyNumber+"", new String[] { policyNumber, amount } );
			llAction.checkBox_Check("web_CC_check_Policy"+policyNumber+"");
			
			llAction.selectByVisibleText("web_CC_lst_cancelType", collectType);
			
			dashboard.setStepDetails("Validate if the amount and cancel type selected",
					"Amount and Cancel Type should be selected as per user", "");
			dashboard.writeResults();
			
			llAction.clickElement("web_CC_btn_SubmitCancelCollection");
			llAction.waitUntilLoadingCompletes();
			
			String text = llAction.getText("web_CC_lable_successMessage");
			if(text.equals("Cancel collection is successful.")) {
				dashboard.setStepDetails("Validate the success message",
						"Cancel collection is successful.", "");
				dashboard.writeResults();
				llAction.clickElement("web_CC_btn_Return");
				llAction.waitUntilLoadingCompletes();
			}else {
				dashboard.setFailStatus(new BPCException("Cancel Collection not successful"));
			}
		}catch(Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateAmountAllocated(String collectType, String amountCollected) {
		int colPos;
		try {
			/*colPos = llAction.GetColumnPositionInTable("web_rcc_tbl_collectionAllocation", "Collect type");
			int rowPos = llAction.GetRowPositionInTable("web_rcc_tbl_collectionAllocation", collectType, colPos);
			WebElement e = llAction.getElementAt("web_rcc_tbl_collectionAllocation", rowPos, colPos - 1, "/input");
			String amtAllocated = e.getAttribute("value");
			if (!amtAllocated.equals(amountCollected)) {
				DashboardHandler.getInstance().setFailStatus(new BPCException("Amount Collected is not equal to Amount Allocated "));
			}*/
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
}
