package ge.fpms.main.bpc.nbu;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;

public class Proposal {
	FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;


	public Proposal() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
		
	}

	public void amendProposal(Hashtable<String, String> hParams) throws Exception {
		try {
			String PolicyNo = StringUtils.EMPTY;
			
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				PolicyNo = hParams.get("PolicyNo");
			} else {
				PolicyNo = policyHandler.getPolicy().getPolicyNo();
			}
			
			llAction.selectMenuItem("NBD", "amend_proposal");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_AmendProposal_PolicyNo", PolicyNo);
			llAction.clickElement("web_txt_AmendProposal_Search");
			
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
			}
			llAction.switchtoFrame(1);
			llAction.waitUntilElementPresent("web_txt_AmendProposal_reUWInd");
			llAction.move_to_element("web_txt_AmendProposal_reUWInd");
			llAction.enterValue("web_txt_AmendProposal_reUWInd", hParams.get("ReUnderwritingIndicator"));
			Utils.sleep(3);
			llAction.selectByVisibleText("web_txt_AmendProposal_reUWReason", hParams.get("UWReason"));
			Utils.sleep(3);
			dashboard.setStepDetails("Enter/Select Underwriting Indicator and Reason", "User should be able to Enter/Select Underwriting Indicator and Reason","");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Detail_Reg_Submit");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Submit and Cancel", "User should be navigated to FPMS home Page","");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void withdrawProposal(Hashtable<String, String> hParams) throws Exception {
		try {
			
			String PolicyNo = StringUtils.EMPTY;
			
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				PolicyNo = hParams.get("PolicyNo");
			} else {
				PolicyNo = policyHandler.getPolicy().getPolicyNo();
			}
			
			llAction.selectMenuItem("NBD", "withdrawal");
			llAction.waitUntilLoadingCompletes();
			
			llAction.enterValue("web_txt_withdrawProposal_PolicyNo", PolicyNo);
			llAction.clickElement("web_txt_withdrawProposal_Search");
			
			llAction.waitUntilLoadingCompletes();
			llAction.selectByVisibleText("web_txt_withdrawProposal_Reason", hParams.get("WithdrawReason"));
			dashboard.setStepDetails("Select Withdraw Proposal Reason", "User should be able to Select Withdraw Proposal Reason","");
			dashboard.writeResults();
			llAction.clickElement("web_uw_btn_withdrawSubmit");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_btn_withdrawCancel");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Submit and Cancel", "User should be navigated to FPMS home Page","");
			dashboard.writeResults();
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

}
