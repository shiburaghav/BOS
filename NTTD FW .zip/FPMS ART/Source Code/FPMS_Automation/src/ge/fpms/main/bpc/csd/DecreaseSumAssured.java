package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.WebElement;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.*;

public class DecreaseSumAssured {

	// Name: ILPDecreaseSumAssured
	// Purpose: Navigate to CS module from the Main Page and decrease sum assured
	// for a policy
	// Parameters : Parameter Hash table
	// Return Value: NA
	// Exception: BPCException
	// @author: Prashantha on 21/12/2018

	private final static Logger LOGGER = Logger.getLogger(DecreaseSumAssured.class.getName());

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public DecreaseSumAssured() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	}
