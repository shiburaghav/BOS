package ge.fpms.main;

import ge.fpms.data.Login;
import ge.fpms.data.PolicyHandler;
import ge.fpms.data.Claims;

public class FPMSManager {

	private static FPMSManager obj;

	private Login login;
	private PolicyHandler policyHandler;
	private Claims caseHandler;
	private ComponentEventHandler evtHandler;
	

	private FPMSManager() {

		login = new Login();
		policyHandler = new PolicyHandler();
		caseHandler = Claims.getInstance();
		evtHandler = new ComponentEventHandler();
	}

	public static FPMSManager getInstance() {

		if (obj == null) {
			obj = new FPMSManager();
		}

		return obj;
	}

	public Login getLoginHandler() {
		return login;
	}

	public PolicyHandler getPolicyHandler() {
		// TODO Auto-generated method stub
		if (policyHandler == null) {
			policyHandler = new PolicyHandler();
		}
		return policyHandler;
	}

	public Claims getCaseHandler() {
		// TODO Auto-generated method stub
		if (caseHandler == null) {
			caseHandler = Claims.getInstance();
		}
		return caseHandler;
	}
	
	public ComponentEventHandler getEvtHandler() {
		return evtHandler;
	}
	
	
}
