package ge.fpms.main;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BatchConstants;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class BatchJob {

	private static final int batchJobNoColPos = 1;

	private static final int batchResultColPos = 8;

	private static final int batchStatusColPos = 7;

	private String jobId;
	
	private String jobName;
	
	private String batchDueDate;
	
	private String batchJobNo;

	private String[] multiStreamJobs;
	
	private String batchProcessingDate;

	private FPMS_Actions llAction;

	private String scheduleId;
	
	private int streamCount;
	
	private boolean status;
	
	private DashboardHandler dashboard;
	
	public BatchJob( String jobName, String scheduleId,String batchDueDate, String batchProcessingDate) {
		dashboard = DashboardHandler.getInstance();
		this.jobId = "";
		this.jobName = jobName;
		this.batchDueDate = batchDueDate;
		this.batchProcessingDate = batchProcessingDate;
		this.scheduleId = scheduleId;
		this.llAction = new FPMS_Actions();
		this.streamCount = BatchConstants.UNDEFINED;
		
	}
	
	public BatchJob( String jobId, String batchDueDate, String batchProcessingDate) {
		dashboard = DashboardHandler.getInstance();

		this.jobId = Utils.isNumeric(jobId) ? jobId : "";
		this.jobName = Utils.isAlpha(jobId) ? jobId : "";
		this.batchDueDate = batchDueDate;
		this.batchProcessingDate = batchProcessingDate;
		this.llAction = new FPMS_Actions();
		this.streamCount = BatchConstants.UNDEFINED;
	}
	public BatchJob(String jobId, String batchDueDate, String batchProcessingDate,String[] multiStreamJobs) {
		dashboard = DashboardHandler.getInstance();
		this.jobId = Utils.isNumeric(jobId) ? jobId : "";
		this.jobName = Utils.isAlpha(jobId) ? jobId : "";
		this.batchDueDate = batchDueDate;
		this.batchProcessingDate = batchProcessingDate;
		this.multiStreamJobs = multiStreamJobs;
		this.streamCount = BatchConstants.UNDEFINED;
		this.llAction = new FPMS_Actions();
	}
	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(String scheduleId) {
		this.scheduleId = scheduleId;
	}

	public String getBatchDueDate() {
		return batchDueDate;
	}
	public String getBatchJobNo() {
		return batchJobNo;
	}
	public void setBatchDueDate(String batchDueDate) {
		this.batchDueDate = batchDueDate;
	}
	public String getBatchProcessingDate() {
		return batchProcessingDate;
	}
	public void setBatchProcessingDate(String batchProcessingDate) {
		this.batchProcessingDate = batchProcessingDate;
	}
	public String[] getMultiStreamJobs() {
		return multiStreamJobs;
	}
	public void setMultiStreamJobs(String streamJobs) {
		if (!StringUtils.isEmpty(streamJobs)) {
			multiStreamJobs = streamJobs.split(",");
		}
	}
	
	public int getStreamCount() {
		return streamCount;
	}

	public void setStreamCount(int streamCount) {
		this.streamCount = streamCount;
	}

	public int getMultiStreamJobCount(){
		int count = 0;
		if(multiStreamJobs!=null){
			count = multiStreamJobs.length;
		}
		return count;
	}
	
	public void updateUI() throws Exception{
		menuSelection();
		if (!StringUtils.isEmpty(jobName)) {
			jobName = jobName.toUpperCase();
			llAction.selectByVisibleText("web_batch_monitoring_job_name",
					jobName);
			Utils.sleep(5);
			llAction.sendkeyStroke("web_batch_monitoring_job_name", Keys.ENTER);
		}
		if (!StringUtils.isEmpty(scheduleId)) {
			llAction.selectByVisibleText("web_lst_adhoc_scheduleId", scheduleId);
			Utils.sleep(5);
			llAction.sendkeyStroke("web_lst_adhoc_scheduleId", Keys.ENTER);
			Utils.sleep(2);
		}

		if (!StringUtils.isEmpty(jobId)) {
			llAction.enterValue("web_txt_JobCode", jobId);
		}
		llAction.enterValue("web_txt_BatchDueDate", batchDueDate);
		llAction.enterValue("web_txt_BatchProcessingDate", batchProcessingDate);
	}
	
	public void run() throws Exception{
		try{
			
			
		updateUI();
		
		String printLog = StringUtils.isEmpty(jobName) ? jobId: jobName;
		dashboard.setStepDetails("Batch Job", "About to run batch  job  " +  printLog + "..","N/A");
		dashboard.writeResults();
		
		llAction.clickElement("web_btn_SubmitJob");
		llAction.waitUntilLoadingCompletes();
		
		String tblElementKey = "web_batch_monitoring_tbl";
		
		int batchJobNoColPos = llAction.GetColumnPositionInTable(tblElementKey, "Batch Job No");
		this.batchJobNo = llAction.getItemAt(tblElementKey,BatchConstants.BATCH_MONITOR_ROWINDEX,batchJobNoColPos,"a");
		
		status = true;
		dashboard.setStepDetails("Batch Query", "Initiated batch job  : " + log() ,"N/A");
		dashboard.writeResults();
		llAction.clickElement("web_btn_ExitBatchJobMonitor");
		llAction.waitUntilLoadingCompletes();
		}
		catch(Exception exception){
			throw new BPCException(exception);
		}
		
	}
	
	public int checkBatchJobStatus() throws Exception {
	
		String tblElementKey = "web_batch_monitoring_tbl";
		//int batchJobNoColPos = llAction.GetColumnPositionInTable(tblElementKey, "Batch Job No");//1
		int rowIndex = llAction.GetRowPositionInTable(tblElementKey,
				batchJobNo, batchJobNoColPos);
		//Assumptions : Batch job to be monitored will always be "2" ie. the first record in the batch updated list once query is run.
		//int batchResultColPos = llAction.GetColumnPositionInTable(tblElementKey, "Result");//8
		String executionResult = llAction.getItemAt(tblElementKey,rowIndex,batchResultColPos,"");
		
		//int batchStatusColPos = llAction.GetColumnPositionInTable(tblElementKey, "Status");//7
		String executionStatus = llAction.getItemAt(tblElementKey,rowIndex,batchStatusColPos,"");

		int result = StringUtils.isEmpty(executionStatus)? BatchConstants.BATCH_JOB_STATUS_NOT_AVAILABLE
				: BatchConstants.BATCH_JOB_STATUS_INPROGRESS;
		
		if (result == BatchConstants.BATCH_JOB_STATUS_INPROGRESS && executionStatus.equalsIgnoreCase(BatchConstants.BATCH_JOB_STATUS_COMPLETED)) {
			if (executionResult.equalsIgnoreCase(BatchConstants.BATCH_JOB_RESULT_SUCCESS) ||executionResult.equalsIgnoreCase(BatchConstants.BATCH_JOB_RESULT_PARTIAL_SUCCESS) ) {
				
				result = BatchConstants.BATCH_JOB_STATUS_SUCCESS;

				dashboard.setStepDetails("Monitor Batch Job", logStatus(executionResult,executionStatus), "N/A");
				dashboard.writeResults();
			}else{
				result = BatchConstants.BATCH_JOB_STATUS_FAILED;
				dashboard.setFailStatus(new BPCException("Monitor Batch Job Failed!!" + logStatus(executionResult,executionStatus)));
			}
		}
		return result;

	}
	public Hashtable<String, String> prepareMultiStreamJob() throws Exception {
		int multiStreamJobCount = getMultiStreamJobCount();
		String tblElementKey = "web_batch_monitoring_tbl";
		
		Hashtable<String, String> hParams=new Hashtable<String, String>();
		
		if(multiStreamJobCount > 0){
			if(streamCount == BatchConstants.UNDEFINED){
				int colPos = llAction.GetColumnPositionInTable(tblElementKey, "Batch Job No");
				int rowIndex = llAction.GetRowPositionInTable(tblElementKey,
						batchJobNo, colPos);
				llAction.SelectRowInTable(tblElementKey, rowIndex, colPos,"a");
				llAction.waitUntilLoadingCompletes();
				streamCount = Integer.parseInt(llAction.getAttribute("web_txt_streamcount","value"));
				dashboard.setStepDetails("Process MultiStream"," stream count = " + streamCount + " Job Details  - " + log() ,"N/A");
				dashboard.writeResults();
				Utils.sleep(2);
				llAction.clickElement("web_btn_ExitBatchJobMonitor");
				llAction.waitUntilLoadingCompletes();
			}
			if (streamCount > 0 && streamCount > multiStreamJobCount) {
				String message = "Check test data configured for multistream job ids. Streamcount = "
						+ streamCount
						+ " Multistream job count in testdata is : "
						+ multiStreamJobCount;
				dashboard.setFailStatus(new BPCException(message));
				dashboard.writeResults();
				throw new BPCException(new Exception(message));
			} else if (streamCount >= 0) {
				hParams.put(BatchConstants.BATCH_DUE_DATE, batchDueDate);
				hParams.put(BatchConstants.BATCH_PROCESSING_DATE,batchProcessingDate);
				hParams.put(BatchConstants.BATCH_NO_OF_JOBS,String.valueOf(streamCount));
				String msJobIds =  multiStreamJobs[0];
				
				int sc = streamCount == 0 ? multiStreamJobCount : streamCount;
				
				for (int i = 1; i < sc; i++) {
					msJobIds = msJobIds + "," + multiStreamJobs[i];
				}
				hParams.put(BatchConstants.BATCH_JOBID, msJobIds);
				hParams.put(BatchConstants.BATCH_JOBNAME, "");
			}
			
		}
		if(isRunning()){
			llAction.clickElement("web_btn_ExitBatchJobMonitor");
			llAction.waitUntilLoadingCompletes();
		}
		return hParams;
	}
	
	public String log(){
		String textMessage="";
		
		if((!StringUtils.isEmpty(jobId)) && (Integer.parseInt(jobId) > 0)){
			textMessage = "Batch Job Id: " + jobId + ", Batch Job No: "+ batchJobNo ;
		}else if(!StringUtils.isEmpty(jobName)){
			textMessage = "Batch Job Name: " + jobName + ", Batch Job No: "+ batchJobNo ;
		}
		return textMessage;
	}
	public String logStatus(String executionResult, String executionStatus ){
		String textMessage = log()  + "," + " Batch Job Execution Result : " + executionResult
				+ ", Batch Job Execution Status : "	+ executionStatus;
		return textMessage;
	}
	
	public boolean isRunning(){
		return status;
	}
	
	public void menuSelection() throws Exception{
		llAction.goMenuItem("TEST&DEBUG", "web_batchjobs_menuitem_l1");
		llAction.goMenuItem("eBao Use Module", "web_batchjobs_menuitem_l2");
		llAction.goMenuItem("Tools", "web_batchjobs_menuitem_l3");
		llAction.goMenuItem("Batch Job Testing", "web_batchjobs_menuitem_l4");
		llAction.goMenuItem("Scheduled Batch Task", "web_batchjobs_menuitem_l5");//Prashantha changed on Feb 28..2019 select "Scheduled Batch Task"
		llAction.selectMenuItem("RUN_JOB_TASK");
		
	}
}
