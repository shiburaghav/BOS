package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;

public class AMLAdmin {
	private PolicyHandler policyHandler;
	
	public AMLAdmin() {

		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}

	public void authorisationHRCByPass(Hashtable<String, String> hParams) throws Exception {
		FPMS_Actions llAction = new FPMS_Actions();
		String policyNumber = null;
		try {
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			llAction.selectMenuItem("AML Admin", "authorisation_hrc_bypass");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_aiml_txt_PolicyNo", policyNumber);
			llAction.clickElement("web_aiml_btn_HRCByPassSearch");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_aiml_btn_HRCByPassSubmit", 5)) {
				llAction.clickElement("web_aiml_check_HRCSelectAll");
				llAction.clickElement("web_aiml_btn_HRCByPassSubmit");
				llAction.waitUntilAlertisShown();
				llAction.acceptAlert();
				llAction.waitUntilLoadingCompletes();
			}
			llAction.clickElement("web_aiml_btn_HRCByPassExit");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
