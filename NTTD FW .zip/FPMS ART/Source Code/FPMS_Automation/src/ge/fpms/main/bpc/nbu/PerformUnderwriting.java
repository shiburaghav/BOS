package ge.fpms.main.bpc.nbu;

import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.ILoading;
import ge.fpms.main.ILoadingType;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.components.AMLAdmin;
import ge.fpms.main.bpc.nbu.components.LoadingComponent;

public class PerformUnderwriting extends BusinessComponent {
	FPMS_Actions llAction = new FPMS_Actions();
	DocumentManagement docMgt = new DocumentManagement();
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	AMLAdmin amlAdmin=new AMLAdmin();

	public PerformUnderwriting() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}

	public void Underwriting(Hashtable<String, String> hParams) throws Exception {
		try {
			amlAdmin.authorisationHRCByPass(hParams);
			UnderwritingSearchPolicy(hParams);
			MakeUnderwritingBenefitDecision(hParams);
			llAction.clickElement("web_uw_btn_PrepareQueryLetter");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoChildWindow("Certificate Error: Navigation Blocked");
			llAction.ClickOnOverideLink();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Prepare Query Letter button Displayed on Underwriting Decision Page",
					"User should be Navigated to Search SLQ Page", "N/A");
			dashboard.writeResults();
			/*
			 * String TableFirstRowData =
			 * llAction.getText("web_uw_tbl_UWSearchSLQDocListRow"); if
			 * (StringUtils.isEmpty(TableFirstRowData)) {
			 * llAction.clickElement("web_uw_tbl_UWSearchSLQDocListCheckAll");
			 * llAction.clickElement("web_uw_btn_UWSearchSLQPublish");
			 * llAction.waitUntilLoadingCompletes(); }
			 */

			if (llAction.isDisplayed("web_uw_tbl_UWSearchSLQDocListCheckAll", 5)) {
				llAction.clickElement("web_uw_tbl_UWSearchSLQDocListCheckAll");
				llAction.clickElement("web_uw_btn_UWSearchSLQPublish");
				llAction.waitUntilLoadingCompletes();
			}
			llAction.clickElement("web_uw_btn_SearchSLQExit");
			llAction.sleep(6);
			llAction.switchtoDefaultWindow();
			llAction.clickElement("web_uw_btn_UWSaveAndExit");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_btn_UWSPExit");
			docMgt.SearchLCALetters(hParams);
			docMgt.SelectLCALetter(hParams);
			docMgt.PerformActionOnSelectedLetters(hParams);
			docMgt.DocumentWithReply(hParams);
			UnderwritingSearchPolicy(hParams);
			MakeUnderwritingBenefitDecision(hParams);
			// ValidateUnderwritingDecision(hParams);
			ExitToHomePage(hParams);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: UnderwritingSearchPolicy Purpose: Navigate to Underwriting Page from
	 * the Main Page and Search a Policy to Underwrite. Select Policy based on the
	 * Plan Code For Underwriting From the Search Results Parameters: Parameter Hash
	 * table Return Value: NA Exception: BPCException Added By: ManjuPrasad 0n
	 * 22/11/2018
	 */
	public void UnderwritingSearchPolicy(Hashtable<String, String> hParams) throws Exception {
		String policyNumber = null;
		try {
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			llAction.selectMenuItem("NBD", "underwriting");
			llAction.clickElement("web_uw_txt_PolicyNo");
			llAction.enterValue("web_uw_txt_PolicyNo", policyNumber);
			Utils.sleep(5);
			llAction.clickElement("web_uw_btn_Search");
			llAction.waitUntilLoadingCompletes();
			llAction.move_to_element("web_uw_tbl_USPSearchPolicyList");
			System.out.println("PerformUnderwriting.UnderwritingSearchPolicy() policyNumber : " + policyNumber);

			int colPos = llAction.GetColumnPositionInTable("web_uw_tbl_USPSearchPolicyList", "Policy No.");
			int rowPos = llAction.GetRowPositionInTable("web_uw_tbl_USPSearchPolicyList", policyNumber, colPos);
			llAction.SelectRowInTable("web_uw_tbl_USPSearchPolicyList", rowPos, colPos, "a");

			llAction.waitUntilElementPresent("web_uw_check_UnderwritingOption_SelectAll");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("In Underwriting Sharing Pool Search for Policy Number  " + policyNumber,
					"The Policy Should be Available in Search Results. ", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: MakeUnderwritingBenefitDecision Purpose: Select All Benefits for
	 * Underwriting Decision Table. Click on Make Benefits Decision Button.
	 * Accept/Conditionally Accept/Postpone/Decline a Benefit based on the Input and
	 * Submit. Parameters: Parameter Hash table Return Value: NA Exception:
	 * BPCException Added By: ManjuPrasad 0n 22/11/2018
	 */
	public void MakeUnderwritingBenefitDecision(Hashtable<String, String> hParams) throws Exception {
		try {
			String UnderwritingDecision = hParams.get("UnderwritingDecision");
			String Option = hParams.get("UWDocsToBeSelected");

			if (Option.toUpperCase().equals("ALL")) {
				llAction.move_to_element("web_uw_check_UnderwritingOption_SelectAll");
				llAction.checkBox_Check("web_uw_check_UnderwritingOption_SelectAll");

				dashboard.setStepDetails(
						"Click on Select All Checkbox Displayed Under Underwriting Decision - Benefits Table",
						"All the Benefits Listed Under Underwriting Decision - Benefits Table should be Selected  ",
						"N/A");
				dashboard.writeResults();

				llAction.move_to_element("web_uw_btn_MBenefitDec");
				llAction.clickElement("web_uw_btn_MBenefitDec");

				llAction.waitUntilElementPresent("web_uw_txt_UWDec");
				llAction.waitUntilLoadingCompletes();
			} else {
				// TODO The method has to select individual CheckBox
			}

			switch (UnderwritingDecision.trim().toUpperCase()) {
			case "ACCEPTED":
				llAction.move_to_element("web_uw_txt_UWDec");
				llAction.enterValue("web_uw_txt_UWDec", "1");
				dashboard.setStepDetails("Accept the Underwriting by entering 1",
						"User should be able to enter 1 and Accept the Underwriting  ", "N/A");
				dashboard.writeResults();
				break;
			case "DECLINED":
				llAction.move_to_element("web_uw_txt_UWDec");
				llAction.enterValue("web_uw_txt_UWDec", "4");
				llAction.sendkeyStroke("web_uw_txt_UWDec", Keys.ENTER);
				dashboard.setStepDetails("Decline the Underwriting by entering 4",
						"User should be able to enter 4 and Decline the Underwriting  ", "N/A");
				dashboard.writeResults();
				break;
			case "POSTPONED":
				llAction.move_to_element("web_uw_txt_UWDec");
				llAction.enterValue("web_uw_txt_UWDec", "3");
				llAction.sendkeyStroke("web_uw_txt_UWDec", Keys.ENTER);
				llAction.enterValue("web_uw_txt_UWReasonDesc", "001");
				llAction.sendkeyStroke("web_uw_txt_UWReasonDesc", Keys.ENTER);
				dashboard.setStepDetails("Postpone the Underwriting by entering 3",
						"User should be able to enter 3 and Postpone the Underwriting  ", "N/A");
				dashboard.writeResults();
				break;
			case "CONDITIONALLY ACCEPTED":
				llAction.move_to_element("web_uw_txt_UWDec");
				llAction.enterValue("web_uw_txt_UWDec", "2");
				llAction.clickElement("web_uw_txt_UWPreviousUnderwriter");

				dashboard.setStepDetails("Conditionally Accept the Underwriting by entering 2",
						"User should be able to enter 2 and Conditionally Accept the Underwriting  ", "N/A");
				dashboard.writeResults();
				break;
			}
			if (!UnderwritingDecision.equals("CONDITIONALLYACCEPT")) {
				llAction.clickElement("web_uw_btn_SubmitUWDec");
				llAction.waitUntilAlertisShown();
				llAction.acceptAlert();
				llAction.waitUntilLoadingCompletes();
				
				dashboard.setStepDetails("Validate if user is navigated to Underwrting Decision Page",
						"User should be navigated to Underwrting Decision Page", "N/A");
				dashboard.writeResults();
				if (llAction.isDisplayed("web_btn_continue", 5)) {
					llAction.clickElement("web_btn_continue");
					llAction.waitUntilLoadingCompletes();
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: PrepareQueryLetter Purpose: Click on Prepare Query Letter Button and
	 * Generate a New SLQ by clikcing on Create Button Parameters: Parameter Hash
	 * table Return Value: NA Exception: BPCException Added By: ManjuPrasad 0n
	 * 26/11/2018
	 */
	public void PrepareQueryLetter(Hashtable<String, String> hParams) throws Exception {
		String[] MedicalReqCodes = hParams.get("MedicalRequirementCode").split(",");
		String[] QuesCodes = hParams.get("QuestionnaireCode").split(",");
		try {
			UnderwritingSearchPolicy(hParams);
			llAction.move_to_element("web_uw_btn_PrepareQueryLetter");
			llAction.clickElement("web_uw_btn_PrepareQueryLetter");
			llAction.waitUntilLoadingCompletes();
			llAction.switchtoChildWindow("Certificate Error: Navigation Blocked");
			llAction.ClickOnOverideLink();
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Prepare Query Letter button Displayed on Underwriting Decision Page",
					"User should be Navigated to Search SLQ Page", "N/A");
			dashboard.writeResults();
			llAction.waitUntilElementPresent("web_uw_btn_CreateSLQ");
			llAction.switchtoChildWindow("Search SLQ");
			llAction.clickElement("web_uw_btn_CreateSLQ");
			llAction.waitUntilLoadingCompletes();
			llAction.waitUntilElementPresent("web_uw_txt_GenSLQMedReqCode");
			llAction.switchtoChildWindow("Generation of SLQ");
			dashboard.setStepDetails("Click on Create button Displayed on Search SLQ Page",
					"User should be Navigated to Generation of SLQ Page", "N/A");
			dashboard.writeResults();
			llAction.maximizeWindow();
			for (String MedReqCode : MedicalReqCodes) {
				llAction.enterValue("web_uw_txt_GenSLQMedReqCode", MedReqCode);
				llAction.sendkeyStroke("web_uw_txt_GenSLQMedReqCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_uw_lst_MedQuesCodeRole", hParams.get("MedQuestionToRole"));
				llAction.clickElement("web_uw_btn_GenSLQMedCodeAdd");
				llAction.waitUntilLoadingCompletes();
			}
			for (String QuesCode : QuesCodes) {
				llAction.enterValue("web_uw_txt_GenSLQQuesCode", QuesCode);
				llAction.sendkeyStroke("web_uw_txt_GenSLQQuesCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_uw_lst_QuesCodeRole", hParams.get("QuestionToRole"));
				llAction.clickElement("web_uw_btn_GenSLQQuesCodeAdd");
				llAction.waitUntilLoadingCompletes();
			}

			dashboard.setStepDetails("Enter Questionnaire Codes and Click on Publish Query Letter button",
					"User should be able to enter the Questionnaire Codes and System should Close Generation of SLQ Pop-Up Screen", "N/A");
			llAction.clickElement("web_uw_btn_GenSLQPublish");
			llAction.waitUntilLoadingCompletes();
			dashboard.writeResults();
			llAction.switchtoChildWindow("Search SLQ");
			dashboard.writeResults();
			llAction.clickElement("web_uw_btn_SearchSLQExit");
			llAction.sleep(6);
			llAction.switchtoDefaultWindow();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void EnterExtraLoading(Hashtable<String, String> hParams) throws Exception {
		
		try {
			LoadingFactory factory = new LoadingFactory();
			ILoading loading = factory.createLoading(hParams.get("LoadingOption"));
			ILoadingType loadingType = factory.createLoadingType(hParams.get("LoadingType"));

			LoadingComponent comp = new LoadingComponent(loadingType, loading);
			comp.addLoadingTypeInfo(hParams);
			llAction.clickElement("web_uw_btn_SubmitUWDec");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			SaveExitToHomePage(hParams);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	/*
	 * Name: EnterLienInformation Purpose: Enter Lien Information for Conditionally
	 * Accepts a Benefit Information Parameters: Parameter Hash table Return Value:
	 * NA Exception: BPCException Added By: ManjuPrasad 0n 26/11/2018
	 */
	public void EnterLienInformation(Hashtable<String, String> hParams) throws Exception {
		String LienType = hParams.get("LienType");
		String EMValue = hParams.get("LienEMValue");
		String LienPercentage = hParams.get("LienPercentageFactor");
		try {
			llAction.clickElement("web_uw_btn_UWEnterLien");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_txt_LienType");
			llAction.enterValue("web_uw_txt_LienType", LienType);
			llAction.clickElement("web_uw_txt_EMValue");
			llAction.enterValue("web_uw_txt_EMValue", EMValue);
			llAction.clickElement("web_uw_txt_LienPercentage");
			llAction.enterValue("web_uw_txt_LienPercentage", LienPercentage);

			dashboard.setStepDetails(
					"Enter LienType: " + LienType + ", EM Value: " + EMValue + ", Lien Percentage: " + LienPercentage
							+ " and CLick on Submit Button ",
					"User should be able to enter the values and User should be Navigated to Underwiriting Main Screen",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_uw_txt_TotalLienAmt");
			dashboard.setStepDetails("Validate if Lien Information is Entered",
					"Lien Information should be enterd", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_uw_btn_UWLienSubmit");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_btn_SubmitUWDec");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			SaveExitToHomePage(hParams);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	

	public boolean ValidateUnderwritingDecision(Hashtable<String, String> hParams) throws Exception {
		boolean Status = false;
		String expectedBenefitStatus = hParams.get("ExpectedBenefitStatus");
		try {

			int colPos = llAction.GetColumnPositionInTable("web_uw_tbl_UWBenefitsList", "Underwriting Decision");
			List<String> actualBenefitStatus = llAction.GetAllTextUnderColumnInTable("web_uw_tbl_UWBenefitsList",
					colPos);

			for (String benefitStatus : actualBenefitStatus) {
				if (benefitStatus.equals(expectedBenefitStatus.toUpperCase())) {
					dashboard.setStepDetails(
							"Validate if status is " + expectedBenefitStatus
									+ " under Underwriting Benefit Status Column",
							"The Expected Benefit Status should be " + expectedBenefitStatus + "", "N/A");
					dashboard.writeResults();
				} else {
					dashboard.setFailStatus(new BPCException("The Actual Benefit Status " + benefitStatus
							+ " does not match with Expected Benefit Status " + expectedBenefitStatus + ""));
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
		return Status;
	}
	

	public void ExitToHomePage(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.waitUntilLoadingCompletes();
			llAction.isDisplayed("web_uw_btn_SubmitUWmain", 5);
			llAction.clickElement("web_uw_btn_SubmitUWmain");

			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();

			/*
			 * if (llAction.isEnabled("web_uw_btn_SubmitUWmain")) {
			 * llAction.clickElement("web_uw_btn_SubmitUWmain");
			 * llAction.waitUntilAlertisShown(); llAction.acceptAlert();
			 * llAction.waitUntilLoadingCompletes(); }
			 */
			
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
			}

			if (llAction.isDisplayed("web_uw_btn_UWInForceInfoExit", 5)) {
				dashboard.setStepDetails("Validate if Policty Status is displayed",
						"Policty Status Should be displayed", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_uw_btn_UWInForceInfoExit");
				llAction.waitUntilLoadingCompletes();
			}

			if (llAction.isDisplayed("web_uw_btn_UWSPBack", 5)) {
				dashboard.setStepDetails("Validate if Policty Status is displayed",
						"Policty Status Should be displayed", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_uw_btn_UWSPBack");
				llAction.waitUntilLoadingCompletes();
			}

			llAction.isDisplayed("web_uw_btn_UWSPExit", 5);
			llAction.clickElement("web_uw_btn_UWSPExit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void SaveExitToHomePage(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.clickElement("web_uw_btn_UWSaveAndExit");
			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
			}
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_btn_UWSPExit");
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void validateUnderwritingErrorMessage(Hashtable<String, String> hParams) throws Exception{
		try{
			amlAdmin.authorisationHRCByPass(hParams);
			UnderwritingSearchPolicy(hParams);
			MakeUnderwritingBenefitDecision(hParams);
			llAction.isDisplayed("web_uw_btn_SubmitUWmain", 5);
			llAction.clickElement("web_uw_btn_SubmitUWmain");

			llAction.waitUntilAlertisShown();
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			if(llAction.isDisplayed("web_table_UnderwrtingWarningMessage", 5)) {
				String warningMessage = llAction.getText("web_table_UnderwrtingWarningMessage");
				if(warningMessage.contains("SPP SA exceed")) {
					dashboard.setStepDetails("Validate if SPP SA Exceed error message is displayed", "Error Message should be displayed", "");
					dashboard.writeResults();
					SaveExitToHomePage(hParams);
				}
			}
		}catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}

