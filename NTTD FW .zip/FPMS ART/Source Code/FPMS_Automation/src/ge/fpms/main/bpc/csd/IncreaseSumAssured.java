package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class IncreaseSumAssured {

	// Name: ILPIncreaseSumAssured
	// Purpose: Navigate to CS module from the Main Page and increase sum assured
	// for a policy
	// Parameters : Parameter Hash table
	// Return Value: NA
	// Exception: BPCException
	// @author: Prashantha on 19/12/2018

	

	private FPMS_Actions llAction = new FPMS_Actions();

	private DashboardHandler dashboard;

	public IncreaseSumAssured() {
		dashboard = DashboardHandler.getInstance();
		llAction = new FPMS_Actions();
	}

	
}
