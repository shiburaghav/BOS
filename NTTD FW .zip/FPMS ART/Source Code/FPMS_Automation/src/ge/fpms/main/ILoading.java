package ge.fpms.main;

import java.util.Hashtable;

public interface ILoading {
	public static String Health_Loading = "HealthLoading";
	public static String Occupation_Loading = "OccupationLoading";
	public static String Avocation_Loading = "AvocationLoading";
	public static String MotorCyclist_Loading = "MotorCyclistLoading";
	public static String Residential_Loading = "ResidentialLoading";
	public static String Aviation_Loading = "AviationLoading";
	public static String Other_Loading = "OtherLoading";
	public static String MSHL_Loading = "MSHLLoading";
	public void enterSpecificLoadingInfo(Hashtable<String, String> hParams) throws Exception;
}