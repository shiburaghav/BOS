package ge.fpms.main.bpc.nbu.negative;

import java.util.Hashtable;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.DetailRegistrationComponent;

public class DetailRegistration {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	public DetailRegistrationComponent DRC;

	public DetailRegistration() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
		DRC = new DetailRegistrationComponent();
	}
	
	public void validatePartyAge(Hashtable<String, String> hParams) throws Exception{
		try {
			
			llAction.selectMenuItem("NBD", "Detail Registration");
			DRC.searchPolicy(hParams.get("PolicyNo"), "web_detail_tbl_PolicyList", "web_txt_DetailReg_PolicyNumber");
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			
			int colPos = llAction.GetColumnPositionInTable("web_addr_table_proposer", "Party ID No");
			String partyID = llAction.GetTextFromTable("web_addr_table_proposer", 2, colPos);
			String partyIDType = llAction.GetTextFromTable("web_addr_table_proposer", 2, colPos-1);
			String partyName = llAction.GetTextFromTable("web_addr_table_proposer", 2, colPos+1);
			llAction.SelectRowInTable("web_addr_table_proposer", 2, colPos, "a");
			
			llAction.handleCertificateErrors();
			llAction.switchtoSecondWindow();
			
			
			
			
		}catch(Exception ex) {
			throw new BPCException(ex);
		}
	}
}
