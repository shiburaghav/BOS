package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.bpc.csd.components.CSDHelper;
import ge.fpms.main.actions.FPMS_Actions;

public class Loan {

	/*
	 * Name: Loan Purpose: Navigate to CS module from the Main Page and apply loan
	 * for a policy Parameters:Parameter Hash table Return Value: NA Exception:
	 * BPCException
	 * 
	 * @author: Prashantha on 29/12/2018
	 */
	public Loan() {
		dashboard = DashboardHandler.getInstance();
		llAction = new FPMS_Actions();
	}

	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;

	public void applyPolicyLoan(Hashtable<String, String> hParams) throws Exception {

		try {

			String policyNumber = hParams.get("PolicyNumber");
			String loanAmount = hParams.get("LoanAmount");
			llAction.selectMenuItem("Customer Service", "Apply Policy Loan");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_PolicyLoan_PolicyNumber", policyNumber);
			llAction.clickElement("web_btn_Search");
			llAction.waitUntilLoadingCompletes();
			llAction.move_to_element("web_tbl_policyInformation");
			dashboard.setStepDetails("Enter Policy Number '" + policyNumber + "' in the Text Box. Click [Search].",
					"Policy search could not be successfully searched", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_PolicyLoanAmt", loanAmount);
			String netLoanAmtAvailable = llAction.table_GetValueOfSpecificLabel("web_tbl_policyLoanAmtAvailabilityInfo",
					"Net policy loan available amount");
			dashboard.setStepDetails("Capture netLoanAmtAvailable",
					"The netLoanAmtAvailable is:= " + netLoanAmtAvailable, "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_PolicyLoanSubmit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on submit button", "Clicked on Submit button", "N/A");
			dashboard.writeResults();
			if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {
				CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg_applypolicyloan",
						hParams.get("WarningErrorMessage"));
				llAction.clickElement("web_applypolicyloan_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			} else {

				if (llAction.isDisplayed("web_applypolicyloan_btn_Continue", 5))
					llAction.clickElement("web_btn_continue");
				CSDHelper.getInstance().captureChange("Capture Loan Amount Before Submit", "BEFORECHANGE");
				llAction.selectMenuItem("Query", "Common Query");
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_radio_PolicyNumber");
				llAction.enterValue("web_txt_CommonQueryPolicyNumber", policyNumber);
				llAction.move_to_element("web_btn_Query_Search");
				llAction.clickElement("web_btn_Query_Search");
				dashboard.setStepDetails("Seach Policy ", "Policy number should be entered and clicked successfully",
						"N/A");
				dashboard.writeResults();
				llAction.waitUntilLoadingCompletes();
				llAction.selectTab("Financial Info");
				llAction.waitUntilLoadingCompletes();
				llAction.scrolldown();
				CSDHelper.getInstance().captureChange("Capture Financial Info", "AFTERCHANGE");
				llAction.waitUntilLoadingCompletes();
				llAction.selectTab("Loan/Deposit Info");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().captureChange("Capture LoanDeposit Info", "AFTERCHANGE");
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_PartyChanges_btn_Exit");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Click on exit", "System should display the Main Page of the FPMS.", "N/A");
				dashboard.writeResults();
			}

		}

		catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

}
