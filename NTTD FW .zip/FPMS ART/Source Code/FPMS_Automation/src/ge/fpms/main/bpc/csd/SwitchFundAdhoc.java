package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import org.openqa.selenium.Keys;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class SwitchFundAdhoc {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public SwitchFundAdhoc() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void switchFundByUnitsOrValue(Hashtable<String, String> hParams) throws Exception {

		try {

			String switchBy = hParams.get("SwitchBy");
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			int colPos = llAction.GetColumnPositionInTable("web_tbl_BenefitInformation", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_BenefitInformation", hParams.get("BenefitCode"),
					colPos);
			if (llAction.getRowCountInTable("web_tbl_BenefitInformation") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitInformation", rowPos, colPos - 2, "input");
			}
			CSDHelper.getInstance().captureChange("Switch Fund Adhoc", "BeforeChange");
			if (switchBy.equalsIgnoreCase(FPMSConstants.SWITCHBYVALUE)) {
				llAction.clickElement("web_btn_SwitchByValue");
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");
				dashboard.setStepDetails("Enter Fund Switch value", "Fund Switch value is entered", "N/A");
				llAction.selectByVisibleText("web_lst_FromBenefit", hParams.get("FromBenefit"));
				llAction.sendkeyStroke("web_lst_FromBenefit", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_lst_ToBenefit", hParams.get("ToBenefit"));
				llAction.sendkeyStroke("web_lst_ToBenefit", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_lst_FundFrom", hParams.get("From"));
				llAction.sendkeyStroke("web_lst_FundFrom", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_FundTo", hParams.get("To"));
				llAction.sendkeyStroke("web_txt_FundTo", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_SwitchFund_Value", hParams.get("Value"));
				dashboard.writeResults();
				dashboard.setStepDetails("Click on Add button after entering fund value",
						"Fund value should be populated", "N/A");
				llAction.clickElement("web_btn_SwitchFund_Add");
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");
				dashboard.writeResults();
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_btn_SwitchFundByValue_Submit");
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();

			} else {
				llAction.clickElement("web_btn_SwitchByUnits");
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");
				dashboard.setStepDetails("Enter Fund Switch value", "Fund Switch value is entered", "N/A");
				llAction.selectByVisibleText("web_lst_FromBenefit", hParams.get("FromBenefit"));
				llAction.sendkeyStroke("web_lst_FromBenefit", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_lst_ToBenefit", hParams.get("ToBenefit"));
				llAction.sendkeyStroke("web_lst_ToBenefit", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_lst_FundFrom", hParams.get("From"));
				llAction.sendkeyStroke("web_lst_FundFrom", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_FundTo", hParams.get("To"));
				llAction.sendkeyStroke("web_txt_FundTo", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_SwitchFund_Units", hParams.get("Units"));
				dashboard.writeResults();
				dashboard.setStepDetails("Click on Add button after entering fund value",
						"Fund value should be populated", "N/A");
				llAction.clickElement("web_btn_SwitchFund_Add");
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");
				dashboard.writeResults();
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_btn_SwitchFundByValue_Submit");
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();

			}
			CSDHelper.getInstance().captureChange("Switch Fund Adhoc", "AfterChange");
			dashboard.setStepDetails("Click on Submit button in ILP Fund Switch Screen",
					"Application Entry Screen should be displayed", "N/A");
			llAction.clickElement("web_btn_ILPFundSwitch_Submit");
			if (llAction.isDisplayed("web_btn_continue", 5))
				llAction.clickElement("web_btn_continue");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {

			throw new BPCException(ex);

		}
	}

	public void switchFundValidatePolicyAlteration(Hashtable<String, String> hParams) throws Exception {

		try {
			llAction = new FPMS_Actions();
			String message = hParams.get("WarningErrorMessage2");/* Get expected warning message from Test Data */
			String switchBy = hParams.get("SwitchBy");
			llAction.enterValue("web_txt_ValidityDate", hParams.get("Validitydate"));
			int colPos = llAction.GetColumnPositionInTable("web_tbl_BenefitInformation", "Benefit");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_BenefitInformation", hParams.get("BenefitCode"),
					colPos);
			if (llAction.getRowCountInTable("web_tbl_BenefitInformation") != 2) {
				llAction.SelectRowInTable("web_tbl_BenefitInformation", rowPos, colPos - 2, "input");
			}
			CSDHelper.getInstance().captureChange("Switch Fund Adhoc", "BeforeChange");
			if (switchBy.equalsIgnoreCase(FPMSConstants.SWITCHBYVALUE)) {

				llAction.clickElement("web_btn_SwitchByValue");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message);
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Enter Fund Switch value", "Fund Switch value is entered", "N/A");
				llAction.selectByVisibleText("web_lst_FromBenefit", hParams.get("FromBenefit"));
				llAction.sendkeyStroke("web_lst_FromBenefit", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_lst_ToBenefit", hParams.get("ToBenefit"));
				llAction.sendkeyStroke("web_lst_ToBenefit", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_lst_FundFrom", hParams.get("From"));
				llAction.sendkeyStroke("web_lst_FundFrom", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_FundTo", hParams.get("To"));
				llAction.sendkeyStroke("web_txt_FundTo", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_SwitchFund_Value", hParams.get("Value"));
				llAction.sendkeyStroke("web_txt_SwitchFund_Value", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				dashboard.writeResults();
				dashboard.setStepDetails("Click on Add button after entering fund value",
						"Switch Fund by Value page should be displayed", "N/A");
				llAction.clickElement("web_btn_SwitchFund_Add");
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
				dashboard.writeResults();
				llAction.clickElement("web_btn_SwitchFundByValue_Submit");
				if (llAction.isDisplayed("web_btn_continue", 5)) {
					llAction.clickElement("web_btn_continue");
				}
				llAction.waitUntilLoadingCompletes();

			} else {

				llAction.clickElement("web_btn_SwitchByUnits");
				llAction.waitUntilLoadingCompletes();
				CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message);
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Enter Fund Switch Units", "Fund Switch Units are entered", "N/A");
				llAction.selectByVisibleText("web_lst_FromBenefit", hParams.get("FromBenefit"));
				llAction.sendkeyStroke("web_lst_FromBenefit", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_lst_ToBenefit", hParams.get("ToBenefit"));
				llAction.sendkeyStroke("web_lst_ToBenefit", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.selectByVisibleText("web_lst_FundFrom", hParams.get("From"));
				llAction.sendkeyStroke("web_lst_FundFrom", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_FundTo", hParams.get("To"));
				llAction.sendkeyStroke("web_txt_FundTo", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_SwitchFund_Units", hParams.get("Units"));
				llAction.sendkeyStroke("web_txt_SwitchFund_Units", Keys.TAB);
				llAction.waitUntilLoadingCompletes();
				dashboard.writeResults();
				dashboard.setStepDetails("Click on Add button after entering fund units",
						"Switch Fund by Units page should be displayed", "N/A");
				llAction.clickElement("web_btn_SwitchFund_Add");
				llAction.waitUntilLoadingCompletes();
				if (llAction.isDisplayed("web_btn_continue", 5))
					llAction.clickElement("web_btn_continue");
				dashboard.writeResults();
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_btn_SwitchFundByValue_Submit");
				if (llAction.isDisplayed("web_btn_continue", 5)) {
					llAction.clickElement("web_btn_continue");
				}
				llAction.waitUntilLoadingCompletes();

			}

			CSDHelper.getInstance().captureChange("Switch Fund Adhoc", "AfterChange");
			dashboard.setStepDetails("Click on Submit button in ILP Fund Switch Screen",
					"Application Entry Screen should be displayed", "N/A");
			llAction.clickElement("web_btn_ILPFundSwitch_Submit");
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", message);
				llAction.clickElement("web_btn_continue");
			}
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {

			throw new BPCException(ex);

		}

	}

	public void validationAtClickEnterInformation(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		llAction.waitUntilLoadingCompletes();
		CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", hParams.get("WarningErrorMessage1"));
	}
}
