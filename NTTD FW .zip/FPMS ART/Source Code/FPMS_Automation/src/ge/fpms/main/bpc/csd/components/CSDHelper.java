package ge.fpms.main.bpc.csd.components;

import ge.fpms.main.FPMSConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import com.nttdata.core.LL_Actions;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class CSDHelper {
	private static CSDHelper helper;
	private DashboardHandler dashboard;
	private LL_Actions llAction;

	private CSDHelper() {
		dashboard = DashboardHandler.getInstance();
		llAction = new LL_Actions();
	}

	public static CSDHelper getInstance() {
		if (helper == null) {
			helper = new CSDHelper();
		}
		return helper;
	}

	public boolean validateWarningMessages(String tableElementKey, String message) throws Exception {
		try {
			boolean isValid=false;
			List<WebElement> actualWarningMsgElements;
			List<String> actualWarningMsgs = new ArrayList<String>();
			List<String> expectedWarningMsgs = new ArrayList<String>();

			if (message.contains(";")) {
				String[] parts = message.split(";");
				expectedWarningMsgs = Arrays.asList(parts);
				LL_Actions llAction = new LL_Actions();
				actualWarningMsgElements = llAction.findElements(tableElementKey);
				for (WebElement actualWarningMsgElement : actualWarningMsgElements) {
					actualWarningMsgs.add(actualWarningMsgElement.getText());
				}

				if (expectedWarningMsgs.size() >= actualWarningMsgs.size()) {
					for (int i = 0; i < expectedWarningMsgs.size(); i++) {
						for (int j = 0; j < actualWarningMsgs.size(); j++) {
							if (actualWarningMsgs.get(j).contains(expectedWarningMsgs.get(i).trim())) {
								dashboard.setStepDetails(message + " Warning message should be displayed",
										"The Warning message displayed is :"+actualWarningMsgs.get(j), "N/A");
								dashboard.writeResults();
								isValid=true;
								break;
							}
						}//break;
					}
				}

				else {
					dashboard.setFailStatus(new BPCException("Not all expected error messages are displayed"));
				}

			} else {

				String[] parts = message.split(",");

				expectedWarningMsgs = Arrays.asList(parts);

				LL_Actions llAction = new LL_Actions();
				actualWarningMsgElements = llAction.findElements(tableElementKey);
				for (WebElement actualWarningMsgElement : actualWarningMsgElements) {
					actualWarningMsgs.add(actualWarningMsgElement.getText());
				}

				if (expectedWarningMsgs.size() <= actualWarningMsgs.size()) {
					for (int i = 0; i < expectedWarningMsgs.size(); i++) {
						for (int j = 0; j < actualWarningMsgs.size(); j++) {
							if (actualWarningMsgs.get(j).contains(expectedWarningMsgs.get(i).trim())) {
								dashboard.setStepDetails(expectedWarningMsgs.get(i) + " Warning message should be displayed",
										"The Warning message displayed is :"+actualWarningMsgs.get(j), "N/A");
								dashboard.writeResults();
								isValid=true;
								//break;
							}
						}
						if(!isValid)
						{
							dashboard.setFailStatus(new BPCException("Warning message "+expectedWarningMsgs.get(i)+ "is not found"));
						}
					}
				}

				else {
					dashboard.setFailStatus(new BPCException("Not all expected error messages are displayed"));
				}
			}
			return isValid;
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/**
	 * captureChange :
	 * 
	 * @param functionality
	 *            - Method name or functionality for which changes are checked
	 * @param ActionType
	 *            - BeforeChnage or AfterChange
	 */
	public void captureChange(String functionality, String ActionType) throws Exception {
		try {
			switch (ActionType.toUpperCase()) {
			case "BEFORECHANGE":
				dashboard.setStepDetails(functionality + " before changes", "Captured changes successfully", "N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":
				dashboard.setStepDetails(functionality + " after changes", "Captured changes successfully", "N/A");
				dashboard.writeResults();
				break;
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void checkApplicationStatus() throws Exception {
		try {
			String text = llAction.getText("web_txt_application_status");

			if (!StringUtils.isEmpty(text) && (text.contains(FPMSConstants.POLICY_STATUS_APPROVED)
					|| text.contains(FPMSConstants.POLICY_STATUS_INFORCE)
					|| text.contains(FPMSConstants.POLICY_STATUS_INFORCE1)
					|| text.contains(FPMSConstants.POLICY_STATUS_AUHTORITY))) {
				DashboardHandler.getInstance().setStepDetails("Application Status", text, "N/A");
			} else {
				DashboardHandler.getInstance().setWarningStatus(
						"Failed : Application Status " + " Application can not be processed. " + text);
			}
			DashboardHandler.getInstance().writeResults();
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_txt_common_back_to_main");
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void endOfTransaction() {
		try {


			if (llAction.isDisplayed("web_btn_continue", 8)) {
				dashboard.setStepDetails("Warning message is displayed on submit button click",
						"Warning message is captured", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();

			}
			String screenName = llAction.getText("web_txt_deleterider_screen_validation").replaceAll("[^a-zA-Z0-9\\s+]",
					" ");
			dashboard.setStepDetails("System should display " + screenName + " screen on submit button click",
					screenName + " is Displayed on submit button click", "N/A");
			dashboard.writeResults();

			if (screenName.equalsIgnoreCase("Modify collection refund")) {
				screenName = submit();
			}

			if (screenName.equalsIgnoreCase("Application entry")) {
				screenName = submit();
			}

			if (screenName.equalsIgnoreCase("Display offset fee result")) {
				dashboard.setStepDetails("Click on Exit Buttom", "System should show Operation result screen", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_btn_deleterider_exit_button");
				llAction.waitUntilLoadingCompletes();
			}
			checkApplicationStatus();			
		} catch (Exception ex) {

			throw new BPCException(ex);
		}

	}

	public String submit() throws Exception {
		try {

			llAction.clickElement("web_btn_addrider_common_submit_button");
			llAction.waitUntilLoadingCompletes();
			String screenName = llAction.getText("web_txt_deleterider_screen_validation").replaceAll("[^a-zA-Z0-9\\s+]",
					" ");
			dashboard.setStepDetails("System should display " + screenName + " screen on submit button click",
					screenName + " is Displayed on submit button click", "N/A");
			dashboard.writeResults();
			return screenName;

		} catch (Exception ex) {

			throw new BPCException(ex);
		}
	}
}
