package ge.fpms.main.bpc.csd;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;

public class UnlockFrozenPolicy {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public UnlockFrozenPolicy() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	public void unlockFrozenPolicy(Hashtable<String, String> hParams) throws Exception {

		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {
			String frozenStatus = "N";
			llAction.selectMenuItem("Customer Service", "Unlock Frozen Policy");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_frozen_PolicyNo", hParams.get("PolicyNumber"));
			dashboard.setStepDetails("Enter a frozen Policy Number to be unlocked","Frozen policy Number is entered","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_CPF_Search");
			llAction.waitUntilLoadingCompletes();
			if(llAction.getText("web_txt_frozenReason").equalsIgnoreCase(FPMSConstants.VALIDFROZENREASON))
			{
				llAction.checkBox_Check("web_btn_unlockPolicy");
				llAction.clickElement("web_btn_unlock_Submit");
				dashboard.setStepDetails("Check the unlockPolicy button and submit","Frozen Policy is Unlocked","N/A");
				dashboard.writeResults();
				llAction.selectMenuItem("Query", "Common Query");
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_btn_policyRadiobtn");
				llAction.enterValue("web_txt_Query_PolicyNo", hParams.get("PolicyNumber"));
				llAction.sendkeyStroke("web_txt_Query_PolicyNo", Keys.ENTER);
				llAction.clickElement("web_btn_Query_Search");
				llAction.waitUntilLoadingCompletes();
				if(llAction.getText("web_txt_frozenStatus").equalsIgnoreCase(frozenStatus))
				{
					dashboard.setStepDetails("Verify the Frozen Status of policy in Common Query","Frozen Status of policy should be N ","N/A");
					dashboard.writeResults();
				}
				llAction.clickElement("web_btn_unlock_Exit");
			}
			else
			{
				llAction.checkBox_Check("web_btn_unlockPolicy");
				if(llAction.isAlertDisplayed())
				{
					dashboard.setStepDetails("Unlock check box is checked","System prompts-This function is not allowed for this policy Popup ","N/A");
					dashboard.writeResults();
					llAction.acceptAlert();
					llAction.clickElement("web_btn_unlock_Exit");
					dashboard.setStepDetails("Accept the alert and click on Exit","Main Menu page is displayed ","N/A");
					dashboard.writeResults();
				}
				else {
					dashboard.setFailStatus(new BPCException("Expected pop-up is not displayed"));
				}
			}
		} catch (Exception ex) {

			throw new BPCException(ex);

		}
	}
}
