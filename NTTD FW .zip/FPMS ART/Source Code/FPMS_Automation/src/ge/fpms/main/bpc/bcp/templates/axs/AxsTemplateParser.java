package ge.fpms.main.bpc.bcp.templates.axs;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import org.apache.commons.lang3.StringUtils;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.nttdata.common.util.ColumnHeader;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.core.handler.DataHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.bcp.templates.PaymentTemplatesParse;
import ge.fpms.main.bpc.bcp.templates.Type;
import ge.fpms.main.bpc.bcp.templates.axs.Details;

public class AxsTemplateParser extends PaymentTemplatesParse {

	private Axs axs;
	private ArrayList<Details> detailList;
	private Details initalDR;
	private String sheetName;
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private int hashPolicLength = 0;
	private String gelApplication = "";
	private String fileName = "";
	private String batchName = "";

	public AxsTemplateParser() {
		super();
		sheetName = ColumnHeader.AXS.toString();
		detailList = new ArrayList<Details>();
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		
	}

	/**
	 * parseGiro - for parsing giro files
	 * 
	 * @param params
	 *            - parameters from testdata
	 */
	public void uploadAxsFile(Hashtable<String, String> params) throws Exception {
		try {

			llAction.selectMenuItem("System Administration", "BCP", "Upload LockBox&EBank File");
			llAction.selectByVisibleText("web_select_fileupload_type", "AXS");
			processAxsTemplate(params); //Can be called seperately if you need only file
			llAction.enterValue("web_select_fileupload_batchname",batchName);
			llAction.enterValue("web_select_fileupload", fileName);
			Utils.sleep(3);
			dashboard.setStepDetails("Prepare Axs file to upload and select the file for upload",
					fileName + " AXS file is created successfully and ready to validate", "");
			dashboard.writeResults();
			llAction.clickElement("web_select_fileupload_validate");
			if (llAction.isAlertDisplayed((long) 5)) {
				llAction.acceptAlert();
				dashboard.setFailStatus(new BPCException("AXS template is invalid"));
			}
			llAction.waitUntilLoadingCompletes();
			if (llAction.getText("web_select_fileupload_message").equalsIgnoreCase("Success")) {
				dashboard.setStepDetails("Axs file validation should be successfull", "AXS validated successfully", "");
				dashboard.writeResults();
				llAction.clickElement("web_select_fileupload_submit");
				llAction.acceptAlert();
				llAction.waitUntilLoadingCompletes();
				if (llAction.getText("web_select_fileupload_message").equalsIgnoreCase("File Upload Success")) {
					dashboard.setStepDetails("Axs file upload should be successfull", "AXS file uploaded successfully",
							"");
					dashboard.writeResults();
					llAction.clickElement("web_select_fileupload_exit");
					llAction.waitUntilLoadingCompletes();
				}
			} else {
				dashboard.setFailStatus(new BPCException("AXS file is invalid"));
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void processAxsTemplate(Hashtable<String, String> params) throws Exception {
		try {
			String jsonTemplate = "";
			if (params.get("Type").equalsIgnoreCase("Life") || (params.get("Type").equalsIgnoreCase("Fpms"))) {
				hashPolicLength = 10;
				gelApplication = "FPMS";
				fileName = params.get("OutputFile") + "\\AXS" + gelApplication.toUpperCase() + getSystemDate() + ".txt";
				jsonTemplate =FPMSProperties.getInstance().getJsonPath("axsLife.json");
				batchName = "AXS" + gelApplication.toUpperCase() + getSystemDate();

			} else if (params.get("Type").equalsIgnoreCase("ANH") || (params.get("Type").equalsIgnoreCase("Navisys"))) {
				hashPolicLength = 9;
				gelApplication = "NAVISYS";
				Format formatter = new SimpleDateFormat("yyyyMMdd");
				Date date1 = new SimpleDateFormat("ddMMyyyy").parse(getSystemDate());
				fileName = params.get("OutputFile") + "\\AXS" + gelApplication.toUpperCase() + formatter.format(date1)
						+ ".txt";
				jsonTemplate = FPMSProperties.getInstance().getJsonPath("axsLife.json");
//						AxsTemplateParser.class.getResource("axsNavisys.json").getPath().toString();
				batchName = "AXS" + gelApplication.toUpperCase() + formatter.format(date1);
			}
			loadObject(jsonTemplate);
			processTemplateFile(params);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	@Override
	public void processTemplateFile(Hashtable<String, String> params) {
		updateAttributes(params);
		createNewFile(params.get("OutputFile"));
	}

	@Override
	public void beginParse(String line) {
	}

	@Override
	public void parse(String line) {
		System.out.println("AxsTemplateParser.parseDetails() : " + line);
		if (line.startsWith(initalDR.getName())) {
			int startIndex = 0, endIndex = 0;

			int[] attributeSpace = initalDR.getAttributesSize();
			Type[] attributes = initalDR.getAllAttributes();
			Type[] newAttributes = new Type[attributes.length];
			for (int i = 0; i < attributeSpace.length; i++) {
				String value = "";
				endIndex += attributeSpace[i];
				if (endIndex <= line.length()) {
					value = new String(line.substring(startIndex, endIndex));
					startIndex = endIndex;
				} else {
					value = "";
				}
				newAttributes[i] = new Type(attributeSpace[i], attributes[i].getDataType(), value,
						attributes[i].getAlignment(), attributes[i].getPaddingChar());
			}
			detailList.add(getRecordCount(), new Details(newAttributes));
		}
	}

	@Override
	public void endParse(String line) {
		axs.setDetails(detailList.toArray(new Details[0]));
		// parseFooter(line);

	}

	@Override
	public void createNewFile(String outputFile) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
			out.write(axs.getHeader().toString());
			out.newLine();
			for (Details det : axs.getDetails()) {
				out.write(det.toString());
				out.newLine();
			}
			out.write(axs.getSummary().toString());
			out.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void updateAttributes(Hashtable<String, String> hParams) {
		try {

			int totalAmoutnt = 0;
			int finalHashvalue = 0;
			if (!StringUtils.isEmpty(hParams.get("PolicyNumber"))) {
				String[] pNumberList = hParams.get("PolicyNumber").split(",");

				initalDR = axs.getDetails()[0];
				int[] attributeSpace = initalDR.getAttributesSize();
				Type[] attributes = initalDR.getAllAttributes();
				Type[] newAttributes = new Type[attributes.length];
				for (int i = 0; i < attributeSpace.length; i++) {
					newAttributes[i] = new Type(attributeSpace[i], attributes[i].getDataType(),
							attributes[i].getValue(), attributes[i].getAlignment(), attributes[i].getPaddingChar());
				}
				axs.getHeader().getTotalNumberOfRecords().setValue(String.valueOf(pNumberList.length));
				axs.getSummary().getTotalNumberofRecord().setValue(String.valueOf(pNumberList.length));
				if (pNumberList != null && pNumberList.length > 0) {
					for (String pNumber : pNumberList) {
						Details details = new Details(newAttributes);
						Hashtable<String, String> axsData = getAxsData(pNumber);
						int tempHashLogic = 0;
						details.getRecordType().setValue(String.valueOf("2"));
						details.getTransactionDate().setValue(String.valueOf(getSystemDate()));
						details.getTransactionReferenceNumber()
								.setValue(String.valueOf(System.currentTimeMillis()).substring(5));
						details.getBillType().setValue(String.valueOf(axsData.get("BillType")));
						details.getPolicyNumber().setValue(String.valueOf(axsData.get("PolicyOrPropopsalNumber")));
						details.getPaidAmount().setValue(String.valueOf(axsData.get("PaidAmount").replace(".", "")));
						details.getPayerName().setValue(String.valueOf(axsData.get("PayerName")));
						details.getContactNumber().setValue(String.valueOf(axsData.get("ContactNumber")));
						details.getFiller();
						detailList.add(details);
						tempHashLogic = hashLogic(details.getTransactionDate().toString(),
								details.getPolicyNumber().toString(), details.getPaidAmount().toString());
						finalHashvalue = finalHashvalue + tempHashLogic;
						totalAmoutnt = totalAmoutnt + Integer.parseInt(details.getPaidAmount().toString());

					}
					axs.setDetails(detailList.toArray(new Details[pNumberList.length]));

				}

				parseHeader();
				axs.getSummary().getTotalPaidAmount().setValue(String.valueOf(totalAmoutnt));
				parseFooter();
				axs.getSummary().getHashTotal().setValue(String.valueOf(finalHashvalue));

			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	private int hashLogic(String transactionDate, String policyNumber, String amountPaid) {
		int transactionDateValue = Integer.parseInt(transactionDate.substring(0, 2));
		int policyValue = Integer.parseInt(policyNumber.substring(policyNumber.length() - hashPolicLength));
		int amountValue = Integer.parseInt(amountPaid);
		int totalValue = (policyValue + amountValue - transactionDateValue) % 7;
		return totalValue;
	}

	/**
	 * load the GIRO Structure using the JSON template
	 * 
	 * @param jsonTemplate
	 */
	private void loadObject(String jsonTemplate) throws Exception {
		try {
			Gson gson = new Gson();
			axs = gson.fromJson(new FileReader(jsonTemplate), Axs.class);
		} catch (JsonIOException | JsonSyntaxException | FileNotFoundException e) {
			throw new BPCException(e);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public Hashtable<String, String> getAxsData(String pNumber) {
		DataHandler dataHandler = new DataHandler();
		Hashtable<String, String> axsData = dataHandler.getTestData(sheetName,
				FPMSProperties.getInstance().getTestDataFilePath(System.getProperty("Settings.Module")),
				ColumnHeader.getColumnHeader(sheetName), pNumber, "PolicyOrPropopsalNumber");
		return axsData;
	}

	public String getSystemDate() throws Exception {
		String sysDate = llAction.getText("web_span_systemDateTime").split(" ")[0];
		Format formatter = new SimpleDateFormat("ddMMyyyy");
		Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(sysDate);
		sysDate = formatter.format(date1);
		return sysDate;
	}

	private void parseHeader() throws Exception {
		axs.getHeader().getRecordType().setValue("1");
		axs.getHeader().getCorporationCode().setValue(String.valueOf("AXS"));
		axs.getHeader().getTransactionDate().setValue(getSystemDate());
		axs.getHeader().getCorporationName().setValue(String.valueOf("GREAT EASTERN LIFE � GE LIFE"));
		axs.getHeader().getProcService().setValue("AXS");
		axs.getHeader().getGelApplication().setValue(gelApplication); // Set from Test Data sheet
		axs.getHeader().getFiller().setValue("");
	}

	private void parseFooter() {
		axs.getSummary().getRecordType().setValue("3");
		axs.getSummary().getLabelID().setValue("TRL");
		axs.getSummary().getTrlProcService().setValue("AXS");
	}

}