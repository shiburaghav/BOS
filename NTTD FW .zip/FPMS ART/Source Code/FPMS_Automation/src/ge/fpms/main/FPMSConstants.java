package ge.fpms.main;

public interface FPMSConstants {

	public static final String CERTIFICATE_ERR_NAVIGATION_BLOCKED = "Certificate Error: Navigation Blocked";
	public static final String ADDRESS_TYPE_CORRESPONDENCE = "Correspondence";
	public static final String ADDRESS_INDICATOR_LOCAL = "Local";
	public static final String ADDRESS_TYPE_FORMATTED = "Formatted";
	public static final String BACKWARD_SEPERATOR = "/";
	public static final String BLANK_SEPERATOR = " ";
	public static final String WINDOW_TITLE_LA_INFORMATION = "Life Assured Information";
	public static final String WINDOW_TITLE_EX_CUSTOMER_INFORMATION = "Existing Customer Information";
	public static final String WINDOW_TITLE_INITIAL_REGISTRATION = "Initial Registration";
	public static final String WINDOW_TITLE_IDV_PROPOSER_INFOMATION = "Individual Proposer Information";
	public static final String WINDOW_TITLE_DATA_ENTRY = "Data Entry";
	public static final String WINDOW_TITLE_CORRESPONDENCE_ADDRESS = "Correspondence Address";
	public static final String WINDOW_TITLE_DIRECT_CREDIT = "Direct Credit";
	public static final String WINDOW_TITLE_PAYMENT_METHOD= "Payment Method Information";
	public static final String WINDOW_TITLE_CRS= "CRS";
	public static final String WINDOW_TITLE_PRODUCT_INFO= "Product Info";
	public static final String COMMENT_INITIAL_REG= "Initial Registration Completed.";
	public static final String FUNDCODE= "FundCode";
	public static final String APPORTIONMENT= "Apportionment";
	public static final String SINGLEFUNDCODE= "RiderFundCode";
	public static final String SINGLEAPPORTIONMENT= "RiderApportionment";
	public static final String RECURFUNDCODE= "RiderRecurringFundCode";
	public static final String RECURAPPORTIONMENT= "RiderRecurringApportionment";
	public static final String WITHDRAWUNITS="WithdrawUnitsFund";
	public static final String WITHDRAWVALUE="WithdrawValueFund";
	public static final String WITHDRAWBYUNITS="Partial Withdraw by Units";
	public static final String WITHDRAWBYVALUE="Partial Withdraw by Value";
	public static final String ILP_OPENING_STATEMENT_JOB = "ILP Opening Statement Generation"; 
	public static final String PAYEE= "Payee";
	public static final String PAYER= "Payer"; 
	public static final String SWITCHBYUNITS="Switch by Units";
	public static final String SWITCHBYVALUE="Switch by value";
	public static final String NAT_SINGAPOREAN = "SINGAPOREAN";
	public static final String BANKWARNING = "Bank";
	public static final String VALIDFROZENREASON = "Difference in premium component from CPF Return"; 
	public static final String WINDOW_TITLE_SearchLA = "Search Life Assured";
	public static final String UNKNOWN = "Unknown";
	
	public static final String POLICY_STATUS_INFORCE = "Inforce";
	
	public static final String CQ_CS_INFO = "CS Info";
	public static final String CS_Collection = "CS";
	public static final String NB_Collection = "NB";
	public static final String MiscFee_Collection = "MiscFee";
	
	public  static final String APP_DATE_FORMAT = "dd/MM/yyyy HH:mm:ss";
	public  static final String DATE_FORMAT = "dd/MM/yyyy";
	public static final String POLICY_STATUS_LAPSED = "Lapsed";
	public static final String POLICY_STATUS_TERMINATED = "Terminated";
	public static final String BENEFIT_INFO = "Benefit Info";
	public static final String CPFCASHPAYMENT = "Cash";
	public static final String RegistrationSuccess = "(New Application is registered Successfully)";
	public static final String POLICY_STATUS_APPROVED = "Approved";
	public static final String WINDOW_TITLE_COMPANY_PROPOSAL_INFORMATION= "Company Proposal Information";
	public static final String WINDOW_TITLE_EX_COMPANY_PROPOSAL_INFORMATION="Existing Company Customer Information";
	public static final String COMMA_SEPERATOR = ",";
	public static final String NAME_SEPERATOR = "_";
	public static final String DEFAULT_EXPIRY_DATE = "31/12/2099";
	public static final String OUTPUTFILES_FOLDER = "OutputFiles";
	public static final String NBUEXTRACTION_FILE_BASENAME ="NBU Extraction";
	public static final String BATCH_UPLOAD_FILE_BASENAME ="Batch Upload";
	public static final String EXCELFILE_FORMAT =".xlsx";
	public static final String CSVFILE_FORMAT =".csv";
	public static final String CHECKLIST_OPTION ="Y";
	public static final String WINDOW_TITLE_CLAIM_DOCUMENT_LIST ="Claim Document List";
	public static final String COLON_SEPERATOR = ":";
	public static final String NBUEXTRACT_SHEETNAME = "NBU Run_Data";
	public static final String POLICY_STATUS_INFORCE1 = "In Force";
	public static final String POLICY_STATUS_AUHTORITY = "Authority Approval";
	public static final String WINDOW_TITLE_CASE_EVALUATION = "Case Evaluation";
	public static final String WINDOW_TITLE_CASE_APPROVE_CASE = "Case Evaluation";
	public static final String CASE_EVALUATED = "Case Evaluated";
	public static final String EXECUTION_STATUS_INPROGRESS = "InProgress";
	public static final String EXECUTION_STATUS_COMPLETE = "Complete";
	public static final String EXECUTION_STATUS_NOT_STARTED = "NotStarted";
	public static final String LEFT_ALIGNMENT="left";
	public static final String RIGHT_ALIGNMENT="right";
	public static final String MAIN_BENEFITS_CXT = "MainBenefits";
	public static final String RIDER_CXT = "Rider";
	public static final String DETAILREG_SUBMIT_CXT = "DetailRegistrationSubmit";
	public static final String MAINBENEFIT_CODE_CXT = "MainBenefitCode";
	public static final String INITIAL_REG_SUBMIT = "InitialRegistrationSubmit";
}

