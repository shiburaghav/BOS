package ge.fpms.main.bpc.bcp.templates.creditcard;



import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class FileFooter implements IPaymentSection {

	private Type recordType;
	private Type recordCount;
	private Type totalAmount;

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Type recordCount) {
		this.recordCount = recordCount;
	}

	public Type getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Type totalAmount) {
		this.totalAmount = totalAmount;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(),
				recordCount.getSize(),
				totalAmount.getSize()
				};
	}

	public void setParamaters(String[] buffer) {
		recordType.setValue(buffer[0]);
		recordCount.setValue(buffer[1]);
		totalAmount.setValue(buffer[2]);
	}

	public String getName() {
		return "FT";
	}

	public String toString() {

		return new StringBuffer().append(getRecordType().toString())
				.append(getRecordCount().toString())
				.append(getTotalAmount().toString()).toString();
	}

	@Override
	public Type[] getAllAttributes() {
		// TODO Auto-generated method stub
		return null;
	}

}
