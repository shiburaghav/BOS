package ge.fpms.main.bpc.bcp.templates.giro;

import org.apache.commons.lang3.StringUtils;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.IPaymentType;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Details implements IPaymentSection {

	private Type recordType;
	private Type receivingBankBICCode;
	private Type receivingAccountNumber;
	private Type receivingAccountCurrency;
	private Type receivingAccountName;
	private Type settlementCurrency;
	private Type settlementAmountinCents;
	private Type mandateReferenceNumber;
	private Type purposeCode;
	private Type endtoEndID;
	private Type paymentDetails;
	private Type debtorName;
	private Type creditorName;
	private Type returnCode;
	private Type returnDescription;
	private Type raCustomerReference;
	private Type filler1;

	public Details(Type[] type) {
		super();
		this.recordType = new Type(type[0].getSize(), type[0].getDataType(),
				type[0].getValue(), type[0].getAlignment(),
				type[0].getPaddingChar());
		
		this.receivingBankBICCode = new Type(type[1].getSize(),
				type[1].getDataType(), type[1].getValue(),
				type[1].getAlignment(), type[1].getPaddingChar());
		
		this.receivingAccountNumber = new Type(type[2].getSize(),
				type[2].getDataType(), type[2].getValue(),
				type[2].getAlignment(), type[2].getPaddingChar());
		
		this.receivingAccountCurrency = new Type(type[3].getSize(),
				type[3].getDataType(), type[3].getValue(),
				type[3].getAlignment(), type[3].getPaddingChar());
		
		this.receivingAccountName = new Type(type[4].getSize(),
				type[4].getDataType(), type[4].getValue(),
				type[4].getAlignment(), type[4].getPaddingChar());
		
		this.settlementCurrency = new Type(type[5].getSize(),
				type[5].getDataType(), type[5].getValue(),
				type[5].getAlignment(), type[5].getPaddingChar());
		
		this.settlementAmountinCents = new Type(type[6].getSize(),
				type[6].getDataType(), type[6].getValue(),
				type[6].getAlignment(), type[6].getPaddingChar());
		
		this.mandateReferenceNumber = new Type(type[7].getSize(),
				type[7].getDataType(), type[7].getValue(),
				type[7].getAlignment(), type[7].getPaddingChar());
		
		this.purposeCode = new Type(type[8].getSize(), type[8].getDataType(),
				type[8].getValue(), type[8].getAlignment(),
				type[8].getPaddingChar());
		
		this.endtoEndID = new Type(type[9].getSize(), type[9].getDataType(),
				type[9].getValue(), type[9].getAlignment(),
				type[9].getPaddingChar());
		
		this.paymentDetails = new Type(type[10].getSize(),
				type[10].getDataType(), type[10].getValue(),
				type[10].getAlignment(), type[10].getPaddingChar());
		
		this.debtorName = new Type(type[11].getSize(), type[11].getDataType(),
				type[11].getValue(), type[11].getAlignment(),
				type[11].getPaddingChar());
		
		this.creditorName = new Type(type[12].getSize(),
				type[12].getDataType(), type[12].getValue(),
				type[12].getAlignment(), type[12].getPaddingChar());
		
		this.returnCode = new Type(type[13].getSize(), type[13].getDataType(),
				type[13].getValue(), type[13].getAlignment(),
				type[13].getPaddingChar());
		
		this.returnDescription = new Type(type[14].getSize(),
				type[14].getDataType(), type[14].getValue(),
				type[14].getAlignment(), type[14].getPaddingChar());
		
		this.raCustomerReference = new Type(type[15].getSize(),
				type[15].getDataType(), type[15].getValue(),
				type[15].getAlignment(), type[15].getPaddingChar());
		
		this.filler1 = new Type(type[16].getSize(), type[16].getDataType(),
				type[16].getValue(), type[16].getAlignment(),
				type[16].getPaddingChar());
	}

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getReceivingBankBICCode() {
		return receivingBankBICCode;
	}

	public void setReceivingBankBICCode(Type receivingBankBICCode) {
		this.receivingBankBICCode = receivingBankBICCode;
	}

	public Type getReceivingAccountNumber() {
		return receivingAccountNumber;
	}

	public void setReceivingAccountNumber(Type receivingAccountNumber) {
		this.receivingAccountNumber = receivingAccountNumber;
	}

	public Type getReceivingAccountCurrency() {
		return receivingAccountCurrency;
	}

	public void setReceivingAccountCurrency(Type receivingAccountCurrency) {
		this.receivingAccountCurrency = receivingAccountCurrency;
	}

	public Type getReceivingAccountName() {
		return receivingAccountName;
	}

	public void setReceivingAccountName(Type receivingAccountName) {
		this.receivingAccountName = receivingAccountName;
	}

	public Type getSettlementCurrency() {
		return settlementCurrency;
	}

	public void setSettlementCurrency(Type settlementCurrencysettlementCurrency) {
		this.settlementCurrency = settlementCurrencysettlementCurrency;
	}

	public Type getSettlementAmountinCents() {
		return settlementAmountinCents;
	}

	public void setSettlementAmountinCents(Type settlementAmountinCents) {
		this.settlementAmountinCents = settlementAmountinCents;
	}

	public Type getMandateReferenceNumber() {
		return mandateReferenceNumber;
	}

	public void setMandateReferenceNumber(Type mandateReferenceNumber) {
		this.mandateReferenceNumber = mandateReferenceNumber;
	}

	public Type getPurposeCode() {
		return purposeCode;
	}

	public void setPurposeCode(Type purposeCode) {
		this.purposeCode = purposeCode;
	}

	public Type getEndtoEndID() {
		return endtoEndID;
	}

	public void setEndtoEndID(Type endtoEndID) {
		this.endtoEndID = endtoEndID;
	}

	public Type getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(Type paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	public Type getDebtorName() {
		return debtorName;
	}

	public void setDebtorName(Type debtorName) {
		this.debtorName = debtorName;
	}

	public Type getCreditorName() {
		return creditorName;
	}

	public void setCreditorName(Type creditorName) {
		this.creditorName = creditorName;
	}

	public Type getReturnCode() {
		String val = returnCode.getValue().trim();
		if(StringUtils.isEmpty(val)){
			val = IPaymentType.DEFAULT_RETURN_CODE;
			returnCode.setValue(val);
		}
		return returnCode;
	}

	public void setReturnCode(Type returnCode) {
		this.returnCode = returnCode;
	}

	public Type getReturnDescription() {
		return returnDescription;
	}

	public void setReturnDescription(Type returnDescription) {
		this.returnDescription = returnDescription;
	}

	public Type getRaCustomerReference() {
		return raCustomerReference;
	}

	public void setRaCustomerReference(Type raCustomerReference) {
		this.raCustomerReference = raCustomerReference;
	}

	public Type getFiller1() {
		return filler1;
	}

	public void setFiller1(Type filler1) {
		this.filler1 = filler1;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(),
				receivingBankBICCode.getSize(),
				receivingAccountNumber.getSize(),
				receivingAccountCurrency.getSize(),
				receivingAccountName.getSize(), settlementCurrency.getSize(),
				settlementAmountinCents.getSize(),
				mandateReferenceNumber.getSize(), purposeCode.getSize(),
				endtoEndID.getSize(), paymentDetails.getSize(),
				debtorName.getSize(), creditorName.getSize(),
				returnCode.getSize(), returnDescription.getSize(),
				raCustomerReference.getSize(), filler1.getSize() };
	}

	public String getName() {
		return "1";
	}

	public String toString() {
		String details = new StringBuilder().append(getRecordType().toString())
				.append(getReceivingBankBICCode().toString())
				.append(getReceivingAccountNumber().toString())
				.append(getReceivingAccountCurrency().toString())
				.append(getReceivingAccountName().toString())
				.append(getSettlementCurrency().toString())
				.append(getSettlementAmountinCents().toString())
				.append(getMandateReferenceNumber().toString())
				.append(getPurposeCode().toString())
				.append(getEndtoEndID().toString())
				.append(getPaymentDetails().toString())
				.append(getDebtorName().toString())
				.append(getCreditorName().toString())
				.append(getReturnCode().toString())
				.append(getReturnDescription().toString())
				.append(getRaCustomerReference().toString())
				.append(getFiller1().toString()).toString();
		
		return details;
	}

	public Type[] getAllAttributes() {
		return new Type[] { recordType, receivingBankBICCode,
				receivingAccountNumber, receivingAccountCurrency,
				receivingAccountName, settlementCurrency,
				settlementAmountinCents, mandateReferenceNumber, purposeCode,
				endtoEndID, paymentDetails, debtorName, creditorName,
				returnCode, returnDescription, raCustomerReference, filler1 };
	}
}
