package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.common.util.UtilsForTesting;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import com.nttdata.framework.exceptions.LowLevelException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;

public class VerifyPDF
{
	private DashboardHandler dashboard;
	private FPMS_Actions llAction;
	private PolicyHandler policyHandler;
	
	
	public VerifyPDF() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}
	public void capture_lca_pdf_data(Hashtable<String, String> hParams) throws Exception
	{
	  try
	  {
		  
		  String actual_LifeAssuredName= UtilsForTesting.testGetVariableOccurence(hParams.get("PDFPath"), "LIFE ASSURED:", "").get(0).trim();
		//  policyHandler.getPolicy().setLifeAssuredName();
		  dashboard.setStepDetails("Capture Life Assured Name", "Life Assured Name In PDF: "+actual_LifeAssuredName+ " is Captured successfully", "N/A");
		  dashboard.writeResults();
		  
		  String actual_BenefitName=UtilsForTesting.testGetVariableOccurence(hParams.get("PDFPath"), "", ":").get(5);
		  policyHandler.getPolicy().setActualBenefitName(actual_BenefitName);
			
		  dashboard.setStepDetails("Capture Life Benefit Name", "Benefit Name In PDF: "+actual_LifeAssuredName+ " is Captured successfully", "N/A");
		  dashboard.writeResults();
		  
		  String actual_InstallementPremium=UtilsForTesting.testGetVariableOccurence(hParams.get("PDFPath"), actual_BenefitName.trim(), "").get(0).split(" ")[1];
		  policyHandler.getPolicy().setActualInstallementPremium(actual_InstallementPremium);
		  dashboard.setStepDetails("Capture Installment Premium", "Installment Premium In PDF: "+actual_InstallementPremium+ " is Captured successfully", "N/A");
		  dashboard.writeResults();
		  
		  String actual_SumAssured=UtilsForTesting.testGetVariableOccurence(hParams.get("PDFPath"), actual_BenefitName.trim(), "").get(0).split(" ")[0];
		  policyHandler.getPolicy().setActualSumAssured(actual_SumAssured);
		  dashboard.setStepDetails("Capture Sum Assured", "Sum Assured In PDF: "+actual_SumAssured+ "  Captured successfully", "N/A");
		  dashboard.writeResults();
		  
		  String actual_PaymentFrequency=UtilsForTesting.testGetVariableOccurence(hParams.get("PDFPath"),  "Sum Assured", "Premium").get(0).trim();
		  policyHandler.getPolicy().setActualPaymentFrequency(actual_PaymentFrequency);
		  dashboard.setStepDetails("Capture Premium Frequency", "Premium Frequency In PDF: "+actual_PaymentFrequency+ " is Captured successfully", "N/A");
		  dashboard.writeResults();
		  
		  String actual_LoadingOption=UtilsForTesting.testGetVariableOccurence(hParams.get("PDFPath"),"", "@ RM").get(0).trim();
		  policyHandler.getPolicy().setActualLoadingOption(actual_LoadingOption);
		  dashboard.setStepDetails("Capture Loading Option", "Loading Option In PDF: "+actual_LoadingOption+ " is Captured successfully", "N/A");
		  dashboard.writeResults();
		  
		  String actual_LoadingRate=UtilsForTesting.testGetVariableOccurence(hParams.get("PDFPath"),  "@ RM", "(per").get(0).trim();
		  policyHandler.getPolicy().setActualLoadingRate(actual_LoadingRate);
		  dashboard.setStepDetails("Capture Loading Rate", "Loading Rate In PDF: "+actual_LoadingRate+ " is Captured successfully", "N/A");
		  dashboard.writeResults();
		  
		  

		  
	  }
	  catch(Exception ex)
	  {
		  throw new LowLevelException("Exception occured in capture PDF");
	  }
	}
	
	public void Search_Policy(Hashtable<String, String> hParams) throws Exception
	{
		try
		{			  
			  llAction.selectMenuItem("Query", "Common Query");
			  llAction.waitUntilElementPresent("web_radio_PolicyNumber");
			  llAction.clickElement("web_radio_PolicyNumber");
			  llAction.enterValue("web_txt_CommonQueryPolicyNumber", hParams.get("PolicyNumber")); // should come Run time
			  llAction.returnWebElement("web_txt_CommonQueryPolicyNumber").sendKeys(Keys.TAB);
			  Utils.sleep(1);
			  dashboard.setStepDetails("Enter Policy #","Policy number: "+hParams.get("PolicyNumber")+" should be entered successfully","N/A");
			  dashboard.writeResults();
			  llAction.clickElement("web_btn_SearchParty");

			  dashboard.setStepDetails("Click Search Button ","Search button should be clicked successfully","N/A");
			  llAction.waitUntilElementPresent("web_btn_ExitBenefitInformation");
			  dashboard.writeResults();
			  
		}
		catch (Exception e)
		{
			throw new LowLevelException("Exception in Search Policy");
		}
	}
	
	public void Verify_Benefit_Info_Tab_data(Hashtable<String, String> hParams) throws Exception
	{
	  try
	  {
		  FPMS_Actions llAction=new FPMS_Actions();

		  
		  llAction.selectTab("Benefit Info");
		  llAction.waitforPageLoad();
		  
		  dashboard.setStepDetails("Click On Benefit Info Tab","Benefit info Tab should be  clicked successfully","N/A");
		  llAction.waitUntilElementPresent("web_tbl_LifeAssuredName");
		  dashboard.writeResults();
		
		 
		  String expected_LifeAssuredName=policyHandler.getPolicy().getLifeAssuredName("");
		  llAction.waitUntilElementPresent("web_tbl_LifeAssuredName");
		  String actual_LifeAssuredName=llAction.getText("web_tbl_LifeAssuredName").trim();
		  
		  if(actual_LifeAssuredName.trim().equalsIgnoreCase(expected_LifeAssuredName.replace("MR", "").trim()))
		  {
		  dashboard.setStepDetails("Verify Life Assured Name", "Life Assured Name In PDF: "+expected_LifeAssuredName.replace("MR", "")+ " and In UI:"+actual_LifeAssuredName +" verified successfully", "N/A");
		  dashboard.writeResults();
		  }
		  else
		  {
			  throw new LowLevelException("Mismatch Found in Life Assured Name In PDF:"+expected_LifeAssuredName.replace("MR","")+" In UI :"+actual_LifeAssuredName);
		  }
		  
		  
		  String actual_InstallementPremium=policyHandler.getPolicy().getActual_InstallementPremium();
		  String expected_InstallementPremium=llAction.getText("web_tbl_InstallmentPremium").trim();
		  dashboard.setStepDetails("Verify Installment Premium", "Installment Premium In PDF :"+actual_InstallementPremium+ " and In UI: "+expected_InstallementPremium +" verified verified successfully", "N/A");
		  
		  if(actual_InstallementPremium.trim().replace(".00", "").equalsIgnoreCase(expected_InstallementPremium.trim().replace(".00", "")))
		  {
		  dashboard.writeResults();
		  }
		  
		  else
		  {
			  throw new LowLevelException("Mismatch  Found in Installment Premium In PDF:"+actual_InstallementPremium+" In UI :"+expected_InstallementPremium);
		  }
		  
		
		  
		  String actual_SumAssured=policyHandler.getPolicy().getActualSumAssured();
		  String expected_SumAssured=llAction.getText("web_tbl_SumAssured").trim();
		  dashboard.setStepDetails("Verify Sum Assured", "Sum Assured In PDF :"+actual_SumAssured+ " and In UI: "+expected_SumAssured +" verified verified successfully", "N/A");
		  if(actual_SumAssured.trim().replace(".00", "").equalsIgnoreCase(expected_SumAssured.trim().replace(".00", "")))
		  {
		  dashboard.writeResults();
		  }
		  
		  else
		  {
			  throw new LowLevelException("Mismatch  Found in Sum Assured In PDF Found:"+actual_SumAssured+" In UI Found :"+expected_SumAssured);
		  }
		 
		 
	
		 
	  }
	  catch (Exception e)
	  {
		  throw new  LowLevelException("Exception occured in Verify Data");
	 }
	  
	
	}
	
	  public void verify_Benefit_Information_page_data(Hashtable<String, String> hParams)
	  {
		  try
		  {
			  FPMS_Actions llAction=new FPMS_Actions();
			  // Here need to add the code to see the click the link
			  llAction.waitUntilElementPresent("web_lnk_PlanName");
			 
			 
			  llAction.waitUntilElementPresent("web_tbl_bottomBenefitInfo");
			  dashboard.setStepDetails("Click on Policy Name link ","Policy number link should be clicked and Benefit Information page should be displayed","N/A");
	          dashboard.writeResults();
	          llAction.clickElement("web_lnk_PlanName");
	          
			  String actual_BenefitName=policyHandler.getPolicy().getActualBenefitName();
			  llAction.waitUntilElementPresent("web_label_BenefitName");
			  
			  String expected_BenefitName=llAction.getText("web_label_BenefitName");
			  dashboard.setStepDetails("Verify Benefit Name", "Benefit Name In PDF :"+actual_BenefitName+ " and In UI: "+expected_BenefitName +" verified verified successfully", "N/A");
			  if(actual_BenefitName.trim().equalsIgnoreCase(expected_BenefitName.trim()))
			  {
			  dashboard.writeResults();
			  }
			  
			  else
			  {
				  throw new LowLevelException("Mismatch  Found in Benefit Name In PDF:"+actual_BenefitName+" In UI :"+expected_BenefitName);
			  }
			  
			  String actual_PaymentFrequency=policyHandler.getPolicy().getActualPaymentFrequency();
			  String expected_PaymentFrequency=llAction.getText("web_lable_PaymentFrequency");
			  dashboard.setStepDetails("Verify PaymentFrequency", "Payment Frequency In PDF :"+actual_PaymentFrequency+ " and In UI: "+expected_PaymentFrequency +" verified verified successfully", "N/A");
			  if(actual_PaymentFrequency.trim().replace(".00", "").equalsIgnoreCase(expected_PaymentFrequency.trim().replace(".00", "")))
			  {
			  dashboard.writeResults();
			  }
			  
			  else
			  {
				  throw new LowLevelException("Mismatch  Found in Payment Frequency In PDF:"+actual_PaymentFrequency+" In UI :"+expected_PaymentFrequency);
			  }
			  

			  String actual_LoadingOption=policyHandler.getPolicy().getActualLoadingOption();
			  String expected_LoadingOption=llAction.getText("web_tbl_LoadingOption");
			  dashboard.setStepDetails("Verify Loading Option", "Loading Option In PDF :"+actual_LoadingOption+ " and In UI: "+expected_LoadingOption +" verified verified successfully", "N/A");
			  if(actual_LoadingOption.trim().replace(".00", "").equalsIgnoreCase(expected_LoadingOption.trim().replace(".00", "")))
			  {
			  dashboard.writeResults();
			  }
			  
			  else
			  {
				  throw new LowLevelException("Mismatch  Found in Loading Option in PDF:"+actual_LoadingOption+" In UI :"+expected_LoadingOption);
			  }
			  
			 
			  
			  String actual_LoadingRate=policyHandler.getPolicy().getActualLoadingRate();
			  String expected_LoadingRate=llAction.getText("web_tbl_LoadingRate");
			  dashboard.setStepDetails("Verify Loading Rate", "Loading Rate In PDF :"+actual_LoadingRate+ " and In UI: "+expected_LoadingRate +" verified verified successfully", "N/A");
			  if(actual_LoadingRate.trim().replace(".00", "").equalsIgnoreCase(expected_LoadingRate.trim().replace(".00", "")))
			  {
			  dashboard.writeResults();
			  }
			  
			  else
			  {
				  throw new LowLevelException("Mismatch  Found in Loading Rate In PDF:"+actual_LoadingRate+" In UI :"+expected_LoadingRate);
			  }
			 
			 llAction.clickElement("web_btn_ExitBenefitInformation");
			 dashboard.setStepDetails("Click on Exit", "Exit button should be clicked successfully", "N/A");
			 llAction.waitforPageLoad();
			 
			 dashboard.writeResults();
		  }
		  catch (Exception e)
		  {
			// TODO: handle exception
		}	
	  }
	
}
	


