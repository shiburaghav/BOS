package ge.fpms.main.bpc.nbu.components;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.channels.FileChannel;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.text.PDFTextStripper;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.SCPClient;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;

import com.nttdata.common.util.PIPSGenerics;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class BatchJobFileProcessor {

	private String remoteSiteHostName;
	
	private String remoteSiteUserName;
	private String remoteSitePassword;
	private String outputFolderPath;

	private DashboardHandler dashboard;

	private String downloadPath;

	private String year;

	private String currentTime;

	private String month;

	private String date;
		
	public BatchJobFileProcessor(){
		dashboard = DashboardHandler.getInstance();
		remoteSiteHostName = System.getProperty("Settings.BatchJobRemoteSiteHostName");
		remoteSiteUserName = System.getProperty("Settings.BatchJobRemoteSiteUsername");
		remoteSitePassword = System.getProperty("Settings.BatchJobRemoteSitePassword");
		
		downloadPath= System.getProperty("Settings.ART Downloads");
	}
	
	private ArrayList<String> parseLine(String folderPath, BufferedReader reader, String month, String date, String year, String currentTime) {

		ArrayList<String> copyFileList = new ArrayList<String>();
		
		String line;
		try {
			line = reader.readLine(); // total count line -ignoring this

			while (true) {
				line = reader.readLine();
				if (line == null)
					break;
				else {

					if (line.contains(month)) {
						String tempLine = line.substring((month + ' ' + date + ' ').length()+1).trim();
						int len = (month + ' ').length() + 1;
						String fcDate = line.substring(len,2 + len);
						//System.out.println("BatchJobFileProcessor.parseLine() tempLine :"	+ tempLine);
						
						if (tempLine.indexOf(":") != -1) {
							String time = tempLine.substring(0,	tempLine.indexOf(" "));
							String fileName = tempLine.substring(time.length()).trim();
							Date bjDateTime = getDateTime(year,month,date,currentTime);
							Date fcDateTime = getDateTime(year,month,fcDate,time);
							
							if (fcDateTime.compareTo(bjDateTime)>=0) {
								copyFileList.add(folderPath + "/" + fileName);
							}

						}
					}
				}
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
		return copyFileList;
	}
	
	private boolean isPDFCreated(String policyNo){
		boolean status = true;
		int batchQueryTimeout =  Integer.parseInt(System.getProperty("Settings.BatchQueryTimeOut"));
		long currentTime = System.currentTimeMillis();
		long maxBatchProcessingTime = currentTime + TimeUnit.SECONDS.toMillis(batchQueryTimeout);
		
		while (currentTime <= maxBatchProcessingTime)
		{
			
			File folder = new File(outputFolderPath);
			if(folder.exists()) {
				File[] listOfFiles = folder.listFiles();
	
				for (File file : listOfFiles) {
				    if (file.isFile() && file.getName().contains(policyNo)) {
						status = true;
						break;
				    }
				}
			}

		}
		return status;
	}
	/**
	 * 
	 * Method - copyFilesFromServer
	 * @param serverHostName
	 * @param serverUserName
	 * @param serverPassword
	 * @param sourceFolderPath - source folder location 
	 * @param month
	 * @param date
	 * @param currentTime
	 * @throws Exception
	 */
	public ArrayList<String> copyFilesFromServer(String serverHostName,
			String serverUserName, String serverPassword,
			String sourceFolderPath, Date batchJobStartTime) throws Exception {
		
		return copyFilesFromServer( serverHostName,
				 serverUserName,  serverPassword,
				 sourceFolderPath,batchJobStartTime,  true);
	}
	/**
	 * 
	 * Method - copyFilesFromServer
	 * @param serverHostName
	 * @param serverUserName
	 * @param serverPassword
	 * @param sourceFolderPath - source folder location 
	 * @param month
	 * @param date
	 * @param currentTime
	 * @throws Exception 
	 */
	public ArrayList<String> copyFilesFromServer(String serverHostName,
			String serverUserName, String serverPassword,
			String sourceFolderPath, Date batchJobStartTime,boolean validateFileExist) throws Exception {

		Connection connection = null;
		Session session = null;
		ArrayList<String> copyFileList = new ArrayList<String>();
		
		setBatchJobStartDateTime(batchJobStartTime);
		
		try {

			connection = new Connection(serverHostName);
			connection.connect();
			boolean isAuthenticated = connection.authenticateWithPassword(
					serverUserName, serverPassword);
			if (isAuthenticated == false) {
				dashboard.setFailStatus(new IOException(
						"Connecting to remote server " + serverHostName
								+ " failed Authentication failed."));
			} else {
				session = connection.openSession();
				// execute commnad to cd to remoteSite input folder and list all
				// files sorting based on time and print date,month,time and
				// filename
				session.execCommand("cd " + sourceFolderPath
						+ " ;  ls -lt | awk '{print substr($0,41)}'");
				Utils.sleep(5);

				InputStream stdout = new StreamGobbler(session.getStdout());
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(stdout));

				SCPClient client = new SCPClient(connection);
				copyFileList = parseLine(sourceFolderPath,
						reader, month, date, year,currentTime);

				if (copyFileList != null && copyFileList.size() > 0) {
					client.get(copyFileList.toArray(new String[0]),
							downloadPath);

					Utils.sleep(8);
					copyFileList = formatFilePath(copyFileList, sourceFolderPath, downloadPath);
				} else {
					if(validateFileExist){
						dashboard.setFailStatus(new BPCException("Batch Job File Processing "
											+ "Failed : No new file generated upon running batch job "));
					}
				}
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		} finally {
			if (session != null) {
				session.close();
			}
			if (connection != null) {
				connection.close();
			}
		}
		
		return copyFileList;
	}
	
	
	public boolean isPDFCreatedForBatch(String folderPath, String jobId) throws IOException {
		boolean status = false;
		DateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date dt = new Date();	
		
		String dtFormat = sdf.format(dt).toString();
		
		try {			
			File folder = new File(folderPath);
			if (folder.exists()) {				
				File[] listOfFiles = folder.listFiles();
				for (File file : listOfFiles) {
					if (file.getName().startsWith("RPTFIN______" ) && file.getName().endsWith(".pdf")) {
							PIPSGenerics pipsObj = new PIPSGenerics();
							PDDocument pdfDoc = null;
							String pdfAllTexts = null;
							ArrayList<String> allOccurance = null;
							String pdfFilePath = folderPath + "\\" + file.getName();
							File file1 = new File(pdfFilePath);
							PDFTextStripper pdfStripper = new PDFTextStripper();
							pdfStripper.setSortByPosition(true);
							PDFont titl = PDType1Font.TIMES_BOLD;
							pdfDoc = PDDocument.load(file1);
							pdfAllTexts = pdfStripper.getText(pdfDoc);
							String lines[] = pdfAllTexts.split("\\r?\\n");
							allOccurance = pipsObj.getAllValuesBetweenStrings(lines, "Job ID", "");
							for (int j = 0; j < allOccurance.size(); j++) {
								if (allOccurance.get(j).contains(jobId)) {
									dashboard.setStepDetails("Verify PDF created",
										"The PDF is successfully verified"  + " The file name is:"
												+ file.getName() + "  ",
										"N/A");
									dashboard.writeResults();
									status = true;
									pdfDoc.close();
								break;
							}							
						}
						if (pdfDoc != null) {
							pdfDoc.close();
						}
						
					}
					if (status) {
						break;
					}
				}
					
			}
		}

		catch (Exception ex) {
			throw new BPCException(ex);
		}
		return status;

	}
		
	public boolean fileExist(String serverHostName, String serverUserName,
			String serverPassword, String sourceFolderPath,Date batchJobStartTime, String fileName) {
		boolean status = false;

		Connection connection = null;
		Session session = null;
		
		setBatchJobStartDateTime(batchJobStartTime);
		
		try {

			connection = new Connection(serverHostName);
			connection.connect();
			boolean isAuthenticated = connection.authenticateWithPassword(
					serverUserName, serverPassword);
			if (isAuthenticated == false) {
				dashboard.setFailStatus(new IOException(
						"Connecting to remote server " + remoteSiteHostName
								+ " failed Authentication failed."));
			} else {
				session = connection.openSession();
				// execute commnad to cd to remoteSite input folder and list all
				// files sorting based on time and print date,month,time and
				// filename

				session.execCommand("cd " + sourceFolderPath
						+ " ;  ls -lt | awk '{print substr($0,41)}'");
				Utils.sleep(5);

				InputStream stdout = new StreamGobbler(session.getStdout());
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(stdout));

				SCPClient client = new SCPClient(connection);
				
				String line;

				line = reader.readLine(); // total count line -ignoring this

				while (true) {
					line = reader.readLine();
					if (line == null)
						break;
					else {
						
						if (line.contains(month)) {
							String tempLine = line.substring((month + ' ' + date + ' ').length()).trim();
							int len = (month + ' ').length() + 1;
							String fcDate = line.substring(len,2 + len);
							
							//	System.out.println("BatchJobFileProcessor.parseLine() tempLine :"+ tempLine);
							if (tempLine.indexOf(":") != -1) {
								String time = tempLine.substring(0,tempLine.indexOf(" "));
								String sfileName = tempLine.substring(time.length()).trim();
								
								Date bjDateTime = getDateTime(year,month,date,currentTime);
								Date fcDateTime = getDateTime(year,month,fcDate,time);
							
								if (fcDateTime.compareTo(bjDateTime)>=0) {
									if (sfileName.contains(fileName)) {										
										status = true;
										break;
									}
								}
							}
						}

					}
				}
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		} finally {
			if (session != null) {
				session.close();
			}
			if (connection != null) {
				connection.close();
			}

		}
		return status;
	}

	/**
	 * 
	 * Method - verifyCSVFilesAfterBatchRun
	 * @param folderPath - source folderPath
	 * @param month
	 * @param date
	 * @param currentTime
	 * @param expCSVFileName - name of the file which will be generated when job is executed
	 * @return
	 * @throws Exception
	 */
	public boolean verifyCSVFilesAfterBatchRun(String folderPath, Date batchJobStartTime, String expCSVFileName)
			throws Exception {

		// TODO: confirm with Prashanth if line.contains(expCSVFileName) is
		// replaced with if(sfileName.equalsIgnoreCase(sfileName))
		boolean status =  fileExist(remoteSiteHostName, remoteSiteUserName,
				remoteSitePassword, folderPath, batchJobStartTime,
				expCSVFileName);
		dashboard.setStepDetails("Verify file created","The file " + expCSVFileName + " is successfully verified.","N/A");
		dashboard.writeResults();
		return status;
	}

	public void copyFilesFromServer(String folderPath, Date batchJobStartTime) throws Exception {

		copyFilesFromServer(remoteSiteHostName, remoteSiteUserName,
				remoteSitePassword, folderPath, batchJobStartTime);
	}
	
	public boolean fesFileExist(String FESFileLocation, final String fileName) {		
		
		File fesFolder = new File(FESFileLocation);

		// list the files using a anonymous FileFilter
		File[] files = fesFolder.listFiles(new FileFilter() {
			
			@Override
			public boolean accept(File file) {
				 return file.getName().startsWith(fileName);
			}
		});
		
		boolean fileExist = files != null && files.length > 0 ? true : false;
		
		return fileExist;
	}
	
	public File[] getFileFromFESFolder(String FESFileLocation, final String fileName) {		
		
		File fesFolder = new File(FESFileLocation);

		// list the files using a anonymous FileFilter
		File[] files = fesFolder.listFiles(new FileFilter() {
			
			@Override
			public boolean accept(File file) {
				 return file.getName().startsWith(fileName);
			}
		});
		return files;
	}
	
	private ArrayList<String> formatFilePath(ArrayList<String> sfiles, String oldPath,String newPath) {
		ArrayList<String> files = new ArrayList<String>();
		Iterator<String> it = sfiles.iterator();
		while (it.hasNext()) {
			String file = it.next();
			file = file.replace(oldPath, newPath);
			files.add(file);
		}
		return files;
	}
	/**
	 * 
	 * Method - copyFileFromFesSharedLocation - copy files from FES location
	 * @param hParams
	 * @return
	 * @throws Exception
	 */
	public ArrayList<String>copyFileFromFesSharedLocation(Hashtable<String, String> hParams)
			throws Exception {
		ArrayList<String> fileList= new ArrayList<String>();
		String fesIpAddress = hParams.get("FesIPAddress");
		String folderLocation = hParams.get("FolderLocation");
		String fesLocation = "\\\\" + fesIpAddress + folderLocation ;
		File[] files = getFileFromFESFolder(fesLocation, hParams.get("FileName"));
		
		if(files!=null && files.length > 0){
			String downloadPath= System.getProperty("Settings.ART Downloads");
			FileChannel inputChannel = null,outputChannel = null;
			for(File sourceFile : files){				
				try{
					String destinationFile = downloadPath + File.separator + sourceFile.getName() ;
					inputChannel = new FileInputStream(sourceFile.getAbsolutePath()).getChannel();   
					outputChannel = new FileOutputStream(destinationFile).getChannel();
					outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
					fileList.add(destinationFile);
				}
				finally {     
					inputChannel.close();    
					outputChannel.close();   
				}
			}
		}/*else{
			
				dashboard
						.setFailStatus(new BPCException(
								"Batch Job File Processing "
										+ "Failed : No new file generated upon running batch job "));
			
		}*/
		

		return fileList;
		
	}
	
	private Date getDateTime(String year, String month, String date, String time) {
		date = date.trim();
		if(date.length() == 1){
			date = "0" + date;
		}
		StringBuilder build = new StringBuilder();
		String dateTime = build.append(year).append("-").append(month)
				.append("-").append(date).append(" ").append(time).append(":00")
				.toString();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
		Date dt;
		try {
			dt = format.parse(dateTime);

		} catch (ParseException e) {
			throw new BPCException(e);
		}

		return dt;
	}
	private void setBatchJobStartDateTime(Date batchJobStartTime){
		//Store the current date time for comparison
        if(batchJobStartTime!=null) {
	        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
	        currentTime = sdf.format(batchJobStartTime);
	        currentTime = currentTime.substring(0, currentTime.lastIndexOf(":"));
	      
	        month = new SimpleDateFormat("MMM").format(batchJobStartTime);
	        date = new SimpleDateFormat("d").format(batchJobStartTime);
	        year = new SimpleDateFormat("YYYY").format(batchJobStartTime);
        }
	}
}
		

