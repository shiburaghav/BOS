/**
 * @(#)FLP.java 10 Aug 2017 6.12PM
 *
 * Copyright 2000-2001 by Great Eastern Life
 * All rights reserved
 *
 * @history
 * 10 Aug 2017 Rasheed First draft

 * support
 */
package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;









import com.nttdata.common.util.Utils;
import com.nttdata.core.LL_Actions;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;



/**
 * <b>Purpose</b> - <br>
 * This class handles all the Data filling related to FLP Application UI
 *
 * <b>Sample Usage</b> - <br>
 * The following shows how to use this class.
 *
 * <code> This method will be triggered from Execute BPC through Reflection the name should be same as in testplan sheet</code>
 *
 * @version 1.0 Aug 10 2017
 * @author Rasheed
 */

public class Registraion {
	
	LL_Actions l_Actions = new LL_Actions();
	
	private final static Logger LOGGER = Logger.getLogger(Registraion.class.getName());

	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	
	
	public Registraion() {
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}
	public void Application_Registration(Hashtable<String, String> hParams) throws Exception 
	{
		
		
		DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
		try {
			/*createFLp(hParams);

			basicInformation(hParams);
			dashboard.setStepDetails("Enter Basic Information",
					"Basic information should be entered successfully", "N/A");
			dashboard.writeResults();

			additionalInformation(hParams);
			enterBuildingDetails(hParams);
			dashboard.setStepDetails("Enter Additional Information",
					"Additional information should be entered successfully", "N/A");
			dashboard.writeResults();

			spourceorJointApplicant(hParams);
			dashboard.setStepDetails("Enter Spouse Details",
					"Spouse/Joint applicant data should be entered successfully", "N/A");
			dashboard.writeResults();

			investmentExperienceEductionDetails(hParams);
			dashboard.setStepDetails("Enter Investment Details",
					"Investment/education details should be entered successfully", "N/A");
			dashboard.writeResults();

			dependantOtherIndividualDetails(hParams);
			dashboard.setStepDetails("Enter Dependent Details",
					"Dependent details should be entered successfully", "N/A");
			dashboard.writeResults();
			// Kept at last since there is an application issue
*/		
			
			LL_Actions llAction = new LL_Actions();
			/*llAction.move_to_element("web_list_CustomerService");
			DashboardHandler.sleep(2);
			llAction.move_to_element("web_list_NewRegistration");
			DashboardHandler.sleep(2);
			llAction.clickElementJs("web_list_NewRegistration");*/
			llAction.enterValue("web_txt_PolicyNumber", hParams.get("Policy_Number"));
			llAction.selectByVisibleText("web_lst_branchId", hParams.get("Branch_received"));
			llAction.enterValue("web_text_Applicationsigneddate", hParams.get("Application_date"));
			llAction.enterValue("web_txt_Applicationdate", hParams.get("Application_signed_date"));
			
			llAction.selectByVisibleText("web_txt_Policyalterationitem", hParams.get("Policy_alteration_item"));
			
			llAction.clickElement("web_btn_Add");
			
			llAction.clickElement("web_btn_Register");
			
			dashboard.setStepDetails("Enter Policy Details","Policy Details should be entered Successfully","N/A");
			dashboard.writeResults();
			
			
			
			
			
			

		} 
		catch (Exception ex)
		{
			DashboardProperties.gBPCStatus = 1; // set the business component status to fail
			LOGGER.log(Level.SEVERE,"Exception occured while calling flp_personaldetails method \n Exception is " + ex.getMessage());
			throw new BPCException("");

		}
	}
		
		public void initial_Registration(Hashtable<String, String> hParams) throws Exception 
		{
			
			
			DashboardProperties.gBPCStatus = 4; // this is to set the bpc status to the calling function
			try
			{
				
				FPMS_Actions llAction = new FPMS_Actions();
				llAction.selectMenuItem("NBD", "Initial Registration","Initial Reg");
			
			/*	llAction.enterValue("web_txt_PolicyNumber", hParams.get("Policy_Number"));
				llAction.selectByVisibleText("web_lst_branchId", hParams.get("Branch_received"));
				*/
				
				
				llAction.enterValue("web_list_NBD_BI_ProposalNo1", hParams.get("ProposalNo"));
				
				llAction.enterValue("web_list_NBD_BI_ProposalDate", hParams.get("ProposalDate"));
				llAction.enterValue("web_list_NBD_BI_IAC1", hParams.get("IACNo"));
				//llAction.enterValue("web_list_NBD_BI_IAC2", hParams.get(""));
				
				llAction.enterValue("web_list_NBD_BI_MainBCode1", hParams.get("MainBenefitCode"));
				
				//llAction.enterValue("web_list_NBD_BI_MainBCode2", hParams.get(""));
			   llAction.enterValue("web_list_NBD_BI_BSumAssured", hParams.get("BasicSumAssured"));
				//llAction.enterValue("web_list_NBD_BI_PayFreq2", hParams.get(""));
				llAction.enterValue("web_list_NBD_BI_IniPremiumAmt", hParams.get("InitialPremiumAmount"));
			
				llAction.enterValue("web_list_NBD_BI_PayFreq1", hParams.get("PaymentFrequency"));
				
				
				//llAction.enterValue("web_list_NBD_BI_Currency1", hParams.get("Currency"));
				//llAction.enterValue("web_list_NBD_BI_Currency2", hParams.get(""));
				
				llAction.enterValue("web_txt_Fact_Find_Ind", hParams.get("FactFindInd"));
				
				
				llAction.enterValue("web_text_CompanyInd", hParams.get("CompanyInd"));
				
				dashboard.setStepDetails("Basic Information entered","Policy Details should be entered Successfully","N/A");
				dashboard.writeResults();
				
				
				llAction.clickElementJs("web_btn_AddProposer");
				//llAction.executeMethod();
				
				llAction.switchtoChildWindow("Certificate Error: Navigation Blocked",""); //common function to switch to any frame 
				
				llAction.AcceptCertificateError();
				
				llAction.waitUntilElementPresent("web_text_PartyName");
				llAction.enterValue("web_text_PartyName", policyHandler.getPolicy().getProposerName()); // hard coded this needs to changed
				
				llAction.clickElementJs("web_Btn_PartySearch");
				dashboard.setStepDetails("Individual Proposer Information","Individual Proposer Information should be entered","N/A");
				dashboard.writeResults();
				
				llAction.switchtoChildWindow("Certificate Error: Navigation Blocked","");
				llAction.AcceptCertificateError();
				
				llAction.clickElementJs("web_radio_radioName");
				llAction.clickElementJs("web_btn_PartySubmit");
				
				dashboard.setStepDetails("Select Existing Customer","Existing customer list should be selected Successfully","N/A");
				dashboard.writeResults();
				
				llAction.switchtoChildWindow("Individual Proposer Information","");
				

				llAction.clickElementJs("web_btn_mySubmit");
				if(llAction.isDisplayed("web_btn_continue",5)) llAction.clickElement("web_btn_continue");
				
				llAction.switchtoChildWindow("Initial Registration","");
				llAction.selectByVisibleText("web_lst_payMentMode", "Cash");
				
				llAction.clickElement("web_btn_BasicInfomationSubmit");
				
				dashboard.setStepDetails("Enter Payment Mode","Payment Mode should be selected Successfully","N/A");
				dashboard.writeResults();
				llAction.acceptAlert();
				
				Utils.sleep(5);
				
				llAction.waitUntilElementPresent("web_btn_initialRegistration_Back");
				String policyDetails=llAction.getText("web_lbl_successMsg");
				String policyNumber=policyDetails.substring(policyDetails.indexOf("Policy No is")+"Policy No is".length(),policyDetails.length()).trim();
				
				policyHandler.getPolicy().setPolicyNo(policyNumber);
				dashboard.setStepDetails("Initial registration completed","Policy Number is created  '"+policyNumber+"' Successfully","N/A");
				dashboard.writeResults();
				
			   llAction.clickElement("web_btn_initialRegistration_Back");
			   llAction.waitforPageLoad();
			   
			} 
			catch (Exception ex)
			{
				DashboardProperties.gBPCStatus = 1; // set the business component status to fail
				LOGGER.log(Level.SEVERE,"Exception occured while calling flp_personaldetails method \n Exception is " + ex.getMessage());
				throw new BPCException("");

			}
		
		

	}
		
		
		public void Detail_Registration(Hashtable<String, String> hParams) throws Exception
        {
                        String policyNumber = null; //a
                        try
                        {

                                        FPMS_Actions llAction = new FPMS_Actions();
                                        
                                        llAction.selectMenuItem("NBD", "Detail Registration");
                                        llAction.enterValue("web_txt_DetailReg_PolicyNumber", policyHandler.getPolicy().getPolicyNo()); // Number should be come from party creation run time we should get newly created policy Number
                                                                                                        
                                        llAction.clickElement("web_txt_DetailReg_Search");
                                        dashboard.setStepDetails("In Data Entry Sharing pool search for policy   " + policyHandler.getPolicy().getPolicyNo(),"The policy should be avaialble in Search Results. ","N/A");
                                        dashboard.writeResults();                                                              
                                        llAction.clickElement("web_lnk_PolicyNumber");
                                        
                                        llAction.switchtoFrame(1);
                                        llAction.clickElement("web_lnk_Poposer_ProposerName");
                                        
                                        llAction.switchtoChildWindow("Certificate Error: Navigation Blocked", "");
                                        
                                        llAction.AcceptCertificateError();
                                        
                                        llAction.enterValue("web_txt_BasicInformation_AnnualIncome", hParams.get("AnnualIncome"));
                                        
                                        llAction.enterValue("web_txt_JobCategoryId", hParams.get("Occupation"));
                                        
                                        
                                        llAction.selectByVisibleText("web_lst_HomeCountry", hParams.get("HomeNo1"));
                                        
                                        llAction.enterValue("web_txt_HomeTelephone", hParams.get("HomeNo2"));
                                        
                                        llAction.clickElement("web_btn_EnterAddress");
                                        if(llAction.isDisplayed("web_btn_continue",5)) llAction.clickElement("web_btn_continue");
                                        Utils.sleep(120);
                                        llAction.switchtoChildWindow("Correspondence Address", "");
                                        

                                        
                                        llAction.clickElement("web_Radio_AddressRecNumber");
                                        
                                        llAction.clickElement("web_btn_SubmitBasicInformation");
                                        Utils.sleep(120);
                                        llAction.switchtoChildWindow("Individual Proposer Information", "");
                                        
                                        llAction.clickElement("web_btn_mySubmit");
                                        if(llAction.isDisplayed("web_btn_continue",5)) llAction.clickElement("web_btn_continue");
                                        dashboard.setStepDetails("Enter Proposer information ","The required information of proposer should be entered. ","N/A");
                                        dashboard.writeResults();
                                        Utils.sleep(40);
                                        llAction.switchtoChildWindow("Data Entry", "");
                                        
                                        llAction.switchtoFrame(1);
                                        llAction.clickElement("web_lnk_lifeAssuredName");
                                        
                                        Utils.sleep(120);
   // llAction.switchtoChildWindow("Certificate Error: Navigation Blocked", "");
                                        
                        //            llAction.AcceptCertificateError();
                                        llAction.switchtoChildWindow("Life Assured Information","");
                                        llAction.enterValue("web_txt_height", hParams.get("Height_M"));
                                        llAction.enterValue("web_txt_weight",hParams.get("Weight_KG"));
                                        llAction.enterValue("web_txt_smoking", hParams.get("Smoking_IND"));
                                        llAction.enterValue("web_txt_PreferredLifeIND", hParams.get("PreferredLife_IND"));
                                        
                                        
                                        llAction.clickElement("web_btn_LifeAssuredInformationEnterAddress");
                                        Utils.sleep(120);
                                        llAction.clickElement("web_btn_CorrespondenceAddressSubmit");
                                        
                                        
                                        llAction.switchtoChildWindow("Life Assured Information","");
                                        dashboard.setStepDetails("Enter Life insured information ","The required information of life insured should be entered. ","N/A");
                                        dashboard.writeResults();
                                        llAction.clickElement("web_btn_LifeAssuredInformationSubmit");
                                        
                                         
                                         llAction.switchtoChildWindow("Data Entry", "");
                                        
                                         llAction.switchtoFrame(1);
                                        llAction.clickElement("web_lnk_AmmendBaseQuestion");
                                        
                                        llAction.switchtoChildWindow("Certificate Error: Navigation Blocked", "");
                                        llAction.AcceptCertificateError();
                                        
                                         llAction.selectByValue("web_lst_ProposalFormType", hParams.get("Proposal_Form_Type"));
                                        llAction.selectByValue("web_lst_ProposalFormVersion", hParams.get("ProposalFormVersion"));
                                        
                                         dashboard.setStepDetails("Complete       Base Question section  ","The proposal from type and version is selected . ","N/A");
                                        dashboard.writeResults();
                                        llAction.clickElement("web_btn_ProposalformSubmit");
                                        
                                         llAction.acceptAlert();
                                        
                                         llAction.switchtoChildWindow("Data Entry", "");
                                        llAction.switchtoFrame(1);
                                        llAction.clickElement("web_lnk_AmmendBenefit");
                                        
                                         
                                         llAction.switchtoChildWindow("Certificate Error: Navigation Blocked", "");
                                        llAction.AcceptCertificateError();
                                        
                                         llAction.enterValue("web_txt_PremiumAmount", hParams.get("PremiumAmount"));
                                        
                                         llAction.clickElement("web_btn_ProductInfo_Fund_Add");
                                        
                                         llAction.enterValue("web_txt_accountCode", hParams.get("ID"));
                                        llAction.enterValue("web_txt_assignRate", hParams.get("Apportionment"));
                                        
                                         dashboard.setStepDetails("Enter Benefit infromation name ","The benefit information like premium Amount should be updated . ","N/A");
                                        dashboard.writeResults();
                                        
                                         llAction.clickElement("web_ProductInfo_Save");
                                        
                                        
                                         llAction.switchtoChildWindow("Data Entry", "");
                                        
                                         llAction.switchtoFrame(1);
                                        
                                         llAction.enterValue("web_txt_PendingReason", hParams.get("PendingReason"));
                                        
                                         llAction.enterValue("web_txt_VerificationIndicator", hParams.get("VeriifcationIndicator"));
                                        dashboard.setStepDetails("Remove pending reason.","The pending reason should be set to " + hParams.get("PendingReason"),"N/A");
                                        dashboard.writeResults();
                                        
                                         llAction.clickElement("web_btn_DataEntry_Submit");// change
                                        
                                         llAction.acceptAlert();
                                        
                                         llAction.acceptAlert();
                                        dashboard.setStepDetails("Submit all the infromation and click on exit button.","Data is saved and user is taken back to home screen.","N/A");
                                        dashboard.writeResults();
                                        llAction.clickElement("web_btn_exit"); 
                                         Utils.sleep(10);

                                        

                        }
                        catch (Exception e)
                        {
                        	throw new BPCException("");
                        }
        }

	
}
