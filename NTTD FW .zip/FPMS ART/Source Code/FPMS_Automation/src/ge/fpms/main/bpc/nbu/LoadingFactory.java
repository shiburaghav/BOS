package ge.fpms.main.bpc.nbu;

import java.util.HashMap;

import ge.fpms.main.ILoading;
import ge.fpms.main.ILoadingType;
import ge.fpms.main.bpc.nbu.components.loading.HealthLoading;
import ge.fpms.main.bpc.nbu.components.loading.LoadingType1;
import ge.fpms.main.bpc.nbu.components.loading.LoadingType3;
import ge.fpms.main.bpc.nbu.components.loading.OccupationLoading;

public class LoadingFactory {
	static HashMap<String, ILoading> loadingList;
	static HashMap<String, ILoadingType> loadingTypeList;

	public LoadingFactory() {
		registerLoading();
		registerLoadingType();
	}

	private void registerLoading() {
		loadingList = new HashMap<>();
		registerLoading(ILoading.Health_Loading, new HealthLoading());
		registerLoading(ILoading.Occupation_Loading, new OccupationLoading());
	}

	private void registerLoading(String productID, ILoading p) {
		loadingList.put(productID, p);
	}

	public ILoading createLoading(String productID) {
		return ((ILoading) loadingList.get(productID));
	}

	private void registerLoadingType() {
		loadingTypeList = new HashMap<>();
		registerLoadingType(ILoadingType.Loading_Type1, new LoadingType1());
		registerLoadingType(ILoadingType.Loading_Type3, new LoadingType3());
	}

	private void registerLoadingType(String productID, ILoadingType p) {
		loadingTypeList.put(productID, p);
	}

	public ILoadingType createLoadingType(String productID) {
		return ((ILoadingType) loadingTypeList.get(productID));
	}

}
