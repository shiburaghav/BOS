package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import ge.fpms.main.IBenefits;
import ge.fpms.main.actions.FPMS_Actions;

public class EndowmentBenefits  extends MainBenefits implements IBenefits {
	
	private FPMS_Actions llAction;
	
	

	public EndowmentBenefits() {

		super();
	}

	@Override
	public void addBenefitsDetails(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		super.addBenefitsDetails(hParams);
		
		setManualSurrenderValue(hParams.get("SurrenderValueIndicator"));
		setCashBonusOption(hParams.get("CashBonusOption"));
		setMarketingDiscount(hParams.get("MarketingDiscount"));
		setSurvivalOption(hParams.get("SurvivalBenefitOption"));
		
		save();
	}

	@Override
	public void getBenefitsType(String type) {
		
	}
	public void setBenefitsType(String type) {
		try {
			llAction.enterValue("web_benefits_internalIdNew", type);
			llAction.sendkeyStroke("web_benefits_internalIdNew", Keys.ENTER);
			llAction.sleep(5);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	@Override
	public IBenefits createBenefits() {
		return new EndowmentBenefits();
	}
	
	
	@Override
	public IBenefits createRider() {
		// TODO Auto-generated method stub
		return null;
	}

}
