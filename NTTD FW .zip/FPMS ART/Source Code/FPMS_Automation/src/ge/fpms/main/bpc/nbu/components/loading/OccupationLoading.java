package ge.fpms.main.bpc.nbu.components.loading;

import java.util.Hashtable;

import ge.fpms.main.ILoading;
import ge.fpms.main.actions.FPMS_Actions;

public class OccupationLoading implements ILoading {

	private FPMS_Actions llAction;
	public OccupationLoading() {
		llAction = new FPMS_Actions();
	}

	@Override
	public void enterSpecificLoadingInfo(Hashtable<String, String> hParams) throws Exception {
		llAction.checkBox_Check("web_uw_chk_occupationLoading");
		llAction.enterValue("web_txt_health_Duration", hParams.get("Duration"));
	}
}
