package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.Hashtable;
import java.util.logging.Logger;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;

public class RecurringTopup implements RiderFundDetails {
	private final static Logger LOGGER = Logger.getLogger(MainBenefits.class.getName());
	private FPMS_Actions llAction;

	public RecurringTopup(Hashtable<String, String> hParams) {
		llAction = new FPMS_Actions();
	}

	@Override
	public void setTopupAmount(String amount) {
		try {
			llAction.enterValue("web_txt_RecurringTopup", amount);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	@Override
	public void addFunds(Hashtable<String, String> hParams) {
		try {
			// Read hparams ..fund code 1 & fund 1 % , fund 2 code and fund 2 app

			int noOfFunds = Integer.parseInt(hParams.get("RecurNoOfFunds"));

			for (int i = 1; i <= noOfFunds; i++) {

				llAction.clickElement("web_btn_recurAdd");
				Utils.sleep(2);
				Fund obj = new Fund();

				Hashtable<String, String> fundElementTag = ARTProperties.guiMap.get("web_tbl_RecurTopup");
				int rowId = i + 1;
				String temploc1 = fundElementTag.get(fundElementTag.keySet().toArray()[0]) + "/tbody/tr[" + rowId
						+ "]/td[2]/input[1]";
				WebElement Code = llAction.findElementByXpath(temploc1);
				obj.setFundCode(Code, hParams.get(FPMSConstants.RECURFUNDCODE + i));

				llAction.sendkeyStroke("web_tbl_RecurTopup", Keys.ENTER);

				Hashtable<String, String> apportionmentTag = ARTProperties.guiMap.get("web_tbl_RecurTopup");
				String temploc2 = apportionmentTag.get(apportionmentTag.keySet().toArray()[0]) + "/tbody/tr[" + rowId
						+ "]/td[3]/input[2]";
				WebElement apportionmentPer = llAction.findElementByXpath(temploc2);
				obj.setFundApportionmentPercentage(apportionmentPer, hParams.get(FPMSConstants.RECURAPPORTIONMENT + i));

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
