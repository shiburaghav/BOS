package ge.fpms.main.bpc.bcp.templates;

import ge.fpms.main.FPMSConstants;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.common.util.Utils;

public class Type {

	private int size;
	private String dataType;
	private String value;
	private String alignment;
	private char paddingChar;

	public Type(int size, String dataType, String value, String alignment,
			char paddingChar) {
		super();
		this.size = size;
		this.dataType = dataType;
		this.value = value;
		this.alignment = alignment;
		this.paddingChar = paddingChar;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getAlignment() {
		return alignment;
	}

	public void setAlignment(String alignment) {
		if (StringUtils.isEmpty(alignment)) {
			this.alignment = FPMSConstants.LEFT_ALIGNMENT;
		}
		this.alignment = alignment;
	}

	public char getPaddingChar() {
		return paddingChar;
	}

	public void setPaddingChar(char paddingChar) {
		if (paddingChar == '\0') {
			this.paddingChar = ' ';
		} else {
			this.paddingChar = paddingChar;
		}
	}

	public String toString() {
		if (value == null) {
			value = "";
		}
		if (value.length() < size) {
			if (alignment.equalsIgnoreCase(FPMSConstants.LEFT_ALIGNMENT)) {
				value = Utils.leftPad(value, size, paddingChar);
			} else {
				value = Utils.rightPad(value, size, paddingChar);
			}
		}
		return value;
	}

}