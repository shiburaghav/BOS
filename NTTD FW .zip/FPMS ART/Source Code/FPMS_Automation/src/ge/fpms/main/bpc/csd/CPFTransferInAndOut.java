package ge.fpms.main.bpc.csd;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.common.Query;

import java.util.Hashtable;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class CPFTransferInAndOut {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	
	public CPFTransferInAndOut() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}	
	public void cpfInfo(Hashtable<String, String> hParams) throws Exception 
	{

		try {
			llAction = new FPMS_Actions();
			//To check the initial payment method
			Query query=new Query();
			query.launchQuerySearch(hParams.get("PolicyNo"));
			llAction.selectTab("quick links");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_lnk_policyBasicInformation");
			llAction.waitUntilLoadingCompletes();
			String initialPayment=llAction.getText("web_txt_paymentMethod").trim();
			if(initialPayment.equalsIgnoreCase(hParams.get("InitialPaymentMethod")))
			{
				dashboard.setStepDetails("Verify the initial payment method of policy chosen","Payment method before transaction is displayed","N/A");
				dashboard.writeResults();
			}
			else
			{
				dashboard.setFailStatus(new BPCException("Payment method is not matching with expected testdata"));
			}
			llAction.clickElement("web_btn_Exit");
			llAction.waitUntilLoadingCompletes();
			//Transaction
			llAction.selectMenuItem("Customer Service", "Special CPF Transfer In/Out");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Policy Search in CPF transfer page","Policy results should be displayed in CPF transfer page","N/A");
			llAction.selectByVisibleText("web_lst_transactionType", hParams.get("TransactionType"));
			llAction.enterValue("web_txt_policyNo", hParams.get("PolicyNo"));
			llAction.clickElement("web_btn_CPF_Search");
			llAction.waitUntilLoadingCompletes();
			dashboard.writeResults();
			int policNoCol = llAction.GetColumnPositionInTable("web_tbl_CPF_PolicyList", "Policy No");
			int policyRow = llAction.GetRowPositionInTable("web_tbl_CPF_PolicyList", hParams.get("PolicyNo"), policNoCol);
			int optionCol=llAction.GetColumnPositionInTable("web_tbl_CPF_PolicyList", "Option");
			llAction.SelectRowInTable("web_tbl_CPF_PolicyList", policyRow, optionCol,"input");	
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_CPF_Submit");
			llAction.waitUntilLoadingCompletes();
			//To check the final payment method,CashCost and CPFCost
			query.launchQuerySearch(hParams.get("PolicyNo"));
			llAction.selectTab("quick links");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_lnk_policyBasicInformation");
			llAction.waitUntilLoadingCompletes();
			String finalPayment=llAction.getText("web_txt_paymentMethod").trim();
			if(finalPayment.equalsIgnoreCase(hParams.get("FinalPaymentMethod")))
			{
				dashboard.setStepDetails("Payment method should change after CPF transaction","Payment method after transaction is displayed","N/A");
				dashboard.writeResults();
			}
			else
			{
				dashboard.setFailStatus(new BPCException("Payment method is not matching with expected testdata"));
			}
			llAction.clickElement("web_btn_Back");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("CPF Account No should be displayed","CPF Account No is displayed","N/A");
			llAction.selectTab("CPF Info");
			llAction.waitUntilLoadingCompletes();
			dashboard.writeResults();
			llAction.clickElement("web_btn_Exit");
			llAction.selectMenuItem("Query", "Query CPF Cost and Cash Cost");
			llAction.enterValue("web_txt_cost_Policy", hParams.get("PolicyNo"));
			llAction.clickElement("web_btn_Search");
			llAction.waitUntilLoadingCompletes();
			dashboard.writeResults();
			int policyNumCol = llAction.GetColumnPositionInTable("web_tbl_cost_PolicyList", "Policy Number");
			int policyNoRow = llAction.GetRowPositionInTable("web_tbl_cost_PolicyList", hParams.get("PolicyNo"), policyNumCol);
			llAction.SelectRowInTable("web_tbl_cost_PolicyList", policyNoRow, policyNumCol,"a");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Cash cost and CPF Cost should be updated","System updates Cash cost and CPF Cost","N/A");
			dashboard.writeResults();

		}catch (Exception ex) {

			throw new BPCException(ex);

		}
	}
}
