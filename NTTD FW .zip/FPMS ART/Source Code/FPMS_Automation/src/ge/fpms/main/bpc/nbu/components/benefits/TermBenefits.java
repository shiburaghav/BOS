
package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import ge.fpms.main.IBenefits;
import ge.fpms.main.ProductConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BenefitsFactory;


public class TermBenefits  extends MainBenefits implements IBenefits {
	
	private FPMS_Actions llAction;
	
	

	public TermBenefits() {

		super();
	}

	@Override
	public void addBenefitsDetails(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		super.addBenefitsDetails(hParams);
		setMarketingDiscountCategory(hParams.get("MarketingDiscountCode"));
		save();
		
	}

	@Override
	public void getBenefitsType(String type) {
		
	}

	@Override
	public IBenefits createBenefits() {
		return new TermBenefits();
	}
	

	public void setMarketingDiscountCategory(String discount) {

		try {
			llAction.enterValue("web_txt_MarketingDiscount", discount);
		} catch (Exception e) {

			e.printStackTrace();
		}	
	}

	@Override
	public IBenefits createRider() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void setBenefitsType(String type) {
		try {
			llAction.enterValue("web_benefits_internalIdNew", type);
			llAction.sendkeyStroke("web_benefits_internalIdNew", Keys.ENTER);
			llAction.sleep(5);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
}
