package ge.fpms.main.bpc.common;

import ge.fpms.main.actions.FPMS_Actions;

import java.util.Hashtable;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class FpmsSystem {
	FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public FpmsSystem() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void changeSystemDate(String DateToBeChanged) throws Exception {
		try {
			llAction.selectMenuItem("Test&Debug", "eBao Use Module", "System Config", "Setting System Date");
			llAction.enterValue("web_ChangeSysDate_txt_SysDate", DateToBeChanged);
			llAction.clickElement("web_ChangeSysDate_btn_SumbitSysDate");
			dashboard.setStepDetails("Validate if System date is changed to new System Date",
					"System date should be changed to new System Date", DateToBeChanged);
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_ChangeSysDate_btn_CancelSysDate");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void setNewSystemDate(Hashtable<String, String> hParams) throws Exception{
		String systemDate = hParams.get("NewSystemDate");
		changeSystemDate(systemDate);
	}
	
	public void resetNewSystemDate(Hashtable<String, String> hParams) throws Exception{
		String systemDate = hParams.get("ExistingSystemDate");
		changeSystemDate(systemDate);
	}
}
