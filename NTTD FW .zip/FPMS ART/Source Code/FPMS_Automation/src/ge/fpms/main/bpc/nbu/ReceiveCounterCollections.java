package ge.fpms.main.bpc.nbu;


import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;

import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class ReceiveCounterCollections extends BusinessComponent{

	private FPMS_Actions fpmsAction ;
	private PolicyHandler policyHandler;
	
	public ReceiveCounterCollections() {
		
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
		
	}	
	

	public void ReceiveCounterCollection(Hashtable<String, String> hParams) throws Exception {
		fpmsAction = new FPMS_Actions();
		String AmtCollected = hParams.get("Amount");
		try {
			fpmsAction.selectMenuItem("Collection", "Receive Counter Collection");
			DashboardHandler.getInstance().setStepDetails("Select Receive Counter Collection from Colections menu","The Receive Counter Collection search page is displayed.","N/A");
			DashboardHandler.getInstance().writeResults();

			if(hParams.get("CollectionType").trim().equalsIgnoreCase(FPMSConstants.CS_Collection)){
				performCollectionForCS(hParams);
			}else{
				AmtCollected = performCollection(hParams.get("PolicyNo"),hParams.get("Amount"));
			}
			
			if(!StringUtils.isEmpty(hParams.get("CollectionMethod")))
			{
				fpmsAction.enterValue("web_rcc_txt_CollectionMethod", hParams.get("CollectionMethod"));
				fpmsAction.sendkeyStroke("web_rcc_txt_CollectionMethod", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
			}
			
			if(!StringUtils.isEmpty(hParams.get("BankCode")))
			{
				fpmsAction.enterValue("web_rcc_txt_BankCode", hParams.get("BankCode"));
				fpmsAction.sendkeyStroke("web_rcc_txt_BankCode", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
			}
			
			if(!StringUtils.isEmpty(hParams.get("ChequeNo")))
			{
				fpmsAction.enterValue("web_rcc_txt_chequeNumber", hParams.get("ChequeNo"));
				fpmsAction.sendkeyStroke("web_rcc_txt_chequeNumber", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
			}
			
			if(!StringUtils.isEmpty(hParams.get("BankAccount")))
			{
				fpmsAction.selectByVisibleText("web_rcc_list_bankAccount", hParams.get("BankAccount"));
				llAction.waitUntilLoadingCompletes();
			}
			
			if(!StringUtils.isEmpty(hParams.get("Source")))
			{
				fpmsAction.selectByVisibleText("web_rcc_list_source", hParams.get("Source"));
				llAction.waitUntilLoadingCompletes();
			}
			
			if(!StringUtils.isEmpty(hParams.get("MerchantID")))
			{
				fpmsAction.enterValue("web_rcc_txt_MechantID", hParams.get("MerchantID"));
				fpmsAction.sendkeyStroke("web_rcc_txt_MechantID", Keys.ENTER);
				llAction.waitUntilLoadingCompletes();
			}
			
			fpmsAction.clickElement("web_rcc_btn_Add");
			llAction.waitUntilLoadingCompletes();
			fpmsAction.clickElement("web_rcc_btn_Allocate");
			llAction.waitUntilLoadingCompletes();
			/*
			if(hParams.get("ValidationRequired").equalsIgnoreCase("Y")) {
				int colPos = llAction.GetColumnPositionInTable("web_rcc_tbl_collectionAllocation", "Collect type");
				int rowPos = llAction.GetRowPositionInTable("web_rcc_tbl_collectionAllocation", hParams.get("CollectType"), colPos);
				AmtAllocated = llAction.GetTextFromTable("web_rcc_tbl_collectionAllocation", rowPos, colPos-1);
				if(!AmtAllocated.equals(AmtCollected)) {
					DashboardHandler.getInstance().setFailStatus(null);
				}
			}*/
			validateAmountAllocated(hParams.get("CollectType"), AmtCollected);
			DashboardHandler.getInstance().setStepDetails("Enter the NB collection amount,collection method and allocate. " ,"The screen Receive Counter Collection - NB collection should be displayed","N/A");
			DashboardHandler.getInstance().writeResults();	
			fpmsAction.clickElementJs("web_rcc_btn_Submit");	
			fpmsAction.sleep(6);
			fpmsAction.switchtoChildWindow("Receive Counter Collection- Search");
			System.out.println("Receive Counter Collection- Search");
			llAction.waitUntilElementPresent("web_rcc_btn_rccs_sc_Exit");
			fpmsAction.clickElementJs("web_rcc_btn_rccs_sc_Exit");
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	private void searchPolicy(String policyId) throws Exception{
		
		if(policyHandler.isPolicyEmpty()){
			policyHandler.getPolicy().setPolicyNo(policyId);
		}
		String policyNo = policyHandler.getPolicy().getPolicyNo();
		
		if(!StringUtils.isEmpty(policyNo))
		{
			llAction.enterValue("web_rcc_txt_Search_PolicyNo", policyNo);
			Utils.sleep(3);
			llAction.clickElement("web_txt_DetailReg_Search");
			DashboardHandler.getInstance().setStepDetails("Search for policy   "	+ policyHandler.getPolicy().getPolicyNo(),
							"The policy should be avaialble in Search Results. ","N/A");
			DashboardHandler.getInstance().writeResults();
			llAction.waitUntilLoadingCompletes();
			int colPos = llAction.GetColumnPositionInTable("web_tbl_Src_Policy_Rcc", "Proposal / policy number");
			llAction.SelectRowInTable("web_tbl_Src_Policy_Rcc", 2, colPos,"a");
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
			}
			llAction.waitUntilLoadingCompletes();
		}
	}
	
	private void addAmount(String amount) throws Exception{
		fpmsAction.enterValue("web_rcc_txt_Amount", amount);
	}

	private void performCollectionForCS(Hashtable<String, String> hParams) throws Exception{
		llAction.clickElement("web_cs_collection_radbutton");
		llAction.waitUntilLoadingCompletes();
		searchPolicy(hParams.get("PolicyNo"));
		addAmount(hParams.get("Amount"));
	}
	private String performCollection(String policyId,String amount) throws Exception{
		searchPolicy(policyId);
		if(!StringUtils.isEmpty(amount)){
			addAmount(amount);
			return amount;
		}else{
			String inforcingAmount = llAction.getAttribute("web_txt_total_inforcing_Amount", "value");
			addAmount(inforcingAmount);
			return inforcingAmount;
		}
		
	}
	
	public void validateAmountAllocated(String string, String amtCollected) {
		
	}
}
