package ge.fpms.main.bpc.nbu;

import java.util.Hashtable;
import java.util.logging.Logger;

import org.openqa.selenium.Keys;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;
/*
 * Name: MedicalInputbilling 
 * Purpose: Navigate to CS module from the Main Page and MedicalInputbilling a policy
 * Parameters:Parameter Hash table 
 * Return Value: NA 
 * Exception: BPCException
 * @author: Sridhar 0n 18/01/2018
 */

public class Medicalbilling {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;

	public Medicalbilling() {
		dashboard = DashboardHandler.getInstance();
	}

	public void enterMedicalBillDetails(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("NBD", "Medical Billing", "Update Billing");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Enter policy number", "System should accept the input details ","N/A");
			dashboard.writeResults();
			// enter the policy no
			llAction.enterValue("web_mb_txt_policyno", hParams.get("PolicyNumber"));
			llAction.sendkeyStroke("web_mb_txt_policyno", Keys.ENTER);
			dashboard.setStepDetails("Enter policy number"+hParams.get("PolicyNumber"),"System should accept the input details ","N/A");
			dashboard.writeResults();
			// click on search button
			llAction.clickElement("web_mb_btn_Search");
			llAction.waitUntilLoadingCompletes();
			// click on add
			llAction.clickElement("web_mb_btn_Add");
			dashboard.setStepDetails("Click on Add button","A new row is added under Items for Medical Billing section for user input ","N/A");
			dashboard.writeResults();
			enterItemsforMedicalBilling("web_mb_table", "Clinic code", hParams.get("Cliniccode"), "/input");
			enterItemsforMedicalBilling("web_mb_table", "Medical Type", hParams.get("MedicalType"), "/input");
			enterItemsforMedicalBilling("web_mb_table", "Exam Date", hParams.get("ExamDate"), "/input");
			enterItemsforMedicalBilling("web_mb_table", "Disbursement Method", hParams.get("DisbursementMethod"), "/span/select");
			enterItemsforMedicalBilling("web_mb_table", "Payable To", hParams.get("PayableTo"), "/span/select");
			dashboard.setStepDetails("Enter Medical Billing information","System should accept the input details ","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_mb_btn_Submit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Submit button","New medical billing should be added  ","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_mb_btn_Exit");
		} catch (Exception ex) {

			throw new BPCException(ex);
		}
	}

	public void enterItemsforMedicalBilling(String WebTableKey, String ColumnName, String valueToBeEntered, String optionalPath) throws Exception{

		int colPos;
		int rowPos;

		colPos = llAction.GetColumnPositionInTable(WebTableKey, ColumnName);
		rowPos = llAction.getRowCountInTable(WebTableKey);

		llAction.enterTextInTable(WebTableKey, rowPos, colPos, valueToBeEntered, optionalPath);

	}
}