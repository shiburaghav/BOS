package ge.fpms.main.bpc.bcp.templates.creditcard;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import org.apache.commons.lang3.StringUtils;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.nttdata.common.util.ColumnHeader;
import com.nttdata.core.handler.DataHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.bpc.bcp.templates.IPaymentType;
import ge.fpms.main.bpc.bcp.templates.PaymentTemplatesParse;
import ge.fpms.main.bpc.bcp.templates.Type;
import ge.fpms.main.bpc.bcp.templates.creditcard.Details;
import ge.fpms.main.bpc.bcp.templates.creditcard.CreditCard;

public class CreditCardTemplateParser extends PaymentTemplatesParse {

	private CreditCard creditcard;
	private String sheetName;
	private ArrayList<Details> detailList;
	private ArrayList<Details> alldetailList;
	private ArrayList<BatchRecord> batchRecords;
	private BatchRecord batchRecord;
	private Header initalHR;
	private Details initalDR;
	private Summary initalFT;
	private String inputFilePath;
	private String outputFilePath;
	private Header newHeader;
	private int batchRecordCount = 0;

	public CreditCardTemplateParser() {
		super();
		sheetName = ColumnHeader.CreditCard.toString();
		detailList = new ArrayList<Details>();
		alldetailList = new ArrayList<Details>();
	}

	/**
	 * parseGiro - for parsing CreditCard files
	 * 
	 * @param params
	 *            - parameters from testdata
	 * @throws Exception
	 */
	public void processCreditCardTemplate(Hashtable<String, String> params) throws Exception {
		inputFilePath = params.get("InputFile");
		outputFilePath = inputFilePath;
		String jsonTemplate = FPMSProperties.getInstance().getJsonPath("creditcard.json");
		loadObject(jsonTemplate);
		processTemplateFile(params);
	}

	/**
	 * parseGiro - for parsing CreditCard files
	 * 
	 * @param params
	 *            - parameters from testdata
	 * @throws Exception
	 */
	public void parseCCTemplate(Hashtable<String, String> params) throws Exception {
		String jsonTemplate = CreditCardTemplateParser.class.getResource("creditcard.json").getPath().toString();
		loadObject(jsonTemplate);
		parseTemplate(params);
	}

	@Override
	public void beginParse(String line) {
		parseFileHeader(line);
		batchRecord = creditcard.getBatchRecords().get(0);
		initalDR = batchRecord.getDetails().get(0);
		initalHR = batchRecord.getHeader();
		initalFT = batchRecord.getSummary();
		batchRecords = new ArrayList<BatchRecord>();
	}

	@Override
	public void parse(String line) {
		if (line.startsWith(batchRecord.getHeader().getName())) { // BH
			int startIndex = 0, endIndex = 0;
			int[] attributeSpace = initalHR.getAttributesSize();
			Type[] attributes = initalHR.getAllAttributes();
			Type[] newAttributes = new Type[attributes.length];
			for (int i = 0; i < attributeSpace.length; i++) {
				String value = "";
				endIndex += attributeSpace[i];
				if (endIndex <= line.length()) {
					value = new String(line.substring(startIndex, endIndex));
					startIndex = endIndex;
				} else {
					value = "";
				}
				newAttributes[i] = new Type(attributeSpace[i], attributes[i].getDataType(), value,
						attributes[i].getAlignment(), attributes[i].getPaddingChar());
			}
			newHeader = (new Header(newAttributes));

		}
		if (line.startsWith(initalDR.getName())) {// BD
			int startIndex = 0, endIndex = 0;

			int[] attributeSpace = initalDR.getAttributesSize();
			Type[] attributes = initalDR.getAllAttributes();
			Type[] newAttributes = new Type[attributes.length];
			for (int i = 0; i < attributeSpace.length; i++) {
				String value = "";
				endIndex += attributeSpace[i];
				if (endIndex <= line.length()) {
					value = new String(line.substring(startIndex, endIndex));
					startIndex = endIndex;
				} else {
					value = "";
				}
				newAttributes[i] = new Type(attributeSpace[i], attributes[i].getDataType(), value,
						attributes[i].getAlignment(), attributes[i].getPaddingChar());
			}
			detailList.add(new Details(newAttributes));
			alldetailList.add(new Details(newAttributes));

		}

		if (line.startsWith(batchRecord.getSummary().getName())) {// BT
			int startIndex = 0, endIndex = 0;
			Summary newSummary;
			int[] attributeSpace = initalFT.getAttributesSize();
			Type[] attributes = initalFT.getAllAttributes();
			Type[] newAttributes = new Type[attributes.length];
			for (int i = 0; i < attributeSpace.length; i++) {
				String value = "";
				endIndex += attributeSpace[i];
				if (endIndex <= line.length()) {
					value = new String(line.substring(startIndex, endIndex));
					startIndex = endIndex;
				} else {
					value = "";
				}
				newAttributes[i] = new Type(attributeSpace[i], attributes[i].getDataType(), value,
						attributes[i].getAlignment(), attributes[i].getPaddingChar());
			}
			newSummary = new Summary(newAttributes);
			batchRecords.add(batchRecordCount, new BatchRecord(newHeader, detailList, newSummary));
			detailList = new ArrayList<Details>();
			batchRecordCount++;
		}
	}

	@Override
	public void endParse(String line) {
		creditcard.setBatchRecords(batchRecords);
		parseFileFooter(line);

	}

	@Override
	public void createNewFile(String outputFile) {
		try {
			int index = inputFilePath.lastIndexOf(File.separator);
			File file = new File(inputFilePath);
			outputFilePath = (index > -1) ? inputFilePath.substring(0, index) : inputFilePath;
			outputFilePath = outputFilePath + "\\gesout" + file.getName().substring(file.getName().length() - 2);
			BufferedWriter out = new BufferedWriter(new FileWriter(outputFilePath));
			out.write(creditcard.getFileHeader().toString());
			out.newLine();
			for (BatchRecord br : creditcard.getBatchRecords()) {
				out.write(br.getHeader().toString());
				out.newLine();
				for (Details det : br.getDetails()) {
					out.write(det.toString());
					out.newLine();
				}
				out.write(br.getSummary().toString());
				out.newLine();
			}
			out.write(creditcard.getFileFooter().toString());
			out.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void updateAttributes(Hashtable<String, String> params) {
		// Updating Details Section
		if (!StringUtils.isEmpty(params.get("PolicyNumber"))) {
			String[] pNumberList = params.get("PolicyNumber").split(",");
			if (pNumberList != null && pNumberList.length > 0) {
				for (String pNumber : pNumberList) {
					Hashtable<String, String> creditCardData = getCreditCardData(pNumber);
					for (BatchRecord br : creditcard.getBatchRecords()) {
						for (Details det : br.getDetails()) {
							String dPolicy = det.getPolicyReference().getValue(); // PolicyNumber
							int pol = Integer.valueOf(dPolicy.replace(" ", "0"));
							int dAmount = Integer.parseInt(det.getTransactionAmount().getValue()); // Settlement Amount
							if (!creditCardData.isEmpty()) {
								int tdPol = Integer.valueOf(creditCardData.get("PolicyNumber")); // in Cents
								int tdAmt = Integer.parseInt(creditCardData.get("Amount").replace(".", ""));
								if (pol == tdPol && dAmount == tdAmt) {
									det.getResponseCode().setValue(creditCardData.get("ResponseCode"));
									det.getResponseDescription().setValue(creditCardData.get("ResponseDescription"));
									break;
								}
							}
						}
					}
				}
			}
		}

		int totalAcceptedCountFile = 0, totalTransactionAmountFile = 0;
		for (BatchRecord br : creditcard.getBatchRecords()) {
			int totalAcceptedCount = 0, totalTransactionAmount = 0;
			for (Details det : br.getDetails()) {
				if (det.getResponseCode().getValue().trim().equals(IPaymentType.DEFAULT_RESPONSE_CODE)) {
					totalTransactionAmount = totalTransactionAmount
							+ Integer.parseInt(det.getTransactionAmount().getValue());
					totalAcceptedCount++;
					totalAcceptedCountFile++;
					String val = String.valueOf(System.nanoTime());
					det.getResponseDescription().setValue(val);
				}

			}
			br.getSummary().getRecordCount().setValue(String.valueOf(totalAcceptedCount));
			br.getSummary().getTotalAmount().setValue(String.valueOf(totalTransactionAmount));
			totalTransactionAmountFile = totalTransactionAmountFile + totalTransactionAmount;
		}
		creditcard.getFileFooter().getRecordCount().setValue(String.valueOf(totalAcceptedCountFile));
		creditcard.getFileFooter().getTotalAmount().setValue(String.valueOf(totalTransactionAmountFile));
	}

	public Hashtable<String, String> getCreditCardData(String pNumber) {
		DataHandler dataHandler = new DataHandler();
		Hashtable<String, String> creditCardData = dataHandler.getTestData(sheetName,
				FPMSProperties.getInstance().getTestDataFilePath(System.getProperty("Settings.Module")),
				ColumnHeader.getColumnHeader(sheetName), pNumber, "PolicyNumber");
		return creditCardData;
	}

	/**
	 * load the Credit Card Structure using the JSON template
	 * 
	 * @param jsonTemplate
	 */
	private void loadObject(String jsonTemplate) {
		try {

			Gson gson = new Gson();
			creditcard = gson.fromJson(new FileReader(jsonTemplate), CreditCard.class);

		} catch (JsonIOException | JsonSyntaxException | FileNotFoundException e) {

		}

	}

	private void parseFileHeader(String line) {

		if (line.startsWith(creditcard.getFileHeader().getName())) {
			int startIndex = 0, endIndex = 0;
			ArrayList<String> buffer = new ArrayList<String>();
			int[] attributeSpace = creditcard.getFileHeader().getAttributesSize();
			for (int i = 0; i < attributeSpace.length; i++) {
				endIndex += attributeSpace[i];
				buffer.add(line.substring(startIndex, endIndex));
				startIndex = endIndex;
			}
			creditcard.getFileHeader().setParamaters(buffer);
		}
	}

	private void parseFileFooter(String line) {
		if (line.startsWith(creditcard.getFileFooter().getName())) {
			int startIndex = 0, endIndex = 0;
			int[] attributeSpace = creditcard.getFileFooter().getAttributesSize();
			String[] attributesValues = new String[attributeSpace.length];

			for (int i = 0; i < attributeSpace.length; i++) {
				endIndex += attributeSpace[i];

				if (endIndex <= line.length()) {
					attributesValues[i] = new String(line.substring(startIndex, endIndex));
					startIndex = endIndex;
				} else {
					break;
				}
			}

			creditcard.getFileFooter().setParamaters(attributesValues);
		}
	}

	public String getAllPolicies(int nPolicies) {
		Details[] detailsList = alldetailList.toArray(new Details[0]);
		StringBuilder policies = new StringBuilder();
		
		nPolicies = nPolicies > detailsList.length ? detailsList.length :  nPolicies;
		
		for(int i = 0; i < nPolicies ;i++){
			if(i > 0){
				policies.append(FPMSConstants.COMMA_SEPERATOR);
			}
			policies.append(detailsList[i].getPolicyReference().getValue().trim());
		}
		return policies.toString();
	}

	public String getInputFilePath() {
		return inputFilePath;
	}

	public String getOutputFilePath() {
		return outputFilePath;
	}

	// public static void main(String[] args) {
	// String dwlLoad ="C:\\Users\\010_SG3\\Downloads\\gesin22";
	// String output = "D:\\FPMS_ART\\";
	// Hashtable<String, String> params = new Hashtable<String, String>();
	// params.put("InputFile", dwlLoad);
	// params.put("OutputFile", output);
	// params.put("PolicyNumber", "0200941418,0206477209");
	// params.put("Amount", "74900");
	// params.put("ReturnCode", "001");
	//
	// try {
	// new CreditCardTemplateParser().processccTemplate(params);
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }

}