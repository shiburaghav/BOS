package ge.fpms.main.bpc.finance;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSProperties;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.common.Query;
import ge.fpms.main.bpc.nbu.BatchConstants;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.ApachePOIUtility;
import com.nttdata.common.util.ArtRobot;
import com.nttdata.common.util.Utils;
import com.nttdata.core.components.table.TableColumn;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;
import ge.fpms.main.FPMSProperties;


public class FundManagement {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private String home = System.getProperty("user.home");
	private String adjFileName="Batch Adjustment";



	public FundManagement() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();

	}

	/**
	 * searchFundPrice - search the Find Price from FPMS Batch Fund Price Entry screen
	 * @param hParams
	 * @throws Exception
	 */
	public void searchFundPrice(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Fund Administration","web_batchjobs_menuitem_fund_admin");
			llAction.goMenuItem("Fund Price Entry","web_batchjobs_menuitem_fp_entry");
			llAction.selectMenuItem("FUND_NEW_REVISE");

			llAction.enterValue("web_fund_txt_FundCode_From",hParams.get("FundCodeFrom"));
			llAction.sendkeyStroke("web_fund_txt_FundCode_From", Keys.ENTER);
			dashboard.setStepDetails("Select Fund Code From ", "Fund Code from '" + hParams.get("FundCodeFrom") + "' is selected" ,"N/A");
			dashboard.writeResults();

			llAction.enterValue("web_fund_txt_FundCode_To",hParams.get("FundCodeTo"));
			llAction.sendkeyStroke("web_fund_txt_FundCode_To", Keys.ENTER);
			dashboard.setStepDetails("Select Fund Code To ", "Fund Code To" + hParams.get("FundCodeTo") + "' is selected" ,"N/A");
			dashboard.writeResults();
			llAction.enterValue("web_fund_effective_price_date",hParams.get("PriceEffectiveDate"));
			llAction.sendkeyStroke("web_fund_effective_price_date", Keys.ENTER);
			dashboard.setStepDetails("Select Price Effective Date ", "Price Effective Date '" + hParams.get("PriceEffectiveDate") + "' is selected" ,"N/A");
			dashboard.writeResults();			

			llAction.selectByVisibleText("web_fund_Price_Frequency_list", hParams.get("PriceFrequency"));	

			dashboard.setStepDetails("Select Pricing Frequency ", "Price Frequency '" + hParams.get("PriceFrequency") + "' is selected" ,"N/A");
			dashboard.writeResults();

			llAction.selectByVisibleText("web_fund_Price_Currency_list", hParams.get("PricingCurrency"));	
			dashboard.setStepDetails("Select Pricing Currency ", "Pricing Currency '" + hParams.get("PricingCurrency") + "' is selected" ,"N/A");
			dashboard.writeResults();												
			llAction.clickElement("web_batchjob_fund_approval_search_btn");
			llAction.waitUntilLoadingCompletes();


		} catch (Exception e) {
			throw new BPCException(e);
		}
	}


	/**
	 * updateBidPrice - Update the bid Price from FPMS Batch Fund Price Entry screen for the selected fund code.
	 * @param hParams
	 * @throws Exception
	 */
	public void updateBidPrice(Hashtable<String, String> hParams) throws Exception {
		try {

			int PriceStatuscolPos;
			int PriceStatusrowPos;

			int ReviseColPos;
			searchFundPrice(hParams);
			Hashtable<String, String> fundTable = ARTProperties.guiMap.get("web_fund_approval_table");
			String fundTablePath = fundTable.get(fundTable.keySet().toArray()[0]);
			if(llAction.getSize(fundTablePath) > 1){
				//llAction.checkBox_Check("web_fund_selectall");
				dashboard.setStepDetails("Bid Price Update ", "Updating Bid Price for..","N/A");
				dashboard.writeResults();

				String ActionType = hParams.get("FundPriceType");
				PriceStatuscolPos = llAction.GetColumnPositionInTable("web_fund_approval_table", "Price Status");	

				//String fundPriceStatus = llAction.GetTextFromTable("web_fundprice_query_table", PriceStatusrowPos, PriceStatuscolPos+2);


				if (ActionType.equalsIgnoreCase("New"))
				{
					PriceStatusrowPos = llAction.GetRowPositionInTable("web_fund_approval_table", "", PriceStatuscolPos);
					llAction.SelectRowInTable("web_fund_approval_table",PriceStatusrowPos,PriceStatuscolPos - 8,"input");
					llAction.enterTextInTable("web_fund_approval_table", PriceStatusrowPos, PriceStatuscolPos - 5, hParams.get("BidPrice"), "//input[@name='bidPrice']");	
					dashboard.setStepDetails("Fund Price Update", "Fund Price is Updated to '" + hParams.get("BidPrice") +"'","N/A");
					dashboard.writeResults();
					//lauchFundPriceQuery(hParams);

				}
				else {
					ReviseColPos = llAction.GetColumnPositionInTable("web_fund_approval_table", "Revise");
					PriceStatusrowPos = llAction.GetRowPositionInTable("web_fund_approval_table", "Approved", PriceStatuscolPos);					
					if (PriceStatusrowPos <= 0) {
						PriceStatusrowPos = llAction.GetRowPositionInTable("web_fund_approval_table", "Confirmed", PriceStatuscolPos);
					}	
					llAction.SelectRowInTable("web_fund_approval_table",PriceStatusrowPos,PriceStatuscolPos - 8,"input");
					llAction.enterTextInTable("web_fund_approval_table", PriceStatusrowPos, PriceStatuscolPos - 5, hParams.get("BidPrice"), "//input[@name='bidPrice']");	
					llAction.SelectRowInTable("web_fund_approval_table",PriceStatusrowPos,ReviseColPos,"input");
				}

				llAction.clickElement("web_fund_priceEntry_submit");
				llAction.waitUntilLoadingCompletes();
				//if (llAction.isDisplayed("web_fund_Price_errormessage_txt",2))
				//{
				String strErrorMessage= llAction.getText("web_fund_Price_errormessage_txt");

				if (strErrorMessage.contains("Error Message:")) { 
					dashboard.setFailStatus(new BPCException(strErrorMessage + " error message occured."));
					dashboard.writeResults();
				}				
				//}else {
				llAction.clickElement("web_fund_exit");
				llAction.waitUntilLoadingCompletes();
				if (ActionType.equalsIgnoreCase("New"))
				{
					validateFundPrice(hParams,"Price Status","Entered");
				}else if(ActionType.equalsIgnoreCase("Revise")){

					validateFundPrice(hParams,"Price Status,Price Status","Entered,Revised");
				}



			}else{
				dashboard.setFailStatus(new BPCException("Update Bid Price for Funds : No funds found when searched!!!"));
			}


		} catch (Exception e) {
			throw new BPCException(e);
		}
	}


	public void validateFundPrice(Hashtable<String, String> hParams, String fundPriceColumns, String fundPriceValues) throws Exception {
		try {
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Fund Administration","web_batchjobs_menuitem_fund_admin");
			llAction.goMenuItem("Fund Price Approval","web_batchjobs_menuitem_fp_approval");
			llAction.selectMenuItem("QUERY_FUND_PRICE");

			llAction.enterValue("web_fund_txt_FundCode_From",hParams.get("FundCodeFrom"));
			llAction.sendkeyStroke("web_fund_txt_FundCode_From", Keys.ENTER);
			llAction.enterValue("web_fund_txt_FundCode_To",hParams.get("FundCodeTo"));
			llAction.sendkeyStroke("web_fund_txt_FundCode_To", Keys.ENTER);			

			llAction.enterValue("web_fund_txt_effectivePriceFrom",hParams.get("PriceEffectiveDateFrom"));
			llAction.sendkeyStroke("web_fund_txt_effectivePriceFrom", Keys.ENTER);

			llAction.enterValue("web_fund_txt_effectivePriceTo",hParams.get("PriceEffectiveDateTo"));
			llAction.sendkeyStroke("web_fund_txt_effectivePriceTo", Keys.ENTER);		


			//llAction.selectByVisibleText("web_fund_price_status_list", hParams.get("FundPriceStatus"));	

			llAction.clickElement("web_fund_approval_search_btn");
			llAction.waitUntilLoadingCompletes();

			Hashtable<String, String> fundTable = ARTProperties.guiMap.get("web_fundprice_query_table");
			String fundTablePath = fundTable.get(fundTable.keySet().toArray()[0]);

			if(llAction.getSize(fundTablePath) > 1){				
				String [] arrColumns = fundPriceColumns.split(",");
				String [] arrValues = fundPriceValues.split(",");				
				if (arrColumns.length == arrValues.length)
				{
					int colPos = llAction.GetColumnPositionInTable("web_fundprice_query_table", "Price Effective Date");		

					int rowPos = llAction.GetRowPositionInTable("web_fundprice_query_table", hParams.get("PriceEffectiveDate"), colPos);					
					for (int i = 0; i < arrColumns.length; i++) {
						int ColIndex = findColumnIndex("web_fundprice_query_table",arrColumns[i]);	
						if (arrValues[i].equalsIgnoreCase("Revised")) {
							rowPos = rowPos +1 ;
						}								

						String actualValue = llAction.GetTextFromTable("web_fundprice_query_table", rowPos, ColIndex);
						if (actualValue.equalsIgnoreCase(arrValues[i])) {
							dashboard.setStepDetails("Verify " + arrColumns[i] + "",
									arrColumns[i] + "is validated as " + arrValues[i] +"  successfully.", "N/A");
							dashboard.writeResults();

						}
					}
				}		 				
				else {
					dashboard.setFailStatus(new BPCException("Fund Price Column Validation : The no of columns for validation are not matching with no of values to check. Pls provide"));
				}						
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_fund_exit");
				llAction.waitUntilLoadingCompletes();
			}
			else{
				dashboard.setFailStatus(new BPCException("Fund Price Query : No funds found when searched!!!"));
			}

		} catch (Exception e) {
			throw new BPCException(e);

		}
	}


	public int findColumnIndex(String tableName, String headerName) throws Exception {
		int cIndex = -1;
		ArrayList<TableColumn> computationColnHeaders = llAction.getColumnHeaders(tableName, 1);
		for (TableColumn coln : computationColnHeaders) {
			if (coln.getName().equalsIgnoreCase(headerName)) {
				cIndex = coln.getIndex();
				break;
			}
		}

		return cIndex;

	}

	/**
	 * adjustAdhocUnits - This will adjust units for the fund code in an adhoc manner.
	 * @param hParams
	 * @throws Exception
	 */
	public void adjustAdhocUnits(Hashtable<String, String> hParams) throws Exception {
		try {
			/*Hover to Finance and click on Fund administration and click on Unit Adjustment*/
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Fund Administration","web_batchjobs_menuitem_fund_admin");
			llAction.goMenuItem("Fund Price Entry","web_batchjobs_menuitem_fp_entry");
			llAction.selectMenuItem("UNIT_ADJUSTMENT");			
			llAction.enterValue("web_unitadjustment_policynumber_text",hParams.get("PolicyNumber"));
			llAction.sendkeyStroke("web_unitadjustment_policynumber_text", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			if (!hParams.get("FundCode").equalsIgnoreCase("All")) {

				llAction.enterValue("web_unitadjustment_fundcode_txt",hParams.get("FundCode"));
				llAction.sendkeyStroke("web_unitadjustment_fundcode_txt", Keys.ENTER);
			} 			
			/*llAction.enterValue("web_unitadjustment_adjustmentDate_txt",hParams.get("AdjustmentDate"));
			llAction.sendkeyStroke("web_unitadjustment_adjustmentDate_txt", Keys.ENTER);	*/	
			//Right now , adjustment date will be the system date which cannot be changed so commenting it.
			llAction.clickElement("web_unitadjustment_search_btn");
			llAction.waitUntilLoadingCompletes();

			Hashtable<String, String> fundTable = ARTProperties.guiMap.get("web_unit_adjustment_table");
			String fundTablePath = fundTable.get(fundTable.keySet().toArray()[0]);

			if(llAction.getSize(fundTablePath) > 1){				

				int FundCodeCol = llAction.GetColumnPositionInTable("web_unit_adjustment_table", "Fund Code"); 				
				int FundCodeRow = llAction.GetRowPositionInTable("web_unit_adjustment_table",
						hParams.get("FundCode"), FundCodeCol);
				llAction.SelectRowInTable("web_unit_adjustment_table", FundCodeRow, FundCodeCol-3,
						"input");										
				llAction.enterTextInTable("web_unit_adjustment_table", FundCodeRow, 7, hParams.get("UnitsToAdjust"),"/input"); 		
				dashboard.setStepDetails("Adjust Units", hParams.get("UnitsToAdjust") + "' Units are entered for adjustment" ,"N/A");
				dashboard.writeResults();
				llAction.enterTextInTable("web_unit_adjustment_table", FundCodeRow, 9, hParams.get("PriceEffectiveDateforAdjustment"),"/input");
				dashboard.setStepDetails("Enter Price Effective date for adjustment", hParams.get("PriceEffectiveDateforAdjustment") + "' is entered for adjustment" ,"N/A");
				dashboard.writeResults();
				llAction.enterTextInTable("web_unit_adjustment_table", FundCodeRow, 10, hParams.get("ReasonforAdjustment"),"/input");
				dashboard.setStepDetails("Enter reason for adjustment", hParams.get("ReasonforAdjustment") + "' is entered" ,"N/A");
				dashboard.writeResults();
				llAction.clickElement("web_unitadjustment_Submit_btn");
				dashboard.setStepDetails("Click on 'Submit' button", "'Submit' is clicked" ,"N/A");
				dashboard.writeResults();
				llAction.waitUntilLoadingCompletes();
				llAction.clickElement("web_unitadjustment_exit_btn");
				dashboard.setStepDetails("Click on 'Exit' button", "'Exit' button is clicked" ,"N/A");
				dashboard.writeResults();
				llAction.waitUntilLoadingCompletes();	
			}
			else{
				dashboard.setFailStatus(new BPCException("Adjust Units for funds: No funds found when searched!!!"));
			}			

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}


	/**
	 * adjustBatchUnits - adjust the batch units using batch upload.csv.
	 * @param hParams
	 * @throws Exception
	 */
	public void adjustBatchUnits(Hashtable<String, String> hParams) throws Exception {

		try {
			deleteExistingCSVFiles();
			String gainLossInd=hParams.get("GainLossInd");
			String priceEffdate=hParams.get("PriceEffectiveDateforAdjustment");
			String units=hParams.get("UnitsToAdjust");
			String reason=hParams.get("ReasonforAdjustment"); 
			String ouputFileFolderPath=System.getProperty("Settings.ART Downloads")+ File.separator + System.getProperty("Settings.Run Name") + File.separator + FPMSConstants.OUTPUTFILES_FOLDER ;
			DashboardHandler.getInstance().createDirStruct(ouputFileFolderPath);
			String destinationFilePath=ouputFileFolderPath+ File.separator + FPMSConstants.BATCH_UPLOAD_FILE_BASENAME+FPMSConstants.CSVFILE_FORMAT;
			File dest=new File(destinationFilePath);
			//Input fields in UI
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Fund Administration","web_batchjobs_menuitem_fund_admin");
			llAction.selectMenuItem("BATCH_PRICE_CORRECTION");	
			dashboard.setStepDetails("Navigate to Batch Unit adjustment screen", " Batch Unit adjustment screen is displayed","N/A");
			dashboard.writeResults();
			llAction.enterValue("web_bacthunitadjustment_fund_code_txt",hParams.get("FundCode"));
			llAction.sendkeyStroke("web_bacthunitadjustment_fund_code_txt", Keys.ENTER);
			llAction.enterValue("web_batchunitadjustment_priceEffectivedate_txt",hParams.get("PriceEffectiveDate"));
			llAction.sendkeyStroke("web_batchunitadjustment_priceEffectivedate_txt", Keys.ENTER);
			llAction.enterValue("web_bacthunitadjustment_txnDateFrom",hParams.get("TransactionFrom"));
			llAction.sendkeyStroke("web_bacthunitadjustment_txnDateFrom", Keys.ENTER);
			llAction.enterValue("web_bacthunitadjustment_txnDateTo",hParams.get("TransactionTo"));
			llAction.sendkeyStroke("web_bacthunitadjustment_txnDateTo", Keys.ENTER);
			dashboard.setStepDetails("Enter the required information", "System should accept the input details","N/A");
			dashboard.writeResults();	
			downloadBatchUnitFile();
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_fund_exit");
			//File processing
			String adjFilepath=home+"/Downloads/" + adjFileName +FPMSConstants.CSVFILE_FORMAT;
			File adjustmentFile = new File(adjFilepath);
			FileReader filereader = new FileReader(adjustmentFile); 
			CSVReader csvReader = new CSVReader(filereader);
			FileWriter outputfile = new FileWriter(dest); 
			StringBuilder builder=new StringBuilder();
			CSVWriter writer = new CSVWriter(outputfile,',',CSVWriter.NO_QUOTE_CHARACTER,CSVWriter.DEFAULT_ESCAPE_CHARACTER,CSVWriter.DEFAULT_LINE_END ); 
			String[] mainHeader= {"Upload Batch Unit Adjustment,,,,,,,"};
			writer.writeNext(mainHeader);
			String[] NexLines= {String.format("%n")};
			//writer.writeNext(NexLines);	
			String[] blankLines= {",,,,,,,"};				
			writer.writeNext(blankLines);	
		//	writer.writeNext(NexLines);	
			writer.writeNext(blankLines);
			
			String[] subHeaders= {"Policy No","Ben Code","Product Pricing(DP = Dual Pricing)(SP =  Single Pricing)","Fund Code ",
					"Gain/loss Indicators","Price Effective date for adjustment","No of Units for Adjustment","Reason for Adjustment"};
			writer.writeNext(subHeaders);

			int time = 0;
			String PolicyNumber = "";
			List<String[]> allData = csvReader.readAll(); 
			// Copy  Data
			for (String[] row : allData) { 
				if(allData.indexOf(row) > 7 && allData.indexOf(row)<allData.size()-3 ){
					int index = 0;
					String newLine = "";
					time = time +1;
					 newLine = row[0];
					  PolicyNumber = newLine.split(",")[0].toString();
					for (String cell : row) { 
						if( index==4||index==5||index==6 ){
							if(index==4) {
								newLine = newLine + ","+row[5];
							}else if(index==5)
							 {
								newLine = newLine + ","+row[4];
							}
							else {
							newLine = newLine + ","+cell;  
							}
						}
						index++;
					}
			
					builder.append(newLine+","+gainLossInd+","+priceEffdate+","+units+","+reason);// +String.format("%n"));
					
					System.out.println(builder);
					String[] data=builder.toString().split(",");
					System.out.println(time);
					writer.writeNext(data);
					 builder.setLength(0);
					
					
				}
			}
			writer.close();
			 Hashtable<String, String> hParamsPolicies = new Hashtable<String, String>();         
			// String PolicyNumber = newLine.split(",")[0].toString();
			 PolicyNumber = PolicyNumber.replace("PN", "");
			 hParamsPolicies.put("Capture", "Benefit Info");
			 hParamsPolicies.put("PolicyNumber", PolicyNumber);
			 Query qr = new Query();
		     qr.displayCommonQueryInfo(hParamsPolicies);	
		     
			dashboard.setStepDetails("Copy the required fiedls from batch adjustment file to Batch upload file", "Batch Upload.csv file is created in Output files folder","N/A");
			dashboard.writeResults();
			
			//Validate whether upload is successful or not
			
			
			
			
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void validateConfirmFundPrice(Hashtable<String, String> hParams) throws Exception {
		try {

			validateFundPrice(hParams,"Price Status","Confirmed");

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}



	private void downloadBatchUnitFile() throws Exception{

		llAction.clickElementJs("web_unitadjustment_download_btn");	
		llAction.waitUntilLoadingCompletes();
		dashboard.setStepDetails("User clicks on the download Excel button", "System prompts to ask user to save the file","N/A");
		dashboard.writeResults();	
		ArtRobot.saveFile();
		Utils.sleep(3);
	}
	public void uploadBatchUnitFile(Hashtable<String, String> hParams) throws Exception {
		try {
			String ouputFileFolderPath=System.getProperty("Settings.ART Downloads")+ File.separator + System.getProperty("Settings.Run Name") + File.separator + FPMSConstants.OUTPUTFILES_FOLDER ;
			String uploadFilePath=ouputFileFolderPath+ File.separator + FPMSConstants.BATCH_UPLOAD_FILE_BASENAME + FPMSConstants.CSVFILE_FORMAT;
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Fund Administration","web_batchjobs_menuitem_fund_admin");
			llAction.selectMenuItem("BATCH_PRICE_CORRECTION");
			dashboard.setStepDetails("Navigate to Batch Unit adjustment screen", " Batch Unit adjustment screen is displayed","N/A");
			dashboard.writeResults();
			llAction.enterValue("web_unitadjustment_chooseFile",uploadFilePath);
			dashboard.setStepDetails("Browse and provide the upload file path", " Upload file path is entered","N/A");
			dashboard.writeResults();
			llAction.clickElementJs("web_unitadjustment_uploadexcel");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Upload Excel button", " System validates the uploaded file","N/A");
			dashboard.writeResults();
			if(llAction.isDisplayed("web_txt_ErrorMessage",5))
			{
				dashboard.setFailStatus(new BPCException("System displayed an error message!"));
			}
			
			
			
		}catch (Exception e) {
			throw new BPCException(e);
		}finally{
			String ouputFileFolderPath=System.getProperty("Settings.ART Downloads")+ File.separator + System.getProperty("Settings.Run Name") + File.separator + FPMSConstants.OUTPUTFILES_FOLDER ;
			String timestamp=new SimpleDateFormat("ddMMYYHHmm").format(new Date());
			String adjFilepath=home+"/Downloads/" + adjFileName +FPMSConstants.CSVFILE_FORMAT;
			File adjustmentFile=new File(adjFilepath);
			File adjFileFinal=new File(home+"/Downloads/" + adjFileName +FPMSConstants.NAME_SEPERATOR+timestamp+ FPMSConstants.CSVFILE_FORMAT);
			FileUtils.copyFile(adjustmentFile, adjFileFinal);
			if(adjustmentFile.exists())
				adjustmentFile.delete();

			File dest=new File(ouputFileFolderPath+ File.separator + FPMSConstants.BATCH_UPLOAD_FILE_BASENAME+FPMSConstants.CSVFILE_FORMAT);
			String uploadedFilespath=ouputFileFolderPath+ File.separator + FPMSConstants.BATCH_UPLOAD_FILE_BASENAME +FPMSConstants.NAME_SEPERATOR+timestamp + FPMSConstants.CSVFILE_FORMAT;
			File uploadedFile=new File(uploadedFilespath);
			FileUtils.copyFile(dest, uploadedFile);
			if(dest.exists())
				dest.delete();
			dashboard.setStepDetails("Appended timestamp to the Batch Adjustment and Upload file names ", "Renamed the Batch Adjustment and Upload files in their respective locations ","N/A");
			dashboard.writeResults();
		}
	}



	public void lauchFundPriceQuery(Hashtable<String, String> hParams)
			throws Exception {
		try {
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Fund Administration","web_batchjobs_menuitem_fund_admin");
			llAction.goMenuItem("Fund Price Approval","web_batchjobs_menuitem_fp_approval");
			llAction.selectMenuItem("QUERY_FUND_PRICE");

			/*llAction.enterValue("web_fund_txt_FundCode_From",hParams.get("FundCodeFrom"));
		llAction.sendkeyStroke("web_fund_txt_FundCode_From", Keys.ENTER);
		llAction.enterValue("web_fund_txt_FundCode_To",hParams.get("FundCodeTo"));
		llAction.sendkeyStroke("web_fund_txt_FundCode_To", Keys.ENTER);			

		llAction.enterValue("web_fund_txt_effectivePriceFrom",hParams.get("PriceEffectiveDateFrom"));
		llAction.sendkeyStroke("web_fund_txt_effectivePriceFrom", Keys.ENTER);

		llAction.enterValue("web_fund_txt_effectivePriceTo",hParams.get("PriceEffectiveDateTo"));
		llAction.sendkeyStroke("web_fund_txt_effectivePriceTo", Keys.ENTER);		


		llAction.selectByVisibleText("web_fund_price_status_list", hParams.get("FundPriceStatus"));	

		llAction.clickElement("web_fund_approval_search_btn");
		llAction.waitUntilLoadingCompletes();*/

		} 
		catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	
	public void ApproveFundPrice(Hashtable<String, String> hParams) throws Exception{
		llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
		llAction.goMenuItem("Fund Administration","web_batchjobs_menuitem_fund_admin");
		llAction.goMenuItem("Fund Price Approval","web_batchjobs_menuitem_fp_approval");
		llAction.selectMenuItem("FUND_PRICE_APPROVAL");

		llAction.enterValue("web_fund_txt_FundCode_From",hParams.get("FundCodeFrom"));
		llAction.sendkeyStroke("web_fund_txt_FundCode_From", Keys.ENTER);
		llAction.enterValue("web_fund_txt_FundCode_To",hParams.get("FundCodeTo"));
		llAction.sendkeyStroke("web_fund_txt_FundCode_To", Keys.ENTER);
		llAction.enterValue("web_batchjobs_fund_effective_price_date",hParams.get("PriceEffectiveDate"));
		llAction.sendkeyStroke("web_batchjobs_fund_effective_price_date", Keys.ENTER);
		llAction.clickElement("web_batchjob_fund_approval_search_btn");
		llAction.waitUntilLoadingCompletes();

		Hashtable<String, String> fundTable = ARTProperties.guiMap.get("web_batchjob_fund_approval_table");
		String fundTablePath = fundTable.get(fundTable.keySet().toArray()[0]);


		if(llAction.getSize(fundTablePath) > 1){
			llAction.checkBox_Check("web_batachjob_fund_selectall");
			dashboard.setStepDetails("Fund Price Approval ", "Submitting funds for approval","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_batchjob_fund_approval_submit");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_batchjob_fund_exit");
			llAction.waitUntilLoadingCompletes();	
			if (!StringUtils.isEmpty(hParams.get("FundPriceType"))) {		
				validateFundPrice(hParams,"Price Status","Approved");
			}
		}else{
			dashboard.setFailStatus(new BPCException("Approve Funds : No funds found when searched!!!"));
		}

	}

	
	public void deleteExistingCSVFiles() throws Exception {
		try {
			//Delete all pdf files.		
			String runTrailReportFilepath= home+"/Downloads/" ;
			File runTrailReport = new File(runTrailReportFilepath);
			if (runTrailReport.exists()) {				
				File[] listOfFiles = runTrailReport.listFiles();
				for (File file : listOfFiles) {
					if (file.getName().endsWith(".csv"))
						{
						file.delete();
					
						}
				}			
				
			}

		}
			catch (Exception e) {
			throw new BPCException(e);
		}
	}

	
	
	public void validateFileUpload(Hashtable<String, String> hParams) throws Exception {
		try {
			
			//Capture the file no
			String fileUploadNo = llAction.getText("web_txt_fileNo");
			//Pattern numPat = Pattern.compile("\\d+");
			//Matcher m1 = numPat.matcher(fileUploadNo);
			if (!fileUploadNo.contains("Finished File No")) {
				dashboard.setFailStatus(new BPCException("Validate file no  : " + fileUploadNo + " failed!!!"));
			}
			String fileUploadNumber = fileUploadNo.replaceAll("[^0-9+]","");
			//Enter the file upload in the search box
			llAction.enterValue("web_txt_uploadFileNo",fileUploadNumber);
			//Click on search 
			llAction.clickElement("web_fund_search_btn");
			llAction.waitUntilLoadingCompletes();
			
			//table will be loaded below.
			//get row count
			//store failure count in this variable.
			int failedUploads = 0;
			int rowCount = llAction.getRowCountInTable("web_table_uploadResults");
			Hashtable<String, String> hParams1 = new Hashtable<String, String>();         
          
			if(rowCount > 1){
				List<String> successfullPolicies = new ArrayList<String>();
				//check the upload status for all active data rows.
				int uploadStatusColPos = llAction.GetColumnPositionInTable("web_table_uploadResults", "Upload Status");
				int policyNoColPos = llAction.GetColumnPositionInTable("web_table_uploadResults", "Policy Number");
				for(int i=1;i<rowCount;i++) {
					//get the Upload Status Column value					
					String uploadStatus = llAction.GetTextFromTable("web_table_uploadResults", i+1, uploadStatusColPos);
					if(uploadStatus.equalsIgnoreCase("Failed")) {
						failedUploads = failedUploads +1;
						String PolicyNumber = llAction.GetTextFromTable("web_table_uploadResults", i+1, policyNoColPos);
						dashboard.setStepDetails("Upload Status of policy:",PolicyNumber + " upload status is failed.","N/A");
						dashboard.writeResults();
					}else {
						  String PolicyNumber = llAction.GetTextFromTable("web_table_uploadResults", i+1, policyNoColPos);
						  hParams1.put("Capture", "Benefit Info");
				          hParams1.put("PolicyNumber", PolicyNumber);
				          Query qr = new Query();
				          qr.displayCommonQueryInfo(hParams1);	
					}
										
				}
				
				if(failedUploads==rowCount-1) {
					dashboard.setFailStatus(new BPCException("Validate file uploads  : All policies failed!!!"));
				}
			}
	
		}

		 catch (Exception e) {
			throw new BPCException(e);
		}
	}

	
	
	
	
}







