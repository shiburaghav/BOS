package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.Hashtable;
import java.util.logging.Logger;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;

public class SinglePremiumTopup implements RiderFundDetails {
	private final static Logger LOGGER = Logger.getLogger(MainBenefits.class.getName());
	private FPMS_Actions llAction;

	public SinglePremiumTopup(Hashtable<String, String> hParams) {
		llAction = new FPMS_Actions();
	}

	public void setTopupAmount(String amount) throws Exception {
		
		llAction.enterValue("web_txt_SingleTopup", amount);
		

	}

	public void addFunds(Hashtable<String, String> hParams) throws Exception {

		// Read hparams ..fund code 1 & fund 1 % , fund 2 code and fund 2 app

		int noOfFunds = Integer.parseInt(hParams.get("SingleNoOfFunds"));

		for (int i = 1; i <= noOfFunds; i++) {

			llAction.clickElement("web_btn_singleAdd");
			Utils.sleep(2);
			Fund obj = new Fund();

			Hashtable<String, String> fundElementTag = ARTProperties.guiMap
					.get("web_tbl_SingleTopup");
			int rowId = i + 1;
			String temploc1 = fundElementTag.get(fundElementTag.keySet()
					.toArray()[0]) + "/tbody/tr[" + rowId + "]/td[2]/input[1]";
			WebElement Code = llAction.findElementByXpath(temploc1);
			obj.setFundCode(Code, hParams.get(FPMSConstants.SINGLEFUNDCODE + i));

			llAction.sendkeyStroke("web_tbl_SingleTopup", Keys.ENTER);

			Hashtable<String, String> apportionmentTag = ARTProperties.guiMap
					.get("web_tbl_SingleTopup");
			String temploc2 = apportionmentTag.get(apportionmentTag.keySet()
					.toArray()[0]) + "/tbody/tr[" + rowId + "]/td[3]/input[2]";
			WebElement apportionmentPer = llAction.findElementByXpath(temploc2);
			obj.setFundApportionmentPercentage(apportionmentPer,
					hParams.get(FPMSConstants.SINGLEAPPORTIONMENT + i));
			apportionmentPer.sendKeys(Keys.ENTER);
		}

	}
}
