package ge.fpms.main.bpc.csd;

import ge.fpms.main.actions.FPMS_Actions;

import java.util.Hashtable;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class PartyInformationChanges {
	
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	public PartyInformationChanges() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	/*
	 * Name: PartyInformationChanges_SearchSelectParty Purpose: Search And Select Party
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void PartyInformationChanges_SearchSelectParty
(Hashtable<String, String> hParams) throws Exception {
		try {
			
			String PartyName = hParams.get("PartyChangesName");
			String PartyID = hParams.get("PartyChangesID");
			
			llAction.selectMenuItem("NBD", "Search Party");
			llAction.waitUntilLoadingCompletes();
			
			llAction.enterValue("web_PartyChanges_txt_PartyName", PartyName);
			llAction.enterValue("web_PartyChanges_txt_IDNumber", PartyID);
			
			dashboard.setStepDetails("Enter Part Name and Party ID" ,
					"User should be able to enter Party Name and ID", "N/A");
			dashboard.writeResults();
			
			llAction.clickElement("web_PartyChanges_btn_SearchandEdit");
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Click on Search and Edit" ,
					"Application should display the search results", "N/A");
			dashboard.writeResults();
			
			int colPos = llAction.GetColumnPositionInTable("web_PartyChanges_tbl_PartyTable", "ID Number");
			int rowPos = llAction.GetRowPositionInTable("web_PartyChanges_tbl_PartyTable", PartyID, colPos);
			llAction.SelectRowInTable("web_PartyChanges_tbl_PartyTable", rowPos, colPos-6, "a");
			
			llAction.waitUntilLoadingCompletes();
			
			dashboard.setStepDetails("Click on any hyperlink in the search results for the corresponding party" ,
					"Application should navigate Create and Maintain Party Page", "N/A");
			dashboard.writeResults();
			
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	/*
	 * Name: PartyInformationChanges_ChangePartyRole Purpose: Change Party Role
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void PartyInformationChanges_ChangePartyRole(Hashtable<String, String> hParams) throws Exception {
		try {

			String PartyRole = hParams.get("PartyChangesRoles");
			
			llAction.move_to_element("web_PartyChanges_lst_PartyRoles");
			llAction.selectByVisibleText("web_PartyChanges_lst_PartyRoles", PartyRole);
			llAction.clickElement("web_PartyChanges_txt_PartyDOB");
			
			dashboard.setStepDetails("Update Party Role to "+PartyRole+"" ,
					"User should be able to update party role", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	/*
	 * Name: PartyInformationChanges_UpdatePartyInformation Purpose: Update Party Information
	 * Apportionment Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void PartyInformationChanges_UpdatePartyInformation(Hashtable<String, String> hParams) throws Exception {
		try {
			String DOB = hParams.get("PartyChangesDOB");
			String Gender = hParams.get("PartyChangesGender");
			String SmokeInd = hParams.get("PartySmokeInd");
			
			llAction.move_to_element("web_PartyChanges_txt_PartyDOB");
			llAction.enterValue("web_PartyChanges_txt_PartyDOB", DOB);
			
			dashboard.setStepDetails("Update Party DOB",
					"User should be able to update party DOB", "N/A");
			dashboard.writeResults();
			
			llAction.move_to_element("web_PartyChanges_lst_PartyGender");
			llAction.selectByVisibleText("web_PartyChanges_lst_PartyGender", Gender);
			
			dashboard.setStepDetails("Update Party Gender to "+Gender+"" ,
					"User should be able to update party gender", "N/A");
			dashboard.writeResults();
			
			PartyInformationChanges_ChangePartyRole(hParams);
			
			llAction.move_to_element("web_PartyChanges_lst_SmokerInd");
			llAction.selectByVisibleText("web_PartyChanges_lst_SmokerInd", SmokeInd);
			
			dashboard.setStepDetails("Update Party Smoker Ind to "+SmokeInd+"" ,
					"User should be able to update party Smoker Ind", "N/A");
			dashboard.writeResults();
			
			llAction.clickElement("web_PartyChanges_btn_Submit");
			llAction.waitUntilLoadingCompletes();
			if(llAction.isDisplayed("web_PartyChanges_btn_Continue", 8))
			{
				llAction.clickElement("web_PartyChanges_btn_Continue");
				llAction.waitUntilLoadingCompletes();
			}
			llAction.clickElement("web_PartyChanges_btn_Exit");
			llAction.waitUntilLoadingCompletes();
			
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

}
