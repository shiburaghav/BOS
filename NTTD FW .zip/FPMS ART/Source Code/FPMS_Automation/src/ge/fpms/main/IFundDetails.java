package ge.fpms.main;

import java.util.Hashtable;

public interface IFundDetails {

	public void addFundDetails(Hashtable<String, String> hParams) throws Exception;
}
