package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;

public class LinkGIRO {
	FPMS_Actions llAction;

	public void LinkGIROfromParty(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();

			llAction.selectMenuItem("Party", "Search Party");

			llAction.clickElementJs("web_radio_radioName2");

			llAction.enterValue("web_text_PolicyNo", hParams.get("PolicyNO"));

			llAction.sendkeyStroke("web_text_PolicyNo", Keys.ENTER);

			llAction.clickElementJs("web_Btn_Search&Edit");

			llAction.clickElementJs("web_Link_PartyRecNo");

			llAction.clickLinkByText(hParams.get("Tabs"));

			llAction.clickLinkByText(hParams.get("PolicyNO"));

			llAction.selectByIndex("web_lst_AccountRecNo", 1);

			llAction.clickElementJs("web_Btn_Submit_Party");
			llAction.switchtoChildWindow("notes");

			llAction.clickElementJs("web_Btn_Exit_Party");

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
}