package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.ILoading;
import ge.fpms.main.ILoadingType;
import ge.fpms.main.actions.FPMS_Actions;

public class LoadingComponent {

	private ILoadingType loadingtype;
	private ILoading loading;
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public LoadingComponent(ILoadingType Loadingtype, ILoading Loading) {

		if (this.loadingtype == null) {
			this.loadingtype = Loadingtype;
		}
		if (this.loading == null) {
			this.loading = Loading;
		}
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	
	

	public void addLoadingTypeInfo(Hashtable<String, String> hParams) throws Exception {
		goToLoading(hParams);
		loading.enterSpecificLoadingInfo(hParams);
		loadingtype.enterSpecificLoadingTypeInfo(hParams);
		dashboard.setStepDetails("Validate if Loading Information is Entered",
				"Loadinh Information should be enterd", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_uw_btn_loadingSubmit");
		llAction.waitUntilAlertisShown();
		llAction.acceptAlert();
		llAction.waitUntilLoadingCompletes();
	}

	public void goToLoading(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.clickElement("web_uw_btn_extraloading");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}
