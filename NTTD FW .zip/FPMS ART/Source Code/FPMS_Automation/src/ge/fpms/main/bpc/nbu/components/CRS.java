package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;

import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;

public class CRS {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	public CRS() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void fillCrsInfo(Hashtable<String, String> hParams) throws Exception {
		llAction = new FPMS_Actions();
		
		try {
			if(!StringUtils.isEmpty(hParams.get("TINNumber"))){
				llAction.selectByVisibleText("web_lst_CRS_Country", hParams.get("CRSCountry"));
				llAction.waitUntilLoadingCompletes();
				llAction.enterValue("web_txt_CRS_TINNum", hParams.get("TINNumber"));
				// llAction.enterValue("web_txt_CRS_TINStartDate", hParams.get("TINStartDate"));
	
				llAction.clickElement("web_btn_CRS_Apply");
				llAction.waitUntilLoadingCompletes();
				dashboard.setStepDetails("Enter CRS Information and apply", "CRS Information is added", "N/A");
				dashboard.writeResults();
	
				llAction.enterValue("web_txt_CRS_SelfCertDate", hParams.get("SelfCertDate"));
			}
		
			llAction.clickElement("web_btn_CRS_Submit");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception e) {
			throw new BPCException(e);
		}

	}
}
