package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class Payment extends BusinessComponent {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	
	public Payment() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void addPayment(Hashtable<String, String> hParams) throws Exception {
		try {
			String addButtonWidget = "web_btn_payment_Add";
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY,"");
			llAction.switchtoFrame(1);
			
			//if (llAction.isDisplayed(addButtonWidget, 5)) {

				String paymentAction = llAction.getElement(addButtonWidget).getAttribute("value");
				if(paymentAction.equalsIgnoreCase("ADD"))
				{
				
					llAction.clickElement(addButtonWidget);
					Utils.sleep(2);
					llAction.handleCertificateErrors();
					Utils.sleep(2);
	
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_PAYMENT_METHOD, "");
					llAction.maximizeWindow();
					Utils.sleep(3);
	
					String mode = hParams.get("PaymentMode");
					llAction.enterValue("web_txt_PaymentMode", mode);
					switch (mode) {
					case "C":
						dashboard.setStepDetails("Cash is selcted as payment mode ",
								"Cash should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
	
						break;
					case "CC":
						llAction.sendkeyStroke("web_txt_PaymentMode", Keys.ENTER);
						String creditcardno = hParams.get("CreditCardNo");
						String cardno[] = creditcardno.split("\\s");
						llAction.enterValue("web_txt_Credit_Card1", cardno[0]);
						llAction.enterValue("web_txt_Credit_Card2", cardno[1]);
						llAction.enterValue("web_txt_Credit_Card3", cardno[2]);
						llAction.enterValue("web_txt_Credit_Card4", cardno[3]);
	
						String CreditCardExpirydate = hParams.get("CreditCardExpiry");
						String expiry[] = CreditCardExpirydate.split("/");
						llAction.enterValue("web_txt_CreditCard_ExpiryMonth", expiry[0]);
						llAction.enterValue("web_txt_CreditCard_ExpiryYear", expiry[1]);
	
						dashboard.setStepDetails("Credit card is selcted as payment mode ",
								"Credit card details are entered", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
	
						break;
	
					case "G":
						dashboard.setStepDetails("GIRO is selcted as payment mode ",
								"GIRO should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "OA":
						llAction.sendkeyStroke("web_txt_PaymentMode", Keys.ENTER);
						String BankCode = hParams.get("BankCode");
						String BankAccountNo = hParams.get("BankAccountNo");
	
						llAction.enterValue("web_payment_txt_OA_BankCode", BankCode);
						llAction.enterValue("web_payment_txt_OA_BankAccountNo", BankAccountNo);
						dashboard.setStepDetails("OA is selcted as payment mode ",
								"OA should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "SA":
						dashboard.setStepDetails("SA is selcted as payment mode ",
								"SA should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "MEDI":
						dashboard.setStepDetails("MEDI is selcted as payment mode ",
								"MEDI should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "MDCC":
						llAction.sendkeyStroke("web_txt_PaymentMode", Keys.ENTER);
	
						String mDCCNo = hParams.get("CPFMediCreditCardNo");
						String mDCCCardNo[] = mDCCNo.split("\\s");
	
						llAction.enterValue("web_payment_txt_MDCC_Credit_Card1", mDCCCardNo[0]);
						llAction.enterValue("web_payment_txt_MDCC_Credit_Card2", mDCCCardNo[1]);
						llAction.enterValue("web_payment_txt_MDCC_Credit_Card3", mDCCCardNo[2]);
						llAction.enterValue("web_payment_txt_MDCC_Credit_Card4", mDCCCardNo[3]);
	
						String mDCCExpirydate = hParams.get("CPFMediCreditCardExpiryDate");
						String mDCCExpiry[] = mDCCExpirydate.split("/");
						llAction.enterValue("web_payment_txt_MDCC_CreditCard_ExpiryMM", mDCCExpiry[0]);
						llAction.enterValue("web_payment_txt_MDCC_CreditCard_ExpiryYY", mDCCExpiry[1]);
	
						dashboard.setStepDetails("MDCC is selcted as payment mode ",
								"MDCC should be accepted as payment mode", "N/A");
						dashboard.writeResults();
	
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "MDG":
						break;
					case "SRS":
						llAction.sendkeyStroke("web_txt_PaymentMode", Keys.ENTER);
						llAction.enterValue("web_payment_txt_OA_BankCode", hParams.get("SRSBankCode"));
						llAction.enterValue("web_payment_txt_OA_BankAccountNo", hParams.get("SRSBankAccountNo"));
						dashboard.setStepDetails("SRS is selcted as payment mode ",
								"SRS should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						
						break;
					}
				}
		//	}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}
	

	public void reEnterPayment(Hashtable<String, String> hParams) throws Exception {
		try {
						
					llAction.clickElementJs("web_lnk_PaymentMethod");
					Utils.sleep(2);
					llAction.handleCertificateErrors();
					Utils.sleep(2);
	
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_PAYMENT_METHOD, "");
					llAction.maximizeWindow();
					Utils.sleep(3);
	
					String mode = hParams.get("PaymentMode1");
					llAction.enterValue("web_txt_PaymentMode", mode);
					switch (mode) {
					case "C":
						dashboard.setStepDetails("Cash is selcted as payment mode ",
								"Cash should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
	
						break;
					case "CC":
						llAction.sendkeyStroke("web_txt_PaymentMode", Keys.ENTER);
						String creditcardno = hParams.get("CreditCardNo1");
						String cardno[] = creditcardno.split("\\s");
						llAction.enterValue("web_txt_Credit_Card1", cardno[0]);
						llAction.enterValue("web_txt_Credit_Card2", cardno[1]);
						llAction.enterValue("web_txt_Credit_Card3", cardno[2]);
						llAction.enterValue("web_txt_Credit_Card4", cardno[3]);
	
						String CreditCardExpirydate = hParams.get("CreditCardExpiry1");
						String expiry[] = CreditCardExpirydate.split("/");
						llAction.enterValue("web_txt_CreditCard_ExpiryMonth", expiry[0]);
						llAction.enterValue("web_txt_CreditCard_ExpiryYear", expiry[1]);
	
						dashboard.setStepDetails("Credit card is selcted as payment mode ",
								"Credit card details are entered", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
	
						break;
	
					case "G":
						dashboard.setStepDetails("GIRO is selcted as payment mode ",
								"GIRO should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "OA":
						llAction.sendkeyStroke("web_txt_PaymentMode", Keys.ENTER);
						String BankCode = hParams.get("BankCode1");
						String BankAccountNo = hParams.get("BankAccountNo1");
	
						llAction.enterValue("web_payment_txt_OA_BankCode", BankCode);
						llAction.enterValue("web_payment_txt_OA_BankAccountNo", BankAccountNo);
						dashboard.setStepDetails("OA is selcted as payment mode ",
								"OA should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "SA":
						dashboard.setStepDetails("SA is selcted as payment mode ",
								"SA should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "MEDI":
						dashboard.setStepDetails("MEDI is selcted as payment mode ",
								"MEDI should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "MDCC":
						llAction.sendkeyStroke("web_txt_PaymentMode", Keys.ENTER);
	
						String mDCCNo = hParams.get("CPFMediCreditCardNo1");
						String mDCCCardNo[] = mDCCNo.split("\\s");
	
						llAction.enterValue("web_payment_txt_MDCC_Credit_Card1", mDCCCardNo[0]);
						llAction.enterValue("web_payment_txt_MDCC_Credit_Card2", mDCCCardNo[1]);
						llAction.enterValue("web_payment_txt_MDCC_Credit_Card3", mDCCCardNo[2]);
						llAction.enterValue("web_payment_txt_MDCC_Credit_Card4", mDCCCardNo[3]);
	
						String mDCCExpirydate = hParams.get("CPFMediCreditCardExpiryDate");
						String mDCCExpiry[] = mDCCExpirydate.split("/");
						llAction.enterValue("web_payment_txt_MDCC_CreditCard_ExpiryMM", mDCCExpiry[0]);
						llAction.enterValue("web_payment_txt_MDCC_CreditCard_ExpiryYY", mDCCExpiry[1]);
	
						dashboard.setStepDetails("MDCC is selcted as payment mode ",
								"MDCC should be accepted as payment mode", "N/A");
						dashboard.writeResults();
	
						llAction.clickElement("web_btn_payment_CSubmit");
						break;
					case "MDG":
						break;
					case "SRS":
						llAction.sendkeyStroke("web_txt_PaymentMode", Keys.ENTER);
						llAction.enterValue("web_payment_txt_OA_BankCode", hParams.get("SRSBankCode1"));
						llAction.enterValue("web_payment_txt_OA_BankAccountNo", hParams.get("SRSBankAccountNo1"));
						dashboard.setStepDetails("SRS is selcted as payment mode ",
								"SRS should be accepted as payment mode", "N/A");
						dashboard.writeResults();
						llAction.clickElement("web_btn_payment_CSubmit");
						
						break;
					}
				
		//	}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}
	

}


