package ge.fpms.main.bpc.csd;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class AdhocSinglePremiumTopup {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	public AdhocSinglePremiumTopup() {
		dashboard = DashboardHandler.getInstance();
	}
	public void AddTopupInformation(Hashtable<String, String> hParams)
			throws Exception {	
		int colPos;
		int rowPos;
		try {
			llAction = new FPMS_Actions();
			llAction.waitUntilElementPresent("web_txt_ILPTopUp_ValidityDate");
			ChangeRPApportCaptureBeforeOrAfterChange("BeforeChange");
			dashboard.setStepDetails("Enter Application Details","Application details should be entered","N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_ILPTopUp_ValidityDate",hParams.get("Validitydate") );
			llAction.sendkeyStroke("web_txt_ILPTopUp_ValidityDate", Keys.ENTER);
			colPos = llAction.GetColumnPositionInTable("web_tbl_Benefit_Infor_ElementKey", "Benefit Name");
			rowPos = llAction.GetRowPositionInTable("web_tbl_Benefit_Infor_ElementKey", hParams.get("BenefitCode"), colPos);
			llAction.SelectRowInTable("web_tbl_Benefit_Infor_ElementKey", rowPos, colPos-2,"input");
			dashboard.setStepDetails("Select Option for Benefit Information Before Change","System should accept the selected details","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_NewAppReg__ILPTopUp_TopUp");
			String war = hParams.get("WarningError Message");
                        String topUpWar = hParams.get("WarningErrorMessage-TopUp");
			llAction.waitUntilLoadingCompletes();

			if (llAction.isDisplayed("web_btn_continue", 8)) 
			{
				if ((topUpWar!= null)) {
					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg",topUpWar);
				}
				llAction.clickElement("web_btn_continue");
			}
			Utils.sleep(8);
			llAction.enterValue("web_txt_TopUpInfo_TopUpAmount", hParams.get("TopUpAmount"));
			dashboard.setStepDetails("Enter Top Up amount","System should accept the input details","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_TopUpInfo_Radio_Bypercentage");
			for (int i = 1; i <= Integer.parseInt(hParams.get("NoOfTopUp")); i++) 
			{
				llAction.enterValue("web_txt_TopUpInfo_TopUpFund", hParams.get("TopUpFund"+i+""));
				llAction.sendkeyStroke("web_txt_TopUpInfo_TopUpFund", Keys.ENTER);
				llAction.clickElement("web_btnt_TopUpInfo_Add");
				colPos = 0;
				rowPos = 0;
				switch((hParams.get("Fundallocationby").toUpperCase()))
				{
				case "AMOUNT":
					Utils.sleep(4);
					llAction.checkBox_Check("web_btnt_TopUpInfo_Radio_ByAmount");
					colPos = llAction.GetColumnPositionInTable("web_txt_topinfo_fund_table", "Amount Apportionment");
					llAction.enterTextInTable("web_txt_topinfo_fund_table", i+1, colPos, hParams.get("AmountApportionment"+i+"" ),"/*/input");
					break;
				case "PERCENTAGE":
					Utils.sleep(4);
					colPos = llAction.GetColumnPositionInTable("web_txt_topinfo_fund_table", "Percentage Apportionment");
					llAction.enterTextInTable("web_txt_topinfo_fund_table", i+1, colPos, hParams.get("PercentageApportionment"+i+""),"/*/input");
					break;
				}
			}
			dashboard.setStepDetails("Enter Amount Apportionment (the amount should be equal to Top Up amount)","Sytem should accept the input details.","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_TopUpInfo_submit");
			
			ChangeRPApportCaptureBeforeOrAfterChange("Afterchange");
			llAction.clickElement("web_btnt_TopUpInfo_submit");
			if (llAction.isDisplayed("web_btn_continue", 8)) 
			{
				if ((war!= null)) {
					String warningMsg = llAction.getText("web_txt_warningmsg");
					FullSurrenderValidateWarningMessages(warningMsg,war);
					llAction.clickElement("web_btn_continue");
				}
				else
				{
					llAction.clickElement("web_btn_continue");
				}
			}
			CSDHelper.getInstance().endOfTransaction();
		}
		catch (Exception ex) 
		{
			throw new BPCException(ex);
		}
	}

	public void adhocErrorValidationAtSubmit(Hashtable<String, String> hParams)
			throws Exception {
		int colPos;
		int rowPos;
		try {
			llAction = new FPMS_Actions();
			llAction.waitUntilElementPresent("web_txt_ILPTopUp_ValidityDate");
			ChangeRPApportCaptureBeforeOrAfterChange("BeforeChange");
			dashboard.setStepDetails("Enter Application Details","Application details should be entered","N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_ILPTopUp_ValidityDate",hParams.get("Validitydate") );
			llAction.sendkeyStroke("web_txt_ILPTopUp_ValidityDate", Keys.ENTER);
			colPos = llAction.GetColumnPositionInTable("web_tbl_Benefit_Infor_ElementKeyerror", "Benefit Name");
			rowPos = llAction.GetRowPositionInTable("web_tbl_Benefit_Infor_ElementKeyerror", hParams.get("BenefitCode"), colPos);
			llAction.SelectRowInTable("web_tbl_Benefit_Infor_ElementKeyerror", rowPos, colPos-2,"input");
			dashboard.setStepDetails("Select Option for Benefit Information Before Change","System should accept the selected details","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_NewAppReg__ILPTopUp_TopUp");
			String war = hParams.get("WarningError Message");
			llAction.waitUntilLoadingCompletes();

			if (llAction.isDisplayed("web_btn_continue", 8)) 
			{
				if ((war!= null)) {
					String warningMsg = llAction.getText("web_txt_warningmsg");
					FullSurrenderValidateWarningMessages(warningMsg,war);
					llAction.clickElement("web_btn_continue");
				}
				else
				{
					llAction.clickElement("web_btn_continue");
				}
			}
			Utils.sleep(8);
			llAction.enterValue("web_txt_TopUpInfo_TopUpAmount", hParams.get("TopUpAmount"));
			dashboard.setStepDetails("Enter Top Up amount","System should accept the input details","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_TopUpInfo_Radio_Bypercentage");
			for (int i = 1; i <= Integer.parseInt(hParams.get("NoOfTopUp")); i++) 
			{
				llAction.enterValue("web_txt_TopUpInfo_TopUpFund", hParams.get("TopUpFund"+i+""));
				llAction.sendkeyStroke("web_txt_TopUpInfo_TopUpFund", Keys.ENTER);
				llAction.clickElement("web_btnt_TopUpInfo_Add");
				colPos = 0;
				rowPos = 0;
				switch((hParams.get("Fundallocationby").toUpperCase()))
				{
				case "AMOUNT":
					Utils.sleep(4);
					llAction.checkBox_Check("web_btnt_TopUpInfo_Radio_ByAmount");
					colPos = llAction.GetColumnPositionInTable("web_txt_topinfo_fund_table", "Amount Apportionment");
					llAction.enterTextInTable("web_txt_topinfo_fund_table", i+1, colPos, hParams.get("AmountApportionment"+i+"" ),"/*/input");
					break;
				case "PERCENTAGE":
					Utils.sleep(4);
					colPos = llAction.GetColumnPositionInTable("web_txt_topinfo_fund_table", "Percentage Apportionment");
					llAction.enterTextInTable("web_txt_topinfo_fund_table", i+1, colPos, hParams.get("PercentageApportionment"+i+""),"/*/input");
					break;
				}
			}
			llAction.clickElement("web_btnt_TopUpInfo_submit");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().validateWarningMessages("web_txt_AdhocawarrningErrmsg", hParams.get("WarningErrorMessage-ILPTopUpSubmit"));
		}
		catch (Exception ex) 
		{
			throw new BPCException(ex);
		}
	}
	
	public void adhocErrorValidationAtTopup(Hashtable<String, String> hParams)
			throws Exception {
		AdhocSinglePremiumTopup topup = new AdhocSinglePremiumTopup();
		int colPos;
		int rowPos;
		try {
			llAction = new FPMS_Actions();
			llAction.waitUntilElementPresent("web_txt_ILPTopUp_ValidityDate");
			ChangeRPApportCaptureBeforeOrAfterChange("BeforeChange");
			dashboard.setStepDetails("Enter Application Details","Application details should be entered","N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_ILPTopUp_ValidityDate",hParams.get("Validitydate") );
			llAction.sendkeyStroke("web_txt_ILPTopUp_ValidityDate", Keys.ENTER);
			colPos = llAction.GetColumnPositionInTable("web_tbl_Benefit_Infor_ElementKeyerror", "Benefit Name");
			rowPos = llAction.GetRowPositionInTable("web_tbl_Benefit_Infor_ElementKeyerror", hParams.get("BenefitCode"), colPos);
			llAction.SelectRowInTable("web_tbl_Benefit_Infor_ElementKeyerror", rowPos, colPos-2,"input");
			dashboard.setStepDetails("Select Option for Benefit Information Before Change","System should accept the selected details","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_NewAppReg__ILPTopUp_TopUp");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 8)) 
			{
				llAction.clickElement("web_btn_continue");
				
			}
			Utils.sleep(8);
			llAction.enterValue("web_txt_TopUpInfo_TopUpAmount", hParams.get("TopUpAmount"));
			dashboard.setStepDetails("Enter Top Up amount","System should accept the input details","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_TopUpInfo_Radio_Bypercentage");
			for (int i = 1; i <= Integer.parseInt(hParams.get("NoOfTopUp")); i++) 
			{
				llAction.enterValue("web_txt_TopUpInfo_TopUpFund", hParams.get("TopUpFund"+i+""));
				llAction.sendkeyStroke("web_txt_TopUpInfo_TopUpFund", Keys.ENTER);
				llAction.clickElement("web_btnt_TopUpInfo_Add");
				if (llAction.isAlertDisplayed()) {
					String errormsg = llAction.getAlertText();
					topup.FullSurrenderValidateWarningMessages(errormsg,hParams.get("WarningErrorMessage-Add"));
					llAction.dismissAlert();
					break;
				}else {
					colPos = 0;
					rowPos = 0;
					switch((hParams.get("Fundallocationby").toUpperCase()))
					{
					case "AMOUNT":
						Utils.sleep(4);
						llAction.checkBox_Check("web_btnt_TopUpInfo_Radio_ByAmount");
						colPos = llAction.GetColumnPositionInTable("web_txt_topinfo_fund_table", "Amount Apportionment");
						llAction.enterTextInTable("web_txt_topinfo_fund_table", i+1, colPos, hParams.get("AmountApportionment"+i+"" ),"/*/input");
						break;
					case "PERCENTAGE":
						Utils.sleep(4);
						colPos = llAction.GetColumnPositionInTable("web_txt_topinfo_fund_table", "Percentage Apportionment");
						llAction.enterTextInTable("web_txt_topinfo_fund_table", i+1, colPos, hParams.get("PercentageApportionment"+i+""),"/*/input");
						break;
					}
				}
			}
		}
		catch (Exception ex) 
		{
			throw new BPCException(ex);
		}
	}
	
	public void adhocErrorValidationAtILPTopUpscreen(Hashtable<String, String> hParams)
			throws Exception {
		AdhocSinglePremiumTopup topup = new AdhocSinglePremiumTopup();
		int colPos;
		int rowPos;
		try {
			llAction = new FPMS_Actions();
			llAction.waitUntilElementPresent("web_txt_ILPTopUp_ValidityDate");
			ChangeRPApportCaptureBeforeOrAfterChange("BeforeChange");
			dashboard.setStepDetails("Enter Application Details","Application details should be entered","N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_ILPTopUp_ValidityDate",hParams.get("Validitydate") );
			llAction.sendkeyStroke("web_txt_ILPTopUp_ValidityDate", Keys.ENTER);
			colPos = llAction.GetColumnPositionInTable("web_tbl_Benefit_Infor_ElementKeyerror", "Benefit Name");
			rowPos = llAction.GetRowPositionInTable("web_tbl_Benefit_Infor_ElementKeyerror", hParams.get("BenefitCode"), colPos);
			llAction.SelectRowInTable("web_tbl_Benefit_Infor_ElementKeyerror", rowPos, colPos-2,"input");
			dashboard.setStepDetails("Select Option for Benefit Information Before Change","System should accept the selected details","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_NewAppReg__ILPTopUp_TopUp");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().validateWarningMessages("web_txt_AdhocawarrningErrmsg", hParams.get("WarningErrorMessage-TopUp"));
			
		}
		catch (Exception ex) 
		{
			throw new BPCException(ex);
		}
		
	}
	
	public void  validatingErrorAtEnterinformationClick(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction = new FPMS_Actions();
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().validateWarningMessages("web_txt_AdhocawarrningErrmsg", hParams.get("WarningErrorMessage-EnterInformation"));
		}	
		catch (Exception ex) 
		{
			throw new BPCException(ex);
		}
	}

	public void ChangeRPApportCaptureBeforeOrAfterChange(String ActionType) throws Exception
	{

		try {
			switch(ActionType.toUpperCase())
			{
			case "BEFORECHANGE":
				dashboard.setStepDetails("Before Policy alterationitem top up" , "Status should Pending Data Entry", "N/A");
				dashboard.writeResults();
				break;
			case "AFTERCHANGE":
				dashboard.setStepDetails("After Policy alterationitem top up added" , "Status should completed", "N/A");
				dashboard.writeResults();
				break;
			}
		}
		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void FullSurrenderValidateWarningMessages(String warningMsg, String message) throws Exception
	{	
		if (warningMsg.contains(message)) { // compare warning messages
			dashboard.setStepDetails(message + "Warning message should be displayed","Warning message should is displayed ", "N/A");
			dashboard.writeResults();
		} else {

			dashboard.writeResults();
			throw new Exception(""+warningMsg+"is not maching with"+warningMsg+"");

		}
	}

	public void adhocSPTopupErrorValidation(Hashtable<String, String> hParams)
			throws Exception {
		int colPos;
		int rowPos;
		try {
			llAction = new FPMS_Actions();
			String applicationStatus = hParams.get("ApplicationStatus"); /* Get expected warning message from Test Data */
			String topupInfoSubmit = hParams.get("WarningErrorMessage-TopUpinformationSubmit");
			String topUpWar = hParams.get("WarningErrorMessage-TopUp");
			llAction.waitUntilElementPresent("web_txt_ILPTopUp_ValidityDate");
			CSDHelper.getInstance().captureChange("adhocErrorValidationAtSubmit", "BeforeChange");
			dashboard.setStepDetails("Enter Application Details","Application details should be entered","N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_ILPTopUp_ValidityDate",hParams.get("Validitydate") );
			llAction.sendkeyStroke("web_txt_ILPTopUp_ValidityDate", Keys.ENTER);
			colPos = llAction.GetColumnPositionInTable("web_tbl_Benefit_Infor_ElementKey", "Benefit Name");
			rowPos = llAction.GetRowPositionInTable("web_tbl_Benefit_Infor_ElementKey", hParams.get("BenefitCode"), colPos);
			llAction.SelectRowInTable("web_tbl_Benefit_Infor_ElementKey", rowPos, colPos-2,"input");
			dashboard.setStepDetails("Select Option for Benefit Information Before Change","System should accept the selected details","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_NewAppReg__ILPTopUp_TopUp");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) 
			{
				if (topUpWar!= null && topUpWar!="") {
					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg",topUpWar);
				}
				llAction.clickElement("web_btn_continue");
			}
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_TopUpInfo_TopUpAmount", hParams.get("TopUpAmount"));
			dashboard.setStepDetails("Enter Top Up amount","System should accept the input details","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_TopUpInfo_Radio_Bypercentage");
			for (int i = 1; i <= Integer.parseInt(hParams.get("NoOfTopUp")); i++) 
			{
				llAction.enterValue("web_txt_TopUpInfo_TopUpFund", hParams.get("TopUpFund"+i+""));
				llAction.sendkeyStroke("web_txt_TopUpInfo_TopUpFund", Keys.ENTER);
				llAction.clickElement("web_btnt_TopUpInfo_Add");
				colPos = 0;
				rowPos = 0;
				switch((hParams.get("Fundallocationby").toUpperCase()))
				{
				case "AMOUNT":
					Utils.sleep(4);
					llAction.checkBox_Check("web_btnt_TopUpInfo_Radio_ByAmount");
					colPos = llAction.GetColumnPositionInTable("web_txt_topinfo_fund_table", "Amount Apportionment");
					llAction.enterTextInTable("web_txt_topinfo_fund_table", i+1, colPos, hParams.get("AmountApportionment"+i+"" ),"/*/input");
					break;
				case "PERCENTAGE":
					Utils.sleep(4);
					colPos = llAction.GetColumnPositionInTable("web_txt_topinfo_fund_table", "Percentage Apportionment");
					llAction.enterTextInTable("web_txt_topinfo_fund_table", i+1, colPos, hParams.get("PercentageApportionment"+i+""),"/*/input");
					break;
				}
			}
			llAction.clickElement("web_btnt_TopUpInfo_submit");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) 
			{
				if(topupInfoSubmit!=null && topupInfoSubmit!="")
				{
					CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg", topupInfoSubmit);
				}
				llAction.clickElement("web_btn_continue");
			}
			dashboard.setStepDetails("Click on Submit button","System should display ILP Top Up screen and show record in Benefit Information After Change","N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btnt_TopUpInfo_submit");
			llAction.waitUntilLoadingCompletes();
			if(llAction.isDisplayed("web_btn_continue", 5)) 
				llAction.clickElement("web_btn_continue");
			CSDHelper.getInstance().endOfTransaction();
		}
		catch (Exception ex) 
		{
			throw new BPCException(ex);
		}
	}

}
