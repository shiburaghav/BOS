package ge.fpms.main.bpc.csd;
import java.util.Hashtable;
import org.openqa.selenium.Keys;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.*;

public class ILPIncludeUnitDeductionRider {

	/*
	 * Name: ILPIncludeUnitDeductionRider Purpose: Navigate to CS module from the
	 * Main Page and Include Unit Deduction Rider for a policy Parameters :
	 * Parameter Hash table Return Value: NA Exception: BPCException
	 * 
	 * @author: Sahil Singh 0n 17/12/2018
	 */


	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public ILPIncludeUnitDeductionRider() {
		dashboard = DashboardHandler.getInstance();
		llAction = new FPMS_Actions();
	}

	public void includeUnitDeductionRider(Hashtable<String, String> hParams) throws Exception {

		try {
			llAction.waitUntilElementPresent("web_tbl_BenefitAlteration");
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			dashboard.writeResults();
			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_BenefitAlteration", "Benefit");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_BenefitAlteration",
					hParams.get("BenefitCode"), BenefitalterCol);
			llAction.SelectRowInTable("web_tbl_BenefitAlteration", BenefitalterRow, BenefitalterCol - 2, "input");
			dashboard.setStepDetails("Benefit Alteration Item before change is chosen",
					"Benefit Alteration item should be selected", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_IncludeUntRider");
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage-IncludeUnitRider") != null
						&& hParams.get("WarningErrorMessage-IncludeUnitRider") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage-IncludeUnitRider"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}

			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_BenefitType", hParams.get("BenefitType"));
			dashboard.setStepDetails("Benefit Type entered", "Benefit Type should be entered successfully", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Benefit detail before entering any value ",
					"Benefit detail page should be shown successfully", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_txt_CoverageYr", hParams.get("Yearageofcoverageterm"));
			llAction.enterValue("web_txt_PremiumTrm", hParams.get("Yearageofpremiumterm"));
			llAction.enterValue("web_txt_IniPremiumFreq", hParams.get("InitialPremiumfrequency"));
			llAction.enterValue("web_txt_PcalMthd", hParams.get("PremiumCalculatingmethod"));
			llAction.enterValue("web_txt_SumAssured", hParams.get("InitialSumassuredRider"));
			llAction.enterValue("web_txt_MarketingDiscount", hParams.get("MarketingDiscountCode"));
			dashboard.setStepDetails("Benefit detail after entering the values ",
					"Benefit detail page should be shown successfully with new values", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_BenefitSubmit");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage-Submit") != null
						&& hParams.get("WarningErrorMessage-Submit") != "") {
					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage-Submit"));

					llAction.clickElement("web_btn_ContinueRP");
					llAction.waitUntilLoadingCompletes();
				} else {
					llAction.clickElement("web_btn_ContinueRP");
					llAction.waitUntilLoadingCompletes();
				}
			}
			CSDHelper.getInstance().endOfTransaction();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void validateIncludeUnitDeductionRider(Hashtable<String, String> hParams) throws Exception {

		try {

			llAction.waitUntilElementPresent("web_tbl_BenefitAlteration");
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			dashboard.writeResults();
			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_BenefitAlteration", "Benefit");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_BenefitAlteration",
					hParams.get("BenefitCode"), BenefitalterCol);
			llAction.SelectRowInTable("web_tbl_BenefitAlteration", BenefitalterRow, BenefitalterCol - 2, "input");
			dashboard.setStepDetails("Benefit Alteration Item before change is chosen",
					"Benefit Alteration item should be selected", "N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_IncludeUntRider");
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage-IncludeUnitRider") != null
						&& hParams.get("WarningErrorMessage-IncludeUnitRider") != "") {

					CSDHelper.getInstance().validateWarningMessages("web_txt_allwarning_msg",
							hParams.get("WarningErrorMessage-IncludeUnitRider"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}

			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_BenefitType", hParams.get("BenefitType"));
			dashboard.setStepDetails("Benefit Type entered", "Benefit Type should be entered successfully", "N/A");
			dashboard.writeResults();
			llAction.sendkeyStroke("web_txt_BenefitType", Keys.ENTER);
			llAction.waitUntilLoadingCompletes();
			if (hParams.get("WarningErrorMessage-BenefitType") != null
					&& hParams.get("WarningErrorMessage-BenefitType") != "") {

				CSDHelper.getInstance().validateWarningMessages("web_tbl_warning_msg",
						hParams.get("WarningErrorMessage-BenefitType"));

			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}
}
