package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.Hashtable;

public interface RiderFundDetails {

	public void setTopupAmount(String amount) throws Exception;

	public void addFunds(Hashtable<String, String> hParams) throws Exception;

}
