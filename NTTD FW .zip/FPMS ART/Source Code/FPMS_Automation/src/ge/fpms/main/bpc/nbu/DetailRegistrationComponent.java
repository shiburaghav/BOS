package ge.fpms.main.bpc.nbu;

import java.util.Hashtable;
import java.util.logging.Level;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import com.nttdata.framework.exceptions.NegativeScenarioException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.components.BenefitsComponent;
import ge.fpms.main.bpc.nbu.components.Payment;

public class DetailRegistrationComponent extends BusinessComponent {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public DetailRegistrationComponent() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}

	public void DetailRegistration(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("NBD", "Detail Registration");

			searchPolicy(hParams.get("PolicyNo"), "web_detail_tbl_PolicyList", "web_txt_DetailReg_PolicyNumber");

			llAction.switchtoFrame(1);

			updateProposerInformation(hParams);
			Utils.sleep(3);
			//	llAction.sleep(6);
			//llAction.switchtoDefaultWindow();

			updateLAInformation(hParams);

			Payment payment = new Payment();
			payment.addPayment(hParams);

			// addDirectCreditInformation(hParams);

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);

			BenefitsComponent benefitsComp = new BenefitsComponent();
			benefitsComp.addBenefits(hParams);
			llAction.enterValue("web_txt_CommencementDate", hParams.get("CommencementDate"));
			if (!StringUtils.isEmpty(hParams.get("LADiscountType"))) {
				llAction.enterValue("web_txt_discountType", hParams.get("LADiscountType"));
				llAction.sendkeyStroke("web_txt_discountType", Keys.ENTER);
			}
			llAction.enterValue("web_dr_txt_verifcation", hParams.get("Verification_Ind"));
			dashboard.setStepDetails("Validate if Yes\\No is Entered for Verfication", "Value should be entered as per testdata", hParams.get("Verification_Ind"));
			dashboard.writeResults();
			FPMSManager.getInstance().getEvtHandler().setCurrentContext(FPMSConstants.DETAILREG_SUBMIT_CXT);
			llAction.clickElement("web_btn_Detail_Reg_Submit");
			llAction.acceptAlert();
			Utils.sleep(2);
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			FPMSManager.getInstance().getEvtHandler().setCurrentContext(null);
			llAction.clickElement("web_btn_Detail_Reg_Exit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Submit and Exit", "User should be navigated to Home Page","");
			dashboard.writeResults();
			/*
			 * if (hParams.get("Verification_Ind").equalsIgnoreCase("Y")) {
			 * SubmitForVerification(hParams); }
			 */
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	private void updateProposerInformation(Hashtable<String, String> hParams) throws Exception{

		addAdress(hParams);

		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
		llAction.switchtoFrame(1);
		llAction.clickElement("web_lnk_CRS_ViewEdit_Proposer");
		llAction.handleCertificateErrors();
		addCrsInfo(hParams);
	}
	private void addProposerInformation(Hashtable<String, String> hParams) throws Exception {

		llAction.clickElement("web_lnk_Poposer_ProposerName");

		llAction.handleCertificateErrors();
		String windowName = FPMSConstants.WINDOW_TITLE_IDV_PROPOSER_INFOMATION;
		if(isOrganization(hParams.get("CompanyInd"))){
			windowName =FPMSConstants.WINDOW_TITLE_COMPANY_PROPOSAL_INFORMATION;
		}
		llAction.switchtoChildWindow(windowName, "");
		llAction.maximizeWindow();

		dashboard.setStepDetails("Enter Proposer information ",
				"The required information of Proposer should be entered. ", "N/A");
		dashboard.writeResults();

		llAction.clickElement("web_btn_mySubmit");

		Utils.sleep(5);

		llAction.closeWindow(windowName);

	}

	public void addCrsInfo(Hashtable<String, String> hParams, boolean isProposer) throws Exception {
		try {
			//if(!StringUtils.isEmpty(hParams.get("SelfCertDate"))){

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			String elementName = isProposer ? "web_lnk_CRS_ViewEdit_Proposer":"web_lnk_CRS_ViewEdit_LA";
			llAction.clickElement(elementName);
			llAction.handleCertificateErrors();

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CRS, "");
			llAction.maximizeWindow();
			Utils.sleep(2);
			if(!llAction.isDisplayed("web_txt_norecords"))
			{
				llAction.clickElement("web_radio_crsSelector");
				//llAction.enterValue("web_txt_CRS_SelfCertDate", hParams.get("SelfCertDate"));
				dashboard.setStepDetails("Enter CRS information ",
						"The required information of CRS should be entered. ", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_addr_btn_submit");
			}else{
				llAction.clickElement("web_btn_crs_exit");
			}


		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	public void addCrsInfo(Hashtable<String, String> hParams) throws Exception {
		try {

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CRS, "");
			llAction.maximizeWindow();
			Utils.sleep(2);
			if (!llAction.isDisplayed("web_txt_norecords")) {
				llAction.clickElement("web_radio_crsSelector");
				dashboard.setStepDetails("Enter CRS information ",
						"The required information of CRS should be entered. ",
						"N/A");
				dashboard.writeResults();
				llAction.clickElement("web_addr_btn_submit");
			} else {
				llAction.clickElement("web_btn_crs_exit");
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	public void addLAInformation(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			llAction.clickElementJs("web_lnk_lifeAssuredName");

			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_LA_INFORMATION, "");
			llAction.maximizeWindow();
			Utils.sleep(3);

			dashboard.setStepDetails("Enter Life insured information ",
					"The required information of life insured should be entered. ", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_la_Submit");
			Utils.sleep(5);
			if (llAction.isDisplayed("web_btn_continue", 5)){
				llAction.clickElement("web_btn_continue");
			}

		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	public void addDirectCreditInformation(Hashtable<String, String> hParams) throws Exception {

		try {

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);

			llAction.clickElement("web_lnk_DirectCredit");

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DIRECT_CREDIT, "");
			llAction.maximizeWindow();

			llAction.enterValue("web_txt_BankAcNo", "29356000");
			llAction.enterValue("web_txt_BranchCode", "1980");
			dashboard.setStepDetails("Enter Direct Credit", "Direct Credit Information has been entered. ",
					"N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_Save");

		} catch (Exception ex) {
			DashboardProperties.gBPCStatus = 1; // set the business component
			// status to fail
			//LOGGER.log(Level.SEVERE,
			//		"Exception occured while calling Detail Reg method \n Exception is " + ex.getMessage());
			throw new BPCException("");
		}

	}
	@Deprecated
	public void addBenefits(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			llAction.clickElementJs("web_link_Benefit");

			llAction.handleCertificateErrors();

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_PRODUCT_INFO, "");

			llAction.maximizeWindow();

			// llAction.returnWebElement(webElementKey)

			llAction.enterValue("web_txt_CoverageYr", hParams.get("CoverageTerm"));
			llAction.enterValue("web_txt_PremiumTrm", hParams.get("PremiumTerm"));

			// llAction.enterValue("web_txt_MarketingDiscount", "");

			String s = llAction.getAttribute("web_txt_vl_PcalMthd", "value");
			if (s.equalsIgnoreCase("1")) {
				llAction.enterValue("web_txt_SumAssured", hParams.get("BasicSumAssured"));
			} else {
				llAction.enterValue("web_txt_PremiumAmt", hParams.get("PremiumAmount"));
			}
			dashboard.setStepDetails("Enter Benefit Details", "Benefit Details Information has been entered. ",
					"N/A");
			dashboard.writeResults();

			llAction.clickElement("web_btn_saveBn");

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void addAdress(Hashtable<String, String> hParams) throws Exception {
		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
		llAction.switchtoFrame(1);
		String addressLnk = "web_addr_lnk_proposer";
		String s = llAction.getText(addressLnk);
		if (s.equalsIgnoreCase("N")) {
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			llAction.scrollToElement(llAction.getElement("web_addr_table_proposer"));
			Utils.sleep(3);
			llAction.clickElementJs(addressLnk);
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CORRESPONDENCE_ADDRESS, "");
			llAction.maximizeWindow();
			llAction.clickElement("web_Radio_AddressRecNumber");
			// llAction.selectByVisibleText("web_addr_lst_CountryofAddress",
			// hParams.get("CountryCode"));
			// llAction.clickElement("web_addr_btn_apply");
			Utils.sleep(2);
			dashboard.setStepDetails("Address is entered", "Adress should be added Successfully", "N/A");
			dashboard.writeResults();
			// Address ov = new Address();
			// ov.createAddressComponent(hParams);
			llAction.clickElement("web_addr_btn_submit");
		}
	}


	private void updateLAInformation(Hashtable<String, String> hParams) throws BPCException{

		String tblElementKey = "web_lnk_LA";

		try {
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY,"");
			llAction.switchtoFrame(1);

			int addressColPos = llAction.GetColumnPositionInTable(tblElementKey, "Address");

			int crsColPos = llAction.GetColumnPositionInTable(tblElementKey, "CRS Info");
			int rowCount = llAction.getRowCountInTable(tblElementKey);
			for(int i =2; i<=rowCount;i++){
				String text = llAction.GetTextFromTable(tblElementKey,  i, addressColPos,"/a");
				if (text.equalsIgnoreCase("N")) {

					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
					llAction.switchtoFrame(1);
					//	llAction.scrollToElement(llAction.getElement("web_addr_table_proposer")); NOT SURE IF REQUIRED
					//Utils.sleep(3);
					llAction.SelectRowInTable(tblElementKey, i, addressColPos,"a");
					llAction.handleCertificateErrors();
					llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_CORRESPONDENCE_ADDRESS, "");
					llAction.maximizeWindow();
					llAction.clickElement("web_Radio_AddressRecNumber");
					Utils.sleep(2);
					dashboard.setStepDetails("Address is entered", "Adress should be added Successfully", "N/A");
					dashboard.writeResults();
					llAction.clickElement("web_addr_btn_submit");
					Utils.sleep(5);
				}
				//CRS - VIEW/EDIT
				llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
				llAction.switchtoFrame(1);
				llAction.SelectRowInTable(tblElementKey, i, crsColPos,"a");
				llAction.handleCertificateErrors();
				addCrsInfo(hParams);

			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	public void SubmitForVerification(Hashtable<String, String> hParams) throws Exception {
		try {

			if (hParams.get("Verification_Ind").equalsIgnoreCase("Y")){
				llAction = new FPMS_Actions();
				llAction.selectMenuItem("NBD", "Verification");

				llAction.waitUntilLoadingCompletes();
				/*
				 * llAction.enterValue("web_txt_Verification_PolicyNo",
				 * hParams.get("PolicyNo")); llAction.waitUntilLoadingCompletes();
				 * llAction.clickElement("web_btn_Verification_Search");
				 * llAction.waitUntilLoadingCompletes();
				 * dashboard.setStepDetails("Policy Number is entered",
				 * "Policy Number should be searched Successfully", "N/A");
				 * dashboard.writeResults();
				 * 
				 * llAction.clickElementJs("web_btn_Verification_PolicyNo");
				 * llAction.waitUntilLoadingCompletes();
				 */

				searchPolicy(hParams.get("PolicyNo"), "web_tbl_Src_Policy");
				// Utils.sleep(5);
				// llAction.switchtoFrame(1);
				llAction.switchtoFrame("Xpath", "web_btn_Verification_VerificationFrame");
				dashboard.setStepDetails("Policy details are displayed",
						"Policy details should be displayed Successfully", "N/A");
				dashboard.writeResults();
				llAction.clickElementJs("web_btn_Verification_Submit");
				dashboard.setStepDetails("Policy is verified successfully", "Policy should be verified Successfully",
						"N/A");
				dashboard.writeResults();
				String url = llAction.getCurrentURL();
				while(!url.toLowerCase().contains("queryproofingpool.do"))
				{
					Utils.sleep(5);
					url = llAction.getCurrentURL();
				}
				llAction.clickElement("web_btn_Verification_Exit");
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	public void Payment_NegativeScenario(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("NBD", "Detail Registration");

			searchPolicy(hParams.get("PolicyNo"), "web_detail_tbl_PolicyList", "web_txt_DetailReg_PolicyNumber");

			llAction.switchtoFrame(1);

			updateProposerInformation(hParams);
			Utils.sleep(3);
			//	llAction.sleep(6);
			//llAction.switchtoDefaultWindow();

			updateLAInformation(hParams);

			Payment payment = new Payment();
			payment.addPayment(hParams);
			

			// addDirectCreditInformation(hParams);

			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			//if()
			BenefitsComponent benefitsComp = new BenefitsComponent();
			benefitsComp.addBenefits(hParams);
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			payment.reEnterPayment(hParams);
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
			llAction.switchtoFrame(1);
			/*llAction.enterValue("web_txt_discountType",hParams.get("LADiscountType"));
			llAction.sendkeyStroke("web_txt_discountType", Keys.ENTER);
			llAction.enterValue("web_dr_txt_verifcation", hParams.get("Verification_Ind"));
			dashboard.setStepDetails("Validate if Yes\\No is Entered for Verfication", "Value should be entered as per testdata", hParams.get("Verification_Ind"));
			dashboard.writeResults();*/
			FPMSManager.getInstance().getEvtHandler().setCurrentContext(FPMSConstants.DETAILREG_SUBMIT_CXT);
			llAction.clickElement("web_btn_Detail_Reg_Submit");
			System.out.println("DetailRegistrationComponent.Payment_NegativeScenario():submitted");
			llAction.acceptAlert();
			Utils.sleep(2);
			llAction.acceptAlert();
			System.out.println("DetailRegistrationComponent.Payment_NegativeScenario():alert Accepted");
			llAction.waitUntilLoadingCompletes();
		
			llAction.clickElement("web_btn_Detail_Reg_Exit");
			FPMSManager.getInstance().getEvtHandler().setCurrentContext(null);
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Submit and Exit", "User should be navigated to Home Page","");
			dashboard.writeResults();
			/*
			 * if (hParams.get("Verification_Ind").equalsIgnoreCase("Y")) {
			 * SubmitForVerification(hParams); }
			 */
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
}