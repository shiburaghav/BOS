package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.Hashtable;

import ge.fpms.main.IBenefits;
import ge.fpms.main.actions.FPMS_Actions;

public class UniversalLifeBenefits extends MainBenefits implements IBenefits {
	
	private FPMS_Actions llAction;
	public UniversalLifeBenefits() {
		super();
		llAction = new FPMS_Actions();
	}

	@Override
	public void getBenefitsType(String type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setBenefitsType(String type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public IBenefits createBenefits() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IBenefits createRider() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addBenefitsDetails(Hashtable<String, String> hParams) throws Exception {
		super.addBenefitsDetails(hParams);
		llAction.enterValue("web_txt_PremiumAmt", hParams.get("PremiumAmount"));
		llAction.enterValue("web_txt_MarketingDiscount", "");
		super.save();
		llAction.waitUntilLoadingCompletes();
	}

}
