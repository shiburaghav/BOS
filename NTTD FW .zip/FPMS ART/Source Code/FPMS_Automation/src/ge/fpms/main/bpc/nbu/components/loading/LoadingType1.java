package ge.fpms.main.bpc.nbu.components.loading;

import java.util.Hashtable;

import ge.fpms.main.ILoadingType;
import ge.fpms.main.actions.FPMS_Actions;

public class LoadingType1 implements ILoadingType{
	
	private FPMS_Actions llAction;

	public LoadingType1() {
		llAction = new FPMS_Actions();
	}
	
	@Override
	public void enterSpecificLoadingTypeInfo(Hashtable<String, String> hParams) throws Exception {
		llAction.enterValue("web_uw_txt_loadingType", hParams.get("LoadingType"));
		llAction.clickElement("web_uw_txt_loadingType");
		llAction.clickElement("web_txt_LoadingTypePara1");
		llAction.enterValue("web_txt_LoadingTypePara1", hParams.get("AmountPerSA"));
		llAction.clickElement("web_uw_btn_calcExtraPremAmt");
	}
}
