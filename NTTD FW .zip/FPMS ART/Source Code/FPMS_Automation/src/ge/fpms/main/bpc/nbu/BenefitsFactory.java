package ge.fpms.main.bpc.nbu;

import java.util.HashMap;

import ge.fpms.main.IBenefits;
import ge.fpms.main.ProductConstants;
import ge.fpms.main.bpc.nbu.components.benefits.*;

public class BenefitsFactory {

	private static BenefitsFactory factory ;
	static HashMap<String, IBenefits> productList;
	
	private BenefitsFactory() {
		registerBenefits();
	}
	public static BenefitsFactory getInstance() {
		if (factory == null){
			factory = new BenefitsFactory();
		}
		
		return factory;
	}
	
	private void registerBenefits()
	{
		productList = new HashMap<>();
		registerBenefit(ProductConstants.WHOLE_LIFE, new WholeLifeBenefits());
		registerBenefit(ProductConstants.ILP, new ILPBenefits());
		registerBenefit(ProductConstants.TERM, new TermBenefits());
		registerBenefit(ProductConstants.ENDOWMENT, new EndowmentBenefits());
		registerBenefit(ProductConstants.SHP, new SHPBenefits());
		registerBenefit(ProductConstants.UNIVERSAL_LIFE, new UniversalLifeBenefits());
	}
	private void registerBenefit(String productID, IBenefits p)    {
		productList.put(productID, p);
	}
	public IBenefits createBenefits(String productID){
		 return ((IBenefits)productList.get(productID));
	}
	
	
}
