package ge.fpms.main.bpc.claims;

import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class Disbursement extends BusinessComponent {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public Disbursement() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	

	public void updateDisbursementPlan(Hashtable<String, String> hParams) throws Exception {
		// Utils.sleep(6);
		llAction.switchtoDefaultContent();
		llAction.switchtoFrame("main");
		llAction.clickElement("web_disbursement_btn_disbursementPlan");
		llAction.switchtoDefaultContent();
		llAction.waitUntilLoadingCompletes();
		llAction.switchtoFrame("rightFrame");
		llAction.waitUntilLoadingCompletes();
		llAction.switchtoDefaultContent();
		llAction.switchtoFrame("leftFrame");
		dashboard.setStepDetails("Disbursement Plan button is clicked", "Disbursement Plan Summary displayed", "N/A");
		dashboard.writeResults();

		List<WebElement> allPolicies = llAction.findElements("web_disbursementPlan_policies_tree_lnk");
		if (allPolicies.size() == 0) {
			dashboard.setFailStatus(new BPCException("Disbursement Plan - Failed to find policies.. "));
			dashboard.writeResults();
		} else {
			String settlementOption = hParams.get("SettlementOption");
			String pendingPayment = hParams.get("PendingPayment");

			for (int j = 0; j < allPolicies.size(); j++) {
				// Click on each policy
				WebElement policy = allPolicies.get(j);
				llAction.clickElementJs(policy);
				// llAction.waitUntilLoadingCompletes();

				llAction.switchtoDefaultContent();
				llAction.switchtoFrame("rightFrame");
				llAction.waitUntilLoadingCompletes();

				int rowCount = llAction.getRowCountInTable("web_disbursement_tbl_benefitAllocation");
				int payeeCol = llAction.GetColumnPositionInTable("web_disbursement_tbl_benefitAllocation", "Payee");
				String text1 = llAction.GetTextFromTable("web_disbursement_tbl_benefitAllocation", 2, 1);
				if (!text1.equalsIgnoreCase("Record Not Found")) {
					for (int i = 1; i < rowCount; i++) {
						llAction.SelectRowInTable("web_disbursement_tbl_benefitAllocation", i + 1, payeeCol, "a");
						llAction.waitUntilLoadingCompletes();

						if (!StringUtils.isEmpty(settlementOption)) {
							llAction.selectByVisibleText("web_disbursement_lst_settlementOption", settlementOption);
							dashboard.setStepDetails("Disbursement Plan displayed", "Selected settlement Option",
									"N/A");
							dashboard.writeResults();
						}
						llAction.selectByVisibleText("web_disbursement_paymentmethod", hParams.get("Paymentmethod"));
						if (!StringUtils.isEmpty(pendingPayment)) {
							llAction.selectByVisibleText("web_evaluation_disbursement_ispending",
									hParams.get("PendingPayment"));
							dashboard.setStepDetails("Disbursement Plan displayed", "Selected pending payement", "N/A");
							dashboard.writeResults();
						}
						llAction.clickElement("web_evaluation_disbursement_save");
						llAction.handleMultipleAlerts((long) 0);
						llAction.waitUntilLoadingCompletes();
						llAction.clickElement("web_evaluation_txt_close");
						llAction.waitUntilLoadingCompletes();

					}
					dashboard.setStepDetails("Disbursement amount and pending status should be updated",
							"Disbursement amount and pending status is updated", "N/A");
					dashboard.writeResults();
				}
				else
				{
					dashboard.setStepDetails("Products are not found for disbursement amount",
							"No records found", "N/A");
					dashboard.writeResults();
				}
				
				llAction.switchtoDefaultContent();
				llAction.switchtoFrame("leftFrame");
				allPolicies = llAction.findElements("web_disbursementPlan_policies_tree_lnk");

			}

			llAction.clickElement("web_disbursementPlan_caseNumber_tree_lnk");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Disbursement amount and Allocated amount should be updated for claim case",
					"Disbursement amount and Allocated amount should is updated for claim case", "N/A");
			dashboard.writeResults();
		}
	}
}
