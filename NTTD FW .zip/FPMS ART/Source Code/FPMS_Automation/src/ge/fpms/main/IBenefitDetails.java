package ge.fpms.main;

public interface IBenefitDetails {

	public void setCoveragePeriod(String coveragePeriod) throws Exception;
	public void setCoverageTerm(String coverageTerm)throws Exception;
	public void setPremiumPaymentPeriod(String premiumPaymentPeriod)throws Exception;
	public void setInitialPremiumFrequency(String initialPremiumFrequency)throws Exception;
	public void setInitialSumAssured(String initialSumAssured)throws Exception;
	public void setPremiumTerm(String premiumTerm) throws Exception;
	public void setPremiumCalculatingMethod(String premiumCalculatingMethod)throws Exception;
	public void setPremiumAmount(String premiumAmount)throws Exception;
}
