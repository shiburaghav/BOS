package ge.fpms.main.bpc.bcp.templates.axs;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Summary implements IPaymentSection {

	private Type recordType;
	private Type labelID;
	private Type totalNumberofRecord;
	private Type hashTotal;
	private Type totalPaidAmount;
	private Type trlProcService;
	private Type filler;

	

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getLabelID() {
		return labelID;
	}

	public void setLabelID(Type labelID) {
		this.labelID = labelID;
	}

	public Type getTotalNumberofRecord() {
		return totalNumberofRecord;
	}

	public void setTotalNumberofRecord(Type totalNumberofRecord) {
		this.totalNumberofRecord = totalNumberofRecord;
	}

	public Type getHashTotal() {
		return hashTotal;
	}

	public void setHashTotal(Type hashTotal) {
		this.hashTotal = hashTotal;
	}

	public Type getTotalPaidAmount() {
		return totalPaidAmount;
	}

	public void setTotalPaidAmount(Type totalPaidAmount) {
		this.totalPaidAmount = totalPaidAmount;
	}

	public Type getTrlProcService() {
		return trlProcService;
	}

	public void setTrlProcService(Type trlProcService) {
		this.trlProcService = trlProcService;
	}

	public Type getFiller() {
		return filler;
	}

	public void setFiller(Type filler) {
		this.filler = filler;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(),
				labelID.getSize(),
				totalNumberofRecord.getSize(),
				hashTotal.getSize(),
				totalPaidAmount.getSize(),
				trlProcService.getSize(),
				filler.getSize()};
	}

	public void setParamaters(String[] buffer) {
		recordType.setValue(buffer[0]);
		labelID.setValue(buffer[1]);
		totalNumberofRecord.setValue(buffer[2]);
		hashTotal.setValue(buffer[3]);
		totalPaidAmount.setValue(buffer[4]);
		trlProcService.setValue(buffer[5]);
		filler.setValue(buffer[6]);
	}

	public String getName() {
		return "9";
	}

	public String toString() {

		return new StringBuffer().append(getRecordType().toString())
				.append(getLabelID().toString())
				.append(getTotalNumberofRecord().toString())
				.append(getHashTotal().toString())
				.append(getTotalPaidAmount().toString())
				.append(getTrlProcService().toString())
				.append(getFiller().toString()).toString();
	}

	@Override
	public Type[] getAllAttributes() {
		// TODO Auto-generated method stub
		return null;
	}

}
