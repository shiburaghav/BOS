package ge.fpms.main.bpc.csd;

import java.util.Hashtable;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.*;

public class IncreaseSA{ 

	private FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	
	public IncreaseSA() {
		dashboard = DashboardHandler.getInstance();
		llAction = new FPMS_Actions();
	}
			
}








