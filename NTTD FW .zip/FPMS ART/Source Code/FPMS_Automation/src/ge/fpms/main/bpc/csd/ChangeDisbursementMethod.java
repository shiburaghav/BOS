package ge.fpms.main.bpc.csd;
import java.util.Hashtable;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class ChangeDisbursementMethod {
	private DashboardHandler dashboard;
	
	public ChangeDisbursementMethod() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}	
	/*
	 * Name: Change Disbursement Method Purpose: Navigate to CS module from the Main
	 * Page and Change Disbursement Method for a policy Parameters:Parameter Hash
	 * table Return Value: NA Exception: BPCException
	 * 
	 * @author: Sahil SIngh 0n 27/12/2018
	 */

	private FPMS_Actions llAction;

	public void changeDisbursement(Hashtable<String, String> hParams) throws Exception {

		try {
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {

					String getWarningMsg = llAction.getText("web_txt_ErrorWarning").trim();

					validateWarningMessages(getWarningMsg, hParams.get("WarningErrorMessage"));

					llAction.clickElement("web_btn_ContinueRP");
				} else {
					llAction.clickElement("web_btn_ContinueRP");
				}
			}
			llAction.enterValue("web_txt_ValidateDate", hParams.get("Validitydate"));
			dashboard.writeResults();
			int BenefitalterCol = llAction.GetColumnPositionInTable("web_tbl_DisbursementInfo", "Payment Type");
			int BenefitalterRow = llAction.GetRowPositionInTable("web_tbl_DisbursementInfo", hParams.get("PaymentType"),
					BenefitalterCol);
			llAction.SelectRowInTable("web_tbl_DisbursementInfo", BenefitalterRow, BenefitalterCol - 1, "input");
			dashboard.setStepDetails("Alteration Item before change is chosen",
					"Alteration item should be selected", "N/A");
			dashboard.writeResults();
			llAction.selectByVisibleText("web_list_DisbursementMethod", hParams.get("CBDisbursementMethod"));
			dashboard.setStepDetails("Disbursement Method is chosen", "Disbursement Method should be selected",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_SubmitChangeRP");
			// llAction.clickElement("web_btn_Apply");
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {

				llAction.clickElement("web_btn_ContinueRP");
			}
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().captureChange("changeDisbursement", "AfterChange");
			llAction.clickElement("web_btn_SubmitChangeRP");
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().checkApplicationStatus();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void validateWarningMessages(String warningMsg, String message) throws Exception {
		try {
			if (warningMsg.contains(message)) { // compare warning messages
				dashboard.setStepDetails(message + "Warning message should be displayed",
						"\"Warning message should be displayed ", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setWarningStatus(
						"Warning message " + warningMsg + " from application is not matching with test data");
				dashboard.writeResults();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);

		}
	}
}
