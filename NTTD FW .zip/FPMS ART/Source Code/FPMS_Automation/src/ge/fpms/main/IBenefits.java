package ge.fpms.main;

import java.util.Hashtable;

public abstract interface IBenefits {

	public void getBenefitsType(String type);

	public void setBenefitsType(String type);

	public IBenefits createBenefits();

	public IBenefits createRider();

	public void addBenefitsDetails(Hashtable<String, String> hParams) throws Exception;

}
