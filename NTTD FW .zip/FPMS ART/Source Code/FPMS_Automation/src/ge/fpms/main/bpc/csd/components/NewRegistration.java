package ge.fpms.main.bpc.csd.components;

import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import com.nttdata.common.util.Utils;
import com.nttdata.core.LL_Actions;
import com.nttdata.core.backend.DashboardProperties;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class NewRegistration extends BusinessComponent {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public NewRegistration() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
	}
	public void NewApplicationRegistration(Hashtable<String, String> hParams) throws Exception {

		try {
			llAction.selectMenuItem("Customer Service", "New Application Registration");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Enter Application Details", "Application details should be entered",
					"N/A");
			llAction.enterValue("web_txt_PolicyNumber", hParams.get("PolicyNumberRegistration"));
			llAction.selectByVisibleText("web_lst_branchId", hParams.get("Branchreceived"));
			llAction.selectByVisibleText("web_lst_touchPoint", hParams.get("TouchPoint"));
			llAction.enterValue("web_txt_Applicationdate", hParams.get("ApplicationDate"));
			llAction.selectByVisibleText("web_txt_Policyalterationitem", hParams.get("PolicyAlterationitem"));
			llAction.clickElement("web_btn_Add");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Register");
			llAction.waitUntilLoadingCompletes();
			String registrationMessage = llAction.getText("web_txt_RegistrationMessage").trim();
			dashboard.setStepDetails("New registration message is displayed",
					"Policy "+hParams.get("PolicyNumberRegistration")+" registered Successfully", "N/A");
			if (registrationMessage.equalsIgnoreCase(FPMSConstants.RegistrationSuccess)) {
				dashboard.setStepDetails("New registration message is displayed",
						"Policy "+hParams.get("PolicyNumberRegistration")+" registered Successfully", "N/A");
				dashboard.writeResults();
			}else{
				dashboard.setFailStatus(
						new BPCException("Choose a valid Policy-Current message displayed is" + registrationMessage));
			}
			llAction.clickElement("web_btn_Exit");
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	public void EnterApplicationDetails(Hashtable<String, String> hParams) throws Exception {

		try {
			llAction = new FPMS_Actions();
			llAction.selectMenuItem("Customer Service", "Application Entry Sharing Pool");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_PolicyNumber", hParams.get("PolicyNumber"));
			llAction.sendkeyStroke("web_txt_PolicyNumber", Keys.ENTER);
			llAction.clickElement("web_btn_Search");
			//This is to validate the error message
			//it will not impact the normal flow  - by prashantha 18 Jan,2019
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {
				
				if (hParams.get("WarningErrorMessage") != null && hParams.get("WarningErrorMessage") != "") {				
					CSDHelper.getInstance().validateWarningMessages("web_tbl_fullsurrender_warning_msg", hParams.get("WarningErrorMessage"));
				}
				llAction.clickElement("web_btn_ContinueRP");
				llAction.waitUntilLoadingCompletes();
			}
			
			if (!llAction.isDisplayed("web_tbl_PolicyAlteration")) {
				int policynumberCol = llAction.GetColumnPositionInTable("web_tbl_PolicySearch",
						"Policy alteration item");
				int policyRow = llAction.GetRowPositionInTable("web_tbl_PolicySearch",
						hParams.get("PolicyAlterationitem"), policynumberCol);
				int applicationidCol = llAction.GetColumnPositionInTable("web_tbl_PolicySearch", "Application ID");
				llAction.SelectRowInTable("web_tbl_PolicySearch", policyRow, applicationidCol, "a");
				llAction.waitUntilLoadingCompletes();
			}
			int alterationCol = llAction.GetColumnPositionInTable("web_tbl_PolicyAlteration", "Policy alteration item");
			int alterationRow = llAction.GetRowPositionInTable("web_tbl_PolicyAlteration",
					hParams.get("PolicyAlterationitem"), alterationCol);
			int optionCol = llAction.GetColumnPositionInTable("web_tbl_PolicyAlteration", "Option");
			llAction.SelectRowInTable("web_tbl_PolicyAlteration", alterationRow, optionCol, "input");
			dashboard.setStepDetails("Policy Alteration Item is chosen",
					"Policy Alteration item should be selected", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_EnterInformation");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	/*
	 This is a temporary approach to handle multiple policy iteration item in a single flow
	 added by prashantha 24-01-2019, will be deprecated later.Ref: Change Trustee test cases
	 */
	public void NewApplicationRegistrationB(Hashtable<String, String> hParams) throws Exception {

		try {
			llAction = new FPMS_Actions();
			llAction.selectMenuItem("Customer Service", "New Application Registration");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Enter Application Details", "Application details should be entered",
					"N/A");
			llAction.enterValue("web_txt_PolicyNumber", hParams.get("PolicyNumberRegistration"));
			llAction.selectByVisibleText("web_lst_branchId", hParams.get("Branchreceived"));
			llAction.selectByVisibleText("web_lst_touchPoint", hParams.get("TouchPoint"));
			llAction.enterValue("web_txt_Applicationdate", hParams.get("ApplicationDate"));
			llAction.selectByVisibleText("web_txt_Policyalterationitem", hParams.get("PolicyAlterationitem2"));
			llAction.clickElement("web_btn_Add");
			dashboard.writeResults();
			llAction.clickElement("web_btn_Register");
			llAction.waitUntilLoadingCompletes();
			String registrationMessage = llAction.getText("web_txt_RegistrationMessage").trim();
			dashboard.setStepDetails("New registration message is displayed",
					"New Application is registered Successfully", "N/A");
			if (registrationMessage.equalsIgnoreCase(FPMSConstants.RegistrationSuccess)) {
				dashboard.setStepDetails("New registration message is displayed",
						"New Application is registered Successfully", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setFailStatus(
						new BPCException("Choose a valid Policy-Current message displayed is" + registrationMessage));
			}
			llAction.clickElement("web_btn_Exit");
		} catch (Exception ex) {
			throw new BPCException(ex);
		}

	}
	
	/*This is a temporary approach to handle multiple policy iteration item in a single flow
	 added by prashantha 24-01-2019, will be deprecated later. Ref: Change Trustee test cases*/
	public void EnterApplicationDetailsB(Hashtable<String, String> hParams) throws Exception {
	
		try {
			llAction = new FPMS_Actions();
			llAction.selectMenuItem("Customer Service", "Application Entry Sharing Pool");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_PolicyNumber", hParams.get("PolicyNumber"));
			llAction.sendkeyStroke("web_txt_PolicyNumber", Keys.ENTER);
			llAction.clickElement("web_btn_Search");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_ContinueRP", 5)) {

				llAction.clickElement("web_btn_ContinueRP");
			}
			dashboard.setStepDetails("Policy Alteration Item is chosen",
					"Policy Alteration item should be selected", "N/A");
			if (!llAction.isDisplayed("web_tbl_PolicyAlteration")) {
				int policynumberCol = llAction.GetColumnPositionInTable("web_tbl_PolicySearch",
						"Policy alteration item");
				int policyRow = llAction.GetRowPositionInTable("web_tbl_PolicySearch",
						hParams.get("PolicyAlterationitem"), policynumberCol);
				int applicationidCol = llAction.GetColumnPositionInTable("web_tbl_PolicySearch", "Application ID");
				llAction.SelectRowInTable("web_tbl_PolicySearch", policyRow, applicationidCol, "a");
				llAction.waitUntilLoadingCompletes();
			}
			int alterationCol = llAction.GetColumnPositionInTable("web_tbl_PolicyAlteration", "Policy alteration item");
			int alterationRow = llAction.GetRowPositionInTable("web_tbl_PolicyAlteration",
					hParams.get("PolicyAlterationitem2"), alterationCol);
			int optionCol = llAction.GetColumnPositionInTable("web_tbl_PolicyAlteration", "Option");
			llAction.SelectRowInTable("web_tbl_PolicyAlteration", alterationRow, optionCol, "input");
			dashboard.writeResults();
			llAction.clickElement("web_btn_EnterInformation");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	
	
	
	public void  validateAtEnterinformation(Hashtable<String, String> hParams) throws Exception {
		try {
			LL_Actions llAction = new FPMS_Actions();
			llAction.waitUntilLoadingCompletes();
			CSDHelper.getInstance().validateWarningMessages("web_tbl_partialsurrender_warningMsg", hParams.get("WarningErrorMessage-EnterInformation"));
		}      
		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
} 
