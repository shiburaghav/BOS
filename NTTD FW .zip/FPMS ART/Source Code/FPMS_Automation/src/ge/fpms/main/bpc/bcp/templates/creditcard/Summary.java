package ge.fpms.main.bpc.bcp.templates.creditcard;

import java.util.ArrayList;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Summary implements IPaymentSection {

	private Type recordType;
	private Type recordCount;
	private Type totalAmount;

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Type recordCount) {
		this.recordCount = recordCount;
	}

	public Type getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Type totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public Summary(Type[] type) {
		super();
		this.recordType = new Type(type[0].getSize(), type[0].getDataType(), type[0].getValue(), type[0].getAlignment(),
				type[0].getPaddingChar());
		this.recordCount = new Type(type[1].getSize(), type[1].getDataType(), type[1].getValue(),
				type[1].getAlignment(), type[1].getPaddingChar());
		this.totalAmount = new Type(type[2].getSize(), type[2].getDataType(), type[2].getValue(),
				type[2].getAlignment(), type[2].getPaddingChar());
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(),
				recordCount.getSize(),
				totalAmount.getSize()
				};
	}

	public void setParamaters(ArrayList<String> buffer) {
		recordType.setValue(buffer.get(0));
		recordCount.setValue(buffer.get(1));
		totalAmount.setValue(buffer.get(2));
	}

	public String getName() {
		return "BT";
	}

	public String toString() {

		return new StringBuffer().append(getRecordType().toString())
				.append(getRecordCount().toString())
				.append(getTotalAmount().toString()).toString();
	}

	@Override
	public Type[] getAllAttributes() {
		return new Type[] { recordType,
				recordCount,
				totalAmount			};
	}

}
