package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.Hashtable;
import java.util.logging.Logger;

import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.IBenefitDetails;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.csd.components.CSDHelper;

public class MainBenefits implements IBenefitDetails {
	private final static Logger LOGGER = Logger.getLogger(MainBenefits.class.getName());
	private FPMS_Actions llAction;

	public MainBenefits() {
		llAction = new FPMS_Actions();

	}
	public void addBenefitsDetails(Hashtable<String, String> hParams)
			throws Exception {
		FPMSManager.getInstance().getEvtHandler().setCurrentContext(FPMSConstants.MAIN_BENEFITS_CXT);;
		String premiumcalcMethod=llAction.getAttribute("web_txt_PremiumCalculatingMethod", "value");
		if(premiumcalcMethod.equalsIgnoreCase("1")) 
			setInitialSumAssured(hParams.get("InitialSumAssured"));
		else if(premiumcalcMethod.equalsIgnoreCase("2"))
			setPremiumAmount(hParams.get("PremiumAmount"));	
		setCoveragePeriod(hParams.get("CoveragePeriod"));
		setCoverageTerm(hParams.get("CoverageTerm"));
		setPremiumPaymentPeriod(hParams.get("PremiumPaymentPeriod"));
		setPremiumTerm(hParams.get("PremiumTerm"));
		setInitialPremiumFrequency(hParams.get("InitialPremiumFrquency"));
		setPremiumCalculatingMethod(hParams.get("PremiumCalculatingMethod"));

		// TODO: not there for whole life
		// setInitialSumAssured(hParams.get("InitialSumAssured"));
		// setPremiumAmount(hParams.get("PremiumAmount"));

	}

	public void writetoDashbaord() {
		DashboardHandler.getInstance().setStepDetails("Enter Benefit Details",
				"Benefit Details Information has been entered. ", "N/A");
		DashboardHandler.getInstance().writeResults();
	}

	public void setBenefitsType(String type) throws Exception {
		llAction.enterValue("web_txt_BenefitType", type);
	}

	@Override
	public void setCoveragePeriod(String coveragePeriod) throws Exception {

		llAction.enterValuewithAlert("web_txt_CoveragePeriod", coveragePeriod);
		/*if(llAction.isAlertDisplayed((long)2)) {
			String text = llAction.getAlertText();
			System.out.println(text);
				}*/
		
	}

	@Override
	public void setCoverageTerm(String coverageTerm) throws Exception{

		llAction.enterValue("web_txt_CoverageYr", coverageTerm);

	}

	@Override
	public void setPremiumPaymentPeriod(String premiumPaymentPeriod) throws Exception{

		llAction.enterValuewithAlert("web_txt_PremiumPaymentPeriod",
				premiumPaymentPeriod);

	}

	@Override
	public void setInitialPremiumFrequency(String initialPremiumFrequency)throws Exception {

		llAction.enterValue("web_txt_InitialPremiumFrequency",
				initialPremiumFrequency);

	}

	@Override
	public void setInitialSumAssured(String initialSumAssured)throws Exception {

		llAction.enterValue("web_txt_InitialSumAssured", initialSumAssured);

	}

	@Override
	public void setPremiumTerm(String premiumTerm)throws Exception {

		llAction.enterValue("web_txt_PremiumTrm", premiumTerm);

	}

	@Override
	public void setPremiumCalculatingMethod(String premiumCalculatingMethod)throws Exception {

		llAction.enterValuewithAlert("web_txt_PremiumCalculatingMethod",
				premiumCalculatingMethod);

	}

	@Override
	public void setPremiumAmount(String premiumAmount)throws Exception {

		llAction.enterValue("web_txt_PremiumAmt", premiumAmount);

	}

	public void setCashBonusOption(String cashBonusOption)throws Exception {

		llAction.enterValue("web_txt_CashBonusOption", cashBonusOption);

	}

	public void setSurvivalOption(String survivalOption)throws Exception {

		llAction.enterValue("web_txt_SurvivalOption", survivalOption);

	}

	public void setInitialPaymentFrequency(String paymentFrequency) throws Exception{
		// TODO Auto-generated method stub

	}

	public void setMarketingDiscount(String marketingDiscount)throws Exception {

		llAction.enterValue("web_txt_MarketingDiscount", marketingDiscount);

	}

	public void setManualSurrenderValue(String value)throws Exception {

		llAction.enterValue("web_benefits_manuSurrValue", value);

	}
	public void setWrapFeeOption(String value) throws Exception {

		llAction.enterValue("web_txt_benefits_wrap_fee_option", value);

	}

	public void setAutoReBalancingIND(String value) throws Exception {
		llAction.selectByVisibleText("web_detailReg_list_AutoReBalancingInd", value);
	}

	public void save() throws Exception {
		writetoDashbaord();
		llAction.clickElement("web_btn_saveBn");
		FPMSManager.getInstance().getEvtHandler().setCurrentContext(null);
		Utils.sleep(2);
		llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_DATA_ENTRY, "");
		llAction.switchtoFrame("index", "1");

	}

	public void ChangeBenefits(Hashtable<String, String> hParams)
			throws Exception {
		DashboardHandler.getInstance().setStepDetails("Change Benefits ",
				"About to select  change benefit from immediate ", "N/A");
		DashboardHandler.getInstance().writeResults();

		llAction.clickElement("web_btn_cb_immediate");
		llAction.waitUntilLoadingCompletes();

		// changebenefit.UpgradeDowngradeCoverage=>Amend screen
		String benefitInfoTbl = "web_tbl_cb_benefits";
		int cPos = llAction.GetColumnPositionInTable(benefitInfoTbl, "Benefit");
		int rPos = llAction.GetRowPositionInTable(benefitInfoTbl,
				hParams.get("BenefitCode"), cPos);
		int optionButtonPos = llAction.GetColumnPositionInTable(benefitInfoTbl,
				"Option");
		llAction.SelectRowInTable(benefitInfoTbl, rPos, optionButtonPos,
				"input");

		DashboardHandler.getInstance().setStepDetails("Change Benefits ",
				"Selected the plan to be amended ", "N/A");
		DashboardHandler.getInstance().writeResults();

		llAction.clickElement("web_btn_cb_benefits_amend");
		llAction.waitUntilLoadingCompletes();

		llAction.enterValue("web_txt_cb_benefit_info_benefit_type",
				hParams.get("BenefitType"));
		llAction.sendkeyStroke("web_txt_cb_benefit_info_benefit_type",
				Keys.ENTER);
		llAction.clickElement("web_btn_cb_benefit_into_save_button");
		llAction.waitUntilLoadingCompletes();

		llAction.enterValue("web_txt_cb_benefit_details_pcalc_method",
				hParams.get("Premiumcalculationmethod"));
		llAction.sendkeyStroke("web_txt_cb_benefit_details_pcalc_method",
				Keys.ENTER);
		Utils.sleep(2);
		llAction.enterValue("web_txt_cb_benefit_details_premium_amt",
				hParams.get("PremiumAmount"));

		DashboardHandler.getInstance().setStepDetails(" Amend Changes",
				"Amended the changes, about to save.. ", "N/A");
		DashboardHandler.getInstance().writeResults();
		llAction.clickElement("web_btn_cb_benefit_into_save_button");
		llAction.waitUntilLoadingCompletes();

		CSDHelper.getInstance().validateWarningMessages(
				"web_txt_cb_benefit_details_warning_tbl",
				hParams.get("WarningErrorMessage"));

		if (llAction.isDisplayed("web_btn_continue", 5)) {
			llAction.clickElement("web_btn_continue");
		}
		llAction.waitUntilLoadingCompletes();

		// Change Benefit Coverage
		llAction.clickElement("web_btn_cb_coverage_submit");
		llAction.waitUntilLoadingCompletes();

		DashboardHandler.getInstance().setStepDetails("Change Benefits ",
				" UI with Benefit information after change info ", "N/A");
		DashboardHandler.getInstance().writeResults();
		// System should display "Change benefit" UI with Benefit information
		// after change info
		llAction.clickElement("web_btn_cb_coverage_submit");
		llAction.waitUntilLoadingCompletes();

		DashboardHandler.getInstance().setStepDetails(" Modify collection or refund ",
				" Modify collection or refund UI ", "N/A");
		DashboardHandler.getInstance().writeResults();
		// display "Modify collection/refund" UI
		llAction.clickElement("web_btn_cb_mod_refund_submit");
		llAction.waitUntilLoadingCompletes();

		// display Application entry UI
		llAction.clickElement("web_btn_cb_app_entry_submit");
		llAction.waitUntilLoadingCompletes();

		// Display offset fee result
		llAction.clickElement("web_btn_display_offset_result_exit");
		llAction.waitUntilLoadingCompletes();

		// check application status
		CSDHelper.getInstance().checkApplicationStatus();

	}
}
