package ge.fpms.main.bpc.claims;

import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.data.Claims;
import ge.fpms.data.Login;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.ProductConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;

public class Case extends BusinessComponent {

	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private Claims caseHandler;
	private Claims claims;

	public Case() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		caseHandler = FPMSManager.getInstance().getCaseHandler();
		claims = Claims.getInstance();
	}

	public void searchAndProcessCaseTillEvaluation(Hashtable<String, String> hParams) throws Exception {

		try {
			searchClaimsProcessingPoolbyCaseNumber(hParams);
			enterCaseAcceptanceEntryDetails(hParams);
			updateAcceptanceSummary(hParams);
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	/*
	 * Name: searchCase Purpose: Search by case number And Validate the search
	 * results Case Parameters: hParams Return Value: NA Exception: BPCException
	 */
	public void searchClaimsProcessingPoolbyCaseNumber(Hashtable<String, String> hParams) throws Exception {
		try {

			if (caseHandler.isCaseNumberEmpty()) {
				caseHandler.setCaseNumber(hParams.get("CaseNumber"));
			}
			String caseNumber = caseHandler.getCaseNumber();

			// navigate to claims processing pool
			llAction.selectMenuItem("Claim", "Claims Processing Pool");
			llAction.waitUntilElementPresent("web_txt_ClaimsProcessingPool_CaseNumber");
			llAction.clickElement("web_btn_ClaimsProcessingPool_Reset");
			llAction.waitUntilLoadingCompletes();
			llAction.enterValue("web_txt_ClaimsProcessingPool_CaseNumber", caseNumber);
			llAction.clickElement("web_txt_ClaimsProcessingPool_Search");
			llAction.waitUntilLoadingCompletes();
			validateSearchResults(hParams, true);
		}

		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: Validate the search results based on the flag set Case Parameters:
	 * hParams Return Value,boolean flag: NA Exception: BPCException
	 */
	public void validateSearchResults(Hashtable<String, String> hParams, boolean countToBeDisplayed) throws Exception {
		try {

			int recordsCountColPos = llAction.GetColumnPositionInTable("web_tbl_ClaimsProcessingPool_searchResults",
					"0 Records");
			if (countToBeDisplayed) {
				if (recordsCountColPos != 0) {
					dashboard.setFailStatus(new BPCException("0 records displayed."));
					dashboard.writeResults();
				} else {
					dashboard.setStepDetails("Verify search results in the Claims Processing Pool Screen",
							"Record(s) displayed.", "N/A");
					dashboard.writeResults();

				}
			} else {
				dashboard.setStepDetails("Verify search results in the Claims Processing Pool Screen",
						"Record(s) displayed.", "N/A");
				dashboard.writeResults();
			}
		}

		catch (Exception ex) {
			throw new BPCException(ex);
		}

	}

	/*
	 * Name:enterCaseAcceptanceEntryDetails Purpose:To enter all case acceptance
	 * details in the case acceptance entry screen Case Parameters: hParams Return
	 * Value,boolean flag: NA Exception: BPCException
	 */
	public void enterCaseAcceptanceEntryDetails(Hashtable<String, String> hParams) throws Exception {
		try {

			if (caseHandler.getCaseNumber().isEmpty()) {
				caseHandler.setCaseNumber(hParams.get("CaseNumber"));
			}
			String caseNumber = caseHandler.getCaseNumber();

			int colPos = llAction.GetColumnPositionInTable("web_tbl_ClaimsProcessingPool_searchResults", "Case Number");
			int rowPos = llAction.GetRowPositionInTable("web_tbl_ClaimsProcessingPool_searchResults", caseNumber,
					colPos);
			llAction.SelectRowInTable("web_tbl_ClaimsProcessingPool_searchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();
			llAction.selectByVisibleText("web_lst_CaseAcceptanceEntry_ClaimNature", hParams.get("ClaimNature"));
			llAction.selectByVisibleText("web_lst_CaseAcceptanceEntry_CaseClassification",
					hParams.get("CaseClassification"));
			dashboard.setStepDetails("Enter Claim Acceptance details", "Claim Acceptance details should be entered",
					"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_txt_ClaimsProcessingPool_Next");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on Next button ", "Acceptance Summary Screen Should be displayed", "N/A");
			dashboard.writeResults();
		}

		catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void updateAcceptanceSummary(Hashtable<String, String> hParams) throws Exception {

		try {
			String caseAcceptancePolicyDecision = hParams.get("AcceptanceDecision").trim();
			String byPassCheckListForCompleteness = hParams.get("BypassCheckListCompleteness").trim();
			String priceEffectiveDate = hParams.get("PriceEffectiveDateILPProduct").trim();
			String reason = hParams.get("Reason").trim();
			llAction.switchtoFrame(2);
			llAction.selectByVisibleText("web_lst_ClaimsAcceptancePolicy_acceptDecision", caseAcceptancePolicyDecision);
			if (caseAcceptancePolicyDecision.equalsIgnoreCase("CANCEL")
					|| caseAcceptancePolicyDecision.equalsIgnoreCase("WITHDRAWN")) {
				if (reason.isEmpty() == true) {
					dashboard.setFailStatus(new BPCException("Reason is required for " + caseAcceptancePolicyDecision));
					dashboard.writeResults();
				} else {
					llAction.selectByVisibleText("web_lst_ClaimsAcceptancePolicy_reason", reason);
				}
			}

			if (byPassCheckListForCompleteness.isEmpty() == false) {
				llAction.selectByVisibleText("web_lst_ClaimsAcceptancePolicy_bypassCheckListCompleteness",
						byPassCheckListForCompleteness);
			}
			if (llAction.isEnabled("web_evaluation_txt_ILPEffectiveDate")) {
				WebElement webElement = llAction.returnWebElement("web_evaluation_txt_ILPEffectiveDate");
				String readonly = webElement.getAttribute("readonly");
				if (!"true".equals(readonly)) {
					llAction.enterValue("web_evaluation_txt_ILPEffectiveDate", priceEffectiveDate);
				}
			}
			dashboard.setStepDetails("Fill in Acceptance summary", "System should accept input details", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_btn_ClaimsAcceptancePolicy_save");
			Utils.sleep(2);
			Long timeout = (long) 0;
			if (llAction.isAlertDisplayed(timeout)) {
				dashboard.setStepDetails("Click on Save button", "Save button is clicked.", "N/A");
				dashboard.writeResults();
				String alertText = llAction.getAlertText();
				llAction.acceptAlert();
				dashboard.setFailStatus(new BPCException("An error or warning  " + alertText
						+ " is displayed. Please check acceptance status before this case can be accepted."));

			}
			llAction.waitUntilLoadingCompletes();

			llAction.switchtoChildWindow("Case Acceptance Confirmation");
			validateCaseAcceptanceConfirmation(hParams);
		}

		catch (Exception ex) {
			ex.printStackTrace();
			throw new BPCException(ex);
		}
	}

	public void validateCaseAcceptanceConfirmation(Hashtable<String, String> hParams) throws Exception {
		try {
			String caseAcceptanceStatus = hParams.get("CaseStatus");
			String caseAcceptanceConfirmation = llAction
					.getText("web_txt_ClaimsAcceptanceConfirm_AcceptanceConfirmMsg");
			if (caseAcceptanceConfirmation.toLowerCase().contains(caseAcceptanceStatus.toLowerCase())) {
				dashboard.setStepDetails(caseAcceptanceStatus + " Should be populated", "Message is validated", "N/A");
				dashboard.writeResults();
			} else {
				dashboard.setFailStatus(new BPCException("Case could not be '" + caseAcceptanceStatus + "'"));
				dashboard.writeResults();
				dashboard.setFailStatus(
						new BPCException(caseAcceptanceStatus + " message is invalid/Submit was not successful"));
			}

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

}
