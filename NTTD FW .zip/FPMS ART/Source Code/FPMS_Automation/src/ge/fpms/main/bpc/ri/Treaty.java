package ge.fpms.main.bpc.ri;

import java.util.Hashtable;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;
import ge.fpms.main.actions.FPMS_Actions;

public class Treaty {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;

	public Treaty() {
		llAction = new FPMS_Actions(); // Instantiate llAction object
		dashboard = DashboardHandler.getInstance();// Singelton class to get the ART Dashboard
	}

	/*
	 * Name: searchTreaty Purpose: Method will search for Re -insurance treaty based
	 * on the search criteria Parameters: hParams - the test data for the function
	 * in hashmap. Return Value: NA Exception: BPC Exception on
	 */
	public void searchTreaty(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("Query", "by treaty"); // select the Menu item Query->By Treaty
			llAction.waitUntilLoadingCompletes(); // wait till the page load is complete

			llAction.enterValue("web_txt_treatyCode", hParams.get("Treaty_Code")); //enter value in Treaty code input box
			llAction.selectByVisibleText("web_list_treatyType", hParams.get("Treaty_Type"));//select item from treaty type list

			dashboard.setStepDetails("Enter Treaty Code and Select Treaty Type",
					"Treaty Code and Treaty Type should be added", ""); //Set the description and expected result for the step(s)
			dashboard.writeResults();//Insert into the DB - ART Dashboard display

			llAction.clickElement("web_btn_searchTreaty"); //click on the search button
			dashboard.setStepDetails("Validate if Search Results are displayed", "Search Results should be displayed",
					"");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex); //throws exception for any failures/errors 
		}
	}
}
