package ge.fpms.main.bpc.bcp.templates;

public interface IPaymentType {

	public static final String DEFAULT_RETURN_CODE = "0000";
	public static final String DEFAULT_RESPONSE_CODE = "F000";
	public String toString();
	
}
