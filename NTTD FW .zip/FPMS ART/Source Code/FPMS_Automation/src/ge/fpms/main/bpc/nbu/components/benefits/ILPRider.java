package ge.fpms.main.bpc.nbu.components.benefits;

import java.util.Hashtable;
import java.util.logging.Logger;

import ge.fpms.main.IFundDetails;
import ge.fpms.main.IRider;
import ge.fpms.main.actions.FPMS_Actions;

public class ILPRider extends MainBenefits implements IRider, IFundDetails {
	private final static Logger LOGGER = Logger
			.getLogger(MainBenefits.class.getName());
	public FPMS_Actions llAction ;

	public ILPRider() {
		llAction = new FPMS_Actions();	
	}

	@Override
	public void addRider(Hashtable<String, String> hParams, int riderId) throws Exception {
		addBenefitsDetails(hParams);
		addFundDetails(hParams);
		save();
		
	}

	@Override
	public void addBenefitsDetails(Hashtable<String, String> hParams) {

		try {
			setBenefitsType(hParams.get("RiderBenefitType"));
			setPremiumCalculatingMethod(hParams.get("RiderPremiumCalculatingMethod"));
			setCoveragePeriod(hParams.get("RiderCoveragePeriod"));

			setCoverageTerm(hParams.get("RiderCoverageTerm"));
			setPremiumPaymentPeriod(hParams.get("RiderPremiumPaymentPeriod"));
			setInitialPremiumFrequency(hParams.get("RiderInitialPremiumFrquency"));
			setInitialSumAssured(hParams.get("RiderInitialSumAssured"));
			setPremiumTerm(hParams.get("RiderPremiumTerm"));
			//setPremiumCalculatingMethod(hParams.get("PremiumCalculatingMethod"));
			setPremiumAmount(hParams.get("RiderPremiumAmount"));
			//setSurrenderVaueInd(hParams.get("SurrenderValueIndicator"));
			//setCashBonusOption(hParams.get("CashBonusOption"));
			//setMarketingDiscount(hParams.get("BenefitType"));
			//setSurvivalOption(hParams.get("SurvivalBenefitOption"));
			//llAction.clickElement("web_btn_saveBn");
		} catch (Exception e) {

			e.printStackTrace();
		}
	}



public void addFundDetails(Hashtable<String, String> hParams) throws Exception{
	SinglePremiumTopup spTopUp = new SinglePremiumTopup(hParams);
	spTopUp.setTopupAmount(hParams.get("RiderSingleTopupAmount"));
	spTopUp.addFunds(hParams);

	RecurringTopup rTopup = new RecurringTopup(hParams);
	rTopup.setTopupAmount(hParams.get("RiderRecurringTopupAmount"));
	rTopup.addFunds(hParams);
}

}
