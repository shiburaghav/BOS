package ge.fpms.main.bpc.nbu.components.loading;

import java.util.Hashtable;

import ge.fpms.main.ILoading;
import ge.fpms.main.actions.FPMS_Actions;

public class HealthLoading implements ILoading {

	private FPMS_Actions llAction;

	public HealthLoading() {
		llAction = new FPMS_Actions();
	}

	@Override
	public void enterSpecificLoadingInfo(Hashtable<String, String> hParams) throws Exception {
		llAction.checkBox_Check("web_uw_chk_HealthLoading");
		llAction.enterValue("web_txt_health_LifeExtraMortality", hParams.get("LifeExtraMortality"));
		llAction.enterValue("web_txt_health_TPDExtraMortality", hParams.get("TPDExtraMortality"));
		llAction.enterValue("web_txt_health_DreadDiseaseExtraMortality", hParams.get("DreadDiseaseExtraMorbidity"));
		llAction.enterValue("web_txt_health_Duration", hParams.get("Duration"));
		llAction.enterValue("web_txt_health_EMValue", hParams.get("EMValue"));
	}
}
