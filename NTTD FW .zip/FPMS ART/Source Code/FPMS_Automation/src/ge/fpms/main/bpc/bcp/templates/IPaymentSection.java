package ge.fpms.main.bpc.bcp.templates;


public interface IPaymentSection {
	
	public String getName();
	
	public Type[] getAllAttributes();

	public int[] getAttributesSize();
	
	public String toString();
	
}
