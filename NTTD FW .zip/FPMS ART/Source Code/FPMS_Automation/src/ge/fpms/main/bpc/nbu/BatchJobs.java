package ge.fpms.main.bpc.nbu;

import ge.fpms.main.AdhocBatchJob;
import ge.fpms.main.BatchJob;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.bcp.BCPComponent;
import ge.fpms.main.bpc.nbu.components.BatchJobFileProcessor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

public class BatchJobs {
	private FPMS_Actions llAction;
	private DashboardHandler dashboard;
	private String downloadPath;
	private static Date batchJobStartTime; // 
	private static ArrayList<BatchJob> batchJobPool;

	public BatchJobs() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		batchJobPool = new ArrayList<BatchJob>();
		downloadPath= System.getProperty("Settings.ART Downloads");
	}

	/**
	 * ExecuteJobs - Run the batch jobs
	 * @param hParams
	 * @throws Exception
	 */
	public void ExecuteJobs(Hashtable<String, String> hParams) throws Exception {
		ArrayList<String> jobList = parseBatchJobString(hParams.get(BatchConstants.BATCH_JOBID));

		for (String jobId : jobList) {

			BatchJob job = runBatchJob(hParams, jobId,jobList.indexOf(jobId));

		}
	}
	
	

	/**
	 * ExecuteAndMonitorJobs - Run and Monitor the batch jobs
	 * @param hParams
	 * @throws Exception
	 */
	public void ExecuteAndMonitorJobs(Hashtable<String, String> hParams) throws Exception{
		batchJobStartTime = Calendar.getInstance().getTime();
	
		ArrayList<String> jobList = parseBatchJobString(hParams.get(BatchConstants.BATCH_JOBID));
		for (String jobId : jobList) {
			BatchJob job = runBatchJob(hParams,jobId,jobList.indexOf(jobId));
			monitorJobs(hParams, job);
			
			llAction.clickElement("web_btn_ExitBatchJobMonitor");
			llAction.waitUntilLoadingCompletes();
		}
		
	}
	
	/**
	 * ExecuteAndMonitorMultiStreamJobs - Process all multistream job transactions
	 * @param hParams
	 * @throws Exception
	 */

	public void ExecuteAndMonitorMultiStreamJobs(Hashtable<String, String> hParams) throws Exception{
		batchJobStartTime = Calendar.getInstance().getTime();
		processMultiStream(hParams);		
	}	

	private void processMultiStream(Hashtable<String, String> hParams) throws Exception{
		ArrayList<String> jobList = parseBatchJobString(hParams.get(BatchConstants.BATCH_JOBID));
		
		for(String jobId : jobList){
			BatchJob job = prepareJob(hParams,jobId);
			if(job.isRunning()){			
				monitorJobs(hParams, job);
			}else if((!job.isRunning()) && job.getStreamCount() == BatchConstants.UNDEFINED){
				job.run();
				monitorJobs(hParams, job);
			}
			
			Hashtable<String, String> multiStream = job.prepareMultiStreamJob();
			
			if(multiStream!=null && multiStream.size() > 0){
				batchJobPool.add(job);
				processMultiStream(multiStream);
			}
		}
	}

	private BatchJob prepareJob(Hashtable<String, String> hParams, String jobIds) throws Exception {

		BatchJob job = null;
		if (jobIds.indexOf("[") >= 0) {
			String jobs = jobIds.substring(1, jobIds.indexOf("]"));
			ArrayList<String> msj = new ArrayList<String>();
			Collections.addAll(msj, jobs.split(","));	
			job = runBatchJob(hParams, msj);

		} else {
			job = runBatchJob(hParams, jobIds);

		}

		return job;

	}
	/**
	 * GenerateDownloadandUploadfileForCPFSA
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	
	public void GenerateDownloadandUploadfileForCPFSA(
			Hashtable<String, String> hParams) {
		try{
//		llAction.selectMenuItem("Billings", "Perform CPF Extraction","Perform CPF Extraction - Generate File");

			ExecuteAndMonitorJobs(hParams);
			processFileForCPFSA(hParams);
		}catch(Exception e){
			throw new BPCException(e);
		}

	}
	/**
	 * GenerateDownloadandUploadfileForCC
	 * 
	 * @param hParams
	 * @throws Exception
	 */
	
	public void GenerateDownloadandUploadfileForCC(Hashtable<String, String> hParams) throws Exception {
		try {
			ExecuteAndMonitorMultiStreamJobs(hParams);
			BCPComponent bcp = new BCPComponent();
			bcp.processFileForCC(BatchConstants.FILE_DOWNLOAD, hParams);
			bcp.processFileForCC(BatchConstants.FILE_UPLOAD, hParams);
			// launch batch query
			llAction.selectMenuItem("System Administration", "Batch Query");
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}
	
	/**
	 * CopyFileToRemoteSite - empty place holder. this will not be implemented
	 * @param hParams
	 * @throws Exception
	 */
	public void CopyFileToRemoteSite(Hashtable<String, String> hParams) throws Exception{
		/*dashboard.setStepDetails("Login to Filezilla and copy file", "Remarks : This test cannot be automated. Hence not implemented","N/A");
		dashboard.writeResults();
		*/
		try{
			BatchJobFileProcessor processor = new BatchJobFileProcessor();
			//processor.copyFileFromRemoteSite(currentMonth, currentDate, currentTime, Boolean.getBoolean(hParams.get("isA_H")), hParams.get("PolicyNo"));
			batchJobStartTime = null;
		} catch (Exception e) {
			throw new BPCException(e);
		}
	}

	
	/**
	 * runBatchJobConfirmFundPrice - updated on 28 Feb 2019
	 * @param hParams
	 * @throws Exception
	 */
	public void runBatchJobConfirmFundPrice(Hashtable<String, String> hParams)
			throws Exception {			
			ExecuteAndMonitorJobs(hParams);					
			
	}


	public void UploadFundPrice(Hashtable<String, String> hParams) throws Exception{
		try{
			llAction.goMenuItem("Finance", "web_batchjobs_menuitem_finance");
			llAction.goMenuItem("Fund Administration","web_batchjobs_menuitem_fund_admin");
			llAction.goMenuItem("Fund Price Entry", "web_batchjobs_menuitem_fp_entry");
			llAction.goMenuItem("Upload Fund Price", "web_batchjobs_menuitem_fp_upload");
			llAction.selectMenuItem("FUND_PRICE_UPLOAD");
			llAction.enterValue("web_batchjobs_fund_effective_price_date",hParams.get("PriceEffectiveDate"));
			String PriceFrequency  = hParams.get("PriceFrequency");
			if (PriceFrequency != null && PriceFrequency != "" ) {
				llAction.selectByVisibleText("web_finance_fund_txt_PriceFrequency", PriceFrequency);
			}
			String csvFile =  hParams.get("CsvFPFileName");
			
			llAction.sendkeyStroke("web_finance_fund_txt_PriceFrequency", Keys.ENTER);
			llAction.enterValue("web_batchjobs_fp_upload_browseFilePath",csvFile);
			llAction.sendkeyStroke("web_batchjobs_fp_upload_browseFilePath", Keys.ENTER);
			llAction.sendkeyStroke("web_batchjobs_fp_upload_browseFilePath", Keys.ENTER);
			llAction.clickElement("web_batchjobs_fund_upload_submit_btn");
			llAction.waitUntilLoadingCompletes();

			if(llAction.isDisplayed("web_batchjob_fund_upload_error_message",3)){
				String text = llAction.getText("web_batchjob_fund_upload_error_message");
				if(text.contains("Error Message")){
					dashboard.setFailStatus(new BPCException(text));
				}
			}
			
				dashboard.setStepDetails("Upload Fund Price", "File is uploaded successfully","N/A");
				dashboard.writeResults();
				llAction.clickElement("web_batchjob_fund_exit");
				llAction.waitUntilLoadingCompletes();
			
		}
		catch (Exception ex){
			dashboard.setFailStatus(new BPCException("Upload Fund Price has failed .. " + ex.getMessage()));
		}


	}

	private BatchJob runBatchJob(Hashtable<String, String> hParams, String jobId, int index)
			throws Exception {

		BatchJob job;
		if (StringUtils.isEmpty(hParams.get(BatchConstants.PARAMETERS))) {

			job = new BatchJob(jobId,
					hParams.get(BatchConstants.BATCH_DUE_DATE),
					hParams.get(BatchConstants.BATCH_PROCESSING_DATE));
		} else {
			String parameters = parseBatchJobString(hParams.get(BatchConstants.PARAMETERS)).get(index).replace("[", "").replace("]", "");
			String[] scheduleId = hParams.get(BatchConstants.SCHEDULE_ID).split(",");
			job = new AdhocBatchJob(jobId,
					scheduleId[index],
					hParams.get(BatchConstants.BATCH_DUE_DATE),
					hParams.get(BatchConstants.BATCH_PROCESSING_DATE),
					parameters);
		}
		job.run();

		return job;
	}
	
	private BatchJob runBatchJob(Hashtable<String, String> hParams, String jobId)
			throws Exception {

		BatchJob job = null;
		if (StringUtils.isEmpty(hParams.get(BatchConstants.PARAMETERS))) {

			job = new BatchJob(jobId,
					hParams.get(BatchConstants.BATCH_DUE_DATE),
					hParams.get(BatchConstants.BATCH_PROCESSING_DATE));
		} 
		job.run();

		return job;
	}
	private BatchJob runBatchJob(Hashtable<String, String> hParams,
			ArrayList<String> multiStreamJobs) throws Exception {
		BatchJob job;

		if (StringUtils.isEmpty(hParams.get(BatchConstants.PARAMETERS))) {

			String jobiD = multiStreamJobs.get(0);
			multiStreamJobs.remove(0);
			job = new BatchJob(jobiD,
					hParams.get(BatchConstants.BATCH_DUE_DATE),
					hParams.get(BatchConstants.BATCH_PROCESSING_DATE),
					multiStreamJobs.toArray(new String[0]));
		} else {

			job = new AdhocBatchJob(hParams.get(BatchConstants.BATCH_JOBNAME),
					hParams.get(BatchConstants.SCHEDULE_ID),
					hParams.get(BatchConstants.BATCH_DUE_DATE),
					hParams.get(BatchConstants.BATCH_PROCESSING_DATE),
					hParams.get(BatchConstants.PARAMETERS));
		}

		BatchJob jobFromPool = isJobAvailable(job.getJobId());
		if (jobFromPool != null) {
			job.setStreamCount(jobFromPool.getStreamCount());
		}

		return job;
	}
	
	
	private void monitorJobs(Hashtable<String, String> hParams,
			BatchJob batchJob) throws Exception {

		llAction.selectMenuItem("System Administration", "Batch Query");
		
		int status = BatchConstants.BATCH_JOB_STATUS_NOT_AVAILABLE;
		int batchQueryTimeout =  Integer.parseInt(System.getProperty("Settings.BatchQueryTimeOut"));
		int batchQueryPollingTimeOut =  Integer.parseInt(System.getProperty("Settings.BatchQueryPollingTime"));
		long currentTime = System.currentTimeMillis();
		
		long maxBatchProcessingTime = currentTime + TimeUnit.SECONDS.toMillis(batchQueryTimeout);

		searchbyJobId(batchJob.getJobId());
		System.out.println("BatchJobs.monitorJobs() maxBatchProcessingTime : " + maxBatchProcessingTime + " currentTime: " + currentTime);
		
		while (currentTime <= maxBatchProcessingTime) {

			status = batchJob.checkBatchJobStatus();
			if (status == BatchConstants.BATCH_JOB_STATUS_SUCCESS || status == BatchConstants.BATCH_JOB_STATUS_FAILED) {
				break;
			} else {
				Utils.sleep(batchQueryPollingTimeOut);
				search();
				currentTime = System.currentTimeMillis();
			}

		}
		if (status != BatchConstants.BATCH_JOB_STATUS_SUCCESS) {
			String log =  batchJob.log() ;
			dashboard.setFailStatus(
					new BPCException("End of Batch Monitoring : " + log
							+ ". Batch query timeout reached. No results available"));
		}
	}

	private void searchbyJobId(String jobId)
			throws Exception {
		llAction.enterValue("web_txt_JobCode",jobId);
		search();
	}
	private void search() throws Exception {
		llAction.clickElement("web_batch_monitoring_search_btn");
		llAction.waitUntilLoadingCompletes();
	}
	
	private void processFileForCPFSA(Hashtable<String, String> hParams) throws Exception{
		
		llAction.selectMenuItem("Billing","Perform CPF Extraction","Perform CPF Extraction - Generate File");
		llAction.waitUntilLoadingCompletes();
		
		llAction.selectByVisibleText("web_batchJob_dwl_cpf_pay_method",hParams.get("Paymentmethod"));
		llAction.enterValue("web_batchJob_dwl_cpf_batchno",hParams.get("BatchNo"));
		
		llAction.clickElement("web_batchJob_dwl_cpf_search_btn");
		llAction.waitUntilLoadingCompletes();
		
		if(llAction.isEnabled("web_batchJob_dwl_cpf_download_datafile")){
			llAction.SelectRowInTable("web_batchJob_dwl_cpf_table", 1, 1,"input");
			llAction.clickElement("web_batchJob_dwl_cpf_download_datafile");
		}
		
	}
	
	private ArrayList<String> parseBatchJobString(String batchJobId){
		//String batchJobId = "643,644,[1443,1444,1445,1446],645,[SC-1443,2001,2002,2003],100,200";
		//String batchJobId = "633,cmu,[1443,1444,1445,1446]";
		ArrayList <String> jobIds = new ArrayList<>();
		String s1="",s2="";
		int lastIndex=batchJobId.length();
		
		while(batchJobId.length()>0){
			lastIndex=batchJobId.length();
			if(batchJobId.contains("[")){
				int startIndex = batchJobId.indexOf("[");
				
				if(startIndex > 1){
				 s1 = batchJobId.substring(0,startIndex);
				 Collections.addAll(jobIds, s1.split(","));				 
				}
				lastIndex = batchJobId.indexOf("]") + 1;
				s2=batchJobId.substring(startIndex,lastIndex);
				jobIds.add(s2);
			}
			else{
				 Collections.addAll(jobIds, batchJobId.split(","));	
			}
			lastIndex = lastIndex + 1 > batchJobId.length() ? lastIndex : lastIndex + 1;
			batchJobId = batchJobId.substring(lastIndex);
		}
		return jobIds;
	}
	
	private BatchJob isJobAvailable(String jobId){
		BatchJob job = null;
		//jobId = jobId.contains("SC-") ? jobId.replace("SC-", "") : jobId;
		
		for(BatchJob bcp : batchJobPool){
			if(bcp.getJobId().equalsIgnoreCase(jobId)){
				job = bcp;
				break;
			}
		}
		return job;
		
	}
	

	/**
	 * checkFilesCreatedAfterBatchRun
	 * @param hParams
	 * @throws Exception
	 */

	public void checkFilesCreatedAfterBatchRun(Hashtable<String, String> hParams) throws Exception{
		try{			
			BatchJobFileProcessor processor = new BatchJobFileProcessor();								
							
			if  (hParams.get("PDFFilePath") != null && hParams.get("PDFFilePath") != "")
			{
				List<String> expPDFFiles = new ArrayList<String>();
				String[] pdfFiles = hParams.get("PDFJobId").split(",");
				expPDFFiles =  Arrays.asList(pdfFiles);
				int PDFfileFoundCount=0;
				processor.copyFilesFromServer(hParams.get("PDFFilePath"),batchJobStartTime);
				
				for(int i=0;i<expPDFFiles.size();i++) {
					if (processor.isPDFCreatedForBatch(downloadPath,expPDFFiles.get(i)))
					{
						PDFfileFoundCount = PDFfileFoundCount+1;
							
					}
					else 
					{
						dashboard.setStepDetails("Batch Job File Processing","PDF file " + expPDFFiles.get(i)+ " is not found successfully in " +hParams.get("CSVFilePath"), "N/A");
						dashboard.writeResults();	
					}						
					
				}
				if (PDFfileFoundCount==0) {
					dashboard.setFailStatus(new BPCException("Batch Job File Processing " + "Failed : No new PDF file generated upon running batch job " ));
				}else if (PDFfileFoundCount < expPDFFiles.size()) {
					dashboard.setWarningStatus("Not All PDF files verified. Expected: " + expPDFFiles.size() + " , Actual : " + PDFfileFoundCount);
				}
				else {
					dashboard.setStepDetails("Batch Job File Processing","All PDF files verified." +hParams.get("PDFFilePath"), "N/A");
					dashboard.writeResults();	
				}		
				
				
			}
			if(hParams.get("CSVFilePath") != null && hParams.get("CSVFilePath") != "")				{
				
				List<String> expFiles = new ArrayList<String>();
				String[] parts = hParams.get("CSVReportIdentifier").split(",");
				expFiles =  Arrays.asList(parts);
				int fileFoundCount=0;
				for(int j=0;j<expFiles.size();j++) {
				
					if(processor.verifyCSVFilesAfterBatchRun(hParams.get("CSVFilePath"), batchJobStartTime, expFiles.get(j)))						
					{
						fileFoundCount = fileFoundCount+1;								
					}
					else {
						dashboard.setStepDetails("Batch Job File Processing","CSV file " + expFiles.get(j)+ " is not found successfully in " +hParams.get("CSVFilePath"), "N/A");
						dashboard.writeResults();	
					}
				
				}
				
				if (fileFoundCount==0) {
					dashboard.setFailStatus(new BPCException("Batch Job File Processing " + "Failed : No new CSV file generated upon running batch job " ));
				}else if (fileFoundCount < expFiles.size()) {
					dashboard.setWarningStatus("Not All CSV files verified. Expected: " + expFiles.size() + " , Actual : " + fileFoundCount);
				}
				else {
					dashboard.setStepDetails("Batch Job File Processing","All CSV files verified." +hParams.get("CSVFilePath"), "N/A");
					dashboard.writeResults();	
				}		
				
				
				}
		
			batchJobStartTime = null;
		
		}
				
		catch (Exception e) {
			throw new BPCException(e);
			
			}
	}
		
	public boolean isFileGenerated(String serverHostName, String serverUserName,
			String serverPassword, String sourceFolderPath, String fileName){ 
		boolean exist = false; 
		try{
			BatchJobFileProcessor fp = new BatchJobFileProcessor();
			
			for(int i = 0; i<3;i++)
			{ 
				
				exist = fp.fileExist(serverHostName, serverUserName, serverPassword, sourceFolderPath,batchJobStartTime, fileName);
				 if(!exist){
					 Utils.sleep(3);
				 }else{
					 break;
				 }
			}
		}catch(Exception e){
			throw new BPCException(e);
		}
	
		return exist;
	}
	
	public ArrayList<String> copyFilesFromRemoteServer(String serverHostName,
			String serverUserName, String serverPassword,
			String sourceFolderPath) throws Exception {
		
		BatchJobFileProcessor fp = new BatchJobFileProcessor();
		ArrayList<String>fileCopied = fp.copyFilesFromServer(serverHostName, serverUserName,serverPassword, sourceFolderPath, batchJobStartTime,false);
		//ArrayList<String>fileCopied = fp.copyFilesFromServer(serverHostName, serverUserName,serverPassword, sourceFolderPath, "Mar", "27", "14:10");
		return fileCopied;
	}
}