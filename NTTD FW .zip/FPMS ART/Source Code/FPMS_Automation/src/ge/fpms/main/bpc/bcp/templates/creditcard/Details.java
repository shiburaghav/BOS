package ge.fpms.main.bpc.bcp.templates.creditcard;

import org.apache.commons.lang3.StringUtils;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.IPaymentType;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Details implements IPaymentSection {

	private Type recordType;
	private Type userAccount;
	private Type lengthofCardNumber;
	private Type cardNumber;
	private Type expiryDate;
	private Type transactionAmount;
	private Type transactionCurrency;
	private Type policyReference;
	private Type billingdate;
	private Type documentNo;
	private Type responseCode;
	private Type responseDescription;

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(Type userAccount) {
		this.userAccount = userAccount;
	}

	public Type getLengthofCardNumber() {
		return lengthofCardNumber;
	}

	public void setLengthofCardNumber(Type lengthofCardNumber) {
		this.lengthofCardNumber = lengthofCardNumber;
	}

	public Type getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(Type cardNumber) {
		this.cardNumber = cardNumber;
	}

	public Type getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Type expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Type getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(Type transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public Type getTransactionCurrency() {
		return transactionCurrency;
	}

	public void setTransactionCurrency(Type transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}

	public Type getPolicyReference() {
		return policyReference;
	}

	public void setPolicyReference(Type policyReference) {
		this.policyReference = policyReference;
	}

	public Type getBillingdate() {
		return billingdate;
	}

	public void setBillingdate(Type billingdate) {
		this.billingdate = billingdate;
	}

	public Type getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(Type documentNo) {
		this.documentNo = documentNo;
	}

	public Type getResponseCode() {
		String val = responseCode.getValue().trim();
		if(StringUtils.isEmpty(val)){
			val = IPaymentType.DEFAULT_RESPONSE_CODE;
			responseCode.setValue(val);
		}
		return responseCode;
	}

	public void setResponseCode(Type responseCode) {
		this.responseCode = responseCode;
	}

	public Type getResponseDescription() {			
		return responseDescription;
	}

	public void setResponseDescription(Type responseDescription) {
		this.responseDescription = responseDescription;
	}
	
	public Details(Type[] type) {
		super();
		this.recordType = new Type(type[0].getSize(), type[0].getDataType(), type[0].getValue(), type[0].getAlignment(),
				type[0].getPaddingChar());
		this.userAccount = new Type(type[1].getSize(), type[1].getDataType(), type[1].getValue(),
				type[1].getAlignment(), type[1].getPaddingChar());
		this.lengthofCardNumber = new Type(type[2].getSize(), type[2].getDataType(), type[2].getValue(),
				type[2].getAlignment(), type[2].getPaddingChar());
		this.cardNumber = new Type(type[3].getSize(), type[3].getDataType(), type[3].getValue(), type[3].getAlignment(),
				type[3].getPaddingChar());
		this.expiryDate = new Type(type[4].getSize(), type[4].getDataType(), type[4].getValue(), type[4].getAlignment(),
				type[4].getPaddingChar());
		this.transactionAmount = new Type(type[5].getSize(), type[5].getDataType(), type[5].getValue(),
				type[5].getAlignment(), type[5].getPaddingChar());
		this.transactionCurrency = new Type(type[6].getSize(), type[6].getDataType(), type[6].getValue(),
				type[6].getAlignment(), type[6].getPaddingChar());
		this.policyReference = new Type(type[7].getSize(), type[7].getDataType(), type[7].getValue(),
				type[7].getAlignment(), type[7].getPaddingChar());
		this.billingdate = new Type(type[8].getSize(), type[8].getDataType(), type[8].getValue(),
				type[8].getAlignment(), type[8].getPaddingChar());
		this.documentNo = new Type(type[9].getSize(), type[9].getDataType(), type[9].getValue(), type[9].getAlignment(),
				type[9].getPaddingChar());
		this.responseCode = new Type(type[10].getSize(), type[10].getDataType(), type[10].getValue(),
				type[10].getAlignment(), type[10].getPaddingChar());
		this.responseDescription = new Type(type[11].getSize(), type[11].getDataType(), type[11].getValue(),
				type[11].getAlignment(), type[11].getPaddingChar());
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(), userAccount.getSize(), lengthofCardNumber.getSize(),
				cardNumber.getSize(), expiryDate.getSize(), transactionAmount.getSize(), transactionCurrency.getSize(),
				policyReference.getSize(), billingdate.getSize(), documentNo.getSize(), responseCode.getSize(),
				responseDescription.getSize() };
	}

	public String getName() {
		return "BD";
	}

	public String toString() {
		String details = new StringBuilder().append(recordType.toString()).append(userAccount.toString())
				.append(lengthofCardNumber.toString()).append(cardNumber.toString()).append(expiryDate.toString())
				.append(transactionAmount.toString()).append(transactionCurrency.toString())
				.append(policyReference.toString()).append(billingdate.toString()).append(documentNo.toString())
				.append(responseCode.toString()).append(responseDescription.toString()).toString();

		return details;
	}

	public Type[] getAllAttributes() {
		return new Type[] { recordType, userAccount, lengthofCardNumber, cardNumber, expiryDate, transactionAmount,
				transactionCurrency, policyReference, billingdate, documentNo, responseCode, responseDescription };
	}
}
