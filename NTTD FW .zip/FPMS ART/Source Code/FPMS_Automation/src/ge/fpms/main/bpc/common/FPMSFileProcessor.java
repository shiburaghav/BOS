package ge.fpms.main.bpc.common;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.io.FileUtils;

import com.nttdata.common.util.ApachePOIUtility;
import com.nttdata.core.TestCase;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.GenericFunctionLevelException;

import ge.fpms.data.BenefitData;
import ge.fpms.data.FPMSARTDao;
import ge.fpms.data.Policy;
import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.FPMSProperties;

public class FPMSFileProcessor {

	public void persistInfo() throws Exception
	{
			if(System.getProperty("Settings.Is NBU Extract Required?").equalsIgnoreCase("Yes"))
			{
				try {
					
				ApachePOIUtility apacheUtils=new ApachePOIUtility();
				PolicyHandler policyHandler =FPMSManager.getInstance().getPolicyHandler();
				//copy template to desired location
				File src=new File(FPMSProperties.getInstance().getNBUExtactTemplate());
				String timestamp=new SimpleDateFormat("ddMMYYHHmm").format(new Date());
				String ouputFileFolderPath=System.getProperty("Settings.ART Downloads")+ File.separator + System.getProperty("Settings.Run Name") + File.separator + FPMSConstants.OUTPUTFILES_FOLDER ;
				DashboardHandler.getInstance().createDirStruct(ouputFileFolderPath);
				String destinationFilePath=ouputFileFolderPath+ File.separator + FPMSConstants.NBUEXTRACTION_FILE_BASENAME +FPMSConstants.NAME_SEPERATOR+timestamp + FPMSConstants.EXCELFILE_FORMAT;
				File dest=new File(destinationFilePath);
				FileUtils.copyFile(src, dest);
				apacheUtils.Xlsx_Reader(destinationFilePath);
				ArrayList<FPMSARTDao> policyList = policyHandler.getPolicyList();

				int rowcount=apacheUtils.getRowCount(FPMSConstants.NBUEXTRACT_SHEETNAME);

				for(int i=0;i<policyList.size();i++)
				{	

					Policy policyobj = policyList.get(i).getPolicy();
					TestCase testCase = policyList.get(i).getTestCase();
					ArrayList<BenefitData> benefitsList = policyobj.getBenefitList();

					for(int j=0;j<benefitsList.size();j++,rowcount++)
					{
						BenefitData benefits = benefitsList.get(j);
						String runName=System.getProperty("Settings.Run Name");
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Run Name", rowcount, runName);
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Test case ID", rowcount, testCase.getId());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Test case name", rowcount, testCase.getName());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Policy Number", rowcount, policyobj.getPolicyNo());

						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Benefit Code", rowcount, benefits.getBenefitCode());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Life Assured Name", rowcount, benefits.getLifeAssured());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Benefit Term", rowcount, benefits.getBenefitTerm());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "SA", rowcount, benefits.getSumAssured());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Next Standard Installment Premium", rowcount, benefits.getStandardPremium());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Next Extra Installment Premium", rowcount, benefits.getExtraPremium());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Benefit Status", rowcount, benefits.getBenefitStatus());

						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Policy Status", rowcount, policyobj.getPolicyStatus());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Commencement Date", rowcount, policyobj.getCommencementDate());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Payment method", rowcount, policyobj.getPaymentMethod());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Payment Frequency", rowcount, policyobj.getPaymentFrequency());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Policy Holder Name", rowcount, policyobj.getPolicyHolder());
						apacheUtils.setCellData(FPMSConstants.NBUEXTRACT_SHEETNAME, "Agent Code", rowcount, policyobj.getAgentCode());

					}	

				}

			}catch (Exception ex) {

				throw new GenericFunctionLevelException(new Exception(String.format("Exception occured while persisting the data into NBU Extract template")));
			}
		}

	}
}
