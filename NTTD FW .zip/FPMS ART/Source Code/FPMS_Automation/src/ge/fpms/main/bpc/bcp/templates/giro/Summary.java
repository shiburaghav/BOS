package ge.fpms.main.bpc.bcp.templates.giro;

import ge.fpms.main.bpc.bcp.templates.IPaymentSection;
import ge.fpms.main.bpc.bcp.templates.Type;

public class Summary implements IPaymentSection {

	private Type recordType;
	private Type totalAcceptedCount;
	private Type totalAcceptedAmountinCents;
	private Type totalRejectedCount;
	private Type totalRejectedAmountinCents;
	private Type totalTransactionCount;
	private Type totalTransactionAmount;
	private Type hashNumber;
	private Type filler1;

	public Type getRecordType() {
		return recordType;
	}

	public void setRecordType(Type recordType) {
		this.recordType = recordType;
	}

	public Type getTotalAcceptedCount() {
		return totalAcceptedCount;
	}

	public void setTotalAcceptedCount(Type totalAcceptedCount) {
		this.totalAcceptedCount = totalAcceptedCount;
	}

	public Type getTotalAcceptedAmountinCents() {
		return totalAcceptedAmountinCents;
	}

	public void setTotalAcceptedAmountinCents(Type totalAcceptedAmountinCents) {
		this.totalAcceptedAmountinCents = totalAcceptedAmountinCents;
	}

	public Type getTotalRejectedCount() {
		return totalRejectedCount;
	}

	public void setTotalRejectedCount(Type totalRejectedCount) {
		this.totalRejectedCount = totalRejectedCount;
	}

	public Type getTotalRejectedAmountinCents() {
		return totalRejectedAmountinCents;
	}

	public void setTotalRejectedAmountinCents(Type totalRejectedAmountinCents) {
		this.totalRejectedAmountinCents = totalRejectedAmountinCents;
	}

	public Type getTotalTransactionCount() {
		return totalTransactionCount;
	}

	public void setTotalTransactionCount(Type totalTransactionCount) {
		this.totalTransactionCount = totalTransactionCount;
	}

	public Type getTotalTransactionAmount() {
		return totalTransactionAmount;
	}

	public void setTotalTransactionAmount(Type totalTransactionAmount) {
		this.totalTransactionAmount = totalTransactionAmount;
	}

	public Type getHashNumber() {
		return hashNumber;
	}

	public void setHashNumber(Type hashNumber) {
		this.hashNumber = hashNumber;
	}

	public Type getFiller1() {
		return filler1;
	}

	public void setFiller1(Type filler1) {
		this.filler1 = filler1;
	}

	public int[] getAttributesSize() {
		return new int[] { recordType.getSize(), totalAcceptedCount.getSize(),
				totalAcceptedAmountinCents.getSize(),
				totalRejectedCount.getSize(),
				totalRejectedAmountinCents.getSize(), hashNumber.getSize(),
				filler1.getSize() };
	}

	public void setParamaters(String[] buffer) {
		recordType.setValue(buffer[0]);
		totalAcceptedCount.setValue(buffer[1]);
		totalAcceptedAmountinCents.setValue(buffer[2]);
		totalRejectedCount.setValue(buffer[3]);
		totalRejectedAmountinCents.setValue(buffer[4]);
		hashNumber.setValue(buffer[5]);
		filler1.setValue(buffer[6]);
	}

	public String getName() {
		return "9";
	}

	public String toString() {

		return new StringBuffer().append(getRecordType().toString())
				.append(getTotalAcceptedCount().toString())
				.append(getTotalAcceptedAmountinCents().toString())
				.append(getTotalRejectedCount().toString())
				.append(getTotalRejectedAmountinCents().toString())
				.append(getTotalTransactionCount().toString())
				.append(getTotalTransactionAmount().toString())
				.append(getHashNumber().toString())
				.append(getFiller1().toString()).toString();
	}

	@Override
	public Type[] getAllAttributes() {
		return null;
	}

}
