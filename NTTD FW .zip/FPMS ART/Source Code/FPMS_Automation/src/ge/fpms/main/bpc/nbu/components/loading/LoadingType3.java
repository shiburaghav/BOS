package ge.fpms.main.bpc.nbu.components.loading;

import java.util.Hashtable;

import ge.fpms.main.ILoadingType;
import ge.fpms.main.actions.FPMS_Actions;

public class LoadingType3 implements ILoadingType{
	
	private FPMS_Actions llAction;

	public LoadingType3() {
		llAction = new FPMS_Actions();
	}
	
	@Override
	public void enterSpecificLoadingTypeInfo(Hashtable<String, String> hParams) throws Exception {
		llAction.enterValue("web_txt_LoadingTypePara1", hParams.get("TimesAnnualPremium"));
		llAction.clickElement("web_uw_btn_calcExtraPremAmt");
	}
}
