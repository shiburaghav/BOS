package ge.fpms.main.bpc.bcp.templates.axs;

public class Axs {
	private Header Header;
	private Details[] Details;
	private Summary Summary;

	public Header getHeader() {
		return Header;
	}

	public void setFH(Header Header) {
		this.Header = Header;
	}

	public Details[] getDetails() {
		return Details;
	}

	public void setDetails(Details[] details) {
		Details = details;
	}

	public Summary getSummary() {
		return Summary;
	}

	public void setSummary(Summary summary) {
		Summary = summary;
	}
}
