package ge.fpms.main.bpc.bcp;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.nttdata.app.ARTProperties;
import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BatchConstants;

public class FPMSPayment {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;
	private String disbursementPayee;
	private String policyStatus;

	public FPMSPayment() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler = FPMSManager.getInstance().getPolicyHandler();
	}

	public void performPayementRequisition(Hashtable<String, String> hParams) throws Exception {
		String policyNumber = StringUtils.EMPTY;

		if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
			policyNumber = hParams.get("PolicyNo");
		} else {
			policyNumber = policyHandler.getPolicy().getPolicyNo();
		}

		paymentPolicySearch(policyNumber, "Payment requisition");
		paymentSelection(hParams);
		updatePaymentSelection(hParams);
	}

	public void performPayementRequisitionTerminated(Hashtable<String, String> hParams) throws Exception {
		String policyNumber = StringUtils.EMPTY;

		if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
			policyNumber = hParams.get("PolicyNo");
		} else {
			policyNumber = policyHandler.getPolicy().getPolicyNo();
		}

		paymentPolicySearch(policyNumber, "Payment requisition");
		paymentSelectionTerminated(hParams);
		updatePaymentSelection(hParams);
	}
	
	private void paymentPolicySearch(String policyNo, String module) throws Exception {
		try {
			if(module.equalsIgnoreCase("Payment requisition")) {
				llAction.selectMenuItem("Online Payment", "Payment requisition");
			}else {
				llAction.selectMenuItem("Online Payment", "Payment authorization");
			}
			
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_PR_txt_PolicyNumber");
			llAction.enterValue("web_PR_txt_PolicyNumber", policyNo);

			llAction.clickElement("web_PR_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();

			dashboard.setStepDetails("Validate if Policy is available in search Results", "Policy should be available",
					policyNo);
			dashboard.writeResults();
			
			int colPos = llAction.GetColumnPositionInTable("web_PR_tbl_SearchResults", "Policy number");
			int rowPos = llAction.GetRowPositionInTable("web_PR_tbl_SearchResults", policyNo, colPos);
			policyStatus = llAction.GetTextFromTable("web_PR_tbl_SearchResults", rowPos, colPos + 2);
			llAction.SelectRowInTable("web_PR_tbl_SearchResults", rowPos, colPos, "a");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void paymentSelection(Hashtable<String, String> hParams) throws Exception {
		try {
			boolean chckBoxStatus = false;
			List<WebElement> options = new ArrayList<WebElement>();
			List<WebElement> amounts = new ArrayList<WebElement>();
			
			List<String> paymentRecordTypes = new ArrayList<String>();
			List<String> paymentAmounts = new ArrayList<String>();
			List<String> disbursementMethods = new ArrayList<String>();
			List<String> selectionTypes = new ArrayList<String>();

			int noOfPaymentRecords = Integer.parseInt(hParams.get("NoOfRecords"));

			for (int i = 1; i <= noOfPaymentRecords; i++) {
				paymentRecordTypes.add(hParams.get("PaymentRecordType" + i + ""));
				paymentAmounts.add(hParams.get("Amount" + i + ""));
				disbursementMethods.add(hParams.get("DisbursementMethod" + i + ""));
				selectionTypes.add(hParams.get("SelectionType" + i + ""));
			}

			for (int j = 0; j < paymentRecordTypes.size(); j++) {
				switch (paymentRecordTypes.get(j).toUpperCase().trim()) {
				case "PAYMENT RECORDS":
					Hashtable<String, String> hTableGUIMap = ARTProperties.guiMap
							.get("web_PR_btn_PaymentSelection_PaymentRecords");
					options = llAction.findElementsByXpath(hTableGUIMap.get(hTableGUIMap.keySet().toArray()[0]));
					break;
				default:
					options = getPaymentRequisitionRecords(paymentRecordTypes.get(j), selectionTypes.get(j), disbursementMethods.get(j));
					amounts = getPayAmountElements(paymentRecordTypes.get(j), selectionTypes.get(j), disbursementMethods.get(j));
					break;
				}
				
				if (!paymentRecordTypes.get(j).toUpperCase().trim().equals("PAYMENT RECORDS")) {
					for (int i = 0; i < amounts.size(); i++) {

						if (StringUtils.isEmpty(paymentAmounts.get(j))) {
							amounts.get(i).clear();
							amounts.get(i).sendKeys("0.00");
						} else {
							amounts.get(i).clear();
							amounts.get(i).sendKeys(paymentAmounts.get(j));
						}
					}
				}
				
				for (WebElement option : options) {
					chckBoxStatus = option.isSelected();

					if (chckBoxStatus != true) {
						option.click();
					}
				}
			}
			llAction.clickElement("web_PR_btn_CalcTotalAmount");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails(
					"Validate if the amount is entered under the right record and for the selected disbursementmode",
					"The amount should be entered under the right record and for the selected disbursementmode",
					"");
			dashboard.writeResults();
			llAction.clickElement("web_PR_btn_SubmitPaymentSelection");
			llAction.acceptAlert((long) 5);
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void paymentSelectionTerminated(Hashtable<String, String> hParams) throws Exception {
		try {
			boolean chckBoxStatus = false;
			boolean recordsNotFound = false;
			List<WebElement> options = new ArrayList<WebElement>();
			List<String> paymentRecordTypes = new ArrayList<String>();
			paymentRecordTypes.add("Payment Records");
			paymentRecordTypes.add("Suspense Records");
			paymentRecordTypes.add("Other Amounts Refundable");
			paymentRecordTypes.add("Debts Outstanding");
			
			String key = StringUtils.EMPTY;
			
			for(String paymentType: paymentRecordTypes) {
				switch(paymentType) {
				case "Payment Records":
					key = "web_PR_PaymentRecords";
					if(llAction.getText(key).trim().equalsIgnoreCase("No payment records found")) {
						recordsNotFound = true;
					}
					break;
				case "Suspense Records":
					key = "web_PR_NoSuspenseRecords";
					if(llAction.getText(key).trim().equalsIgnoreCase("No suspense records found")) {
						recordsNotFound = true;
					}
					break;
				case "Other Amounts Refundable":
					key = "web_PR_NoOtherAmountsRefundableRecords";
					if(llAction.getText(key).trim().equalsIgnoreCase("No other amounts refundable records found")) {
						recordsNotFound = true;
					}
					break;
				case "Debts Outstanding":
					key = "web_PR_DebtsOutstanding";
					if(llAction.getText(key).trim().equalsIgnoreCase("No debts outstanding records found")) {
						recordsNotFound = true;
					}
					break;
				}
				 if(!recordsNotFound){
					options = llAction.findElementsByXpath("web_PR_AllPaymentRecordCheckBoxDummy", new String[] { paymentType });
					for (WebElement option : options) {
						chckBoxStatus = option.isSelected();

						if (chckBoxStatus != true) {
							option.click();
							llAction.handleMultipleAlerts((long) 3);
						}
					}
				}
				 recordsNotFound = false;
			}
			
			llAction.clickElement("web_PR_btn_CalcTotalAmount");
			Utils.sleep(2);
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails(
					"Validate if the amount is entered under the right record and for the selected disbursementmode",
					"The amount should be entered under the right record and for the selected disbursementmode",
					"");
			dashboard.writeResults();
			llAction.clickElement("web_PR_btn_SubmitPaymentSelection");
			llAction.acceptAlert((long) 5);
			llAction.waitUntilLoadingCompletes();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	private List<WebElement> getPaymentRequisitionRecords(String recordType, String suspenseType,
			String disbursementMethod) throws Exception {
		return llAction.findElementsByXpath("web_PR_btn_PaymentSelection_Dummy",
				new String[] { recordType, suspenseType, disbursementMethod });
	}

	private List<WebElement> getPayAmountElements(String recordType, String suspenseType, String disbursementMethod)
			throws Exception {
		return llAction.findElementsByXpath("web_PR_btn_PaymentAmount_Dummy",
				new String[] { recordType, suspenseType, disbursementMethod });
	}

	private void updatePaymentSelection(Hashtable<String, String> hParams) throws Exception {
		try {
			String updateDisbursementMethod = hParams.get("Update_DisbursementMethod");
			String accountNumber = hParams.get("DirectCredit-DisbursementAccountNo");
			String amount = hParams.get("Amount");
			if (!updateDisbursementMethod.trim().toUpperCase().equals("INTERNAL TRANSFER")) {
				llAction.selectByVisibleText("web_PR_lst_DisbursementMethod", updateDisbursementMethod);
			}
			if (StringUtils.isEmpty(amount)) {
				amount = llAction.getText("web_PR_txt_TotalPaymentAmount");
			}

			switch (updateDisbursementMethod.trim().toUpperCase()) {
			case "DIRECT CREDIT":
				llAction.enterValue("web_PR_txt_DisbursementAmount", amount);
				int colPos = llAction.GetColumnPositionInTable("web_PR_tbl_DirectCreditAccount",
						"Account No");
				int rowPos = llAction.GetRowPositionInTable("web_PR_tbl_DirectCreditAccount", accountNumber,
						colPos);
				llAction.SelectRowInTable("web_PR_tbl_DirectCreditAccount", rowPos, 1, "input");
				llAction.clickElement("web_PR_btn_AddPayment");
				llAction.waitUntilLoadingCompletes();
				break;
			case "INTERNAL TRANSFER":
				llAction.enterValue("web_PR_txt_TransferPolicy", hParams.get("PolicyNo"));
				llAction.enterValue("web_PR_txt_TransferAmount", hParams.get("TransferAmount"));
				llAction.selectByVisibleText("web_PR_lst_TransferType", hParams.get("Suspense"));
				llAction.clickElement("web_PR_btn_AddTransferPayment");
				llAction.waitUntilLoadingCompletes();
				break;
			default:
				llAction.enterValue("web_PR_txt_DisbursementAmount", amount);
				llAction.clickElement("web_PR_btn_AddPayment");
				llAction.waitUntilLoadingCompletes();
				break;
			}
			dashboard.setStepDetails("Validate if the amount is entered for the selected disbursementmode",
					"The amount should be entered for the selected disbursementmode", updateDisbursementMethod);
			dashboard.writeResults();
			llAction.clickElement("web_PR_btn_SubmitPaymentRequisition");
			llAction.waitUntilAlertisShown();
			String alertText = llAction.getAlertText();
			llAction.acceptAlert((long) 1);
			if (!alertText.trim().equalsIgnoreCase("Perform allocation successfully!")) {
				dashboard.setFailStatus(
						new BPCException("Success Message not displayed. Message displayed = " + alertText + ""));
			}
			llAction.clickElement("web_PR_btn_ExitPaymentRequisition");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Validate if the user is navigated to Main Page after Submit",
					"User should be navigated to the Main Page", updateDisbursementMethod);
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void authorizePayment(Hashtable<String, String> hParams) throws Exception{
		try {
			String policyNumber = StringUtils.EMPTY;

			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}

			paymentPolicySearch(policyNumber, "Payment authorization");
			decisionOnPayments(hParams);
		}catch(Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	private void decisionOnPayments(Hashtable<String, String> hParams) throws Exception {
		int colPos = 0;
		
		switch(hParams.get("DecisiononPayments").toUpperCase()) {
		case "REJECT":
			llAction.clickElement("web_PA_radio_rejectPayment");
			break;
		case "AUTHORISE":
			llAction.clickElement("web_PA_radio_authorizePayment");
			break;
		}
		
		switch(hParams.get("FilterAmountsByColumn").toUpperCase()) {
		case "BATCH NUMBER":
			colPos = llAction.GetColumnPositionInTable("web_PA_tbl_paymentRecords", "Batch Number");
			break;
		case "GROSS PAYMENT":
			colPos = llAction.GetColumnPositionInTable("web_PA_tbl_paymentRecords", "Gross Payment");
			break;
		case "INTERNAL TRANSFER":
			colPos = llAction.GetColumnPositionInTable("web_PA_tbl_paymentRecords", "Internal Transfer");
			break;
		case "NET PAYMENT":
			colPos = llAction.GetColumnPositionInTable("web_PA_tbl_paymentRecords", "Net Payment");
			break;
		}
		int rowPos = llAction.GetRowPositionInTable("web_PA_tbl_paymentRecords", hParams.get("ValuetobeMatched"), colPos);
		llAction.SelectRowInTable("web_PA_tbl_paymentRecords", rowPos, 1, "input");
		
		if(hParams.get("DecisiononPayments").toUpperCase().equals("REJECT")) {
			colPos = llAction.GetColumnPositionInTable("web_PA_tbl_paymentRecords", "Rejection Reason");
			WebElement ele = llAction.getElementAt("web_PA_tbl_paymentRecords", rowPos, colPos, "//Select");
			Select dropDown = new Select(ele);
			dropDown.selectByVisibleText(hParams.get("RejectReason"));
		}
		
		dashboard.setStepDetails("Validate if the corresponding row is selected under Payment records with the mentioned authorisation",
				"The corresponding row is selected under Payment records with the mentioned authorisation", "");
		dashboard.writeResults();
		
		llAction.clickElement("web_PR_btn_SubmitPaymentDecision");
		llAction.waitUntilAlertisShown();
		String alertText = llAction.getAlertText();
		llAction.acceptAlert((long) 1);
		if (!alertText.trim().equalsIgnoreCase("Authorise payments successfully")) {
			dashboard.setFailStatus(
					new BPCException("Success Message not displayed. Message displayed = " + alertText + ""));
		}
		llAction.waitUntilLoadingCompletes();
		Utils.sleep(5);
		llAction.clickElement("web_PR_btn_ExitPaymentAuthorise");
		llAction.waitUntilLoadingCompletes();
	}
	
	public void chequePrinting(Hashtable<String, String> hParams) throws Exception {

		try {
			llAction.selectMenuItem("Online Payment", "Cheque Printing");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Cheques Printing - Search screen should be displayed",
					"Cheques Printing - Search  screen is displayed", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_PR_txt_PolicyNumber", hParams.get("PolicyNo"));
			llAction.clickElement("web_PR_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_CP_lnk_policyNumber", "web_search_policynumber",
					new String[] { hParams.get("PolicyNo") });
			if (llAction.isDisplayed("web_search_policynumber", 5)) {
				dashboard.setStepDetails("Policy should be displayed in search result",
						"Policy is displayed in search result", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_search_policynumber");
				llAction.waitUntilLoadingCompletes();

				int noOfCheques = StringUtils.isNotBlank(hParams.get("Numberofchequestoprint"))
						? Integer.parseInt(hParams.get("Numberofchequestoprint"))
						: 0;
				if (noOfCheques > 0) {
					for (int i = 1; i <= noOfCheques; i++) {
						llAction.SelectRowInTable("web_CP_tbl_cheque_table", i + 1, 1, "input");
					}
				} else {
					llAction.checkBox_Check("web_CP_chkBox_cheque_selectAll");
				}
				llAction.checkBox_Check("web_CP_chkBox_cheque_consolidated");
				llAction.enterValue("web_CP_chkBox_cheque_startNumber", hParams.get("ChequeNumber"));
				dashboard.setStepDetails("Select cheque and enter details",
						"Cheque should be selected and details are filled in", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_PR_btn_SubmitPaymentRequisition");
				llAction.waitUntilLoadingCompletes();
				Utils.executeScript(".\\resources\\WaitForAcrobatReader.exe");
				dashboard.setStepDetails("Acrobat Reader window should be displayed",
						"Acrobat Reader window is displayed", "N/A");
				dashboard.writeResults();
				Utils.executeScript(".\\resources\\selectYesAcrobatReader.exe");
				dashboard.setStepDetails("Acrobat Reader window should be displayed",
						"Acrobat Reader window is displayed", "N/A");
				dashboard.writeResults();
				
				llAction.clickElement("web_EB_btn_ExtractionBack");

			} else {
				throw new BPCException("No Records found for the policy search in cheque printing");
		}



		} catch (Exception ex) {
			throw new BPCException(ex);

		}
	}

	public void changePaymentDetails(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("Online Payment","Change Payment Details");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Change Payment Details - Search screen should be displayed",
					"Change Payment Details - Search  screen is displayed", "N/A");
			dashboard.writeResults();
			llAction.enterValue("web_PR_txt_PolicyNumber", hParams.get("PolicyNo"));
			Utils.editXpath("web_CP_rad_changepaymenttype", "web_CP_rad_selectpaymenttype", new String[] {hParams.get("ChangePayment")});
			llAction.clickElement("web_CP_rad_selectpaymenttype");
			dashboard.setStepDetails("Enter Policy and select Payment Details to be changed for",
					"Payment details is selected and policy is entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_PR_btn_SearchPolicy");
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_CP_lnk_policyNumber", "web_search_policynumber",
					new String[] { hParams.get("PolicyNo") });
			if (llAction.isDisplayed("web_search_policynumber", 5)) {
				dashboard.setStepDetails("Policy should be displayed in search result",
						"Policy is displayed in search result", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_search_policynumber");
				llAction.waitUntilLoadingCompletes();				
			}
			else
			{
				throw new BPCException("Search result did not find record");
			}
			dashboard.setStepDetails("Change Payment Details - Payment Selection screen should be displayed",
					"Change Payment Details - Payment Selection screen is displayed", "N/A");
			dashboard.writeResults();	
			Utils.editXpath("web_CP_rad_selectpolicy", "web_CP_rad_selectpolicynumber", new String[] {hParams.get("PolicyNo"),hParams.get("DisbursementMethod"),hParams.get("PayAmount")});
			llAction.clickElement("web_CP_rad_selectpolicynumber");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Select payment change record",
					"Payment change record is selected", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_PR_btn_SubmitPaymentRequisition");
			llAction.waitUntilLoadingCompletes();
			selectPaymentDetails(hParams);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void selectPaymentDetails(Hashtable<String, String> hParams) throws Exception {
		try {
			switch(hParams.get("ChangePayment"))
			{
			case "Change Disbursement Payee":
				dashboard.setStepDetails("Change Payment Details - Update screen should be displayed",
						"Change Payment Details - Update screen is displayed", "N/A");
				dashboard.writeResults();
				llAction.selectByVisibleText("web_CP_select_partyIDType", hParams.get("PartyIDType"));
				llAction.enterValue("web_CP_txt_party", hParams.get("PartyIDNumber"));
				llAction.clickElement("web_CP_btn_retrievedetails");
				llAction.waitUntilLoadingCompletes();
				llAction.switchtoChildWindow("Disbursement Payee - Search");
				llAction.waitUntilLoadingCompletes();
				llAction.handleCertificateErrors();
				Utils.editXpath("web_CP_rad_selectdisbursmentPayee", "web_CP_lnk_selectdsibursmentPayee", new String[] {hParams.get("PartyIDNumber"),hParams.get("PartyIDType")});
				dashboard.setStepDetails("Disbursment Payee search result should be displayed",
						"Disbursment Payee record is displayed", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_CP_lnk_selectdsibursmentPayee");
				llAction.switchtoDefaultWindow();
				dashboard.setStepDetails("Select Disbursment Payee",
						"Disbursment Payee is selected successfully", "N/A");
				dashboard.writeResults();
				
				break;
			case "Change Payment Bank Account":
				
				dashboard.setStepDetails("Change Payment Details - Update screen should be displayed",
						"Change Payment Details - Update screen is displayed", "N/A");
				dashboard.writeResults();
				List<String> list = llAction.getDropDownList("web_CP_select_acno");
				for(String value : list)
				{
					if(value.trim().equalsIgnoreCase(hParams.get("BankAccountNumber")))
					{
						llAction.selectByVisibleText("web_CP_select_acno", value);
						break;
					}
				}
				
				dashboard.setStepDetails("Select new bank account number",
						"New bank account number is selected", "N/A");
				dashboard.writeResults();
				break;
			case "Change Disbursement Method":
				dashboard.setStepDetails("Change Disbursement Method - Update screen should be displayed",
						"Change Disbursement Method - Update screen is displayed", "N/A");
				dashboard.writeResults();
				llAction.selectByVisibleText("web_CP_select_disbursment_method", hParams.get("ChangeDisbursmentMethod"));
				dashboard.setStepDetails("Disbursment method should be selected",
						"New Disbursment method is selected", "N/A");
				dashboard.writeResults();
				break;
			}
			llAction.clickElement("web_PR_btn_SubmitPaymentRequisition");							
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_EB_btn_ExtractionExit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Change Payment Details - should be displayed",
					"Change Payment Details - is displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_EB_btn_ExtractionExit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Home screen should be displayed",
					"Home screen is displayed", "N/A");
			dashboard.writeResults();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void cancelPayment(Hashtable<String, String> hParams) throws Exception {
		try {
			llAction.selectMenuItem("Online Payment","Cancel Payment");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Navigate to Cancel Payment screen should be displayed",
					"Cancel Payment screen", "N/A");
			llAction.enterValue("web_PR_txt_PolicyNumber", hParams.get("PolicyNo"));
			llAction.selectByVisibleText("web_CP_select_cancel_reason", hParams.get("CancelReason"));
			dashboard.setStepDetails("Enter Policy and select Payment Details to be changed for",
					"Payment details is selected and policy is entered", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_PR_btn_SearchPolicy");			
			llAction.waitUntilLoadingCompletes();
			Utils.editXpath("web_CP_lnk_policyNumber", "web_search_policynumber",
					new String[] { hParams.get("PolicyNo") });
			if (llAction.isDisplayed("web_search_policynumber", 5)) {
				dashboard.setStepDetails("Policy should be displayed in search result",
						"Policy is displayed in search result", "N/A");
				dashboard.writeResults();
				llAction.clickElement("web_search_policynumber");
				llAction.waitUntilLoadingCompletes();				
			}
			else
			{
				throw new BPCException("Search result did not find record");
			}
			Utils.editXpath("web_CP_chk_selectpolicy", "web_CP_chk_selectpolicynumber", new String[] {hParams.get("PolicyNo"),hParams.get("DisbursementMethod"),hParams.get("PayAmount")});
			llAction.clickElement("web_CP_chk_selectpolicynumber");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Click on policy number link",
					"policy details should be displayed", "N/A");
			dashboard.writeResults();
			llAction.clickElement("web_PR_btn_SubmitPaymentRequisition");							
			llAction.acceptAlert();
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_EB_btn_ExtractionExit");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("Home screen should be displayed",
					"Home screen is displayed", "N/A");
			dashboard.writeResults();

		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void cancelRewards(Hashtable<String, String> hParams) throws Exception {
		llAction.selectMenuItem("Batch Payment","Upload & Cancel Rewards File");
		llAction.waitUntilLoadingCompletes();
		
		llAction.enterValue("web_payment_cancelrewards_batchNo", hParams.get("BatchNo"));
		llAction.enterValue("web_payment_cancelrewardsdate", hParams.get("UpdateCancelDate"));
		dashboard.setStepDetails("Upload & Cancel Rewards File",
				"About to cancel rewards", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_payment_cancelrewardsbtn");
		
		String alertText = llAction.getAlertText();
		if(alertText.equalsIgnoreCase(BatchConstants.CANCEL_REWARDS_SUCCESS_TXT)){
			dashboard.setStepDetails("Upload & Cancel Rewards File",
					"Rewards cancelled successfully", "N/A");
			dashboard.writeResults();
			llAction.acceptAlert();
		}else{
			dashboard.setFailStatus(new BPCException("Cancellation Failed"));
		}
		
		dashboard.setStepDetails("Upload & Cancel Rewards File",
				"About to click on exit button", "N/A");
		dashboard.writeResults();
		llAction.clickElement("web_payment_cancel_exitrewardsbtn");
		llAction.waitUntilLoadingCompletes();	
	}
	
	public void uploadRewards(Hashtable<String, String> hParams) throws Exception {
		llAction.selectMenuItem("Batch Payment","Upload & Cancel Rewards File");
		llAction.waitUntilLoadingCompletes();
		
		
		llAction.selectByVisibleText("web_payment_uploadrewardscampaignCode",hParams.get("CampaignCode"));

		//llAction.enterValue("web_payment_uploadrewards_batchNo", hParams.get("BatchNo"));
		llAction.enterValue("web_payment_uploadrewardsdate", hParams.get("UpdateCancelDate"));
		
		llAction.enterValue("web_batchJob_upload_cc_browseBtn",hParams.get("UploadFilePath"));
		llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
		llAction.sendkeyStroke("web_batchJob_upload_cc_browseBtn", Keys.ENTER);
		dashboard.setStepDetails("Upload & Cancel Rewards File", "File is uploaded. About to validate" ,"N/A");
		dashboard.writeResults();
		
		if(llAction.isEnabled("web_payment_validaterewardsbtn")){
			llAction.clickElement("web_payment_validaterewardsbtn");
			llAction.acceptAlert();
			dashboard.setStepDetails("Upload & Cancel Rewards File", "File is valid. About to submit" ,"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_payment_submitrewardsbtn");
			llAction.acceptAlert((long)1);
			llAction.waitUntilLoadingCompletes();	
			dashboard.setStepDetails("Upload & Cancel Rewards File", "About to click on exit button" ,"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_payment_update_exitrewardsbtn");
			llAction.waitUntilLoadingCompletes();	
		}else{
			dashboard.setFailStatus(new BPCException("Upload & Cancel Rewards File - Validate Failed!! - File is invalid!!"));
		}
	}
	
	public void PaymentCancellationExpiry(Hashtable<String, String> hParams) throws Exception {
	
			llAction.selectMenuItem("Batch Payment","Payment Cancellation&Expiry");
			llAction.waitUntilLoadingCompletes();	
			llAction.enterValue("web_payment_cancellation_policyNo", hParams.get("PolicyNo"));
			llAction.enterValue("web_payment_cancellation_batchNo", hParams.get("BatchNo"));
			llAction.selectByVisibleText("web_payment_cancellation_disbursement_method",hParams.get("CancelDisbursementMethod"));
			dashboard.setStepDetails("Batch Payment - Payment Cancellation&Expiry", "About to search based on batch number or policynumber" ,"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_query_btn_Search");
			llAction.waitUntilLoadingCompletes();	
			
			llAction.selectByVisibleText("web_payment_canceltype",hParams.get("CancellationType"));
			llAction.clickElement("web_payment_canceloptionbox");
			dashboard.setStepDetails("Batch Payment - Payment Cancellation&Expiry", "Selected the records for cancellation. About to click on submit" ,"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_payment_cancellation_submit");
			llAction.waitUntilLoadingCompletes();	
			dashboard.setStepDetails("Batch Payment - Payment Cancellation&Expiry", "About to click on exit" ,"N/A");
			dashboard.writeResults();
			llAction.clickElement("web_PR_btn_ExitPaymentRequisition");
			llAction.waitUntilLoadingCompletes();	
			
	}
	
	//not complete
	public void batchChequePrinting(Hashtable<String, String> hParams) throws Exception {
		
		llAction.selectMenuItem("Batch Payment","Batch Cheque Printing");
		llAction.waitUntilLoadingCompletes();	
		llAction.enterValue("web_batch_cheque_print_policyNo", hParams.get("PolicyNo"));
		llAction.enterValue("web_batch_cheque_print_batchNo", hParams.get("BatchNo"));
		
		llAction.clickElement("web_query_btn_Search");
		llAction.waitUntilLoadingCompletes();	
		
		llAction.selectByVisibleText("web_payment_canceltype",hParams.get("CancellationType"));
		llAction.clickElement("feeid");
		llAction.clickElement("web_payment_cancellation_submit");
		llAction.waitUntilLoadingCompletes();	
		llAction.clickElement("web_PR_btn_ExitPaymentRequisition");
		llAction.waitUntilLoadingCompletes();	
		
}
}
