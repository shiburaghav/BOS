package ge.fpms.main.bpc.nbu.negative;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.nttdata.common.util.Utils;
import com.nttdata.core.handler.DashboardHandler;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.data.PolicyHandler;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.ILoading;
import ge.fpms.main.ILoadingType;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BusinessComponent;
import ge.fpms.main.bpc.nbu.LoadingFactory;
import ge.fpms.main.bpc.nbu.components.AMLAdmin;
import ge.fpms.main.bpc.nbu.components.LoadingComponent;

public class Underwriting extends BusinessComponent {
	FPMS_Actions llAction = new FPMS_Actions();
	private DashboardHandler dashboard;
	private PolicyHandler policyHandler;

	public Underwriting() {
		llAction = new FPMS_Actions();
		dashboard = DashboardHandler.getInstance();
		policyHandler= FPMSManager.getInstance().getPolicyHandler();
	}

	public void performUnderwriting_N(Hashtable<String, String> hParams) throws Exception {
		try {
			UnderwritingSearchPolicy(hParams);
			MakeUnderwritingBenefitDecision(hParams);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: UnderwritingSearchPolicy Purpose: Navigate to Underwriting Page from
	 * the Main Page and Search a Policy to Underwrite. Select Policy based on the
	 * Plan Code For Underwriting From the Search Results Parameters: Parameter Hash
	 * table Return Value: NA Exception: BPCException Added By: ManjuPrasad 0n
	 * 22/11/2018
	 */
	public void UnderwritingSearchPolicy(Hashtable<String, String> hParams) throws Exception {
		String policyNumber = null;
		try {
			if (StringUtils.isEmpty(policyHandler.getPolicy().getPolicyNo())) {
				policyNumber = hParams.get("PolicyNo");
			} else {
				policyNumber = policyHandler.getPolicy().getPolicyNo();
			}
			llAction.selectMenuItem("NBD", "underwriting");
			llAction.clickElement("web_uw_txt_PolicyNo");
			llAction.enterValue("web_uw_txt_PolicyNo", policyNumber);
			Utils.sleep(5);
			llAction.clickElement("web_uw_btn_Search");
			llAction.waitUntilLoadingCompletes();
			llAction.move_to_element("web_uw_tbl_USPSearchPolicyList");
			System.out.println("PerformUnderwriting.UnderwritingSearchPolicy() policyNumber : " + policyNumber);

			int colPos = llAction.GetColumnPositionInTable("web_uw_tbl_USPSearchPolicyList", "Policy No.");
			int rowPos = llAction.GetRowPositionInTable("web_uw_tbl_USPSearchPolicyList", policyNumber, colPos);
			llAction.SelectRowInTable("web_uw_tbl_USPSearchPolicyList", rowPos, colPos, "a");

			llAction.waitUntilElementPresent("web_uw_check_UnderwritingOption_SelectAll");
			llAction.waitUntilLoadingCompletes();
			dashboard.setStepDetails("In Underwriting Sharing Pool Search for Policy Number  " + policyNumber,
					"The Policy Should be Available in Search Results. ", "N/A");
			dashboard.writeResults();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	/*
	 * Name: MakeUnderwritingBenefitDecision Purpose: Select All Benefits for
	 * Underwriting Decision Table. Click on Make Benefits Decision Button.
	 * Accept/Conditionally Accept/Postpone/Decline a Benefit based on the Input and
	 * Submit. Parameters: Parameter Hash table Return Value: NA Exception:
	 * BPCException Added By: ManjuPrasad 0n 22/11/2018
	 */
	public void MakeUnderwritingBenefitDecision(Hashtable<String, String> hParams) throws Exception {
		try {
			String UnderwritingDecision = hParams.get("UnderwritingDecision");
			String[] options = hParams.get("UWDocsToBeSelected").split(",");
			
			for (int i = 0; i < options.length; i++) {
				Utils.editXpath("web_uw_DecisionBenefitName", "web_uw_" + options[i] + "",
						new String[] { options[i] });
				llAction.checkBox_Check("web_uw_" + options[i] + "");

				llAction.move_to_element("web_uw_btn_MBenefitDec");
				llAction.clickElement("web_uw_btn_MBenefitDec");

				llAction.waitUntilElementPresent("web_uw_txt_UWDec");
				llAction.waitUntilLoadingCompletes();
				
				switch (UnderwritingDecision.trim().toUpperCase()) {
				case "CONDITIONALLY ACCEPTED":
					llAction.move_to_element("web_uw_txt_UWDec");
					llAction.enterValue("web_uw_txt_UWDec", "2");
					llAction.clickElement("web_uw_txt_UWPreviousUnderwriter");

					dashboard.setStepDetails("Conditionally Accept the Underwriting by entering 2",
							"User should be able to enter 2 and Conditionally Accept the Underwriting  ", "N/A");
					dashboard.writeResults();
					EnterExtraLoading(hParams, (i+1));
					break;
				}
				llAction.clickElement("web_uw_makeBenefitDecisionCancel");
			}
			llAction.clickElement("web_uw_makeBenefitDecisionCancel");
			llAction.waitUntilLoadingCompletes();
			llAction.clickElement("web_uw_btn_UWSPExit");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	public void EnterExtraLoading(Hashtable<String, String> hParams, int productIndex) throws Exception {
		
		try {
			String loadingOption = hParams.get("LoadingOption");
			String loadingTable = StringUtils.EMPTY;
			String loadingBlock = StringUtils.EMPTY;
			goToLoading();
			switch (loadingOption.toUpperCase()) {
			case "HEALTH LOADING":
				llAction.checkBox_Check("web_uw_chk_HealthLoading");
				loadingTable = "healthTable";
				loadingBlock = "A1";
				break;
			case "OCCUPATION LOADING":
				llAction.checkBox_Check("web_uw_chk_occupationLoading");
				loadingTable = "occupationTable";
				loadingBlock = "B1";
				break;
			case "AVOCATION LOADING":
				llAction.checkBox_Check("web_uw_chk_avocationLoading");
				loadingTable = "avocationTable";
				loadingBlock = "C1";
				break;
			case "RESIDENTIAL LOADING":
				llAction.checkBox_Check("web_uw_chk_residentialLoading");
				loadingTable = "residentialTable";
				loadingBlock = "D1";
				break;
			case "AVIATION LOADING":
				llAction.checkBox_Check("web_uw_chk_aviationLoading");
				loadingTable = "aviationTable";
				loadingBlock = "E1";
				break;
			case "OTHER LOADING":
				llAction.checkBox_Check("web_uw_chk_otherLoading");
				loadingTable = "otherTable";
				loadingBlock = "F1";
				break;
			}
			
			String[] loadingTypes = hParams.get("LoadingType"+productIndex+"").split(",");
			for(String type: loadingTypes) {
				Utils.editXpath("web_uw_txt_loadingType", "web_uw_txt_loadingType"+type+"", new String[] {loadingTable, loadingBlock});
				List<WebElement> ele = llAction.findElements("web_uw_txt_loadingType"+type+"");
				ele.get(0).sendKeys(type);
				llAction.handleMultipleAlerts((long) 2);
				ele.get(0).sendKeys(Keys.ENTER);
				boolean flag = validateLoadingErrorMessage();
				if(flag == false) {
					dashboard.setFailStatus(new BPCException("Error Message: Loading Type Disallowed on benefit noty displayed"));
				}
				ele.get(0).clear();
				llAction.waitUntilLoadingCompletes();
			}
			llAction.clickElement("web_uw_extraLoadingCancel");
			llAction.waitUntilLoadingCompletes();
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public boolean validateLoadingErrorMessage() throws Exception{
		try {
			boolean flag = false;
			String errorMessage = StringUtils.EMPTY;
			errorMessage = llAction.handleMultipleAlertsAndReturnText((long) 2);
			if(errorMessage.equalsIgnoreCase("Loading Type Disallowed on benefit")) {
				flag = true;
			}
			return flag;
		}catch(Exception ex) {
			throw new BPCException(ex);
		}
	}
	
	public void goToLoading() throws Exception {
		try {
			llAction.clickElement("web_uw_btn_extraloading");
			llAction.waitUntilLoadingCompletes();
			if (llAction.isDisplayed("web_btn_continue", 5)) {
				llAction.clickElement("web_btn_continue");
				llAction.waitUntilLoadingCompletes();
			}
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	
}

