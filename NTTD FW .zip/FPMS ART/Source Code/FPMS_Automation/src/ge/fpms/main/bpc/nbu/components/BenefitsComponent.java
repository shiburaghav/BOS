package ge.fpms.main.bpc.nbu.components;

import java.util.Hashtable;

import org.openqa.selenium.Keys;

import com.nttdata.common.util.Utils;
import com.nttdata.framework.exceptions.BPCException;

import ge.fpms.main.FPMSConstants;
import ge.fpms.main.FPMSManager;
import ge.fpms.main.IBenefits;
import ge.fpms.main.IRider;
import ge.fpms.main.ProductConstants;
import ge.fpms.main.actions.FPMS_Actions;
import ge.fpms.main.bpc.nbu.BenefitsFactory;
import ge.fpms.main.bpc.nbu.BusinessComponent;
import ge.fpms.main.bpc.nbu.components.benefits.ILPRider;
import ge.fpms.main.bpc.nbu.components.benefits.RiderBenefits;

public class BenefitsComponent extends BusinessComponent {

	private FPMS_Actions llAction;

	public BenefitsComponent() {
		llAction = new FPMS_Actions();
	}

	public void addBenefits(Hashtable<String, String> hParams) throws Exception {
		// assumption: even if there's no data in testdata, we shall launch benefits
		// screen and do a save. hence commented this check

		// String mainBenefitsType = hParams.get("BenefitType");
		// if (mainBenefitsType != null && mainBenefitsType != "") {

		llAction.clickElementJs("web_link_Benefit");
		String productType = hParams.get("ProductType");
		try {
			llAction.handleCertificateErrors();
			llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_PRODUCT_INFO, "");
			llAction.maximizeWindow();
			
			// Add MAIN Benefit Information
			IBenefits benefits = BenefitsFactory.getInstance().createBenefits(productType);
			benefits.addBenefitsDetails(hParams);
			// Add Rider Benefits Information
			addRiderDetails(hParams);
		} catch (Exception ex) {
			throw new BPCException(ex);
		}
	}

	private void addRiderDetails(Hashtable<String, String> hParams) throws Exception {
		String nRiders = hParams.get("NoOfRiders").trim();
		String productType = hParams.get("ProductType");
		if (nRiders != null && nRiders != "") {
			int riderCount = Integer.parseInt(nRiders);
			for (int i = 0; i < riderCount; i++) {
				IRider riderBenefits = null;
				if (productType.equalsIgnoreCase(ProductConstants.ILP)) {
					riderBenefits = new ILPRider();
				} else {
					riderBenefits = new RiderBenefits();
				}
				llAction.clickElement("web_btn_BenefitAdd");// adding rider details
				llAction.handleCertificateErrors();
				llAction.switchtoChildWindow(FPMSConstants.WINDOW_TITLE_PRODUCT_INFO);
				llAction.maximizeWindow();

				llAction.enterValue("web_txt_BenefitType", hParams.get("RiderBenefitType"));
				llAction.sendkeyStroke("web_txt_BenefitType", Keys.ENTER);
				Utils.sleep(6);
				FPMSManager.getInstance().getEvtHandler().setCurrentContext(FPMSConstants.RIDER_CXT);
				riderBenefits.addRider(hParams, i);
			}
		}
	}
}
