package ge.fpms.data;

public class BenefitData {
	private String planCode;
	private String benefitCode;
	private String lifeAssured;
	private String sumAssured;
	private String standardPremium;
	private String extraPremium;
	private String benefitStatus;
	public void setplanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getplanCode() {
		return planCode;
	}
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}
	public String getBenefitCode() {
		return benefitCode;
	}
	public void setLifeAssured(String lifeAssured) {
		this.lifeAssured = lifeAssured;
	}
	public String getLifeAssured() {
		return lifeAssured;
	}
	public void setBenefitTerm(String benefitStatus) {
		this.benefitStatus = benefitStatus;
	}
	public String getBenefitTerm() {
		return benefitStatus;
	}
	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}
	public String getSumAssured() {
		return sumAssured;
	}
	public void setStandardPremium(String standardPremium) {
		this.standardPremium = standardPremium;
	}
	public String getStandardPremium() {
		return standardPremium;
	}
	public void setExtraPremium(String extraPremium) {
		this.extraPremium = extraPremium;
	}
	public String getExtraPremium() {
		return extraPremium;
	}
	public void setBenefitStatus(String benefitStatus) {
		this.benefitStatus = benefitStatus;
	}
	public String getBenefitStatus() {
		return benefitStatus;
	}
	
}