package ge.fpms.data;

public class RIQueriByContractData {
	private String riContractID;
	private String riContractRiskType;
	private String riContractProductCode;
	private String riContractPolicyNumber;
	private String riContractStatus;
	
	public String getRiContractID() {
		return riContractID;
	}

	public void setRiContractID(String riContractID) {
		this.riContractID = riContractID;
	}

	public String getRiContractRiskType() {
		return riContractRiskType;
	}

	public void setRiContractRiskType(String riContractRiskType) {
		this.riContractRiskType = riContractRiskType;
	}

	public String getRiContractProductCode() {
		return riContractProductCode;
	}

	public void setRiContractProductCode(String riContractProductCode) {
		this.riContractProductCode = riContractProductCode;
	}

	public String getRiContractPolicyNumber() {
		return riContractPolicyNumber;
	}

	public void setRiContractPolicyNumber(String riContractPolicyNumber) {
		this.riContractPolicyNumber = riContractPolicyNumber;
	}

	public String getRiContractStatus() {
		return riContractStatus;
	}

	public void setRiContractStatus(String riContractStatus) {
		this.riContractStatus = riContractStatus;
	}
}
