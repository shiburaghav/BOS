package ge.fpms.data;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import ge.fpms.data.BenefitData;
import ge.fpms.data.CSDData;
import ge.fpms.data.Policy;

public class PolicyHandler {
	private Policy policy;
	private CSDData csd;
	private BenefitData benefit;
	private ArrayList<FPMSARTDao> policyList;
	private RIQueriByPolicyData riQueriByPolicyData;
	private RIQueriByContractData rIQueriByContractData;
	private List<RIQueriByPolicyData> listRIQueriByPolicyData = new ArrayList<RIQueriByPolicyData>();
	private List<RIQueriByContractData> listRIQueriByContractData = new ArrayList<RIQueriByContractData>();

	public PolicyHandler() {
		policyList = new ArrayList<FPMSARTDao>();
	}

	public void initializePolicy() {
		createPolicy();
	}

	public void updatePolicy(String propertyName, String value) throws Exception {
		createPolicy();
		// update(policy,popertyName,value);
		// update(csd,popertyName,value);
		update(policy, propertyName, value);
	}

	public void addPolicytoList(FPMSARTDao artDao)

	{
		policyList.add(artDao);
		policy = null;
	}

	private void update(Object obj, String popertyName, String value) throws Exception {
		String methodName = "set" + popertyName;
		Method method = obj.getClass().getMethod(methodName, String.class);
		method.invoke(obj, value);

	}

	private void createPolicy() {

		if (policy == null) {
			policy = new Policy();

		}
		// csd = new CSDData();
		// benefit = new BenefitData();

	}

	public void setQueryRIByPolicyData(String riStatus, String productCode, String riskType, String riDueDate,
			String riPolicyNumber, String riSumAssured) {
		riQueriByPolicyData = new RIQueriByPolicyData();
		riQueriByPolicyData.setRIStatus(riStatus);
		riQueriByPolicyData.setProductCode(productCode);
		riQueriByPolicyData.setRiskType(riskType);
		riQueriByPolicyData.setRIDueDate(riDueDate);
		riQueriByPolicyData.setRIPolicyNumber(riPolicyNumber);
		riQueriByPolicyData.setRiSumAssured(riSumAssured);
		listRIQueriByPolicyData.add(riQueriByPolicyData);
	}

	public RIQueriByPolicyData getQueryRIByPolicyData() throws Exception {
		if (riQueriByPolicyData != null) {
			return riQueriByPolicyData;
		} else {
			return null;
		}
	}

	public Boolean isPolicyEmpty() {

		String policyNo = "";
		if (policy != null) {
			policyNo = policy.getPolicyNo();
		}
		return policyNo == null ? true : policyNo.isEmpty();
	}

	public ArrayList<FPMSARTDao> getPolicyList() {
		// TODO Auto-generated method stub
		return policyList;
	}

	public Policy getPolicy() {

		return policy;
	}

	public RIQueriByContractData getrIQueriByContractData() {
		return rIQueriByContractData;
	}

	public void setrIQueriByContractData(String riContractID, String productCode, String riskType,
			String riContractStatus, String policynumber) {
		rIQueriByContractData = new RIQueriByContractData();
		rIQueriByContractData.setRiContractID(riContractID);
		rIQueriByContractData.setRiContractProductCode(productCode);
		rIQueriByContractData.setRiContractRiskType(riskType);
		rIQueriByContractData.setRiContractPolicyNumber(policynumber);
		rIQueriByContractData.setRiContractStatus(riContractStatus);
		listRIQueriByContractData.add(rIQueriByContractData);
	}

	public List<RIQueriByPolicyData> getListRIQueriByPolicyData() {
		return listRIQueriByPolicyData;
	}

	public List<RIQueriByContractData> getListRIQueriByContractData() {
		return listRIQueriByContractData;
	}
}
