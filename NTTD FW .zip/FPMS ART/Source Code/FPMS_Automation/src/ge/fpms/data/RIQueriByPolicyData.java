package ge.fpms.data;

public class RIQueriByPolicyData {
	private String riStatus;
	private String productCode;
	private String riskType;
	private String riDueDate;
	private String riPolicyNumber;
	private String riSumAssured;

	public String getRIStatus() {
		return riStatus;
	}

	public void setRIStatus(String riStatus) {
		this.riStatus = riStatus;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getRiskType() {
		return riskType;
	}

	public void setRiskType(String riskType) {
		this.riskType = riskType;
	}

	public String getRIDueDate() {
		return riDueDate;
	}

	public void setRIDueDate(String riDueDate) {
		this.riDueDate = riDueDate;
	}

	public String getRIPolicyNumber() {
		return riPolicyNumber;
	}

	public void setRIPolicyNumber(String riPolicyNumber) {
		this.riPolicyNumber = riPolicyNumber;
	}

	public String getRiSumAssured() {
		return riSumAssured;
	}

	public void setRiSumAssured(String riSumAssured) {
		this.riSumAssured = riSumAssured;
	}
}
